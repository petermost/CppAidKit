#include "AidKit_Event.hpp"
#include "AidKit_AsyncEvent.hpp"
#include "AidKit_Property.hpp"
#include "AidKit_Function.hpp"
#include "AidKit_StoredFunction.hpp"

#if defined( AIDKIT_DEBUG )

using namespace AidKit;

namespace AidKit {

namespace {

// Create a couple of incompatible types:

template < int >
	class TDummy {
	};


typedef TDummy< 0 > Result_t;
typedef TDummy< 1 > Dummy1_t;
typedef TDummy< 2 > Dummy2_t;
typedef TDummy< 3 > Dummy3_t;
typedef TDummy< 4 > Dummy4_t;
typedef TDummy< 5 > Dummy5_t;
typedef TDummy< 6 > Dummy6_t;
typedef TDummy< 7 > Dummy7_t;
typedef TDummy< 8 > Dummy8_t;

// Create the events with incompatible types to detect any type errors in the templates:

	class CDummy {
		public:
			TEvent1< Dummy1_t > Event1;
			TEvent2< Dummy1_t, Dummy2_t > Event2;
			TEvent3< Dummy1_t, Dummy2_t, Dummy3_t > Event3;
			TEvent4< Dummy1_t, Dummy2_t, Dummy3_t, Dummy4_t > Event4;

			TAsyncEvent1< Dummy5_t > AsyncEvent1;
			TAsyncEvent2< Dummy5_t, Dummy6_t > AsyncEvent2;
			TAsyncEvent3< Dummy5_t, Dummy6_t, Dummy7_t > AsyncEvent3;
			TAsyncEvent4< Dummy5_t, Dummy6_t, Dummy7_t, Dummy8_t > AsyncEvent4;

			Result_t Method0( void );
			Result_t Method1( Dummy1_t );
			Result_t Method2( Dummy1_t, Dummy2_t );
			Result_t Method3( Dummy1_t, Dummy2_t, Dummy3_t );
			Result_t Method4( Dummy1_t, Dummy2_t, Dummy3_t, Dummy4_t );
	};

static CDummy Dummy;

void CheckAnnounceConst( const CDummy &Dummy )
{
	Dummy1_t Dummy1;
	Dummy2_t Dummy2;
	Dummy3_t Dummy3;
	Dummy4_t Dummy4;
	Dummy5_t Dummy5;
	Dummy6_t Dummy6;
	Dummy7_t Dummy7;
	Dummy8_t Dummy8;

	Dummy.Event1.Announce( Dummy1 );
	Dummy.Event2.Announce( Dummy1, Dummy2 );
	Dummy.Event3.Announce( Dummy1, Dummy2, Dummy3 );
	Dummy.Event4.Announce( Dummy1, Dummy2, Dummy3, Dummy4 );

	Dummy.AsyncEvent1.Announce( Dummy5 );
	Dummy.AsyncEvent2.Announce( Dummy5, Dummy6 );
	Dummy.AsyncEvent3.Announce( Dummy5, Dummy6, Dummy7 );
	Dummy.AsyncEvent4.Announce( Dummy5, Dummy6, Dummy7, Dummy8 );

}


void CheckFunctionTemplates( void )
{
	CDummy Dummy;
	TMethod0< Result_t, CDummy > Method0( &Dummy, &CDummy::Method0 );
	TMethod1< Result_t, CDummy, Dummy1_t > Method1( &Dummy, &CDummy::Method1 );
	TMethod2< Result_t, CDummy, Dummy1_t, Dummy2_t > Method2( &Dummy, &CDummy::Method2 );
	TMethod3< Result_t, CDummy, Dummy1_t, Dummy2_t, Dummy3_t > Method3( &Dummy, &CDummy::Method3 );
	TMethod4< Result_t, CDummy, Dummy1_t, Dummy2_t, Dummy3_t, Dummy4_t > Method4( &Dummy, &CDummy::Method4 );

}


static TProperty< Dummy1_t > Property;

}

}

#endif
