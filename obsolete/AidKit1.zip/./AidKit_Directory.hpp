#ifndef AIDKIT_DIRECTORY_HPP
#define AIDKIT_DIRECTORY_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <string>
#include <io.h>

namespace AidKit {

	class CDirectoryEntry;

	/*---------------------------------------------------------------------------*/
	class CDirectoryHelper {
	/*---------------------------------------------------------------------------*/
		public:
			static string_t AttributesAsString( const CDirectoryEntry &Entry );
			static string_t TimeAsString( time_t Time );
	};



	class CDirectory;

	/*---------------------------------------------------------------------------*/
	class CDirectoryEntry {
	/*---------------------------------------------------------------------------*/
		public:
			CDirectoryEntry( void );
			~CDirectoryEntry( void );

			const char_t *Name( void ) const;
			_fsize_t Size( void ) const;

			bool IsArchived( void ) const;
			bool IsHidden( void ) const;
			bool IsNormal( void ) const;
			bool IsReadOnly( void ) const;
			bool IsDirectory( void ) const;
			bool IsSystem( void ) const;

			time_t CreationTime( void ) const;
			time_t LastAccessTime( void ) const;
			time_t LastWriteTime( void ) const;

		private:
			friend CDirectory;

			_find_data_t my_EntryData;
	};


	
	/*---------------------------------------------------------------------------*/
	class CDirectory {
	/*---------------------------------------------------------------------------*/
		public:
			static string_t CurrentDirectoryAsString( void );

			CDirectory( void );
			~CDirectory( void );

			bool Open( const char_t Path[] );
			bool Close( void );

			bool FirstEntry( CDirectoryEntry *, const char_t WildCard[] );
			bool NextEntry(  CDirectoryEntry * );

			const char_t *PathName( void ) const;

		private:
			CDirectory( const CDirectory & );
			CDirectory &operator = ( const CDirectory & );

			long    my_hDirectory;
			string_t my_OldDirectoryName;
			string_t my_CurrentDirectoryName;
	};
	
	
	
	/*---------------------------------------------------------------------------*/
	class CDirectoryVisitor {
	/*---------------------------------------------------------------------------*/
		public:
			virtual ~CDirectoryVisitor( void );

			virtual void EnterDirectory( const CDirectory &, bool IsLastEntry );
			virtual void LeaveDirectory( const CDirectory & );

			virtual void VisitEntry( const CDirectoryEntry &, bool IsLastEntry );

		protected:
			CDirectoryVisitor( void );
			
	};



	/*---------------------------------------------------------------------------*/
	class CDirectoryGuide {
	/*---------------------------------------------------------------------------*/
		public:
			CDirectoryGuide( void );
			
			bool Tour( const char_t Path[], CDirectoryVisitor *Visitor );

		private:
			bool ParseDirectory( const char_t Path[], bool IsLastEntry );

			CDirectoryVisitor *my_Visitor;
	};
}

#endif
