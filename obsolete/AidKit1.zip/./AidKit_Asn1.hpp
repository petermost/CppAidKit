#ifndef AIDKIT_ASN1_HPP
#define AIDKIT_ASN1_HPP

// #pragma warning( disable : 4786 )
#include <vector>
#include <string>
#include <stdexcept>

#include "AidKit.hpp"
#include "AidKit_Types.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_StlHelper.hpp"
#include "AidKit_Warnings.hpp"

namespace AidKit {

	class CAsn1Stream;
	class CAsn1Item;

	//-----------------------------------------------------------------------------
	class CAsn1Visitor {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CAsn1Visitor( void );

			virtual void EnterStream( const CAsn1Stream * ) = 0;
			virtual void LeaveStream( const CAsn1Stream * ) = 0;
			virtual void VisitItem( const CAsn1Item * ) = 0;
	};


	//-----------------------------------------------------------------------------
	struct SAsn1CodingInfo {
	//-----------------------------------------------------------------------------
		enum ECoding {
			eCodingUndefined,
			eCodingShort,
			eCodingLong,
			eCodingIndefinite
		};

		const char_t *CodingAsString( ECoding eCoding );
		char_t CodingAsCharacter( ECoding eCoding );

		SAsn1CodingInfo( void );

		AidKit::UINT8 nIdentifierOctet;
		ECoding       eTagCoding;
		AidKit::UINT8 nLengthOctet;
		ECoding       eLengthCoding;
	};


	//-----------------------------------------------------------------------------
	struct SAsn1Size {
	//-----------------------------------------------------------------------------
		SAsn1Size( void )
			{ nHead = nBody = nTail = 0; }

		SAsn1Size &operator += ( const SAsn1Size &Other );
		SAsn1Size &operator -= ( const SAsn1Size &Other );

		operator size_t ( void ) const
			{ return ( nHead + nBody + nTail ); }

		size_t nHead;
		size_t nBody;
		size_t nTail;
	};


	//-----------------------------------------------------------------------------
	class CAsn1Error {
	//-----------------------------------------------------------------------------
		public:
	};



	//-----------------------------------------------------------------------------
	class CAsn1LengthError : public CAsn1Error {
	//-----------------------------------------------------------------------------
		public:
			CAsn1LengthError( size_t nInvalidLength )
				{ my_nInvalidLength = nInvalidLength; }

			size_t InvalidLength( void ) const
				{ return ( my_nInvalidLength ); }

		private:
			size_t my_nInvalidLength;
	};


	//-----------------------------------------------------------------------------
	class CAsn1FileError : public CAsn1Error {
	//-----------------------------------------------------------------------------
		public:
			CAsn1FileError( const string_t &Filename )
				{ my_Filename = Filename; }

			const string_t &Filename( void ) const
				{ return ( my_Filename ); }

		private:
			string_t my_Filename;
	};


	//-----------------------------------------------------------------------------
	class CAsn1Header {
	//-----------------------------------------------------------------------------
		public:
			enum EClass {
				eClassUndefined,
				eClassUniversal,
				eClassApplication,
				eClassContext,
				eClassPrivate
			};

			enum EForm {
				eFormUndefined,
				eFormPrimitive,
				eFormConstructed
			};

			static const char_t *ClassAsString( EClass eClass );
			static char_t ClassAsCharacter( EClass eClass );

			static const char_t *FormAsString( EForm eForm );
			static char_t FormAsCharacter( EForm eForm );

			CAsn1Header( EClass eClass = eClassUndefined, EForm eForm = eFormUndefined, AidKit::UINT32 nTag = 0 );
			virtual ~CAsn1Header( void );

			SAsn1Size Read( const void *pMemory, size_t nMemorySize )
				throw ( CAsn1Error );

			SAsn1Size Write( void *pMemory, size_t nMemorySize ) const;

			EClass Class( void ) const
				{ return ( my_eClass ); }

			EForm  Form( void ) const
				{ return ( my_eForm ); }

			AidKit::UINT32 Tag( void ) const
				{ return ( my_nTag ); }

			AidKit::UINT32 Length( void ) const
				{ return ( my_nLength ); }

			size_t HeadLength( void ) const;
				// If the length coding is not withing one byte, then the length of the Head means tag coding and length coding together.

			size_t TailLength( void ) const;
				// If the end of the content is marked, then the length of this marker is returned.

			SAsn1CodingInfo CodingInfo( void ) const
				{ return ( my_CodingInfo ); }

		private:
			EClass my_eClass;
			EForm  my_eForm;
			AidKit::UINT32 my_nTag;
			AidKit::UINT32 my_nLength;
			mutable SAsn1CodingInfo my_CodingInfo;
	};


	class CAsn1Creator;

	//-----------------------------------------------------------------------------
	class CAsn1Item : public CAsn1Header {
	//-----------------------------------------------------------------------------
		public:
			CAsn1Item( EClass eClass = eClassUndefined, UINT32 nTag = 0 );
			virtual ~CAsn1Item( void );

			CAsn1Item &operator = ( const char_t Value[] );
			CAsn1Item &operator = ( int Value );

			virtual SAsn1Size Read( const void *pMemory, size_t nMemorySize, CAsn1Creator * )
				throw ( CAsn1Error, assertion_error );

			virtual SAsn1Size Write( void *pMemory, size_t nMemorySize ) const;

			const AidKit::UINT8 *Content( void ) const
				{ return ( &my_Content[ 0 ] ); }

			AidKit::UINT8 ContentAt( size_t i ) const
				throw ( std::out_of_range )
					{ return ( vector_at( my_Content, i )); }

			virtual AidKit::UINT32 ContentLength( void ) const
				{ return ( my_Content.size() ); }

			CAsn1Stream *Owner( void ) const
				{ return ( my_pOwner ); }

			virtual void AcceptVisitor( CAsn1Visitor *pVisitor ) const;

		protected:
			CAsn1Item( EClass eClass, EForm eForm, UINT32 nTag );

			size_t ReadContent( const void *pMemory, size_t nMemorySize );

			std::vector< AidKit::UINT8 > my_Content;

		private:
			friend class CAsn1Stream;

			CAsn1Stream *my_pOwner;
	};



	//-----------------------------------------------------------------------------
	class CAsn1Stream : public CAsn1Item {
	//-----------------------------------------------------------------------------
		public:
			CAsn1Stream( EClass eClass = eClassUndefined, UINT32 nTag = 0 );
			virtual ~CAsn1Stream( void );

			virtual SAsn1Size Read( const void *pMemory, size_t nMemorySize, CAsn1Creator * )
				throw ( CAsn1Error );

			SAsn1Size ReadItems( const void *pMemory, size_t nMemorySize, CAsn1Creator * )
				throw ( CAsn1Error );

			virtual SAsn1Size Write( void *pMemory, size_t nMemorySize ) const;

			unsigned ItemCount( void ) const
				{ return ( my_Items.size() ); }

			CAsn1Item *ItemAt( size_t i ) const
				throw ( std::out_of_range )
					{ return ( vector_at( my_Items, i )); }

			virtual void AcceptVisitor( CAsn1Visitor *pVisitor ) const;

		protected:
			CAsn1Stream( EClass eClass, EForm eForm, UINT32 nTag );

			void EraseItems( void );

			std::vector< CAsn1Item * > my_Items;

		private:
			CAsn1Stream( const CAsn1Stream & );
			CAsn1Stream &operator = ( const CAsn1Stream & );
	};


	//-----------------------------------------------------------------------------
	class CAsn1Creator {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CAsn1Creator( void );
			virtual CAsn1Item   *MakeNewItem( const CAsn1Header &Header );
			virtual CAsn1Stream *MakeNewStream( const CAsn1Header &Header );
	};


	//-----------------------------------------------------------------------------
	class CAsn1Reader {
	//-----------------------------------------------------------------------------
		public:
			static void FreeAsn1Items( std::vector< CAsn1Item * > *pItems );

			CAsn1Reader( CAsn1Creator *pCreator = NULL );
			~CAsn1Reader( void );

			SAsn1Size ReadStreamFromMemory( const void *pMemory, size_t nMemorySize, CAsn1Stream *pStream )
				throw ( CAsn1Error );

			SAsn1Size ReadItemsFromMemory(  const void *pMemory, size_t nMemorySize, CAsn1Stream *pStream )
				throw ( CAsn1Error );

			SAsn1Size ReadFromMemory( const void *pMemory, size_t nMemorySize, std::vector< CAsn1Item * > *pItems )
				throw ( CAsn1Error );

			typedef SAsn1Size ( CAsn1Reader::*MemoryReadFunction )( const void *, size_t, std::vector< CAsn1Item * > *pItems );

			SAsn1Size ReadFromFile( const string_t &Filename, std::vector< CAsn1Item * > *pItems, MemoryReadFunction = 0 )
				throw ( CAsn1Error );

		private:
			CAsn1Creator my_DefaultCreator;
			CAsn1Creator *my_pCreator;
	};



} // namespace AidKit

#endif
