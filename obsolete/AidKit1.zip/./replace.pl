use strict;
use warnings;

my @InputFileNames = ( "AidKit_Debugger.cpp" );

my $InputFileName = "";
my $OutputFileName = "";

my $InputLines = 0;
my $OutputLines = 0;

if ( opendir( Directory, "." )) {
	@InputFileNames = readdir( Directory );
	closedir( Directory );
} else {
	die( "Kann Verzeichnis nicht lesen! ($!)" );
}


foreach $InputFileName (@InputFileNames) {
	if ( -f $InputFileName && $InputFileName =~ /\.cpp$|\.hpp$/ ) {
		if ( rename( $InputFileName, $InputFileName . "old" )) {
			$OutputFileName = $InputFileName;
			$InputFileName = $InputFileName . "old";
			if ( open( InputFile, $InputFileName ) && open( OutputFile, "> $OutputFileName" )) {
				print "Bearbeite $InputFileName...\n";
				$InputLines = $OutputLines = 0;
				while ( <InputFile> ) {
					$InputLines++;

					s/\bUNIPRINTF/print_f/g;
					s/\bUNISCANF/scan_f/g;
					s/\bUNISSCANF/s_scan_f/g;
					s/\bUNISPRINTF/s_print_f/g;
					s/\bUNIFOPEN/f_open/g;
					s/\bUNIFPRINTF/f_print_f/g;
					s/\bUNIVFPRINTF/vf_print_f/g;
					s/\bUNISNPRINTF/sn_print_f/g;
					s/\bUNIVSNPRINTF/vsn_print_f/g;

					s/\bUNISTRLEN/str_len/g;
					s/\bUNISTRCPY/str_cpy/g;
					s/\bUNISTRNCPY/str_n_cpy/g;
					s/\bUNISTRCMP/str_cmp/g;
					s/\b_UNISTRICMP/_str_i_cmp/g;
					s/\bUNISTRCHR/str_chr/g;
					s/\bUNISTRRCHR/str_r_chr/g;
					s/\bUNISTRNCAT/str_n_cat/g;

					s/\b__UNIARGV/__arg_v/g;
					s/\b_UNIMAKEPATH/make_path/g;
					s/\b_UNISPLITPATH/split_path/g;
					s/\b_UNIITOA/_i_to_a/g;
					s/\bUNIATOI/a_to_i/g;
					s/\b_UNILTOA/_l_to_a/g;

					s/\bUNISTRFTIME/str_f_time/g;
					s/\b_UNIGETCWD/_get_cwd/g;
					s/\b_UNICHDIR/_ch_dir/g;

					s/\b_UNIFINDDATA_T/_find_data_t/g;
					s/\b_UNIFINDFIRST/_find_first/g;
					s/\b_UNIFINDNEXT/_find_next/g;

					s/\bUNITOUPPER/to_upper/g;
					s/\bUNIISCNTRL/is_cntrl/g;

					s/\bUNIIFSTREAM/if_stream/g;
					s/\bUNIOFSTREAM/of_stream/g;

					print OutputFile;
					$OutputLines++;
				}
				if ( $InputLines != $OutputLines ) {
					die( "Ungleiche Anzahl von Eingabe- und Ausgabezeilen!" );
				}
			} else {
				warn( "Konnte Datei nicht oeffnen! ($!)" );
			}
		} else {
			die( "Kann $InputFileName nicht umbenennen! ($!)" );
		}
	} else {
		print "Skip: $InputFileName...\n";
	}
}
