#ifndef AIDKIT_THREAD_LOCK_HPP
#define AIDKIT_THREAD_LOCK_HPP

#include "AidKit.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CThreadGuardBasics {
	//-----------------------------------------------------------------------------
		public:
			typedef unsigned long thread_t;

			virtual ~CThreadGuardBasics( void );

		protected:
			virtual thread_t DoLock( void ) = 0;
			virtual void DoUnlock( void ) = 0;
	};

}

#if defined( AIDKIT_WINDOWS )
	#include "Windows/AidKit_Windows_ThreadLock.hpp"
	namespace AidKit {
		typedef CWindowsThreadGuard CNativeThreadGuard;
	}
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_ThreadLock.hpp"
	namespace AidKit {
		typedef CUnixThreadGuard CNativeThreadGuard;
	}
#endif



namespace AidKit {

	//-----------------------------------------------------------------------------
	class CThreadGuard : public CNativeThreadGuard {
	//-----------------------------------------------------------------------------
		public:
			CThreadGuard( void );

			void Lock( void );
			void Unlock( void );

		private:
			thread_t my_hOwner;
	};


	template < typename CGuard >
		//-----------------------------------------------------------------------------
		class TThreadLock {
		//-----------------------------------------------------------------------------
			public:
				TThreadLock( CGuard *pGuard );
				~TThreadLock( void );

				void Lock( void );
				void Unlock( void );

			private:
				TThreadLock( const TThreadLock & );
				TThreadLock &operator = ( const TThreadLock & );

				CGuard *my_pGuard;
				bool my_IsLocked;
		};

	typedef TThreadLock< CThreadGuard > CThreadLock;





	template < typename CResource, typename CGuard = CThreadGuard >
		//-----------------------------------------------------------------------------
		class TThreadResourceGuard {
		//-----------------------------------------------------------------------------
			public:
				TThreadResourceGuard( void )
					{ }

				CResource *Lock( void )
					{ my_Guard.Lock(); return ( &my_Resource ); }

				void Unlock( CResource **ppResource )
					{ *ppResource = NULL; my_Guard.Unlock(); }

				const CResource *Lock( void ) const
					{ my_Guard.Lock(); return ( &my_Resource ); }

				void Unlock( const CResource **ppResource ) const
					{ *ppResource = NULL; my_Guard.Unlock(); }
					
			private:
				TThreadResourceGuard( const TThreadResourceGuard & );
				TThreadResourceGuard &operator = ( const TThreadResourceGuard & );

				mutable CGuard my_Guard;
				CResource my_Resource;
		};



	template < typename CResource >
		//-----------------------------------------------------------------------------
		class TThreadResourceLock {
		//-----------------------------------------------------------------------------
			public:
				TThreadResourceLock( TThreadResourceGuard< CResource > *pGuard )
					{ my_pGuard = pGuard; my_pResource = NULL; Lock(); }

				TThreadResourceLock( const TThreadResourceGuard< CResource > *pGuard )
					{ my_pGuard = const_cast< TThreadResourceGuard< CResource > * >( pGuard ); my_pResource = NULL; Lock(); }

				~TThreadResourceLock( void )
					{ Unlock(); }


				void Lock( void )
				{
					if ( my_pResource == NULL )
						my_pResource = my_pGuard->Lock();
				}

				void Unlock( void )
				{
					if ( my_pResource != NULL )
						my_pGuard->Unlock( &my_pResource );
				}



				CResource *operator -> ( void )
					{ return ( my_pResource ); }

				const CResource *operator -> ( void ) const
					{ return ( my_pResource ); }



				CResource *operator & ( void )
					{ return ( my_pResource ); }

				const CResource *operator & ( void ) const
					{ return ( my_pResource ); }



				CResource &operator * ( void )
					{ return ( *my_pResource ); }

				const CResource &operator * ( void ) const
					{ return ( *my_pResource ); }

			private:
				// Allocating on the heap is not allowed:
				static void *operator new( size_t );
				static void *operator new[]( size_t );

				static void operator delete( void * );
				static void operator delete[]( void * );

				// Copying is also not allowed:
				TThreadResourceLock( const TThreadResourceLock & );
				TThreadResourceLock &operator = ( const TThreadResourceLock & );

				TThreadResourceGuard< CResource > *my_pGuard;
				CResource *my_pResource;
		};



}

#include "AidKit_ThreadLockImp.cpp"

#endif
