#ifndef AIDKIT_THREAD_LOCAL_STORAGE_HPP
#define AIDKIT_THREAD_LOCAL_STORAGE_HPP

#include "AidKit.hpp"
#include "AidKit_ThreadLock.hpp"
#include <afxmt.h>
#include <map>

namespace AidKit {

	template < typename CValue >
		//-----------------------------------------------------------------------------
		class TThreadLocalStorage {
		//-----------------------------------------------------------------------------
			public:
				TThreadLocalStorage( void );
				~TThreadLocalStorage( void );

				const CValue &Store( const CValue &Value );
				bool Erase( void );
				const CValue &Retrieve( void ) const;

				const CValue &operator = ( const CValue & );
				operator const CValue &( void ) const;

			private:
				TThreadLocalStorage( const TThreadLocalStorage & );
				const TThreadLocalStorage &operator = ( const TThreadLocalStorage & );

				typedef std::map< DWORD, CValue > CStorageMap;
				mutable TThreadGuard< CStorageMap > my_Storage;
		};

	template < typename CValue >
		inline const CValue &TThreadLocalStorage< CValue >::operator = ( const CValue &Value )
			{ return ( Store( Value )); }

	template < typename CValue >
		inline TThreadLocalStorage< CValue >::operator const CValue &( void ) const
			{ return ( Retrieve() ); }
}

#include "AidKit_ThreadLocalStorage.cpp"

#endif
