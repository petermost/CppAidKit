// AidKit_ToolTip.cpp : implementation file
//

#include "AidKit_ToolTip.hpp"
#include "AidKit_Dialog.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CToolTipGadget
//###
//#############################################################################
//#############################################################################
//#############################################################################

BEGIN_MESSAGE_MAP(CToolTipGadget, CToolTipCtrl)
	//{{AFX_MSG_MAP(CToolTipGadget)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


//=============================================================================
CToolTipGadget::CToolTipGadget()
	: my_RelayEventHandler( this, &CToolTipGadget::RelayEvent )
//=============================================================================
{
}



//=============================================================================
CToolTipGadget::~CToolTipGadget()
//=============================================================================
{
	
}




//=============================================================================
int CToolTipGadget::OnCreate(LPCREATESTRUCT lpCreateStruct) 
//=============================================================================
{
	if ( CToolTipCtrl::OnCreate(lpCreateStruct) == -1 )
		return ( -1 );
	
	try {
		CDialogGadget *pDialog = dynamic_cast< CDialogGadget * >( GetParent() );
		if ( pDialog != NULL ) {
			pDialog->PreTranslateMessageEvt += my_RelayEventHandler;
		}
	}
	catch ( exception & ) {
		return ( -1 );
	}
	return ( 0 );
}



//=============================================================================
void CToolTipGadget::OnDestroy() 
//=============================================================================
{
	try {
		CDialogGadget *pDialog = dynamic_cast< CDialogGadget * >( GetParent() );
		if ( pDialog != NULL ) {
			pDialog->PreTranslateMessageEvt -= my_RelayEventHandler;
		}
	}
	catch ( exception & ) {
	}
	CToolTipCtrl::OnDestroy();
}


} // namespace AidKit
