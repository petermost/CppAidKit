#ifndef AIDKIT_ASYNC_EVENT_HPP
#define AIDKIT_ASYNC_EVENT_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
#include "AidKit_Function.hpp"

namespace AidKit {

//#############################################################################
//
// TAsyncEvent
//
//#############################################################################

	//-----------------------------------------------------------------------------
	class TAsyncEvent {
	//-----------------------------------------------------------------------------
		public:
			typedef TCall1< void, const TAsyncEvent * > Dispatcher;

			static Dispatcher *ExchangeDispatcher( Dispatcher *pDispatcher );

			virtual void Relay( void ) const = 0;

		protected:
			TAsyncEvent( void );
			virtual ~TAsyncEvent( void );

			void Dispatch( const TAsyncEvent * ) const;

		private:
			static Dispatcher *our_pDispatcher;
	};

	//-----------------------------------------------------------------------------
	class TAsyncEvent0 : public TEvent0, public TAsyncEvent {
	//-----------------------------------------------------------------------------
			public:
				TAsyncEvent0( void );

				virtual void Announce( void ) const;

			protected:
				virtual void Relay( void ) const;

			private:
				mutable unsigned my_nAnnouncements;
	};


template < typename P1 >
	//-----------------------------------------------------------------------------
	class TAsyncEvent1 : public TEvent1< P1 >, public TAsyncEvent {
	//-----------------------------------------------------------------------------
			public:
				virtual void Announce( P1 ) const;

			protected:
				virtual void Relay( void ) const;

			private:
				struct SParameters {
					P1 my_Parameter1;
				};
				typedef std::list< SParameters > CParameters;
				mutable CParameters my_Parameters;
	};


template < typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TAsyncEvent2 : public TEvent2< P1, P2 >, public TAsyncEvent {
	//-----------------------------------------------------------------------------
			public:
				virtual void Announce( P1, P2 ) const;

			protected:
				virtual void Relay( void ) const;

			private:
				struct SParameters {
					P1 my_Parameter1;
					P2 my_Parameter2;
				};
				typedef std::list< SParameters > CParameters;
				mutable CParameters my_Parameters;
	};


template < typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TAsyncEvent3 : public TEvent3< P1, P2, P3 >, public TAsyncEvent {
	//-----------------------------------------------------------------------------
			public:
				virtual void Announce( P1, P2, P3 ) const;

			protected:
				virtual void Relay( void ) const;

			private:
				struct SParameters {
					P1 my_Parameter1;
					P2 my_Parameter2;
					P3 my_Parameter3;
				};
				typedef std::list< SParameters > CParameters;
				mutable CParameters my_Parameters;
	};


template < typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TAsyncEvent4 : public TEvent4< P1, P2, P3, P4 >, public TAsyncEvent {
	//-----------------------------------------------------------------------------
			public:
				virtual void Announce( P1, P2, P3, P4 ) const;

			protected:
				virtual void Relay( void ) const;

			private:
				struct SParameters {
					P1 my_Parameter1;
					P2 my_Parameter2;
					P3 my_Parameter3;
					P4 my_Parameter4;
				};
				typedef std::list< SParameters > CParameters;
				mutable CParameters my_Parameters;
	};

} // namespace AidKit

#include "AidKit_AsyncEventImp.cpp"

#endif
