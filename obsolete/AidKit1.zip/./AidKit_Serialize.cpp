#include "AidKit_Serialize.hpp"
#include "AidKit_StlHelper.hpp"
#include "AidKit_String.hpp"
#include "AidKit_Debug.hpp"

using namespace std;

namespace AidKit {


static const char SEPERATOR( TEXT( '-' ));


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSerializer
//###
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
CSerializer::CSerializer( void )
//=============================================================================
{
}



//=============================================================================
CSerializer::~CSerializer( void )
//=============================================================================
{
}




//=============================================================================
bool CSerializer::Save( const CSerializable *pRoot )
//=============================================================================
{
	my_SerializedObjects.clear();
	string_clear( &my_Section );

	return ( pRoot->Serialize( this ));
}

//=============================================================================
string_t CSerializer::DoGenerateObjectID( const CSerializable *pObject )
//=============================================================================
{
	COMPILER_ASSERT( sizeof( pObject ) == sizeof( unsigned long ));
	AIDKIT_ASSERT( pObject != NULL );

	// Generate a object-id similiar to 'NAME-0x12345678':

	string_t ObjectID = pObject->TypeName() + SEPERATOR + string_printf( TEXT( "%lX" ),
		reinterpret_cast< unsigned long >( dynamic_cast< const void * >( pObject )));

	return ( ObjectID );
}



//=============================================================================
bool CSerializer::WriteObject( const string_t &Name, const CSerializable *pObject )
//=============================================================================
{
	bool IsSerialized = true;
	string_t ObjectID;

	if ( pObject != NULL )
		ObjectID = DoGenerateObjectID( pObject );

	if ( DoWriteString( my_Section, Name, ObjectID )) {
		if ( pObject != NULL && !map_find( my_SerializedObjects, ObjectID, &pObject )) {
			map_insert( &my_SerializedObjects, ObjectID, pObject );
			string_t OldSection = my_Section;
			my_Section = ObjectID;
			IsSerialized = pObject->Serialize( this );
			my_Section = OldSection;
		}
	}
	return ( IsSerialized );
}


//=============================================================================
bool CSerializer::WriteBool( const string_t &Name, bool Value )
//=============================================================================
{
	return ( DoWriteBool( my_Section, Name, Value ));
}



//=============================================================================
bool CSerializer::WriteInteger( const string_t &Name, int Value )
//=============================================================================
{
	return ( DoWriteInteger( my_Section, Name, Value ));
}

//=============================================================================
bool CSerializer::WriteULong( const string_t &Name, unsigned long Value )
//=============================================================================
{
	return ( DoWriteULong( my_Section, Name, Value ));
}



//=============================================================================
bool CSerializer::WriteString( const string_t &Name, const string_t &Value )
//=============================================================================
{
	return ( DoWriteString( my_Section, Name, Value ));
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDeserializer
//###
//#############################################################################
//#############################################################################
//#############################################################################

TStatic< std::map< string_t, CDeserializer::DeserializableCreator_t * > > CDeserializer::our_CreatorMap;

//=============================================================================
bool CDeserializer::RegisterCreator( const string_t &TypeName, DeserializableCreator_t *pCreator )
//=============================================================================
{
	return ( map_insert( &our_CreatorMap, TypeName, pCreator ));
}



//=============================================================================
CDeserializable *CDeserializer::CreateObject( const string_t &TypeName )
//=============================================================================
{
	CDeserializable *pObject = NULL;
	DeserializableCreator_t *pCreator;

	if ( map_find( our_CreatorMap.Reference(), TypeName, &pCreator )) {
		pObject = ( pCreator )();
	}
	return ( pObject );
}



//=============================================================================
CDeserializer::CDeserializer( void )
//=============================================================================
{
}


//=============================================================================
CDeserializer::~CDeserializer( void )
//=============================================================================
{
}



//=============================================================================
bool CDeserializer::Load( CDeserializable *pRoot )
//=============================================================================
{
	my_DeserializedObjects.clear();
	string_clear( &my_Section );

	return ( pRoot->Deserialize( this ));
}



//=============================================================================
CDeserializable *CDeserializer::DoCreateObject( const string_t &ObjectID )
//=============================================================================
{
	string_t::size_type SeperatorPos;
	CDeserializable *pObject = NULL;

	if (( SeperatorPos = ObjectID.find( SEPERATOR )) != string_t::npos ) {
		string_t TypeName = ObjectID.substr( 0, SeperatorPos );
		string_t ID = ObjectID.substr( SeperatorPos + 1 );
		pObject = CreateObject( TypeName );
	}
	return ( pObject );
}



//=============================================================================
bool CDeserializer::ReadObject( const string_t &Name, CDeserializable *pObject )
//=============================================================================
{
	bool IsDeserialized = true;
	string_t ObjectID;
	CDeserializable *pOtherObject;

	if ( DoReadString( my_Section, Name, &ObjectID )) {
		if ( !map_find( my_DeserializedObjects, ObjectID, &pOtherObject )) {
			map_insert( &my_DeserializedObjects, ObjectID, pObject );
			string_t OldSection = my_Section;
			my_Section = ObjectID;
			IsDeserialized = pObject->Deserialize( this );
			my_Section = OldSection;
		} else {
			// We don't try to catch the bad_cast exception!
			pObject->Assign( *pOtherObject );
		}
	} else {
		// This would be the part which would deserialize an object even though
		// it wasn't possible to read an object-id. If we would try to allow this,
		// then we have to create an object-id (CSerializer::DoGenerateObjectID)
		// and store it in the deserialized objects.
		// All in all it seem's like to much work for the very rare case that
		// an object relies on it's Deserialize method beeing called.
	}
	return ( IsDeserialized );
}


//=============================================================================
CDeserializable *CDeserializer::ReadObject( const string_t &Name )
//=============================================================================
{
	bool IsDeserialized = true;
	string_t ObjectID;
	CDeserializable *pObject = NULL;

	if ( DoReadString( my_Section, Name, &ObjectID )) {
		if ( !map_find( my_DeserializedObjects, ObjectID, &pObject )) {
			if (( pObject = DoCreateObject( ObjectID )) != NULL ) {
				map_insert( &my_DeserializedObjects, ObjectID, pObject );
				string_t OldSection = my_Section;
				my_Section = ObjectID;
				IsDeserialized = pObject->Deserialize( this );
				my_Section = OldSection;
			}
		}
	}
	return (( IsDeserialized ) ? pObject : NULL );
}



//=============================================================================
bool CDeserializer::ReadBool( const string_t &Name, bool *pValue )
//=============================================================================
{
	return ( DoReadBool( my_Section, Name, pValue ));
}



//=============================================================================
bool CDeserializer::ReadBool( const string_t &Name, bool DefaultValue )
//=============================================================================
{
	bool Value;

	if ( !ReadBool( Name, &Value ))
		Value = DefaultValue;

	return ( Value );
}



//=============================================================================
bool CDeserializer::ReadInteger( const string_t &Name, int *pValue )
//=============================================================================
{
	return ( DoReadInteger( my_Section, Name, pValue ));
}



//=============================================================================
int CDeserializer::ReadInteger( const string_t &Name, int DefaultValue )
//=============================================================================
{
	int Value;

	if ( !ReadInteger( Name, &Value ))
		Value = DefaultValue;

	return ( Value );
}


//=============================================================================
bool CDeserializer::ReadULong( const string_t &Name, unsigned long *pValue )
//=============================================================================
{
	return ( DoReadULong( my_Section, Name, pValue ));
}



//=============================================================================
unsigned long CDeserializer::ReadULong( const string_t &Name, unsigned long DefaultValue )
//=============================================================================
{
	unsigned long Value;

	if ( !ReadULong( Name, &Value ))
		Value = DefaultValue;

	return ( Value );
}



//=============================================================================
bool CDeserializer::ReadString( const string_t &Name, string_t *pValue )
//=============================================================================
{
	return ( DoReadString( my_Section, Name, pValue ));
}



//=============================================================================
string_t CDeserializer::ReadString( const string_t &Name, const string_t &DefaultValue )
//=============================================================================
{
	string_t Value;

	if ( !ReadString( Name, &Value ))
		Value = DefaultValue;

	return ( Value );
}

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDeserializable
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CDeserializable::CDeserializable( void )
//=============================================================================
{
}


//=============================================================================
CDeserializable::~CDeserializable( void )
//=============================================================================
{
}


//=============================================================================
bool CDeserializable::Deserialize( CDeserializer * )
//=============================================================================
{
	return ( true );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSerializable
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CSerializable::CSerializable( void )
//=============================================================================
{
}


//=============================================================================
CSerializable::~CSerializable( void )
//=============================================================================
{
}




//=============================================================================
bool CSerializable::Serialize( CSerializer * ) const
//=============================================================================
{
	return ( true );
}



//=============================================================================
string_t CSerializable::TypeName( void ) const
//=============================================================================
{
	return ( EMPTY_STRING );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CPersistentable
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CPersistentable::CPersistentable( void )
//=============================================================================
{
}


//=============================================================================
CPersistentable::~CPersistentable( void )
//=============================================================================
{
}




} // namespace AidKit



/* This approach gets you an object pointer before it has been completely
initialized:

typedef std::list< std::pair< string_t, const CSerializable * > > CObjectList;

//=============================================================================
bool CSerializer::Save( const char_t Section[], const CSerializable *pRoot )
//=============================================================================
{
	my_Objects.clear();

	pRoot->Serialize( Section, this );

	CObjectList::iterator itObject;
	for ( itObject = my_Objects.begin(); itObject != my_Objects.end(); ++itObject ) {
		itObject->second->Serialize( itObject->first.c_str(), this );
	}
	return ( true );
}



//=============================================================================
bool CSerializer::WriteObject( const char_t Section[], const char_t Name[], const CSerializable *pObject )
//=============================================================================
{
	CObjectList::iterator itObject;
	for ( itObject = my_Objects.begin(); itObject != my_Objects.end(); ++itObject ) {
		if ( itObject->second == pObject )
			return ( true );
	}
	string_t ObjectID;
	DoWriteObject( Section, Name, &ObjectID, pObject );
	my_Objects.push_back( CObjectList::value_type( ObjectID, pObject ));

	return ( true );
}




typedef std::list< std::pair< string_t, CSerializable * > > CObjectList;

//=============================================================================
bool CDeserializer::Load( const char_t Section[], CSerializable *pRoot )
//=============================================================================
{
	my_Objects.clear();

	pRoot->Deserialize( Section, this );

	CObjectList::iterator itObject;
	for ( itObject = my_Objects.begin(); itObject != my_Objects.end(); ++itObject ) {
		itObject->second->Deserialize( itObject->first.c_str(), this );
	}
	return ( true );
}

//=============================================================================
CSerializable *CDeserializer::ReadObject( const char_t Section[], const char_t Name[], CSerializable *pObject )
//=============================================================================
{
	CObjectList::iterator itObject;
	for ( itObject = my_Objects.begin(); itObject != my_Objects.end(); ++itObject ) {
		if ( itObject->second == pObject )
			return ( pObject );
	}
	string_t ObjectID;
	if (( pObject = DoReadObject( Section, Name, &ObjectID, pObject )) != NULL )
		my_Objects.push_back( CObjectList::value_type( ObjectID, pObject ));

	return ( pObject );
}

*/
