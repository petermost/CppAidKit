#ifndef AIDKIT_WIN_ERROR_IMP_CPP
#define AIDKIT_WIN_ERROR_IMP_CPP

#include "AidKit_WinError.hpp"

namespace AidKit {

template < typename TError >
	//=============================================================================
	DWORD check_win_error( DWORD nError )
		throw ( TError )
	//=============================================================================
	{
		if ( nError != NO_ERROR ) {
			throw TError( nError );
		}
		return ( nError );
	}


template < typename TError >
	//=============================================================================
	BOOL check_win_api( BOOL Success )
		throw ( TError )
	//=============================================================================
	{
		if ( !Success ) {
			throw TError( ::GetLastError() );
		}
		return ( Success );
	}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TWinError
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < typename TName >
	//=============================================================================
	TWinError< TName > TWinError< TName >::LastError( void )
		throw()
	//=============================================================================
	{
		return ( TWinError( ::GetLastError() ));
	}


template < typename TName >
	//=============================================================================
	TWinError< TName >::TWinError( DWORD LastError )
		throw()
			: CWinError( LastError )
	//=============================================================================
	{
	}


template < typename TName >
	//=============================================================================
	TWinError< TName >::TWinError( const TWinError &OtherError )
		throw()
			: CWinError( OtherError )
	//=============================================================================
	{
	}

template < typename TName >
	//=============================================================================
	TWinError< TName > &TWinError< TName >::operator = ( const TWinError &OtherError )
		throw()
	//=============================================================================
	{
		CWinError::operator = ( OtherError );

		return ( *this );
	}

} // namespace AidKit

#endif
