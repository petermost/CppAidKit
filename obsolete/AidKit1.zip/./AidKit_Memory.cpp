#include "AidKit_Memory.hpp"
#include "AidKit_Warnings.hpp"

#include <stdio.h>

using namespace std;

//=============================================================================
void *operator new( size_t nObjectSize, void *pMemory, size_t nMemorySize )
	throw ( bad_alloc )
//=============================================================================
{
	if ( nObjectSize <= nMemorySize )
		return ( pMemory );
	else
		throw bad_alloc();
}


//=============================================================================
void operator delete( void * /* pObject */, void * /* pMemory */, size_t /* MemorySize */ )
	throw()
//=============================================================================
{
}

namespace AidKit {

#ifdef AIDKIT_UNIX
//=============================================================================
size_t memory_vprintf( memory< char_t > *output, const char_t format[], va_list arguments )
//=============================================================================
{
	int required_size;
	size_t available_size;

	do {
		available_size = output->size();
		required_size = vsn_print_f( *output, available_size, format, arguments );
		if ( required_size >= available_size || required_size == -1 ) {
			output->resize( available_size * 2 );
		}
	} while ( required_size >= available_size || required_size == -1 );

	return ( required_size );
}
#else
	#error "Check documentation for the results from snprintf!"
#endif


//=============================================================================
size_t memory_read( const void **ppMemory, size_t *pMemorySize, void *pValue, size_t nSize )
	throw ( std::length_error )
//=============================================================================
{
	if ( *pMemorySize > nSize )
		throw ( std::length_error( "memory_read" ));

	memcpy( pValue, *ppMemory, nSize );
	// static_cast< const char * >( *ppMemory ) += nSize;
	*ppMemory = static_cast< const char * >( *ppMemory ) + nSize;
	*pMemorySize -= nSize;

	return ( nSize );
}



//=============================================================================
size_t memory_write( void **ppMemory, size_t *pMemorySize, const void *pValue, size_t nSize )
	throw ( std::length_error )
//=============================================================================
{
	if ( *pMemorySize < nSize )
		throw ( std::length_error( "memory_write" ));

	memcpy( *ppMemory, pValue, nSize );
	// static_cast< char * >( *ppMemory ) += nSize;
	*ppMemory = static_cast< char * >( *ppMemory ) + nSize;
	*pMemorySize -= nSize;

	return ( nSize );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CMemory
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CMemory::CMemory( size_t nSize )
	throw ( bad_alloc )
//=============================================================================
{
	my_pAddress = NULL;
	my_nSize = 0;

	void *pAddress;

	if (( pAddress = malloc( nSize )) != NULL ) {
		my_pAddress = pAddress;
		my_nSize = nSize;
	} else
		throw bad_alloc();
}



//=============================================================================
CMemory::~CMemory( void )
	throw()
//=============================================================================
{
	free( my_pAddress );
}



//=============================================================================
void CMemory::Resize( size_t nNewSize )
	throw ( bad_alloc )
//=============================================================================
{
	void *pNewAddress;

	if ( nNewSize > 0 ) { // avoid freeing the memory.
		if (( pNewAddress = realloc( my_pAddress, nNewSize )) != NULL ) {
			my_pAddress = pNewAddress;
			my_nSize = nNewSize;
		} else
			throw bad_alloc();
	} else
		my_nSize = nNewSize;
}



} // namespace AidKit


/*
*/










/*

// #define MODULE_TEST

#ifdef MODULE_TEST
void main()
{
	using namespace AidKit;

	#pragma pack( 1 )

	struct TDaten {
		char c;
		int  i;
		long l;
	};
	char c;
	int i;
	long l;

	TDaten Daten = { 'c', 0xAA, 0xBBBB };
	const void *pDaten = &Daten;

	ReadMemory( &pDaten, &c );
	ReadMemory( &pDaten, &i );
	ReadMemory( &pDaten, &l );
}
#endif

static void MemoryTest( void )
// Wird nicht aufgerufen, sondern instanziert nur die Templates
// um Kompilerfehler zu entdecken!
{
	using namespace AidKit;

 	#pragma pack( 1 )

	struct TMemory {
		char c;
		int  i;
	};
	const TMemory RMemory = { 'c', 0xCC };
	TMemory WMemory = { 0xBF, 0xBF };

	char cType;
	int iType;

	const void *pConstMemory = 0;
	void *pMemory = 0;

	ReadMemory( &cType, &RMemory );
	ReadMemory( &RMemory, &cType, &pConstMemory );
	ReadMemory( pConstMemory, &iType, &pConstMemory );

	WriteMemory( cType, &WMemory, &pMemory );
	WriteMemory( iType, pMemory, &pMemory );
}
*/
