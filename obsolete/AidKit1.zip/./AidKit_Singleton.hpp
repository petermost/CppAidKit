#ifndef AIDKIT_SINGLETON_HPP
#define AIDKIT_SINGLETON_HPP

#include "AidKit.hpp"

namespace AidKit {

	template < typename CClass >
		//-----------------------------------------------------------------------------
		class TClassicSingleton {
		//-----------------------------------------------------------------------------
			public:
				static CClass *Instance( void );

			private:
				static CClass *our_pInstance;
	};


	template < typename CClass >
		//-----------------------------------------------------------------------------
		class TSingleton {
		//-----------------------------------------------------------------------------
			public:
				static CClass *Instance( void );

			protected:
				TSingleton( void );
				~TSingleton( void );

			private:
				static CClass *our_pInstance;
	};

}

#include "AidKit_SingletonImp.cpp"

#endif
