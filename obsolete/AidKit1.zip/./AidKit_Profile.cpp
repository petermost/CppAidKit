#include "AidKit_Profile.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_WinError.hpp"
#include "AidKit_StdLibrary.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

static const char_t kStructureBegin[] = TEXT( "{ " );
static const char_t kStructureEnd[]   = TEXT( " }" );

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### Helper functions
//###
//#############################################################################
//#############################################################################
//#############################################################################

// !!!
// !!! All writing profile functions return an error code with GetLastError
// !!! but not the reading profile functions.
// !!!

//============================================================================= 
static inline BOOL WriteProfileString( const char_t Key[], const char_t ValueName[],
	const char_t Value[], const char_t FileName[] )
//============================================================================= 
{
	return ( ::WritePrivateProfileString( Key, ValueName, Value, FileName ));
}



//============================================================================= 
static BOOL ReadProfileString( const char_t Key[], const char_t ValueName[],
	char_t Value[], size_t ValueSize, const char_t FileName[] )
//============================================================================= 
{
	DWORD Length;
	char_t  DefaultValue[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };

	Length = ::GetPrivateProfileString( Key, ValueName, DefaultValue, Value, ValueSize - 1, FileName );
	return ( Length != ValueSize - 1 && str_cmp( Value, DefaultValue ) != 0 );
}



//============================================================================= 
static inline BOOL WriteProfileBinary( const char_t Key[], const char_t ValueName[],
	const void *Value, size_t ValueSize, const char_t FileName[] )
//============================================================================= 
{
	return ( ::WritePrivateProfileStruct( Key, ValueName, const_cast< void * >( Value ), ValueSize, FileName ));
}



//============================================================================= 
static inline BOOL ReadProfileBinary( const char_t Key[], const char_t ValueName[],
	void *Value, size_t ValueSize, const char_t FileName[] )
//============================================================================= 
{
	return ( ::GetPrivateProfileStruct( Key, ValueName, Value, ValueSize, FileName ));
}


//============================================================================= 
static BOOL WriteProfileStrings( const char_t Key[], const char_t Values[],
	const char_t FileName[] )
//============================================================================= 
{

	return ( ::WritePrivateProfileSection( Key, Values, FileName));
}



//============================================================================= 
static BOOL ReadProfileStrings( const char_t Key[], char_t Values[], size_t ValuesSize,
	const char_t FileName[] )
//============================================================================= 
{
	DWORD Length;

	Length = ::GetPrivateProfileSection( Key, Values, ValuesSize, FileName );
	return ( Length != ValuesSize - 2 );
}


//=============================================================================
void SplitSectionNames( const char_t SectionNames[], CStringArray *pSectionNames )
//=============================================================================
{
	const char_t *pSectionEnd;
	const char_t *pSectionBegin = SectionNames;
	while (( pSectionEnd = str_chr( pSectionBegin, TEXT( '\0' ))) > pSectionBegin + 1 ) {
		CString SectionName( pSectionBegin, pSectionEnd - pSectionBegin );
		if ( !SectionName.IsEmpty() )
			pSectionNames->Add( SectionName );

		pSectionBegin = pSectionEnd + 1;
	}
}

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CProfile
//###
//#############################################################################
//#############################################################################
//#############################################################################


static const size_t kMaxValueSize = 32767;

//============================================================================= 
CProfile::CProfile( void )
//============================================================================= 
{
}



//============================================================================= 
CProfile::~CProfile( void )
//============================================================================= 
{
	Close();
}



//============================================================================= 
bool CProfile::Open( const char_t FileName[] )
//============================================================================= 
{
	my_FileName = FileName;

	// SetLastError( ERROR_OPEN_FAILED );

	return ( true );
}



//============================================================================= 
bool CProfile::Close( void )
//============================================================================= 
{
	// SetLastError( ERROR_CAN_NOT_COMPLETE );

	return ( true );
}



//============================================================================= 
bool CProfile::WriteInteger( const char_t Key[], const char_t ValueName[], int Value )
//============================================================================= 
{
	char_t szValue[ kMaxValueSize ];

	_i_to_a( Value, szValue, 10 );
	return ( WriteProfileString( Key, ValueName, szValue, my_FileName.c_str() ) == TRUE );
}





//============================================================================= 
bool CProfile::ReadInteger( const char_t Key[], const char_t ValueName[], int *Value ) const
//============================================================================= 
{
	char_t szValue[ kMaxValueSize ];
	bool Success;

	Success = ( ReadProfileString( Key, ValueName, szValue, countof( szValue ), my_FileName.c_str() ) == TRUE );
	if ( Success )
		*Value = a_to_i( szValue );
	else
		SetLastError( ERROR_CANTREAD );

	return ( Success );
}



//============================================================================= 
bool CProfile::WriteString( const char_t Key[], const char_t ValueName[], const string_t &Value )
//============================================================================= 
{
	return ( WriteProfileString( Key, ValueName, Value.c_str(), my_FileName.c_str() ) == TRUE );
}



//============================================================================= 
bool CProfile::ReadString( const char_t Key[], const char_t ValueName[], string_t *Value ) const
//============================================================================= 
{
	char_t szValue[ kMaxValueSize ];
	bool Success;

	Success = ( ReadProfileString( Key, ValueName, szValue, countof( szValue ), my_FileName.c_str() ) == TRUE );
	if ( Success )
		*Value = szValue;
	else
		SetLastError( ERROR_CANTREAD );

	return ( Success );
}



//============================================================================= 
bool CProfile::WriteBinary( const char_t Key[], const char_t ValueName[],
	const void *Value, size_t ValueSize )
//============================================================================= 
{
	return ( WriteProfileBinary( Key, ValueName, Value, ValueSize, my_FileName.c_str() ) == TRUE );
}



//============================================================================= 
bool CProfile::ReadBinary( const char_t Key[], const char_t ValueName[],
	void *Value, size_t ValueSize ) const
//============================================================================= 
{
	bool Success;

	Success = ( ReadProfileBinary( Key, ValueName, Value, ValueSize, my_FileName.c_str() ) == TRUE );
	if ( !Success )
		SetLastError( ERROR_CANTREAD );

	return ( Success );
}



//============================================================================= 
const char_t *CProfile::FileName( void ) const
//============================================================================= 
{
	return ( my_FileName.c_str() );
}


		
//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CXProfile
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CXProfile::CXProfile( void )
	throw ( void )
//=============================================================================
{
}



//=============================================================================
CXProfile::~CXProfile( void )
	throw ( void )
//=============================================================================
{
}



//=============================================================================
void CXProfile::Open( const char_t FileName[] )
	throw ( CProfileError )
//=============================================================================
{
	if ( my_Profile.Open( FileName ))
		my_ProfileName = FileName;
	else {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::Open" << FileName << endl;
		throw ( Error );
	}
}




//=============================================================================
void CXProfile::Close( void )
	throw ( CProfileError )
//=============================================================================
{
	if ( !my_Profile.Close() ) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::Close" << endl;
		throw ( Error );
	}
}



//=============================================================================
void CXProfile::WriteInteger( const char_t Key[], const char_t ValueName[], int Value )
	throw ( CProfileError )
//=============================================================================
{
	if ( !my_Profile.WriteInteger( Key, ValueName, Value )) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::WriteInteger" << Key << ValueName << Value << endl;
		throw ( Error );
	}
}



//=============================================================================
int CXProfile::ReadInteger( const char_t Key[], const char_t ValueName[] ) const
	throw ( CProfileError )
//=============================================================================
{
	int Value = 0;

	if ( !my_Profile.ReadInteger( Key, ValueName, &Value )) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::ReadInteger" << Key << ValueName << endl;
		throw ( Error );
	}
	return ( Value );
}



//=============================================================================
void CXProfile::WriteString( const char_t Key[], const char_t ValueName[], const string_t &Value )
	throw ( CProfileError )
//=============================================================================
{
	if ( !my_Profile.WriteString( Key, ValueName, Value )) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::WriteString" << Key << ValueName << Value << endl;
		throw ( Error );
	}
}



//=============================================================================
const string_t CXProfile::ReadString( const char_t Key[], const char_t ValueName[] ) const
	throw ( CProfileError )
//=============================================================================
{
	string_t Value;

	if ( !my_Profile.ReadString( Key, ValueName, &Value )) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::ReadString" << Key << ValueName << endl;
		throw ( Error );
	}
	return ( Value );
}



//=============================================================================
void CXProfile::WriteBinary( const char_t Key[], const char_t ValueName[],
	const void *Value, size_t ValueSize )
		throw ( CProfileError )
//=============================================================================
{
	if ( !my_Profile.WriteBinary( Key, ValueName, Value, ValueSize )) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::WriteBinary" << Key << ValueName << endl;
		throw ( Error );
	}
}



//=============================================================================
void CXProfile::ReadBinary( const char_t Key[], const char_t ValueName[],
	void *Value, size_t ValueSize ) const
		throw ( CProfileError )
//=============================================================================
{
	if ( !my_Profile.ReadBinary( Key, ValueName, Value, ValueSize )) {
		CProfileError Error( ::GetLastError() );
		Error << "CXProfile::ReadBinary" << Key << ValueName << endl;
		throw ( Error );
	}
}



//=============================================================================
COutput &operator << ( COutput &rOutput, const CXProfile &Profile )
//=============================================================================
{
	return ( rOutput << kStructureBegin << typeid( Profile.my_Profile ) << Profile.my_ProfileName << kStructureEnd );
}

} // namespace AidKit






/*
bool CProfile::WriteInteger( const char_t Key[], const char_t ValueName[], unsigned Value )
{
	char_t ValueStr[ 33 + 1 ];

	sprintf( ValueStr, "%u", Value );
	return ( WriteProfileString( Key, ValueName, ValueStr, my_FileName.c_str() ));
}


bool CProfile::ReadInteger( const char_t Key[], const char_t ValueName[], unsigned *Value ) const
{
	char_t ValueStr[ 33 + 1 ];
	bool Success = false;

	if ( ReadProfileString( Key, ValueName, ValueStr, sizeof( ValueStr ), my_FileName.c_str() )) {
		sscanf( ValueStr, "%u", Value );
		Success = true;
	}
	return ( Success );
}





bool CProfile::WriteIntegers( const char_t Key[], const std::vector< string_t > &ValueNames,
	const std::vector< int > &Values )
{
	string_t::size_type size;
	std::vector< string_t >::size_type i;

	// We first determine the complete length of all strings:

	size = 0;
	for ( i = 0; i < ValueNames.size() && i < Values.size(); ++i ) {
		size += ValueNames[ i ].length() + 6 + 1;
	}
	size += 1;

	// Then we reserve this size in the destination string:

	string_t Value;
	Value.reserve( size );
	for ( i = 0; i < ValueNames.size() && i < Values.size(); ++i ) {
		Value += ValueNames[ i ] + '=' + itos( Values[ i ] ) + '\0';
	}
	Value += '\0';
	return ( WriteProfileStrings( Key, Value.c_str(), my_FileName.c_str() ));
}



bool CProfile::ReadIntegers( const char_t Key[], std::vector< string_t > *pValueNames,
	std::vector< int > *pValues ) const
{
	char_t Value[ 32767 + 2 ];
	char_t *Begin, *End;
	string_t ValueName, IntegerValue;

	if ( ReadProfileStrings( Key, Value, sizeof( Value ), my_FileName.c_str() )) {
		pValueNames->clear();
		pValues->clear();
		Begin = Value;

		while (( End = strchr( Begin, '=' )) != NULL ) {
			ValueName.assign( Begin, End );

			// Skip the '=':

			Begin = End + 1;
			if (( End = strchr( Begin, '\0' )) != NULL ) {
				IntegerValue.assign( Begin, End );
				pValueNames->push_back( ValueName );
				pValues->push_back( stoi( IntegerValue ));

				// Skip the EOS:

				Begin = End + 1;
			}
		}
	}
	return ( true );
}

*/
