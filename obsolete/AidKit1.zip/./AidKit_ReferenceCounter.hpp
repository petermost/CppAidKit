#ifndef AIDKIT_REFERENCE_COUNTER_HPP
#define AIDKIT_REFERENCE_COUNTER_HPP

#include "AidKit.hpp"
#include "AidKit_Atomic.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CReferenceCounter {
	//-----------------------------------------------------------------------------
		public:
			CReferenceCounter( void );
			CReferenceCounter( const CReferenceCounter & );
			virtual ~CReferenceCounter( void );

			CReferenceCounter &operator = ( const CReferenceCounter & );

			void Delete( void );

			virtual void AcquireReference( void );
			virtual void ReleaseReference( void );

		protected:
			virtual void DoDelete( void );

		private:
			CAtomic my_Counter;
	};



	template < typename CType >
		//-----------------------------------------------------------------------------
		class TReferenceCounterPointer {
		//-----------------------------------------------------------------------------
			public:
				TReferenceCounterPointer( CType *pObject = 0 );
				TReferenceCounterPointer( const TReferenceCounterPointer & );

				~TReferenceCounterPointer( void );

				CType *operator = ( CType *pObject );
				TReferenceCounterPointer &operator = ( const TReferenceCounterPointer & );

				CType *operator -> ( void ) const;
				CType &operator * ( void ) const;

				operator CType * ( void ) const;

			private:
				CType *my_pObject;
		};
}

#include "AidKit_ReferenceCounterPointer.cpp"

#endif
