#include "AidKit_Dialog.hpp"
#include "AidKit_Warnings.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDialogGadget
//###
//#############################################################################
//#############################################################################
//#############################################################################

BEGIN_MESSAGE_MAP(CDialogGadget, CDialog)
	//{{AFX_MSG_MAP(CDialogGadget)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


//=============================================================================
CDialogGadget::CDialogGadget( void )
//=============================================================================
{
	Construct();
}



//=============================================================================
CDialogGadget::CDialogGadget(LPCTSTR lpszTemplateName, CWnd* pParentWnd /* = NULL */ )
: CDialog( lpszTemplateName, pParentWnd )
//=============================================================================
{
	Construct();
}



//=============================================================================
CDialogGadget::CDialogGadget(UINT nIDTemplate, CWnd* pParentWnd /* = NULL */ )
: CDialog( nIDTemplate, pParentWnd )
//=============================================================================
{
	Construct();
}



//=============================================================================
void CDialogGadget::Construct( void )
//=============================================================================
{
	//{{AFX_DATA_INIT(CDialogGadget)
	//}}AFX_DATA_INIT


	my_IsModal = FALSE;
}



//=============================================================================
void CDialogGadget::OnOK() 
//=============================================================================
{
	if ( IsModal() )
		CDialog::OnOK();
	else
		DestroyWindow();
}



//=============================================================================
void CDialogGadget::OnCancel() 
//=============================================================================
{
	if ( IsModal() )
		CDialog::OnCancel();
	else
		DestroyWindow();
}


//=============================================================================
void CDialogGadget::PostNcDestroy() 
//=============================================================================
{
	// TODO: Add your specialized code here and/or call the base class

	delete this;
}


//=============================================================================
int CDialogGadget::DoModal( void )
//=============================================================================
{
	int DoModalResult;

	my_IsModal = TRUE;
	DoModalResult = CDialog::DoModal();
	my_IsModal = FALSE;

	return ( DoModalResult );
}



//=============================================================================
BOOL CDialogGadget::IsModal( void ) const
//=============================================================================
{
	return ( my_IsModal );
}



//=============================================================================
BOOL CDialogGadget::PreTranslateMessage(MSG* pMsg) 
//=============================================================================
{
	PreTranslateMessageEvt.Announce( pMsg );
	
	return CDialog::PreTranslateMessage(pMsg);
}


} // namespace AidKit

