#ifndef AIDKIT_OUTPUT_HPP
#define AIDKIT_OUTPUT_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"

#include <string>
#include <typeinfo>

namespace AidKit {
	
	//-----------------------------------------------------------------------------
	class COutput {
	//-----------------------------------------------------------------------------
		public:
			COutput( void );
			virtual ~COutput( void );

			COutput &WriteBoolean( bool Value, const std::type_info &ValueType );
			COutput &WriteCharacter( char_t Value, const std::type_info &ValueType );
			COutput &WriteString( const char_t Value[], const std::type_info &ValueType );
			COutput &WriteString( const string_t &Value, const std::type_info &ValueType );
			COutput &WriteInteger( long Value, const std::type_info &ValueType );
			COutput &WriteInteger( unsigned long Value, const std::type_info &ValueType );
			COutput &WriteFloat( double Value, const std::type_info &ValueType );
			COutput &WritePointer( const void *pValue, const std::type_info &ValueType );
			COutput &WriteType( const std::type_info &Value, const std::type_info &ValueType );

			COutput &Flush( void );

		protected:
			virtual COutput &DoWrite( const char_t Value[], size_t ValueLength, const std::type_info &ValueType ) = 0;
			virtual COutput &DoFlush( void ) = 0;
	};

	inline COutput &operator << ( COutput &rOutput, COutput & ( *pManipulator )( COutput &rOutput ))
		{ return ( pManipulator( rOutput )); }

	inline COutput &operator << ( COutput &rOutput, const std::type_info &Value )
		{ return ( rOutput.WriteType( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, bool Value )
		{ return ( rOutput.WriteBoolean( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, const char_t Value[] )
		{ return ( rOutput.WriteString( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, const string_t &Value )
		{ return ( rOutput.WriteString( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, const void *pValue )
		{ return ( rOutput.WritePointer( pValue, typeid( pValue ))); }

	inline COutput &operator << ( COutput &rOutput, char_t Value )
		{ return ( rOutput.WriteCharacter( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, signed char Value )
		{ return ( rOutput.WriteCharacter( static_cast< char_t >( Value ), typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, unsigned char Value )
		{ return ( rOutput.WriteCharacter( static_cast< char_t >( Value ), typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, int Value )
		{ return ( rOutput.WriteInteger( static_cast< long >( Value ), typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, unsigned int Value )
		{ return ( rOutput.WriteInteger( static_cast< unsigned long >( Value ), typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, long Value )
		{ return ( rOutput.WriteInteger( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, unsigned long Value )
		{ return ( rOutput.WriteInteger( Value, typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, float Value )
		{ return ( rOutput.WriteFloat( static_cast< double >( Value ), typeid( Value ))); }

	inline COutput &operator << ( COutput &rOutput, double Value )
		{ return ( rOutput.WriteFloat( Value, typeid( Value ))); }

	inline COutput &endl( COutput &rOutput )
		{ return ( rOutput.Flush() ); }

}

#endif


