#ifndef AIDKIT_WINDOWS_GUIDE
#define AIDKIT_WINDOWS_GUIDE

#include "AidKit.hpp"

#ifndef __AFXWIN_H__
	#include <afxwin.h>
#endif

class CWnd;

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CWindowsVisitor {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CWindowsVisitor( void );

			virtual bool VisitWindow( CWnd *pWnd ) = 0;
		};


	//-----------------------------------------------------------------------------
	class CWindowsGuide {
	//-----------------------------------------------------------------------------
		public:
			CWindowsGuide( void );
			~CWindowsGuide( void );

			bool Tour( CWindowsVisitor *pVisitor );
			bool TourChilds( CWindowsVisitor *pVisitor, CWnd *pStartWnd = 0 );

		private:
			static BOOL CALLBACK EnumerateFunction( HWND hWnd, LPARAM lParam );

			CWindowsVisitor *my_pVisitor;
			bool my_VisitorResult;
		};

}

#endif
