#ifndef AIDKIT_STATUSBAR_HPP
#define AIDKIT_STATUSBAR_HPP

#include "AidKit.hpp"
#include <afxcmn.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CStatusBarGadget : public CStatusBarCtrl {
	//-----------------------------------------------------------------------------
		public:
			CStatusBarGadget();
			virtual ~CStatusBarGadget();

		private:
			//{{AFX_VIRTUAL(CStatusBarGadget)
			//}}AFX_VIRTUAL

			//{{AFX_MSG(CStatusBarGadget)
			//}}AFX_MSG

			DECLARE_MESSAGE_MAP()
	};

//{{AFX_INSERT_LOCATION}}

}

#endif
