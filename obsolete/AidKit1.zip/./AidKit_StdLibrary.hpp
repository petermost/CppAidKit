#ifndef AIDKIT_STD_LIBRARY_HPP
#define AIDKIT_STD_LIBRARY_HPP

namespace AidKit {

}

#endif
