#ifndef AIDKIT_TREE_HPP
#define AIDKIT_TREE_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"

#include <stack>
#include <vector>
#include <string>
namespace AidKit {

	class CTreeBuilder;

	//-------------------------------------------------------------------------
	class CTree {
	//-------------------------------------------------------------------------
		public:
			CTree( void );

			void CreateBranch( const char_t Inscription[] );
			void AppendLeaf( const char_t Inscription[] );
			void CloseBranch( void );

			void Build( CTreeBuilder *pBuilder ) const;

		private:
			class CBranch : public std::vector< CBranch > {
				public:
					CBranch( void );
					CBranch( const char_t Inscription[] );

					const char_t *Inscription( void ) const;

				private:
					string_t my_Inscription;
			};

			void _Build( const CBranch &Branches, CTreeBuilder *pBuilder ) const;
			
			CBranch my_Branches;
			CBranch::iterator my_itCurrentBranch;
			std::stack< CBranch::iterator > my_LastBranches;
	};



	//-------------------------------------------------------------------------
	class CTreeBuilder {
	//-------------------------------------------------------------------------
		public:
			virtual ~CTreeBuilder( void );

			virtual void CreateNextBranch( const char_t Inscription[] ) = 0;
			virtual void CreateLastBranch( const char_t Inscription[] ) = 0;
			virtual void CloseBranch() = 0;
				
			virtual void AppendNextLeaf( const char_t Inscription[] ) = 0;
			virtual void AppendLastLeaf( const char_t Inscription[] ) = 0;
	};


	//-------------------------------------------------------------------------
	class CAsciiTreeBuilder : public CTreeBuilder {
	//-------------------------------------------------------------------------
		public:
			CAsciiTreeBuilder( std::vector< string_t > *pTree );

			virtual void CreateNextBranch( const char_t Inscription[] );
			virtual void CreateLastBranch( const char_t Inscription[] );
			virtual void CloseBranch();
				
			virtual void AppendNextLeaf( const char_t Inscription[] );
			virtual void AppendLastLeaf( const char_t Inscription[] );

		protected:
			void AppendString( const string_t &Inscription );

		private:
			string_t my_Indention;
			std::vector< string_t > *my_pTree; 
	};

} // namespace AidKit

#endif
