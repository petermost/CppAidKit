#include "AidKit_Misc.hpp"
#include "AidKit_Memory.hpp"
#include <stdio.h>
#include <stdarg.h>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//=============================================================================
unsigned count_bits( unsigned x )
//=============================================================================
{
	unsigned n = 0;

	while ( x > 0 ) {
		++n;
		x >>= 1;
	}
	return ( n );
}



//=============================================================================
unsigned get_bits( unsigned x, unsigned p, unsigned n )
//=============================================================================
{
	return ( x >> ( p + 1 - n )) & ~( ~0 << n );
}


} // namespace AidKit
