#ifndef AIDKIT_PICTURE_HPP
#define AIDKIT_PICTURE_HPP

#include "AidKit.hpp"
#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CPicture : public CStatic {
	//-----------------------------------------------------------------------------
		public:
			CPicture( void );
			virtual ~CPicture( void );

			//{{AFX_VIRTUAL(CPicture)
			protected:
			virtual void PreSubclassWindow();
			//}}AFX_VIRTUAL

		protected:
			//{{AFX_MSG(CPicture)
			afx_msg void OnPaint();
			//}}AFX_MSG

			DECLARE_MESSAGE_MAP()
	};

}

#endif
