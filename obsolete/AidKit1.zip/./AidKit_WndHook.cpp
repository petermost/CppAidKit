#include "AidKit_WndHook.hpp"
#include "AidKit_Warnings.hpp"
#include <afxwin.h>


namespace AidKit {


inline WNDPROC GetWndProc( CWnd *pWnd )
	{ return ( reinterpret_cast< WNDPROC >( GetWindowLong( pWnd->GetSafeHwnd(), GWL_WNDPROC ))); }


inline WNDPROC SetWndProc( CWnd *pWnd, WNDPROC WndProc )
	{ return ( reinterpret_cast< WNDPROC >( SetWindowLong( pWnd->GetSafeHwnd(), GWL_WNDPROC, reinterpret_cast< LONG >( WndProc )))); }


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWndHook
//###
//#############################################################################
//#############################################################################
//#############################################################################


CTypedPtrMap< CMapPtrToPtr, CWnd *, CWndHook * > CWndHook::our_WndHookMap;

//=============================================================================
CWndHook::CWndHook( void )
//=============================================================================
{
	my_pHookedWnd  = NULL;
	my_pOldWndProc = 0;
}




//=============================================================================
CWndHook::~CWndHook( void )
//=============================================================================
{
	if ( my_pHookedWnd != NULL && IsHooked( my_pHookedWnd ))
		UninstallHook( my_pHookedWnd );
}



//=============================================================================
BOOL CWndHook::InstallHook( CWnd *pWnd )
//=============================================================================
{
	ASSERT_VALID( pWnd );
	AIDKIT_ASSERT( pWnd->m_hWnd != 0 ); // Must already be created!

	BOOL IsInstalled = FALSE;

	if ( !IsHooked( pWnd )) {
		my_pHookedWnd = pWnd;

		// Replace the windows procedure with our own (i.e. subclass it):

		my_pOldWndProc = SetWndProc( pWnd, WndHookProc );

		// Remember the window/hook so we can later find it again (-->WndHookProc):

		our_WndHookMap.SetAt( pWnd, this );

		IsInstalled = TRUE;
	}
	return ( IsInstalled );
}



//=============================================================================
BOOL CWndHook::UninstallHook( CWnd *pWnd )
//=============================================================================
{
	ASSERT_VALID( pWnd );
	AIDKIT_ASSERT( pWnd->m_hWnd != 0 ); // Must already be created!
	
	BOOL IsUninstalled = FALSE;

	if ( IsHooked( pWnd )) {
		my_pHookedWnd = NULL;

		// Restore the old window procedure:

		SetWndProc( pWnd, my_pOldWndProc );
		my_pOldWndProc = 0;

		// Remove the window/hook from the map:

		our_WndHookMap.RemoveKey( pWnd );

		IsUninstalled = TRUE;
	}
	return ( IsUninstalled );
}



//=============================================================================
LRESULT CALLBACK CWndHook::WndHookProc( HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam )
//=============================================================================
{
	// Get a C++ object for the handle:

	CWnd* pWnd = CWnd::FromHandlePermanent( hWnd );
	AIDKIT_ASSERT( pWnd != NULL );
	AIDKIT_ASSERT( pWnd->m_hWnd == hWnd );
	
	// Get the hook and call the event handler:

	CWndHook *pHook = FindHook( pWnd );
	AIDKIT_ASSERT( pHook != NULL );
	pHook->MessageEvt.Announce( pWnd, nMsg, wParam, lParam );

	// Call the old wnd procedure:

	AIDKIT_ASSERT( pHook->my_pOldWndProc != 0 );
	return ( CallWindowProc( pHook->my_pOldWndProc, hWnd, nMsg, wParam, lParam ));
}



//=============================================================================
CWndHook *CWndHook::FindHook( CWnd *pWnd )
//=============================================================================
{
	CWndHook *pHook = NULL;
	AIDKIT_ASSERT( our_WndHookMap.Lookup( pWnd, pHook ));
	return ( pHook );
}



//=============================================================================
BOOL CWndHook::IsHooked( CWnd *pWnd )
//=============================================================================
{
	return ( GetWndProc( pWnd ) == WndHookProc );
}

} // namespace AidKit
