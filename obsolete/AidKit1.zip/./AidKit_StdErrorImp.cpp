#ifndef AIDKIT_STD_ERROR_IMP_CPP
#define AIDKIT_STD_ERROR_IMP_CPP

#include "AidKit_StdError.hpp"

namespace AidKit {

template < typename TError >
	//=============================================================================
	int check_err_no( int nError )
		throw ( TError )
	//=============================================================================
	{
		if ( nError != ENONE ) {
			throw TError( nError );
		}
		return ( nError );
	}

template < typename TError >
	//=============================================================================
	int check_err_no_api( int nResult )
		throw ( TError )
	//=============================================================================
	{
		if ( nResult == ERROR ) {
			throw TError( errno );
		}
		return ( nResult );
	}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TStdError
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < typename TName >
	//=============================================================================
	TStdError< TName > TStdError< TName >::LastError( void )
		throw()
	//=============================================================================
      {
		return ( TStdError( errno ));
	}



template < typename TName >
	//=============================================================================
	TStdError< TName >::TStdError( int nError, const string_t &Description )
		throw()
			: CStdError( nError, Description )
	//=============================================================================
	{
	}



template < typename TName >
	//=============================================================================
	TStdError< TName >::TStdError( const TStdError &OtherError )
		throw()
			: CStdError( OtherError )
	//=============================================================================
	{
	}



template < typename TName >
	//=============================================================================
	TStdError< TName > &TStdError< TName >::operator = ( const TStdError &OtherError )
		throw()
	//=============================================================================
	{
		CStdError::operator = ( OtherError );

		return ( *this );
	}

} // namespace AidKit

#endif
