#ifndef AIDKIT_PROPERTY_CPP
#define AIDKIT_PROPERTY_CPP

#include "AidKit_Property.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TProperty
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < typename CType >
	//=============================================================================
	TProperty< CType >::TProperty( const TProperty &OtherProperty )
	//=============================================================================
	: my_Value( OtherProperty.my_Value )
	{
		// No Observers, no AnnounceChange!
	}



template < typename CType >
	//=============================================================================
	TProperty< CType >::TProperty( const CType &Value )
	//=============================================================================
	: my_Value( Value )
	{
		// No Observers, no AnnounceChange!
	}


template < typename CType >
	//=============================================================================
	const CType &TProperty< CType >::operator = ( const CType &Value )
	//=============================================================================
	{
		if ( my_Value != Value ) {
			my_Value = Value;
			ChangedEvt.Announce( this );
		}
		return ( my_Value );
	}



template < typename CType >
	//=============================================================================
	TProperty< CType > &TProperty< CType >::operator = ( const TProperty &OtherProperty )
	//=============================================================================
	{
		*this = OtherProperty.my_Value;
		return ( *this );
	}



template < typename CType >
	//=============================================================================
	inline TProperty< CType >::operator const CType &( void )
	//=============================================================================
	{
		return ( my_Value );
	}



template < typename CType >
	//=============================================================================
	inline TProperty< CType >::operator const CType &( void ) const
	//=============================================================================
	{
		return ( my_Value );
	}

} // namespace AidKit

#endif
