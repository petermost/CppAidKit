#ifndef AIDKIT_WIN_ERROR_HPP
#define AIDKIT_WIN_ERROR_HPP

#include "AidKit.hpp"
#include "AidKit_Error.hpp"
#include "AidKit_Unicode.hpp"

#include <afx.h> // For class CString.
#include <winerror.h>

namespace AidKit {

	CString GetLastErrorString( DWORD LastError );
	CString GetLastErrorCodeString( DWORD LastError, unsigned Base = 10 );

	//-----------------------------------------------------------------------------
	class CWinError : public CError {
	//-----------------------------------------------------------------------------
		public:
			static CWinError LastError( void )
				throw();

			explicit CWinError( DWORD LastError = ERROR_SUCCESS )
				throw();

			CWinError( const CWinError &OtherError )
				throw();

			virtual DWORD Reason( void ) const
				throw();
				// For a complete list of error codes see winerror.h.

			virtual const char_t *Description( void ) const
				throw();

			operator DWORD( void ) const
				{ return ( Reason() ); }

		private:
			DWORD   my_Reason;
			mutable CString my_Description;
	};

	//-----------------------------------------------------------------------------
	template < typename TName >
		class TWinError : public CWinError {
	//-----------------------------------------------------------------------------
			public:
				static TWinError LastError( void )
					throw();

				explicit TWinError( DWORD LastError = ERROR_SUCCESS )
					throw();

				TWinError( const TWinError &OtherError )
					throw();

				TWinError &operator = ( const TWinError &OtherError )
					throw();
		};

	// All this functions check wether there was an error:

	template < typename TError >
		DWORD check_win_error( DWORD nError )
			throw ( TError );

	template < typename TError >
		BOOL check_win_api( BOOL Success )
			throw ( TError );

	DWORD CheckWinError( DWORD nError )
		throw ( CWinError );

	BOOL CheckWinApi( BOOL Success )
		throw ( CWinError );

	HRESULT CheckHResult( HRESULT hResult )
		throw ( CWinError );

}

#include "AidKit_WinErrorImp.cpp"

#endif

