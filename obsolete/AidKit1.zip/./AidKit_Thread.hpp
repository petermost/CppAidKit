#ifndef AIDKIT_THREAD_HPP
#define AIDKIT_THREAD_HPP

#include "AidKit.hpp"
#include "AidKit_Time.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CThreadBasics {
	//-----------------------------------------------------------------------------
		public:
			CThreadBasics( void );
			virtual ~CThreadBasics( void );

		protected:
			virtual bool DoStart( void ( *pFunction )( void * ), void *pParameter ) = 0;
			virtual bool DoWait( milliseconds_t Milliseconds ) = 0;
			virtual bool DoInfiniteWait( void ) = 0;

			virtual void DoYield( void ) = 0;
			virtual bool DoSleep( milliseconds_t Milliseconds ) = 0;
			virtual void DoInfiniteSleep( void ) = 0;
			virtual void DoWakeup( void ) = 0;

			virtual bool IsSelf( void ) const = 0;

			void ( *my_pFunction )( void *pParameter );
			void *my_pFunctionParameter;

		private:

	};

}

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Thread.hpp"
	
	namespace AidKit {
		using Windows::CThreadError;
		typedef CWindowsThread CNativeThread;
	}
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Thread.hpp"
	
	namespace AidKit {
		using Unix::CThreadError;
	}
#endif

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CThread : protected CNativeThread {
	//-----------------------------------------------------------------------------
		public:
			CThread( void );
			virtual ~CThread( void );

			/// Start the thread.
			bool Start( void );

			/// Signal the thread to stop. Can be overwritten, if it is necessary
			/// to get the thread out of a waiting state (like select).
			/// @see Stop()
			virtual void Cancel( void );

			/// Signal and wait until the thread has stopped.
			/// @note Stop also calls Cancel().
			/// @see Cancel()
			void Stop( void );
			bool Stop( milliseconds_t Milliseconds );

			/// Wait for the thread to stop, but does not signal it to do so!
			void Wait( void );
			bool Wait( milliseconds_t Milliseconds );

			/// Wakeup a sleeping thread.
			/// @see Sleep
			void Wakeup( void );

			// There is no method to detect wether the thread is still running, because
			// it leads the user to write something like:
			// while ( IsRunning );
			// Besides it is not that simple to really detect this case and do something
			// usefull with it, because the thread might already have stop.

		protected:
			friend class CThreadBasics;

			/// This is the method in which the work will be done.
			/// The implementation should look like this:
			/// @code 
			/// while ( MayContinue() ) {
			/// 	// Do your work ...
			/// 	Sleep( 500 ); // should be avoided but it is allowed!
			/// }
			/// @endcode

			virtual void Do( void ) = 0;

				//
				// !!! The following methods should only be called from inside
				// the Do-method !!!
				// 

			/// Should be called periodically to check wether the
			/// thread should end itself.
			/// @attention Call it only from inside Do()!
			bool MayContinue( void ) const;

			/// Can be used to detect wether the call is coming from Do().
			using CNativeThread::IsSelf;

			/// Give up the remaining time slice.
			void Yield( void );

			/// Let the thread sleep, but if the thread is beeing canceled then
			/// it will return earlier.
			/// @param Milliseconds - the time to sleep.
			/// @return Wether Sleep() has successful sleeped the whole time.
			/// @see Wakeup()
			/// @attention Call it only from inside Do()!
			void Sleep( void );
			bool Sleep( milliseconds_t Milliseconds );

		private:
			static void Entry( void *pParameter );

			volatile bool my_MayContinue;
	};
}

#endif
