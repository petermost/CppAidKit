#ifndef AIDKIT_LINKER_HPP
#define AIDKIT_LINKER_HPP

#include "AidKit.hpp"

// Give warning, if the wrong run time libraries are beeing used:

#if defined( _DLL )
	#if defined( AIDKIT_UNICODE )
		#if defined( AIDKIT_DEBUG )
			#pragma comment( lib, "AidKitDllDbgWde.lib" )
		#else
			#pragma comment( lib, "AidKitDllWde.lib" )
		#endif
	#else
		#if defined( AIDKIT_DEBUG )
			#pragma comment( lib, "AidKitDllDbg.lib" )
		#else				
			#pragma comment( lib, "AidKitDll.lib" )
		#endif
	#endif
#else
	#if defined( AIDKIT_UNICODE )
		#if defined( AIDKIT_DEBUG )
			#pragma comment( lib, "AidKitDbgWde.lib" )
		#else
			#pragma comment( lib, "AidKitWde.lib" )
		#endif
	#else
		#if defined( AIDKIT_DEBUG )
			#pragma comment( lib, "AidKitDbg.lib" )
		#else
			#pragma comment( lib, "AidKit.lib" )
		#endif
	#endif
#endif

#endif // AIDKIT_LINKER_HPP
