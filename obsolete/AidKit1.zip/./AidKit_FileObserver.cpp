#include "AidKit_FileObserver.hpp"
#include "AidKit_Text.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Templates.hpp"
#include "AidKit_Warnings.hpp"

namespace AidKit {

static const CText kFileDoesntExistTxt(
	TEXT( "File '%s' doesn't exist!" ),    CText::eEnglish,
	TEXT( "Datei '%s' existiert nicht!" ), CText::eGerman,
	NULL );

static const CText kFileChangedTxt(
	TEXT( "File '%s' has changed." ),     CText::eEnglish,
	TEXT( "Datei '%s' wurde ge�ndert." ), CText::eGerman,
	NULL );

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CFileObserver
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CFileObserver::CFileObserver( void )
	: my_Debugger( TEXT( "CFileObserver" ))
//=============================================================================
{
	my_pHandler = NULL;
	my_CheckingPeriod = 0;
	my_CanIgnoreChanges = false;
}




//=============================================================================
CFileObserver::~CFileObserver( void )
//=============================================================================
{
}



//=============================================================================
static bool ReadDirectoryEntry( const char_t FileName[], CDirectoryEntry *pEntry )
//=============================================================================

{
	CDirectory Directory;

	return ( Directory.FirstEntry( pEntry, FileName ));
}



//=============================================================================
bool CFileObserver::Observe( const char_t FileName[], TEventCall2< CFileObserver *, const char_t * > *pHandler,
	unsigned CheckingPeriod )
//=============================================================================
{
	AIDKIT_ASSERT( my_pHandler == NULL );

	my_pHandler       = pHandler;
	my_ChangedEvt.Subscribe( my_pHandler );
	my_FileName       = FileName;
	my_CheckingPeriod = CheckingPeriod;

	return ( Start() );
}



//=============================================================================
bool CFileObserver::Unobserve( void )
//=============================================================================
{
	Stop();

	my_ChangedEvt.Unsubscribe( my_pHandler );
	my_pHandler = NULL;

	return ( true );
}



//=============================================================================
bool CFileObserver::IgnoreChanges( bool Ignore )
//=============================================================================
{
	if ( !Ignore )
		ReadDirectoryEntry( my_FileName.c_str(), &my_CurrentFileEntry );

	return ( Exchange( &my_CanIgnoreChanges, Ignore ));
}



//=============================================================================
static bool HasFileEntryChanged( const CDirectoryEntry &Entry1, const CDirectoryEntry &Entry2 )
//=============================================================================
{
	AIDKIT_ASSERT( Entry1.IsDirectory() == Entry2.IsDirectory() );

	return ( Entry1.CreationTime() != Entry2.CreationTime()
		|| Entry1.LastWriteTime()  != Entry2.LastWriteTime()
		|| Entry1.Size()           != Entry2.Size()
		|| Entry1.IsArchived()     != Entry2.IsArchived()
		|| Entry1.IsHidden()       != Entry2.IsHidden()
		|| Entry1.IsNormal()       != Entry2.IsNormal()
		|| Entry1.IsReadOnly()     != Entry2.IsReadOnly()
		|| Entry1.IsSystem()       != Entry2.IsSystem() );
}



//=============================================================================
void CFileObserver::Do( void )
//=============================================================================
{
	CDirectoryEntry PreviousFileEntry;

	if ( !ReadDirectoryEntry( my_FileName.c_str(), &my_CurrentFileEntry ))
		my_Debugger.Trace( kFileDoesntExistTxt, my_FileName.c_str() );

	while ( MayContinue() ) {
		if ( !my_CanIgnoreChanges ) {
			if ( ReadDirectoryEntry( my_FileName.c_str(), &my_CurrentFileEntry )) {
				if ( HasFileEntryChanged( PreviousFileEntry, my_CurrentFileEntry )) {
					my_Debugger.Trace( kFileChangedTxt, my_FileName.c_str() );
					my_ChangedEvt.Announce( this, my_FileName.c_str() );
					PreviousFileEntry = my_CurrentFileEntry;
				}
			}
		}
		Sleep( my_CheckingPeriod );
	}
}


} // namespace AidKit
