#ifndef AIDKIT_TYPES_HPP
#define AIDKIT_TYPES_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows/AidKit_Windows_Types.hpp"
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Types.hpp"
#endif

namespace AidKit {

	// Common definitions:

	typedef UINT8 BYTE;

	typedef unsigned short ushort;
	typedef unsigned int   uint;
	typedef unsigned long  ulong;

}

#endif
