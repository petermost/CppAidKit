#include "AidKit_WinError.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_WsaError.hpp"
#include <winerror.h>
#include "AidKit_Warnings.hpp"

namespace AidKit {

//============================================================================= 
static DWORD GetLastErrorDescription( DWORD LastError, char_t Description[], size_t DescriptionLength )
//============================================================================= 
{
	const DWORD MaxDescriptionWidth = FORMAT_MESSAGE_MAX_WIDTH_MASK;
	const DWORD Flags = FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS | MaxDescriptionWidth;
	const LPVOID MessageSource = NULL;
	const DWORD LanguageId = 0;   // MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
	va_list *Arguments = NULL;

	DWORD MessageLength;

	MessageLength = FormatMessage( Flags, MessageSource, LastError, LanguageId,
		Description, DescriptionLength, Arguments );

	// Remove the space and the dot at the end of the message:

	if ( MessageLength > 0 ) {
		if ( Description[ MessageLength - 1 ] == TEXT( ' ' ))
			Description[ MessageLength-- - 1 ] = TEXT( '\0' );

		if ( Description[ MessageLength - 1 ] == TEXT( '.' ))
			Description[ MessageLength-- - 1 ] = TEXT( '\0' );
	}
	return ( MessageLength );
}



//============================================================================= 
CString GetLastErrorCodeString( DWORD LastError, unsigned Base )
//============================================================================= 
{
	char_t szLastError[ 33 + 1 ];

	COMPILER_ASSERT( sizeof( LastError ) <= sizeof( long ));
	return ( CString( _l_to_a( LastError, szLastError, Base )));
}



//============================================================================= 
CString GetLastErrorString( DWORD LastError )
//============================================================================= 
{
	size_t DescriptionLength = 0;
	char_t *pDescription = NULL;
	DWORD MessageLength = 0; 
	CString ErrorCodeString;
	CString Description;

	// As long as the error description does not fit into <Description>
	// we grow the buffer of <Description>:

	do {
		try {
			DescriptionLength += 80;
			pDescription = Description.GetBuffer( DescriptionLength );
		} catch ( CMemoryException *pException ) {
			pException->Delete();			
			break;
		}
	} while (( MessageLength = GetLastErrorDescription( LastError, pDescription, DescriptionLength )) == 0
		&& GetLastError() == ERROR_INSUFFICIENT_BUFFER );

	Description.ReleaseBuffer( MessageLength );
	
	// Append the error code only if we have a description:
	if ( !Description.IsEmpty() )
		Description += CString( TEXT( " (" )) + GetLastErrorCodeString( LastError ) + TEXT( ")" );

	return ( Description );
}



//============================================================================= 
static CString LookupErrorString( DWORD Error )
//============================================================================= 
{
	CString String;

	if (( String = GetLastErrorString( Error )).IsEmpty() )
		if (( String = WSAGetLastErrorString( Error )).IsEmpty() )
			String = GetLastErrorCodeString( Error );

	return ( String );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWinError
//###
//#############################################################################
//#############################################################################
//#############################################################################


//============================================================================= 
CWinError CWinError::LastError( void )
	throw()
//============================================================================= 
{
	return ( CWinError( ::GetLastError() ));
}



//============================================================================= 
CWinError::CWinError( DWORD Error )
	throw()
//============================================================================= 
{
	my_Reason = Error;
	my_Description.Empty();
}



//============================================================================= 
CWinError::CWinError( const CWinError &Other )
	throw()
		: CError( Other )
//============================================================================= 
{
	my_Reason      = Other.my_Reason;
	my_Description = Other.my_Description;
}


//============================================================================= 
DWORD CWinError::Reason( void ) const
	throw()
//============================================================================= 
{
	return ( my_Reason );
}



//============================================================================= 
const char_t *CWinError::Description( void ) const
	throw()
//============================================================================= 
{
	if ( my_Description.IsEmpty() )
		my_Description = LookupErrorString( my_Reason );

	return ( my_Description );
}



//=============================================================================
HRESULT CheckHResult( HRESULT hResult )
	throw ( CWinError )
//=============================================================================
{
	if ( hResult != S_OK ) {
		CWinError Error( hResult );
		throw ( Error );
	}
	return ( hResult );
}


// These functions are obviously candidates for inlining, But when I used the
// library as a part of a dll (global hook) the call to CheckWinApi raised an
// access violation.
//=============================================================================
DWORD CheckWinError( DWORD nError )
	throw ( CWinError )
//=============================================================================
{
	return ( check_win_error< CWinError >( nError ));
}


//=============================================================================
BOOL CheckWinApi( BOOL Success )
	throw ( CWinError )
//=============================================================================
{
	return ( check_win_api< CWinError >( Success ));
}


} // namespace AidKit
