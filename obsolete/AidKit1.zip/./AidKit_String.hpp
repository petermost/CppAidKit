#ifndef AIDKIT_STRING_HPP
#define AIDKIT_STRING_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_String.hpp"

	namespace AidKit {
		// using Windows::
	}
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_String.hpp"

	namespace AidKit {
		using Unix::encode_base64;
		using Unix::decode_base64;
	}

#endif

#include "AidKit_Debug.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_StdError.hpp"
#include <stdarg.h>

namespace AidKit {

	extern const string_t EMPTY_STRING;

	long int StrToL( const char_t *pStart, int Base = 10, char_t **ppEnd = NULL )
		throw ( CStdError );

	unsigned long int StrToUL( const char_t *pStart, int Base = 10, char_t **ppEnd = NULL )
		throw ( CStdError );

	long long int StrToLL( const char_t *pStart, int Base = 10, char_t **ppEnd = NULL )
		throw ( CStdError );

	unsigned long long int StrToULL( const char_t *pStart, int Base = 10, char_t **ppEnd = NULL )
		throw ( CStdError );

	int stoi( const string_t &s )
		throw ( CStdError );


	char_t *itoa( int i, char_t *s, int base );
	const string_t itos( int i, int base = 10 );
	const string_t ltos( long l, int base = 10 );

	const string_t string_printf( const char_t format[], ... );
	const string_t string_vprintf( const char_t format[], va_list arguments );

	const string_t trim_left( const string_t &s );
	const string_t trim_right( const string_t &s );
	const string_t trim_left( const string_t &s, char_t c );
	const string_t trim_right( const string_t &s, char_t c );

	const string_t encode_crlf( const string_t &s );
	const string_t decode_crlf( const string_t &s );

	const string_t encode_base64( const string_t &s );
	const string_t decode_base64( const string_t &s );

	char_t *chrcat( char_t *s, char_t c );

	bool is_mixed_pattern_match( const char_t value[], const char_t pattern[] );
	bool is_upper_pattern_match( const char_t value[], const char_t pattern[] );

	template < size_t kSize, typename TChar = char >
		//-----------------------------------------------------------------------------
		class TStringBuffer {
		//-----------------------------------------------------------------------------
			public:
				enum { EOS }; // End Of String

				void Clear( void )
					{ memset( my_Content, EOS, sizeof( my_Content )); }

				const TChar *operator = ( const TChar Other[] )
					{ return ( str_n_cpy( my_Content, Other, kSize )); }

				const TChar *operator += ( const TChar Other[] )
					{ return ( str_n_cat( my_Content, Other, kSize - Length() )); }

				bool operator == ( const TChar Other[] ) const
					{ return ( str_cmp( my_Content, Other ) == 0 ); }


				TChar *Find( TChar c )
					{ return ( str_chr( my_Content, c )); }

				const TChar *Find( TChar c ) const
					{ return ( str_chr( my_Content, c )); }

				TChar *Find( const TChar SubString[] )
					{ return ( str_str( my_Content, SubString )); }

				const TChar *Find( const TChar SubString[] ) const
					{ return ( str_str( my_Content, SubString )); }

				TChar *ReverseFind( TChar c )
					{ return ( str_r_chr( my_Content, c )); }

				const TChar *ReverseFind( TChar c ) const
					{ return ( str_r_chr( my_Content, c )); }


				TChar *Content( void )
					{ return ( my_Content ); }

				const TChar *Content( void ) const
					{ return ( my_Content ); }

				size_t Length( void ) const
					{ return ( str_len( my_Content )); }

				size_t Capacity( void ) const
					{ return ( kSize ); }

				bool IsEmpty( void ) const
					{ return ( my_Content[ 0 ] == EOS ); }

				TChar &operator [] ( size_t i )
					{ AIDKIT_ASSERT( i < kSize ); return ( my_Content[ i ] ); }

				const TChar &operator [] ( size_t i ) const
					{ AIDKIT_ASSERT( i < kSize ); return ( my_Content[ i ] ); }

				// operator TChar * ( void ) { return ( my_Content ); }

				operator const TChar * ( void ) const
					{ return ( Content() ); }

			private:
				TChar my_Content[ kSize + 1 ];
		};


	template < size_t kSize, typename TChar = char >
		//-----------------------------------------------------------------------------
		class TString : public TStringBuffer< kSize, TChar > {
		//-----------------------------------------------------------------------------
			public:
				TString( void )
					{ TString::Clear(); }

				TString( const TChar Other[] )
					{ TString::Clear(); *this = Other; }

				~TString( void )
					{ AIDKIT_ASSERT( TString::my_Content[ kSize ] == TString::EOS ); }
		};


	/*
	template < typename C >
		int is_cntrl( C c );

	template < typename TChar >
		TChar *str_n_cpy( TChar *dst, const TChar *src, size_t max_len );

	template < typename TChar >
		TChar *str_n_cat( TChar *dst, const TChar *src, size_t max_len );

	template < typename TChar >
		int str_cmp( const TChar *src1, const TChar *src2 );

	template < typename TChar >
		TChar *str_chr( TChar *s, int c );

	template < typename TChar >
		const TChar *str_chr( const TChar *s, int c );

	template < typename TChar >
		TChar *str_r_chr( TChar *s, int c );

	template < typename TChar >
		const TChar *str_r_chr( const TChar *s, int c );

	template < typename TChar >
		TChar *str_str( TChar *s1, const TChar *s2 );

	template < typename TChar >
		const TChar *str_str( const TChar *s1, const TChar *s2 );
		
	template < typename TChar >
		size_t str_len( const TChar *s );
	*/
}

#endif
