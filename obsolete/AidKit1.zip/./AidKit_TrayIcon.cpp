#include "AidKit_TrayIcon.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Debug.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### SIconData
//###
//#############################################################################
//#############################################################################
//#############################################################################


struct SIconData : public NOTIFYICONDATA {
	SIconData( CWnd *NotifyWnd, UINT IconID );

	void SetIcon( HICON Icon );
	void SetToolTip( const char_t ToolTip[] );
	void SetCallbackMessage( UINT CallbackMessage );
};


//=============================================================================
SIconData::SIconData( CWnd *NotifyWnd, UINT IconID )
//=============================================================================
{
	COMPILER_ASSERT( sizeof( *this ) == sizeof( NOTIFYICONDATA ));

	memset( this, 0, sizeof( *this ));

	cbSize = sizeof( this );
	hWnd = NotifyWnd->m_hWnd;
	uID  = IconID;
}



//=============================================================================
void SIconData::SetIcon( HICON Icon )
//=============================================================================
{
	hIcon = Icon;
	uFlags |= NIF_ICON;
}



//=============================================================================
void SIconData::SetToolTip( const char_t ToolTip[] )
//=============================================================================
{
	str_n_cpy( szTip, ToolTip, countof( szTip ));
	uFlags |= NIF_TIP;
}



//=============================================================================
void SIconData::SetCallbackMessage( UINT CallbackMessage )
//=============================================================================
{
	uCallbackMessage = CallbackMessage;
	uFlags |= NIF_MESSAGE;
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTrayIcon
//###
//#############################################################################
//#############################################################################
//#############################################################################


// This message will be send whenever the explorer starts/recreates the taskbar:

static const UINT WM_TASKBARCREATED = RegisterWindowMessage( TEXT( "TaskbarCreated" ));

//=============================================================================
CTrayIcon::CTrayIcon( void )
//=============================================================================
{
	my_nIdentifier = 0;
	my_pNotifyWnd  = NULL;
}



//=============================================================================
CTrayIcon::~CTrayIcon( void )
//=============================================================================
{
	if ( my_pNotifyWnd != NULL )
		Destroy();
}



//=============================================================================
BOOL CTrayIcon::Create( CWnd *pNotifyWnd, UINT nMessage, UINT nIdentifier,
	HICON hIcon, const char_t ToolTip[] )
//=============================================================================
{
	BOOL Success = FALSE;

	if ( my_pNotifyWnd == NULL ) {
		my_pNotifyWnd  = pNotifyWnd;
		my_nIdentifier = nIdentifier;

		SIconData IconData( my_pNotifyWnd, my_nIdentifier );
		IconData.SetIcon( hIcon );
		IconData.SetToolTip( ToolTip );
		IconData.SetCallbackMessage( nMessage );
		Success = Shell_NotifyIcon( NIM_ADD, &IconData );
	}
	return ( Success );
}



//=============================================================================
BOOL CTrayIcon::Destroy( void )
//=============================================================================
{
	BOOL Success = FALSE;

	if ( my_pNotifyWnd != NULL ) {
		SIconData IconData( my_pNotifyWnd, my_nIdentifier );
		Success = Shell_NotifyIcon( NIM_DELETE, &IconData );

		my_pNotifyWnd = NULL;
	}
	return ( Success );
}



//=============================================================================
BOOL CTrayIcon::ChangeIcon( HICON hNewIcon )
//=============================================================================
{
	BOOL Success = FALSE;

	if ( my_pNotifyWnd != NULL ) {
		SIconData IconData( my_pNotifyWnd, my_nIdentifier );
		IconData.SetIcon( hNewIcon );
		Success = Shell_NotifyIcon( NIM_MODIFY, &IconData );
	}
	return ( Success );
}



//=============================================================================
BOOL CTrayIcon::ChangeToolTip( const char_t NewToolTip[] )
//=============================================================================
{
	BOOL Success = FALSE;

	if ( my_pNotifyWnd != NULL ) {
		SIconData IconData( my_pNotifyWnd, my_nIdentifier );
		IconData.SetToolTip( NewToolTip );
		Success = Shell_NotifyIcon( NIM_MODIFY, &IconData );
	}
	return ( Success );
}


} // namespace AidKit
