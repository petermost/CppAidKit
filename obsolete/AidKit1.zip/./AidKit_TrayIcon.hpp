#ifndef AIDKIT_TRAY_ICON_HPP
#define AIDKIT_TRAY_ICON_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"

#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CTrayIcon {
	//-----------------------------------------------------------------------------
		public:
			CTrayIcon( void );
			~CTrayIcon( void );

			BOOL Create( CWnd *pNotifyWnd, UINT nMessage, UINT nIdentifier,
				HICON hIcon, const char_t ToolTip[] );

			BOOL Destroy( void );

			BOOL ChangeIcon( HICON hNewIcon );
			BOOL ChangeToolTip( const char_t NewToolTip[] );

		private:
			LRESULT OnTaskbarCreated( WPARAM, LPARAM );

			UINT my_nIdentifier;
			CWnd *my_pNotifyWnd;
	};

}

#endif

