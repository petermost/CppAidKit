#include "AidKit_Preferences.hpp"
#include "AidKit_String.hpp"
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CPreferences
//###
//#############################################################################
//#############################################################################
//#############################################################################

static const string_t TRUE_TXT( TEXT( "Yes" ));
static const string_t FALSE_TXT( TEXT( "No" ));

//=============================================================================
CPreferences::CPreferences( void )
//=============================================================================
{
}



//=============================================================================
CPreferences::~CPreferences( void )
//=============================================================================
{
}



//=============================================================================
bool CPreferences::Load( CStdFile * )
//=============================================================================
{
	return ( true );
}




//=============================================================================
bool CPreferences::Save( CStdFile * )
//=============================================================================
{
	return ( true );
}



//=============================================================================
bool CPreferences::WriteBool( const string_t &Section, const string_t &Key, bool Value )
//=============================================================================
{
	const string_t &rValue = (( Value ) ? TRUE_TXT : FALSE_TXT );

	return ( WriteString( Section, Key, rValue ));
}



//=============================================================================
bool CPreferences::ReadBool( const string_t &Section, const string_t &Key, bool *pValue )
//=============================================================================
{
	string_t Value;
	if ( ReadString( Section, Key, &Value )) {
		if ( str_i_cmp( Value.c_str(), TRUE_TXT.c_str() ) == 0 ) {
			*pValue = true;
			return ( true );
		} else if ( str_i_cmp( Value.c_str(), FALSE_TXT.c_str() ) == 0 ) {
			*pValue = false;
			return ( true );
		} else {
			return ( false );
		}
	} else
		return ( false );
}



//=============================================================================
bool CPreferences::WriteInteger( const string_t &Section, const string_t &Key, int Value )
//=============================================================================
{
	return ( WriteString( Section, Key, itos( Value )));
}



//=============================================================================
bool CPreferences::ReadInteger( const string_t &Section, const string_t &Key, int *pValue )
//=============================================================================
{
	string_t Value;

	if ( ReadString( Section, Key, &Value )) {
		*pValue = stoi( Value );
		return ( true );
	} else {
		return ( false );
	}
}

//=============================================================================
bool CPreferences::WriteULong( const string_t &Section, const string_t &Key, unsigned long Value )
//=============================================================================
{
	return ( WriteString( Section, Key, ltos( Value )));
}



//=============================================================================
bool CPreferences::ReadULong( const string_t &Section, const string_t &Key, unsigned long *pValue )
//=============================================================================
{
	string_t Value;
	char *tmp;

	if ( ReadString( Section, Key, &Value )) {
		*pValue = StrToUL( Value.c_str() );
		return ( true );
	} else {
		return ( false );
	}
}

} // namespace AidKit
