#ifndef AIDKIT_FILE_HPP
#define AIDKIT_FILE_HPP

#include "AidKit.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_StdError.hpp"

#include <time.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

namespace AidKit {

	typedef TStdError< class CFileSystem > CFileSystemError;

	//-----------------------------------------------------------------------------
	class CFileInfo {
	//-----------------------------------------------------------------------------
		public:
			CFileInfo( void );

			size_t Size;
			time_t ModificationTime;
	};

	//-----------------------------------------------------------------------------
	class CFileSystemBasics {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CFileSystemBasics( void );

		protected:
			virtual CFileInfo DoFileInfo( const string_t &Filename ) const
				throw ( CFileSystemError ) = 0;

			virtual CFileInfo DoFileInfo( int nFile ) const
				throw ( CFileSystemError ) = 0;
	};

}

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_File.hpp"
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_File.hpp"

	namespace AidKit {
		typedef CUnxFileSystemBasics CNativeFileSystemBasics;
	}
#endif

namespace AidKit {

	typedef TStdError< class CStdFile > CStdFileError;

	off_t FileSeek( int File, off_t Offset, int Whence )
		throw ( CStdFileError, assertion_error );

	off_t FileTell( int File )
		throw ( CStdFileError, assertion_error );

	long FileSize( CStdFile *File )
		throw ( CStdFileError );


	//-----------------------------------------------------------------------------
	class CFileSystem : public CNativeFileSystemBasics {
	//-----------------------------------------------------------------------------
		public:
			CFileInfo FileInfo( const string_t &Filename ) const
				throw ( CFileSystemError );

			CFileInfo FileInfo( int nFile ) const
				throw ( CFileSystemError );
	};



	//-----------------------------------------------------------------------------
	class CStdFile {
	//-----------------------------------------------------------------------------
		public:
			static const string_t &Rename( const string_t &OldFilename, const string_t &NewFilename )
				throw ( CStdFileError );

			static void Remove( const string_t &Filename )
				throw ( CStdFileError );

			CStdFile( FILE * = NULL )
				throw ( CStdFileError );

			CStdFile( const string_t &Filename, const string_t &Mode )
				throw ( CStdFileError );

			virtual ~CStdFile( void )
				throw( CStdFileError );

			// Open/Close:

			bool Open( const string_t &Filename, const string_t &Mode , CStdFileError *pError )
				throw ( assertion_error );

			void Open( const string_t &Filename, const string_t &Mode )
				throw ( CStdFileError, assertion_error );

			void Close( void )
				throw ( CStdFileError );

			enum EBufferingMode {
				eModeUnbuffer      = _IONBF,
				eModeLineBuffered  = _IOLBF,
				eModeFullyBuffered = _IOFBF
			};

			void SetVBuf( char *Buffer, size_t Size, EBufferingMode eMode = eModeFullyBuffered )
				throw ( CStdFileError, assertion_error );

			// Read/Write:

			int GetC( void )
				throw ( CStdFileError );

			bool GetLine( string_t *pLine, char_t Delimiter = TEXT( '\n' ))
				throw ( CStdFileError );

			size_t Read( void *Buffer, size_t Size )
				throw ( CStdFileError );

			virtual size_t Read( void *Buffer, size_t Size, size_t Count )
				throw ( CStdFileError );

			size_t Write( const void *Buffer, size_t Size )
				throw ( CStdFileError );

			virtual size_t Write( const void *Buffer, size_t Size, size_t Count )
				throw ( CStdFileError );

			// Misc:

			void Flush( void )
				throw ( CStdFileError );

			void Rewind( void )
				throw ( CStdFileError );

			void ClearError( void )
				throw ( CStdFileError );


			// Seek/Tell:

			long Tell( void )
				throw ( CStdFileError );

			enum EWhence {
				eWhenceSet = SEEK_SET,
				eWhenceCurrent = SEEK_CUR,
				eWhenceEnd = SEEK_END
			};

			void Seek( long Offset, EWhence Whence )
				throw ( CStdFileError, assertion_error );

			// PrintF:

			int VPrintF( const char_t Format[], va_list )
				throw ( CStdFileError );

			int PrintF( const char_t Format[], ... )
				throw ( CStdFileError );

			virtual int FileNo( void )
				throw ( CStdFileError );

			bool IsOpen( void ) const
				throw();

			const string_t &Name( void ) const
				throw();

		protected:
			FILE *my_File;
			string_t my_Filename;

		private:
			CStdFile( const CStdFile & );
			CStdFile &operator = ( const CStdFile & );

	};

	//-----------------------------------------------------------------------------
	class CUnlockedStdFile : public CStdFile {
	//-----------------------------------------------------------------------------
		public:
			CUnlockedStdFile( FILE *File = NULL )
				throw ( CStdFileError );

			CUnlockedStdFile( const string_t &Filename, const string_t &Mode )
				throw ( CStdFileError );

			using CStdFile::Read;

			virtual size_t Read( void *Buffer, size_t Size, size_t Count )
				throw ( CStdFileError );

			using CStdFile::Write;

			virtual size_t Write( const void *Buffer, size_t Size, size_t Count )
				throw ( CStdFileError );

			virtual int FileNo( void )
				throw ( CStdFileError );
	};


	typedef TStdError< class CSysFile > CSysFileError;

	//-----------------------------------------------------------------------------
	class CSysFile {
	//-----------------------------------------------------------------------------
		public:
			CSysFile( int nFile = -1 )
				throw ( CSysFileError );

			CSysFile( const string_t &Filename, int Flags, int Mode )
				throw ( CSysFileError );

			~CSysFile( void )
				throw ( CSysFileError );

			void Open( const string_t &Filename, int Flags, int Mode )
				throw ( CSysFileError );

			void Close( void )
				throw ( CSysFileError );

			size_t Read( void *Buffer, size_t Size )
				throw ( CSysFileError );

			size_t Write( const void *Buffer, size_t Size )
				throw ( CSysFileError );

			bool IsOpen( void ) const
				throw ( CSysFileError );

		private:
			CSysFile( const CSysFile & );
			CSysFile &operator = ( const CSysFile & );

			int my_nFile;
	};

}

#endif
