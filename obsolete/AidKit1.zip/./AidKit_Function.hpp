#ifndef AIDKIT_FUNCTION_HPP
#define AIDKIT_FUNCTION_HPP

// Don't try to add a return type as a template parameter! MSC can't handle
// return ( VoidFunction() ). One workaround would be with partial template
// specialication, but MSC doesn't support them either.

#include "AidKit.hpp"

namespace AidKit {


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TCall, TGenericFunction, TGenericMethod, TMethod, TFunction
//###
//#############################################################################
//#############################################################################
//#############################################################################



//#############################################################################
//
// TCall0, TGenericFunction0, TGenericMethod0, TMethod0, TFunction0
//
//#############################################################################

template < typename R >
	//-----------------------------------------------------------------------------
	class TCall0 {
	//-----------------------------------------------------------------------------
		public:
			virtual ~TCall0( void )
				{ }

			virtual R operator()( void ) const = 0;
	};


template < typename R, typename F >
	//-----------------------------------------------------------------------------
	class TGenericFunction0 : public TCall0< R > {
	//-----------------------------------------------------------------------------
		public:
			TGenericFunction0( F Function )
				: my_Function( Function )
					{ }

			R operator()( void ) const
				{ return ( my_Function() ); }

		private:
			F my_Function;
	};


template < typename R, typename C, typename M >
	//-----------------------------------------------------------------------------
	class TGenericMethod0 : public TCall0< R > {
	//-----------------------------------------------------------------------------
		public:
			TGenericMethod0( C pCallee, M pMethod )
				: my_pCallee( pCallee ), my_pMethod( pMethod )
					{ }

			R operator()( void ) const
				{ return (( my_pCallee->*my_pMethod )() ); }

		private:
			C my_pCallee;
			M my_pMethod;
	};


template < typename R >
	//-----------------------------------------------------------------------------
	class TFunction0 : public TGenericFunction0< R, R ( * )( void ) > {
	//-----------------------------------------------------------------------------
		public:
			TFunction0( void ( *pFunction )( void ))
				: TGenericFunction0< R, R ( * )( void ) >( pFunction )
					{ }
	};

	
template < typename R, typename C >
	//-----------------------------------------------------------------------------
	class TMethod0 : public TGenericMethod0< R, C *, R ( C:: * )( void ) > {
	//-----------------------------------------------------------------------------
		public:
			TMethod0( C *pCallee, R ( C::*pMethod )( void ))
				: TGenericMethod0< R, C *, R ( C:: * )( void ) >( pCallee, pMethod )
					{ }
	};


//#############################################################################
//
// TCall1, TGenericFunction1, TGenericMethod, TMethod1, TFunction1
//
//#############################################################################

template < typename R, typename P1 >
	//-----------------------------------------------------------------------------
	class TCall1 {
	//-----------------------------------------------------------------------------
		public:
			virtual ~TCall1( void )
				{ }

			virtual R operator()( P1 p1 ) const = 0;
	};

template < typename R, typename F, typename P1 >
	//-----------------------------------------------------------------------------
	class TGenericFunction1 : public TCall1< R, P1 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericFunction1( F Function )
				: my_Function( Function )
					{ }

			R operator()( P1 p1 ) const
				{ return ( my_Function( p1 )); }

		private:
			F my_Function;
	};


template < typename R, typename C, typename M, typename P1 >
	//-----------------------------------------------------------------------------
	class TGenericMethod1 : public TCall1< R, P1 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericMethod1( C pCallee, M pMethod )
				: my_pCallee( pCallee ), my_pMethod( pMethod )
					{ }

			R operator()( P1 p1 ) const
				{ return (( my_pCallee->*my_pMethod )( p1 )); }

		private:
			C my_pCallee;
			M my_pMethod;
	};


template < typename R, typename P1 >
	//-----------------------------------------------------------------------------
	class TFunction1 : public TGenericFunction1< R, R ( * )( P1 ), P1 > {
	//-----------------------------------------------------------------------------
		public:
			TFunction1( R ( *pFunction )( P1 ))
				: TGenericFunction1< R, R ( * )( P1 ), P1 >( pFunction )
					{ }
	};


template < typename R, typename C, typename P1 >
	//-----------------------------------------------------------------------------
	class TMethod1 : public TGenericMethod1< R, C *, R ( C::* )( P1 ), P1 > {
	//-----------------------------------------------------------------------------
		public:
			TMethod1( C *pCallee, R ( C::*pMethod )( P1 ))
				: TGenericMethod1< R, C *, R ( C::* )( P1 ), P1 >( pCallee, pMethod )
					{ }
	};


//#############################################################################
//
// TCall2, TGenericFunction2, TGenericMethod2, TMethod2, TFunction2
//
//#############################################################################

template < typename R, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TCall2 {
	//-----------------------------------------------------------------------------
		public:
			virtual ~TCall2( void )
				{ }

			virtual R operator()( P1 p1, P2 p2 ) const = 0;
	};


template < typename R, typename F, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TGenericFunction2 : public TCall2< R, P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericFunction2( F Function )
				: my_Function( Function )
					{ }

			R operator()( P1 p1, P2 p2 ) const
				{ return ( my_Function( p1, p2 )); }

		private:
			F my_Function;
	};


template < typename R, typename C, typename M, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TGenericMethod2 : public TCall2< R, P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericMethod2( C pCallee, M pMethod )
				: my_pCallee( pCallee ), my_pMethod( pMethod )
					{ }

			R operator()( P1 p1, P2 p2 ) const
				{ return (( my_pCallee->*my_pMethod )( p1, p2 )); }

		private:
			C my_pCallee;
			M my_pMethod;
	};


template < typename R, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TFunction2 : public TGenericFunction2< R, R ( * )( P1, P2 ), P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TFunction2( R ( *pFunction )( P1, P2 ))
				: TGenericFunction2< R, R ( * )( P1, P2 ), P1, P2 >( pFunction )
					{ }
	};


template < typename R, typename C, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TMethod2 : public TGenericMethod2< R, C *, R ( C::* )( P1, P2 ), P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TMethod2( C *pCallee, R ( C::*pMethod )( P1, P2 ))
				: TGenericMethod2< R, C *, R ( C::* )( P1, P2 ), P1, P2 >( pCallee, pMethod )
					{ }
	};


//#############################################################################
//
// TCall3, TGenericFunction3, TGenericMethod3, TMethod3, TFunction3
//
//#############################################################################

template < typename R, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TCall3 {
	//-----------------------------------------------------------------------------
		public:
			virtual ~TCall3( void )
				{ }

			virtual R operator()( P1, P2, P3 ) const = 0;
	};

template < typename R, typename F, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TGenericFunction3 : public TCall3< R, P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericFunction3( F Function )
				: my_Function( Function )
					{ }

			R operator()( P1 p1, P2 p2, P3 p3 ) const
				{ return ( my_Function( p1, p2, p3 )); }

		private:
			F my_Function;
	};


template < typename R, typename C, typename M, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TGenericMethod3 : public TCall3< R, P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericMethod3( C pCallee, M pMethod )
				: my_pCallee( pCallee ), my_pMethod( pMethod )
					{ }

			R operator()( P1 p1, P2 p2, P3 p3 ) const
				{ return (( my_pCallee->*my_pMethod )( p1, p2, p3 )); }

		private:
			C my_pCallee;
			M my_pMethod;
	};


template < typename R, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TFunction3 : public TGenericFunction3< R, R ( * )( P1, P2, P3 ), P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TFunction3( R ( *pFunction )( P1, P2, P3 ))
				: TGenericFunction3< R, R ( * )( P1, P2, P3 ), P1, P2, P3 >( pFunction )
					{ }
	};


template < typename R, typename C, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TMethod3 : public TGenericMethod3< R, C *, R ( C::* )( P1, P2, P3 ), P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TMethod3( C *pCallee, R ( C::*pMethod )( P1, P2, P3 ))
				: TGenericMethod3< R, C *, R ( C::* )( P1, P2, P3 ), P1, P2, P3 >( pCallee, pMethod )
					{ }
	};




//#############################################################################
//
// TCall4, TGenericFunction4, TGenericMethod4, TMethod4, TFunction4
//
//#############################################################################

template < typename R, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TCall4 {
	//-----------------------------------------------------------------------------
		public:
			virtual ~TCall4( void )
				{ }

			virtual R operator()( P1, P2, P3, P4 ) const = 0;
	};


template < typename R, typename F, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TGenericFunction4 : public TCall4< R, P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericFunction4( F Function )
				: my_Function( Function )
					{ }

			R operator()( P1 p1, P2 p2, P3 p3, P4 p4 ) const
				{ return ( my_Function( p1, p2, p3, p4 )); }

		private:
			F my_Function;
	};

template < typename R, typename C, typename M, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TGenericMethod4 : public TCall4< R, P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TGenericMethod4( C pCallee, M pMethod )
				: my_pCallee( pCallee ), my_pMethod( pMethod )
					{ }

			R operator()( P1 p1, P2 p2, P3 p3, P4 p4 ) const
				{ return (( my_pCallee->*my_pMethod )( p1, p2, p3, p4 )); }

		private:
			C my_pCallee;
			M my_pMethod;
	};


template < typename R, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TFunction4 : public TGenericFunction4< R, R ( * )( P1, P2, P3, P4 ), P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TFunction4( R ( *pFunction )( P1, P2, P3, P4 ))
				: TGenericFunction4< R, R ( * )( P1, P2, P3, P4 ), P1, P2, P3, P4 >( pFunction )
					{ }
	};


template < typename R, typename C, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TMethod4 : public TGenericMethod4< R, C *, R ( C::* )( P1, P2, P3, P4 ), P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TMethod4( C *pCallee, R ( C::*pMethod )( P1, P2, P3, P4 ))
				: TGenericMethod4< R, C *, R ( C::* )( P1, P2, P3, P4 ), P1, P2, P3, P4 >( pCallee, pMethod )
					{ }
	};


} // namespace AidKit


#endif
