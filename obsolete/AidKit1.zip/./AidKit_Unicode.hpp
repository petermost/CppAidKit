#ifndef AIDKIT_UNICODE_HPP
#define AIDKIT_UNICODE_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Unicode.hpp"

#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Unicode.hpp"

#endif

#include <string>
#include <iosfwd>

#if defined( AIDKIT_GCC_2 )
	namespace std {
		// Is commentet out in string:
		typedef basic_string< wchar_t > wstring;
	}
#endif

namespace AidKit {
	// string:
	#if defined( AIDKIT_UNICODE )
		typedef wchar_t char_t;
		typedef std::wstring string_t;
	#else
		typedef char char_t;
		typedef std::string string_t;
	#endif

	// fstream:
	#if defined( AIDKIT_UNICODE )
		typedef std::wifstream if_stream_t;
		typedef std::wofstream of_stream_t;
		#if !defined( AIDKIT_GCC_2 )
			typedef std::wistringstream i_string_stream_t;
		#endif
	#else
		typedef std::ifstream if_stream_t;
		typedef std::ofstream of_stream_t;
		#if !defined( AIDKIT_GCC_2 )
			typedef std::istringstream i_string_stream_t;
		#endif
	#endif

	char_t char_to_unichar( wchar_t wc );
	wchar_t unichar_to_char( char_t c );

	std::wstring &text_to_wstring( std::wstring *wbuffer, const std::string &text );
	std::wstring &wtext_to_wstring( std::wstring *wbuffer, const std::wstring &wtext );

	std::string &wtext_to_string( std::string *buffer, const std::wstring &wtext );
	std::string &text_to_string( std::string *buffer, const std::string &text );

	string_t &text_to_unitext( string_t *buffer, const std::string &text );
	std::string &unitext_to_string( std::string *buffer, const string_t &itext );

	//-----------------------------------------------------------------------------
	class text {
	//-----------------------------------------------------------------------------
		public:
			text( const std::string &text );
			text( const std::wstring &wtext );

			~text( void );

			operator const char * ( void ) const;
			operator const wchar_t * ( void ) const;

		private:
			std::string my_buffer;
			std::wstring my_wbuffer;
	};

}


#if !defined( _TEXT )
	#define _TEXT( Text ) TEXT( Text )
#endif


// stdio.h:
#if defined( AIDKIT_UNICODE )
	#define print_f   wprintf
	#define scan_f    wscanf
	#define s_scan_f  swscanf
	#define s_print_f swprintf

	#define f_open     _wfopen
	#define f_print_f  fwprintf
	#define vf_print_f vfwprintf
#else
	#define print_f   printf
	#define scan_f    scanf
	#define s_scan_f  sscanf
	#define s_print_f sprintf

	#define f_open     fopen
	#define f_print_f  fprintf
	#define vf_print_f vfprintf
#endif

#if defined( AIDKIT_WINDOWS )
	#if defined( AIDKIT_UNICODE )
		#define sn_print_f  _snwprintf
		#define vsn_print_f _vsnwprintf
	#else
		#define sn_print_f  _snprintf
		#define vsn_print_f _vsnprintf
	#endif
#endif

#if defined( AIDKIT_UNIX )
	#if defined( AIDKIT_UNICODE )
		#define sn_print_f  swprintf
		#define vsn_print_f vswprintf
	#else
		#define sn_print_f  snprintf
		#define vsn_print_f vsnprintf
	#endif
#endif

// string.h:
#if defined( AIDKIT_UNICODE )
	#define str_len    wcslen
	#define str_cpy    wcscpy
	#define str_n_cpy  wcsncpy
	#define str_cmp    wcscmp
	#define str_chr    wcschr
	#define str_r_chr  wcsrchr

	#define str_n_cat  wcsncat
#else
	#define str_len    strlen
	#define str_cpy    strcpy
	#define str_n_cpy  strncpy
	#define str_cmp    strcmp
	#define str_chr    strchr
	#define str_r_chr  strrchr
	#define str_n_cat  strncat
#endif

#if defined( AIDKIT_WINDOWS )
	#if defined( AIDKIT_UNICODE )
		#define str_i_cmp _wcsicmp
	#else
		#define str_i_cmp _stricmp
	#endif
#endif

#if defined( AIDKIT_UNIX )
	#if defined( AIDKIT_UNICODE )
		#define str_i_cmp wcscasecmp
	#else
		#define str_i_cmp strcasecmp
	#endif
#endif

// stdlib.h:
#if defined( AIDKIT_UNICODE )
	#define __arg_v     __wargv
	#define make_path  _wmakepath
	#define split_path _wsplitpath

	#define _i_to_a  _itow
	#define a_to_i   _wtoi
	#define _l_to_a  _ltow
#else
	#define __arg_v    __argv
	#define make_path  _makepath
	#define split_path _splitpath

	#define _i_to_a _itoa
	#define a_to_i  atoi
	#define a_to_l atol
	#define _l_to_a _ltoa
#endif

// time.h:

#if defined( AIDKIT_UNICODE )
	#define str_f_time wcsftime
#else

	#define str_f_time strftime
#endif

// direct.h:
#if defined( AIDKIT_UNICODE )
	#define _get_cwd _wgetcwd
	#define _ch_dir  _wchdir
#else
	#define _get_cwd _getcwd
	#define _ch_dir  _chdir
#endif

// io.h:
#if defined( AIDKIT_UNICODE )
	#define _find_data_t _wfinddata_t
	#define _find_first  _wfindfirst
	#define _find_next   _wfindnext
#else
	#define _find_data_t _finddata_t
	#define _find_first  _findfirst
	#define _find_next   _findnext
#endif

// ctype.h:
#if defined( AIDKIT_UNICODE )
	#define to_upper towupper
	#define is_cntrl iswcntrl
	#define is_digit iswdigit
	#define is_space iswspace
#else
	#define to_upper toupper
	#define is_cntrl iscntrl
	#define is_digit isdigit
	#define is_space isspace
#endif


// windows:
#if defined( AIDKIT_WINDOWS )
	#if defined( AIDKIT_UNICODE )
		#define Win_Main wWinMain
		#define std_main wmain
	#else
		#define Win_Main WinMain
		#define std_main main
	#endif
#endif

#endif
