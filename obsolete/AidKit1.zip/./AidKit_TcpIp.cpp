#include "AidKit_TcpIp.hpp"
#include "AidKit_Misc.hpp"
#include <AfxSock.h>
#include <AfxCmn.h>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTcpIpAddress
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
static bool transfer_host_bytes( const hostent *pHost, int *pField0, int *pField1, int *pField2,
	int *pField3 )
//=============================================================================
{
	bool Transfered;

	if ( pHost->h_addr_list[ 0 ] != NULL && pHost->h_length == 4 ) {
		*pField0 = pHost->h_addr_list[ 0 ][ 0 ];
		*pField1 = pHost->h_addr_list[ 0 ][ 1 ];
		*pField2 = pHost->h_addr_list[ 0 ][ 2 ];
		*pField3 = pHost->h_addr_list[ 0 ][ 3 ];
		Transfered = true;
	} else {
		*pField0 = *pField1 = *pField2 = *pField3 = 0;
		Transfered = false;
	}
	return ( Transfered );
}


//=============================================================================
CTcpIpAddress::CTcpIpAddress( void )
//=============================================================================
{
	my_Field0 = my_Field1 = my_Field2 = my_Field3 = 0;
	my_Port = 0;
}



//=============================================================================
CTcpIpAddress::CTcpIpAddress( const hostent *pHost, unsigned Port )
//=============================================================================
{
	if ( transfer_host_bytes( pHost, &my_Field0, &my_Field1, &my_Field2, &my_Field3 ))
		my_Port = Port;
	else
		my_Port = 0;
}


//=============================================================================
CTcpIpAddress::CTcpIpAddress( const string_t &String, unsigned Port )
//=============================================================================
{
	hostent *pHost;

	if ( s_scan_f( String.c_str(), TEXT( "%d.%d.%d.%d" ), &my_Field0, &my_Field1, &my_Field2, &my_Field3 ) == 4 )
		my_Port = Port;
	else if (( pHost = gethostbyname( text( String.c_str() ))) != NULL ) {
		if ( transfer_host_bytes( pHost, &my_Field0, &my_Field1, &my_Field2, &my_Field3 ))
			my_Port = Port;
		else
			my_Port = 0;
	} else {
		my_Field0 = my_Field1 = my_Field2 = my_Field3 = 0;
		my_Port = 0;
	}
}



//=============================================================================
CTcpIpAddress::CTcpIpAddress( BYTE Byte0, BYTE Byte1, BYTE Byte2, BYTE Byte3, unsigned Port )
//=============================================================================
{
	my_Field0 = Byte0;
	my_Field1 = Byte1;
	my_Field2 = Byte2;
	my_Field3 = Byte3;
	my_Port = Port;
}



//=============================================================================
bool CTcpIpAddress::operator == ( const CTcpIpAddress &Other ) const
//=============================================================================
{
	return ( my_Field0 == Other.my_Field0 && my_Field1 == Other.my_Field1
		&& my_Field2 == Other.my_Field2 && my_Field3 == Other.my_Field3
		&& my_Port == Other.my_Port );
}



//=============================================================================
bool CTcpIpAddress::operator != ( const CTcpIpAddress &Other ) const
//=============================================================================
{
	return ( ! ( *this == Other ));
}



//=============================================================================
bool CTcpIpAddress::IsEmpty( void ) const
//=============================================================================
{
	return ( my_Field0 == 0 && my_Field1 == 0 && my_Field2 == 0 && my_Field3 == 0
		&& my_Port == 0 );
}




//=============================================================================
const string_t CTcpIpAddress::Host( void ) const
//=============================================================================
{
	char_t szString[ 20 ];
	int StringLength;

	StringLength = sn_print_f( szString, countof( szString ), TEXT( "%d.%d.%d.%d" ),
		my_Field0, my_Field1, my_Field2, my_Field3 );

	return ( string_t( szString, StringLength ));
}



//=============================================================================
unsigned CTcpIpAddress::Port( void ) const
//=============================================================================
{
	return ( my_Port );
}



//=============================================================================
void CTcpIpAddress::AsBytes( BYTE *pByte0, BYTE *pByte1,
	BYTE *pByte2, BYTE *pByte3, unsigned *pPort ) const
//=============================================================================
{
	#pragma warning( disable : 4244 ) // conversion from 'const int' to 'unsigned char', possible loss of data

	*pByte0 = my_Field0;
	*pByte1 = my_Field1;
	*pByte2 = my_Field2;
	*pByte3 = my_Field3;
	*pPort = my_Port;
}

} // namespace AidKit
