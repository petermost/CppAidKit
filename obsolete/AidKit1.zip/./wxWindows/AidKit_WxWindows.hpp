#ifndef AIDKIT_WXWINDOWS_HPP
#define AIDKIT_WXWINDOWS_HPP

#include "../AidKit_Compiler.hpp"

// These settings are described in 'Technical Note 0010' (tn0010.htm)

// Because they are already seperated for debug and release builds, I simply
// converted them to preprocessor defines and did not extract those settings
// which have to be set for both builds.

// Problems:
// 1) To get the memory checking running under linux it was necessary to patch
// the 'setup.h.in' from '#define wxUSE_DEBUG_CONTEXT 0' to '#define wxUSE_DEBUG_CONTEXT 1'
// The switch for configure '--enable-debug_cntxt' didn't seem to work!

// 2) In the file 'memory.h' it was necessary to add the exception specification
// to 'operator new' and 'operator delete'

#if defined( AIDKIT_MSC )
	#if defined( AIDKIT_DEBUG )
		#define WIN32
		#define _DEBUG
		#define _WINDOWS

		#define __WINDOWS__
		#define __WXMSW__
		#define __WXDEBUG__
		#define WXDEBUG 1
		#define __WIN95__
		#define __WIN32__
		#define WINVER 0x0400
		#define STRICT

		#pragma comment( lib, "wxd.lib" )
	#else
		#define NDEBUG
		#define WIN32
		#define _WINDOWS

		#define __WINDOWS__
		#define __WXMSW__
		#define __WIN95__
		#define __WIN32__
		#define WINVER 0x0400
		#define STRICT

		#pragma comment( lib, "wx.lib" )
	#endif

	#pragma comment( lib, "ws2_32.lib" )
	#pragma comment( lib, "comctl32.lib" )
	#pragma comment( lib, "rpcrt4.lib" )
#endif

#endif // AIDKIT_WXWINDOWS_HPP
