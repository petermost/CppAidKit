#ifndef AIDKIT_STL_HELPER_HPP
#define AIDKIT_STL_HELPER_HPP

#include "AidKit.hpp"
#include "AidKit_Error.hpp"
#include "AidKit_StdError.hpp"

#include <stdexcept>
#include <map>

namespace AidKit {

	//#############################################################################
	//#############################################################################
	//#############################################################################
	//###
	//### string_helper
	//###
	//#############################################################################
	//#############################################################################
	//#############################################################################

	template < typename container_t >
		//=============================================================================
		void string_clear( container_t *container )
		//=============================================================================
		{
			#if !defined( AIDKIT_GCC_2 )
				container->clear();
			#else
				container->erase();
			#endif
		}


	//#############################################################################
	//#############################################################################
	//#############################################################################
	//###
	//### vector_helper
	//###
	//#############################################################################
	//#############################################################################
	//#############################################################################

	template < typename container_t >
		//=============================================================================
		typename container_t::reference vector_at( container_t &container, typename container_t::size_type n )
			throw ( std::out_of_range )
		//=============================================================================
		{
			#if !defined( AIDKIT_GCC_2 )
				return ( container.at( n ));
			#else
				if ( n >= container.size() )
					throw ( std::out_of_range( "vector_at" ));

				return ( container[ n ] );
			#endif
		}


	template < typename container_t >
		//=============================================================================
		typename container_t::const_reference vector_at( const container_t &container, typename container_t::size_type n )
			throw ( std::out_of_range )
		//=============================================================================
		{
			#if !defined( AIDKIT_GCC_2 )
				return ( container.at( n ));
			#else
				if ( n >= container.size() )
					throw ( std::out_of_range( "vector_at" ));

				return ( container[ n ] );
			#endif
		}
	
		

	//#############################################################################
	//#############################################################################
	//#############################################################################
	//###
	//### list helper
	//###
	//#############################################################################
	//#############################################################################
	//#############################################################################

	template < typename container_t >
		//=============================================================================
		void list_erase_pointer( container_t *container, const typename container_t::value_type pointer )
		//=============================================================================
		{
			for ( typename container_t::iterator iterator = container->begin(); iterator != container->end();  ) {
				if ( *iterator == pointer ) {
					delete *iterator;
					container->erase( iterator++ );
				} else
					++iterator;
			}
		}


	template < typename container_t >
		//=============================================================================
		void list_erase_pointers( container_t *container )
		//=============================================================================
		{
			for ( typename container_t::iterator iterator = container->begin(); iterator != container->end();  ) {
				delete *iterator;
				container->erase( iterator++ );
			}
		}


	//#############################################################################
	//#############################################################################
	//#############################################################################
	//###
	//### map helper
	//###
	//#############################################################################
	//#############################################################################
	//#############################################################################

	typedef generic_exception< class map > map_error;

	template < typename container_t >
		//=============================================================================
		bool map_insert( container_t *container, const typename container_t::key_type &key,
			const typename container_t::mapped_type &value )
		//=============================================================================
		{
			typedef std::pair< typename container_t::iterator, bool > insert_iterator_t;
			
			insert_iterator_t insert_iterator =
				container->insert( typename container_t::value_type( key, value ));

			return ( insert_iterator.second );
		}


	template < typename container_t >
		//=============================================================================
		typename container_t::iterator map_insert( container_t *container,
			const typename container_t::key_type &key )
		//=============================================================================
		{
			typedef std::pair< typename container_t::iterator, bool > insert_iterator_t;
			
			insert_iterator_t insert_iterator =
				container->insert( typename container_t::value_type( key, typename container_t::referent_type() ));

			// If the value could be inserted, then return the iterator to the inserted
			// element, otherwise return the end-iterator:

			return (( insert_iterator.second ) ? insert_iterator.first : container->end() );
		}


	template < typename container_t >
		//=============================================================================
		bool map_find( const container_t &container, const typename container_t::key_type &key,
			typename container_t::mapped_type *value )
		//=============================================================================
		{
			typename container_t::const_iterator find_iterator = container.find( key );
			if ( find_iterator != container.end() )
				*value = find_iterator->second;

			return ( find_iterator != container.end() );
		}


	template < typename container_t >
		//=============================================================================
		bool map_erase( container_t *container, const typename container_t::key_type &key )
		//=============================================================================
		{
			return ( container->erase( key ) >= 1 );


		}


	template < typename container_t >
		//=============================================================================
		void xmap_insert( container_t *container, const typename container_t::key_type &key,
			const typename container_t::mapped_type &value )
				throw ( map_error )
		//=============================================================================
		{
			if ( !map_insert( container, key, value )) {
				throw ( map_error( "insert" ));
			}
		}


	template < typename container_t >
		//=============================================================================
		void xmap_find( const container_t &container, const typename container_t::key_type &key,
			typename container_t::mapped_type *value )
				throw ( map_error )
		//=============================================================================
		{
			if ( !map_find( container, key, value )) {
				throw ( map_error( "find" ));
			}
		}

	template < typename container_t >
		//=============================================================================
		void xmap_erase( container_t *container, const typename container_t::key_type &key )
			throw ( map_error )
		//=============================================================================
		{
			if ( !map_erase( container, key )) {
				throw ( map_error( "erase" ));
			}
		}


	//#############################################################################
	//#############################################################################
	//#############################################################################
	//###
	//### set helper
	//###
	//#############################################################################
	//#############################################################################
	//#############################################################################

	template < typename container_t >
		//=============================================================================
		bool set_insert( container_t *container, const typename container_t::value_type &value )
		//=============================================================================
		{
			typedef std::pair< typename container_t::iterator, bool > insert_iterator_t;

			insert_iterator_t insert_iterator = container->insert( value );
			return ( insert_iterator.second );
		}



	template < typename container_t >
		//=============================================================================
		bool set_find( const container_t &container, const typename container_t::value_type &value )
		//=============================================================================
		{
			typename container_t::const_iterator find_iterator = container.find( value );

			return ( find_iterator != container.end() );
		}
		
}

#endif
