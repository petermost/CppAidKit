#ifndef AIDKIT_SERIALIZE_HELPER_HPP
#define AIDKIT_SERIALIZE_HELPER_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Serialize.hpp"

namespace AidKit {

template < typename CKey, typename CValue >
	//-----------------------------------------------------------------------------
	class TMapSerializerTraits {
	//-----------------------------------------------------------------------------
		public:
			static bool DoWriteKey( CSerializer *pSerializer, const string_t &KeyName, const CKey &Key )
				{ return ( pSerializer->WriteString( KeyName, Key )); }

			static bool DoWriteValue( CSerializer *pSerializer, const string_t &ValueName, const CValue &Value )
				{ return ( pSerializer->WriteObject( ValueName, &Value )); }

			static bool DoWriteValue( CSerializer *pSerializer, const string_t &ValueName, const CValue *pValue )
				{ return ( pSerializer->WriteObject( ValueName, pValue )); }
	};


template < typename CKey, typename CValue >
	//-----------------------------------------------------------------------------
	class TMapDeserializerTraits {
	//-----------------------------------------------------------------------------
		public:
			static bool DoReadKey( CDeserializer *pDeserializer, const string_t &KeyName, CKey *pKey )
				{ return ( pDeserializer->ReadString( KeyName, pKey )); }

			static bool DoReadValue( CDeserializer *pDeserializer, const string_t &ValueName, CValue *pValue )
				{ return ( pDeserializer->ReadObject( ValueName, pValue )); }
	};

template < typename CMap, typename CTraits = TMapSerializerTraits< typename CMap::key_type, typename CMap::mapped_type > >
	//-----------------------------------------------------------------------------
	class TMapSerializer {
	//-----------------------------------------------------------------------------
		public:
			bool Serialize( CSerializer *pSerializer, const CMap &rMap, const string_t &KeyName, const string_t &ValueName )
			{
				int n;
				string_t Key;
				typename CMap::const_iterator itValue;

				for ( n = 0, itValue = rMap.begin(); itValue != rMap.end(); ++n, ++itValue ) {
					Key = string_printf( TEXT( "%s[%d]" ), KeyName.c_str(), n );
					if ( !CTraits::DoWriteKey( pSerializer, Key, itValue->first ))
						return ( false );

					Key = string_printf( TEXT( "%s[%d]" ), ValueName.c_str(), n );
					if ( !CTraits::DoWriteValue( pSerializer, Key, itValue->second ))
						return ( false );
				}
				return ( true );
			}
	};

/*
template < typename CMap, typename CTraits = TMapDeserializerTraits< typename CMap::key_type, typename CMap::mapped_type > >
	//-----------------------------------------------------------------------------
	class TMapDeserializer {
	//-----------------------------------------------------------------------------
		public:
			bool Deserialize( CDeserializer *pDeserializer, CMap *pMap, const string_t &KeyName, const string_t &ValueName )
			{
				int n;
				string_t Key;
				typename CMap::key_type KeyEntry;
				typename CMap::mapped_type ValueEntry;

				for ( n = 0; n < INT_MAX; ++n ) {
					Key = string_printf( TEXT( "%s[%d]" ), KeyName.c_str(), n );
					if ( !CTraits::DoReadKey( pDeserializer, Key, &KeyEntry ))
						return ( false );

					Key = string_printf( TEXT( "%s[%d]" ), ValueName.c_str(), n );
					if ( !CTraits::DoReadValue( pDeserializer, Key, &ValueEntry ))
						return ( false );

					pMap->insert( typename CMap::value_type( KeyEntry, ValueEntry ));
				}
				return ( true );
			}
	};
*/


template < typename CMap, typename CTraits = TMapDeserializerTraits< typename CMap::key_type, typename CMap::mapped_type > >
	//-----------------------------------------------------------------------------
	class TMapDeserializer {
	//-----------------------------------------------------------------------------
		public:
			bool Deserialize( CDeserializer *pDeserializer, CMap *pMap, const string_t &KeyName, const string_t &ValueName )
			{
				typedef std::pair< typename CMap::iterator, bool > iterator_bool_t;
				int n;
				string_t Key;
				typename CMap::key_type KeyEntry;
				iterator_bool_t InsertResult;

				for ( n = 0; n < INT_MAX; ++n ) {
					Key = string_printf( TEXT( "%s[%d]" ), KeyName.c_str(), n );
					if ( CTraits::DoReadKey( pDeserializer, Key, &KeyEntry )) {
						InsertResult = pMap->insert( typename CMap::value_type( KeyEntry, typename CMap::mapped_type() ));
						if ( InsertResult.second ) {
							Key = string_printf( TEXT( "%s[%d]" ), ValueName.c_str(), n );
							if ( !CTraits::DoReadValue( pDeserializer, Key, &InsertResult.first->second )) {
								pMap->erase( InsertResult.first );
								return ( false );
							}
						}
					} else
						return ( true );
				}
				return ( false );
			}
	};


template < typename CObject >
	//-----------------------------------------------------------------------------
	class TGenericObjectDeserializer : public CDeserializable {
	//-----------------------------------------------------------------------------
		public:
			TGenericObjectDeserializer( CObject *pObject, const char_t TypeName[],
				bool ( *Deserialize )( CDeserializer *, CObject * ))
				{
					my_pObject = pObject;
					my_TypeName = TypeName;
					my_Deserialize = Deserialize;
				}

		protected:
			virtual bool Deserialize( CDeserializer *pDeserializer )
				{ return ( my_Deserialize( pDeserializer, my_pObject )); }

			virtual string_t TypeName( void ) const
				{ return ( my_TypeName ); }

		private:
			CObject *my_pObject;
			string_t my_TypeName;
			bool ( *my_Deserialize )( CDeserializer *, CObject * );
	};



template < typename CObject >
	//-----------------------------------------------------------------------------
	class TGenericObjectSerializer : public CSerializable {
	//-----------------------------------------------------------------------------
		public:
			TGenericObjectSerializer( const CObject &rObject, const string_t &TypeName,
				bool ( *Serialize )( CSerializer *, const CObject & ))
				: my_rObject( rObject )
				{
					my_TypeName = TypeName;
					my_Serialize = Serialize;
				}

		protected:
			virtual bool Serialize( CSerializer *pSerializer ) const
				{ return ( my_Serialize( pSerializer, my_rObject )); }

			virtual string_t TypeName( void ) const
				{ return ( my_TypeName ); }

		private:
			const CObject &my_rObject;
			string_t my_TypeName;
			bool ( *my_Serialize )( CSerializer *, const CObject & );
	};

} // namespace AidKit

#endif
