#ifndef AIDLIB_ENUM_HPP
#define AIDLIB_ENUM_HPP

#include "AidLib.hpp"

namespace AidLib {

	template < typename CEnum >
		//-----------------------------------------------------------------------------
		class TEnum {
		//-----------------------------------------------------------------------------
			public:
				TEnum( const CEnum eEnum = CEnum() )
					{ *this = eEnum; }

				TEnum( const char *pEnumString )
					{ *this = pEnumString; }

				const CEnum operator = ( const CEnum eEnum )
					{ return ( _eEnum = eEnum ); }

				const CEnum operator = ( const char *pEnumString )
					{ return ( _eEnum = ConvertFromString( pEnumString )); }

				operator const CEnum ( void ) const
					{ return ( _eEnum ); }

				operator const char * ( void ) const
					{ return ( ConvertToString( _eEnum )); }

				const char *AsString( void ) const
					{ return ( static_cast< const char * >( *this )); }

			private:
				CEnum _eEnum;

				// You have to write the convert-functions yourself, otherwise
				// you will get linker errors.

				static const CEnum ConvertFromString( const char *pEnumString );
				static const char *ConvertToString( const CEnum eEnum );
		};

}

#endif
