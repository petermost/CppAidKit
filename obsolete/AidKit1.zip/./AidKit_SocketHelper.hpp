#ifndef AIDKIT_SOCKET_HELPER_HPP
#define AIDKIT_SOCKET_HELPER_HPP

#include "AidKit.hpp"
#include "AidKit_Time.hpp"
#include "AidKit_Socket.hpp"
#include <vector>

struct timeval;

namespace AidKit {

	//---------------------------------------------------------
	class CFdSet : public fd_set {
	//---------------------------------------------------------
		public:
			CFdSet( void );

			void Set( socket_t s )
				throw ( assertion_error );

			bool IsSet( socket_t s ) const
				throw ( assertion_error );

			socket_t Highest( void ) const;

		private:
			void Clr( socket_t s ); // Not supported!

			socket_t my_Highest;
	};

	//---------------------------------------------------------
	class CSelectable {
	//---------------------------------------------------------
		public:
			CSelectable( void );
			virtual ~CSelectable( void );

			virtual int ReadableHandle( void ) const = 0;
			virtual int WritableHandle( void ) const = 0;
	};

	int Select( CFdSet *pInputSet, CFdSet *pOutputSet, CFdSet *pExceptSet,
		milliseconds_t Timeout );
}

#endif
