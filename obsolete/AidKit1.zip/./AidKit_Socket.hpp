#ifndef AIDKIT_SOCKET_HPP
#define AIDKIT_SOCKET_HPP

#include "AidKit.hpp"
#include "AidKit_Time.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Unicode.hpp"
#include "Unix/AidKit_Unix_Selector.hpp"

#include <limits.h>

struct sockaddr;
struct servent;

namespace AidKit {

	typedef int port_t;
	const port_t INVALID_PORT = -1;

	//---------------------------------------------------------
	class CSocketBasics {
	//---------------------------------------------------------
		public:
			virtual ~CSocketBasics( void )
				throw();

			enum EType {
				eTypeInetV4,
				eTypeInetV6,
				eTypeLocal
			};

			enum EDirection {
				eDirectionRead,
				eDirectionWrite,
				eDirectionReadWrite
			};

			enum EMode {
				eModeBlock,
				eModeUnblock
			};

			enum EOption {
				eOptionReuseAddress,
				eOptionError,
				eOptionSendBufferSize,
				eOptionReceiveBufferSize,
				eOptionKeepAlive
			};

			enum ETcpOption {
				eTcpOptionKeepAliveTime,
				eTcpOptionKeepAliveInterval,
				eTcpOptionKeepAliveProbes,

				eTcpOptionCork
			};

			enum EReceiveFlag {
				eReceiveFlag_None     = 0x00,
				eReceiveFlag_OOB      = 0x01,
				eReceiveFlag_WaitAll  = 0x02,
				eReceiveFlag_NoSignal = 0x04,
				eReceiveFlag_Peek     = 0x08
			};

			enum ESendFlag {
				eSendFlag_None     = 0x00,
				eSendFlag_OOB      = 0x01,
				eSendFlag_DontWait = 0x02,
				eSendFlag_NoSignal = 0x04
			};

	};

} // namespace AidKit

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Socket.hpp"
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Socket.hpp"
#endif


namespace AidKit {

	int CheckSocketApi( int nResult )
		throw ( CSocketError );

	//---------------------------------------------------------
	class CSocketUtil {
	//---------------------------------------------------------
		public:
			static const char_t PROTOCOL_NAME_TCP[];
			static const char_t PROTOCOL_NAME_UDP[];

			/// Determine the standard port for the requested service.
			static port_t ServicePort( const char_t ServiceName[], const char_t ProtocolName[] = PROTOCOL_NAME_TCP )
				throw ( CSocketError );

			static int SocketType( const char_t ProtocolName[] )
				throw ( CSocketError, assertion_error );

			static int ProtocolType( const char_t ProtocolName[] )
				throw ( CSocketError );

			static string_t HostName( void )
				throw ( CSocketError );
	};

	//---------------------------------------------------------
	struct SSocketPeer {
	//---------------------------------------------------------
		string_t Name;
		port_t Port;
	};

	//---------------------------------------------------------
	class CSocket : public CNativeSocketBasics {
	//---------------------------------------------------------
		public:
			CSocket( void )
				throw ( CSocketError );

			virtual ~CSocket( void )
				throw();

			bool Open( EType eType = eTypeInetV4 )
				throw ( CSocketError, assertion_error );

			bool IsOpen( void ) const
				throw();

			void Shutdown( EDirection = eDirectionReadWrite )
				throw ( CSocketError, assertion_error );

			bool Close( void )
				throw ( CSocketError, assertion_error );

			void SetOption( EOption eOption, int nOptionValue = true )
				throw ( CSocketError, assertion_error );

			int GetOption( EOption eOption )
				throw ( CSocketError, assertion_error );

			void SetTcpOption( ETcpOption eOption, int nOptionValue = true )
				throw ( CSocketError, assertion_error );

			int GetTcpOption( ETcpOption eOption )
				throw ( CSocketError, assertion_error );

			EMode IOControl( EMode eMode )
				throw ( CSocketError, assertion_error );

			void Notify( void )
				throw ( CSocketError, assertion_error );

			bool IsNotified( void )
				throw ();

			int Select( CFdSet *pInputSet, CFdSet *pOutputSet, CFdSet *pExceptSet,
				milliseconds_t Timeout = INFINITE_MILLISECONDS, bool IsNotifiable = false )
					throw ( CSocketError, assertion_error );

			bool Connect( const char_t HostName[], port_t nPort )
				throw ( CSocketError, assertion_error );

			void Bind( port_t nPort= INVALID_PORT, const char_t HostName[] = NULL )
				throw ( CSocketError, assertion_error );

			void Listen( int nBackLog )
				throw ( CSocketError, assertion_error );

			CSocket *Accept( CSocket *pSocket, in_addr *pAddress = NULL )
				throw ( CSocketError, assertion_error );

			size_t Receive( void *pData, size_t nDataSize, unsigned Flags = eReceiveFlag_None )
					throw ( CSocketError, assertion_error );

			size_t Send( const void *pData, size_t nDataSize, unsigned Flags = eSendFlag_None )
				throw ( CSocketError, assertion_error );

			size_t Send( file_t hFile, off_t *pOffset, size_t Count )
				throw ( CSocketError, assertion_error );

			SSocketPeer Peer( void ) const
				throw ( CSocketError, assertion_error );

			port_t Port( void ) const
				throw ( CSocketError, assertion_error );

			operator socket_t ( void ) const
				{ return ( my_hSocket ); }

		private:
			CSocket( const CSocket &OtherSocket );
			CSocket &operator = ( const CSocket &OtherSocket );

			socket_t my_hSocket;
			Unix::CSelector my_Selector;
	};

	//---------------------------------------------------------
	class CSocketBase {
	//---------------------------------------------------------
		public:
			CSocketBase( void )
				throw ( CSocketError, assertion_error );

			virtual ~CSocketBase( void )
				throw ();

			void Notify( void )
				throw ( CSocketError, assertion_error );

			bool IsNotified( void )
				throw();

			bool IsConnected( void ) const
				throw();

		protected:
			CSocket my_Socket;
	};

	//---------------------------------------------------------
	class CSocketConnection : public CSocketBase {
	//---------------------------------------------------------
		public:
			friend class CServerSocket;

			CSocketConnection( void )
				throw( CSocketError, assertion_error );

			virtual ~CSocketConnection( void )
				throw();

			void Shutdown( void )
				throw ( CSocketError, assertion_error );

			void SetOption( CSocket::EOption, int Value = true )
				throw ( CSocketError, assertion_error );

			void SetTcpOption( CSocket::ETcpOption, int Value )
				throw ( CSocketError, assertion_error );

			CSocket::EMode IOControl( CSocket::EMode eMode )
				throw ( CSocketError, assertion_error );

			virtual void Disconnect( void )
				throw ( CSocketError, assertion_error );



			bool CanSend( milliseconds_t Timeout = INFINITE_MILLISECONDS, bool IsNotifiable = false )
				throw ( CSocketError, assertion_error );

			bool CanReceive( milliseconds_t Timeout = INFINITE_MILLISECONDS, bool IsNotifiable = false )
				throw ( CSocketError, assertion_error );

			bool CanTransmit( bool *pCanSend, bool *pCanReceive,
				milliseconds_t Timeout = INFINITE_MILLISECONDS, bool IsNotifiable = false )
					throw ( CSocketError, assertion_error );



			size_t Send( const void *pData, size_t nDataSize, unsigned Flags = CSocket::eSendFlag_None )
				throw ( CSocketError, assertion_error );

			size_t Send( file_t hDataFile, off_t *pDataOffset, size_t nDataSize )
				throw ( CSocketError, assertion_error );

			size_t Receive( void *pData, size_t nDataSize, unsigned Flags = CSocket::eReceiveFlag_None )
				throw ( CSocketError, assertion_error );


			size_t Read( void *pData, size_t nDataSize )
				throw ( CSocketError, assertion_error );

			size_t Read( void *pData, size_t nDataSize,
				milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime,
				bool IsNotifiable )
					throw ( CSocketError, assertion_error );

			/// Writes the data into the socket.
			/// @param pData is a pointer to the data.
			/// @param nDataSize is the size of the data.
			/// @return if successful, then the number of written bytes are
			///         returned.

			size_t Write( const void *pData, size_t DataSize )
				throw ( CSocketError, assertion_error );

			size_t Write( const void *pData, size_t nDataSize,
				milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime,
				bool IsNotifiable )
					throw ( CSocketError, assertion_error );

			size_t Write( file_t hDataFile, off_t *pDataOffset, size_t nDataSize,
				milliseconds_t BlockWaitingTime = INFINITE_MILLISECONDS,
				milliseconds_t CharWaitingTime = INFINITE_MILLISECONDS,
				bool IsNotifiable = false )
					throw ( CSocketError, assertion_error );

			SSocketPeer Peer( void ) const
				throw ( CSocketError, assertion_error );

			port_t Port( void ) const
				throw ( CSocketError, assertion_error );
	};


	//---------------------------------------------------------
	class CClientSocket : public CSocketConnection {
	//---------------------------------------------------------
		public:
			CClientSocket( void )
				throw ( CSocketError, assertion_error );

			~CClientSocket( void )
				throw();

			/// Connects to a server.
			/// @param HostName is the host name of the server.
			/// @param Port contains the port number.
			bool Connect( const char_t HostName[], port_t Port,  milliseconds_t WaitingTime = INFINITE_MILLISECONDS )
				throw ( CSocketError, assertion_error );
	};




	//---------------------------------------------------------
	class CServerSocket : public CSocketBase {
	//---------------------------------------------------------
		public:
			CServerSocket( void )
				throw ( CSocketError, assertion_error );

			~CServerSocket( void )
				throw();

			/// Binds the socket to the given port number.
			/// @param Port to bind the socket to. If this parameter is -1 then the next
			///        free port will be chosen.
			/// @return The given port or the chosen one.
			port_t Bind( port_t nPort = INVALID_PORT, const char_t HostName[] = NULL )
				throw ( CSocketError, assertion_error );

			void Listen( int nMaxListener )
				throw ( CSocketError, assertion_error );

			/// Checks wether an accept can be called without blocking.
			/// @param WaitingTime specifies how long CanAccept waits.
			/// @param pRemainingTime will be updated with the remaining
			///        waiting time.
			/// @see Cancel()

			CSocketConnection *Accept( CSocketConnection *pSocket, milliseconds_t WaitingTime = INFINITE_MILLISECONDS )
				throw ( CSocketError, assertion_error );
					
			void Refuse( void )
				throw ( CSocketError, assertion_error );

			bool IsBound( void ) const
				throw();

			bool IsListening( void ) const
				throw();

		private:
			enum EState {
				eStateClosed,
				eStateBound,
				eStateListening
			};
			EState my_eState;
	};

}

#endif
