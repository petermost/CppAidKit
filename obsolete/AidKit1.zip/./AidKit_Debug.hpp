#ifndef AIDKIT_DEBUG_HPP
#define AIDKIT_DEBUG_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Debug.hpp"
	namespace AidKit {
		using Windows::debug_printf;
	}
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Debug.hpp"
	namespace AidKit {
		using Unix::debug_printf;
	}
#endif


#if defined( AIDKIT_MSC )
	#pragma warning( disable : 4786 )
#endif

#include <vector>
#include <string>
#include <stdexcept>

namespace AidKit {

	// Assert support:

	//-----------------------------------------------------------------------------
	class assertion_error : public std::logic_error {
	//-----------------------------------------------------------------------------
		public:
			explicit assertion_error( const std::string &message );
			~assertion_error( void ) throw();

			Unix::CCallStack call_stack;
	};



	void CheckAssertion( bool IsSatisfied, const char Expression[], const char FileName[], int LineNumber )
		throw ( assertion_error );

	#ifdef AIDKIT_DEBUG

		#define AIDKIT_ASSERT( expression ) \
			AidKit::CheckAssertion( expression, #expression, __FILE__, __LINE__ )


		#define AIDLIB_ASSERT_ONCE( Expression )	\
			{										\
				static bool our_IsAsserted = false;	\
													\
				if ( !our_IsAsserted ) {				\
					our_IsAsserted = true;			\
					AIDKIT_ASSERT( Expression );	\
				}									\
			}

	#else

		#define AIDKIT_ASSERT( expression )
		#define AIDKIT_ASSERT_ONCE( Expression ) (( void ) 0 )

	#endif


	// #define debug_assert( expression ) do { if ( !expression ) debug_break(); } while ( 0 )

	// Helper functions to log exceptions:

	class CDebugger;
	class CError;

	const char_t *ShortFileName( const char_t FileName[] );

	/*
	void LogError( CDebugger *pDebugger, const CError &Error );
	void LogUnknownError( CDebugger *pDebugger, const char_t *SourceFileName, int SourceLineNumber );
	*/

	// Helper functions to dump flags:

	typedef std::vector< string_t > string_vector;

	struct SFlag {
		unsigned long Bits;
		const char_t *pName;
	};

	string_vector AnalyzeFlags( unsigned long FlagBits, const SFlag Flags[], size_t Count );
	void DumpFlags( const string_vector &Flags, void ( *pDump )( const char_t [], ... ));
}

#define AIDKIT_DEFINE_DEBUGGER()\
	static AidKit::CDebugger our_Debugger( AidKit::ShortFileName( TEXT( __FILE__ )))

#define LOG_ERROR( Error )\
	AidKit::LogError( &our_Debugger, Error )
	
#define LOG_UNKNOWN_ERROR()\
	AidKit::LogUnknownException( &s_Debugger, AidKit::ShortFileName( TEXT( __FILE__ )), __LINE__ )

#define COMPILER_ASSERT( Expression )\
	( 1 / ( Expression ))

/*
#ifdef TRACE
	#pragma message( AIDKIT__FILE__LINE__ " : Warning: A previously defined TRACE will be redefined!" )
	#undef TRACE
#endif
#define TRACE our_Debugger.Trace
*/

#ifdef DUMP
	#pragma message( AIDKIT__FILE__LINE__ " : Warning: A previously defined DUMP will be redefined!" )
	#undef DUMP
#endif
#define DUMP our_Debugger.Dump


#ifdef LOG
	#pragma message( AIDKIT__FILE__LINE__ " : Warning: A previously defined LOG will be redefined!" )
	#undef LOG
#endif
#define LOG our_Debugger.Log

#endif // AIDKIT_DEBUG_HPP
