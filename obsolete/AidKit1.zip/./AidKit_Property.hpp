#ifndef AIDKIT_PROPERTY_HPP
#define AIDKIT_PROPERTY_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
#include <list>

namespace AidKit {

	//-----------------------------------------------------------------------------
	template < typename CType >
		class TProperty {
	//-----------------------------------------------------------------------------
			public:
				TEvent1< TProperty * > ChangedEvt;

				TProperty( const TProperty & );
				TProperty( const CType &Value = CType() );

				TProperty &operator = ( const TProperty & );
				const CType &operator = ( const CType &Value );
				
				operator const CType &( void );
				operator const CType &( void ) const;

			private:
				CType my_Value;
		};

}

#include "AidKit_Property.cpp"

#endif

