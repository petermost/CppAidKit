#ifndef AIDKIT_HPP
#define AIDKIT_HPP

// #define _WIN32_WINNT 0x0500

#include "AidKit_Compiler.hpp"
#include "AidKit_Warnings.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows.hpp"
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix.hpp"
#endif

#define AIDKIT_STRINGIZING(Parameter) #Parameter

#define AIDKIT_STRINGIZING_SYMBOL(Parameter) AIDKIT_STRINGIZING(Parameter)

#define AIDKIT__FILE__LINE__ __FILE__ "("AIDKIT_STRINGIZING_SYMBOL(__LINE__)")"

// Give warning, if some compiler switches are missing:

#if defined( AIDKIT_MSC )
	#if defined( _MBCS ) && defined( _UNICODE )
		#error "Both symbols _MBCS and _UNICODE are defined!"
	#endif

	#if !defined( AIDKIT_MULTITHREAD )
		#if defined( AIDKIT_DEBUG )
			#pragma message( AIDKIT__FILE__LINE__ " : Warning: Please enable run-time library: 'Debug Multithreaded' in 'Project/Settings.../C++/Code Generation'!" )
		#else
			#pragma message( AIDKIT__FILE__LINE__ " : Warning: Please enable run-time library: 'Multithreaded' in 'Project/Settings.../C++/Code Generation'!" )
		#endif
	#endif

	#if !defined( _CPPRTTI )
		#pragma message( AIDKIT__FILE__LINE__ " : Warning: Please enable: 'Enable Run-Time Type Information (RTTI)' in 'Project/Settings.../C++/C++ Language'!" )
	#endif

	#if !defined( _CPPUNWIND )
		#pragma message( AIDKIT__FILE__LINE__ " : Warnings: Please enable: 'Enable exception handling' in 'Project/Settings.../C++/C++ Language'!" )
	#endif
#endif // AIDKIT_WINDOWS


#if defined( AIDKIT_BUILD )
	#define AIDKITAPI __declspec( dllexport )
#else
	#define AIDKITAPI __declspec( dllimport )
#endif


#endif // AIDKIT_HPP
