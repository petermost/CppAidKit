#ifndef AIDKIT_STDIO_HPP
#define AIDKIT_STDIO_HPP

#include "AidKit.hpp"
#include <stdio.h>

namespace AidKit {

	template < typename TChar >
		FILE *f_open( const TChar *name, const TChar *mode );

}

#endif
