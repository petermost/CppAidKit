#include "AidKit_WindowsHook.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Warnings.hpp"
#include "AidKit_WinError.hpp"
#include "winerror.h"

#define ASSERT_HOOKTYPE( HookType ) \
	AIDKIT_ASSERT( HookType > WH_MINHOOK && HookType <= WH_MAXHOOK )

namespace AidKit {

//=============================================================================
inline BOOL CheckHookApi( BOOL Success )
//=============================================================================
	{ return ( check_win_api< CWindowsHookError >( Success )); }



//=============================================================================
HHOOK InstallWindowsHook( int HookType, HOOKPROC pHook, HINSTANCE hLibrary, DWORD ThreadID )
	throw ( CWindowsHookError )
//=============================================================================
{
	HHOOK hHook = SetWindowsHookEx( HookType, pHook, hLibrary, ThreadID );
	CheckHookApi( hHook != NULL );
	return ( hHook );
}



//=============================================================================
void UninstallWindowsHook( HHOOK hHook )
	throw ( CWindowsHookError )
//=============================================================================
{
	CheckHookApi( UnhookWindowsHookEx( hHook ));
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWindowsHook
//###
//#############################################################################
//#############################################################################
//#############################################################################


HHOOK CWindowsHook::our_hHooks[ WH_MAXHOOK + 1 ];
CList< CWindowsHook *, CWindowsHook * > CWindowsHook::our_HookList[ WH_MAXHOOK + 1 ];


//=============================================================================
CWindowsHook::CWindowsHook( void )
//=============================================================================
{
}


//=============================================================================
CWindowsHook::~CWindowsHook( void )
//=============================================================================
{
}



//=============================================================================
void CWindowsHook::InstallHook( int HookType )
	throw ( CWindowsHookError, assertion_error )
//=============================================================================
{
	ASSERT_HOOKTYPE( HookType );

	#define IMPLEMENT_CASE( HookType, HookProc ) \
		case HookType: \
			pHookProc = &HookProc; \
			break;

	HOOKPROC pHookProc;

	switch ( HookType ) {
		IMPLEMENT_CASE( WH_JOURNALRECORD,   JournalRecordProc )
		IMPLEMENT_CASE( WH_JOURNALPLAYBACK, JournalPlaybackProc )
		IMPLEMENT_CASE( WH_KEYBOARD,        KeyboardProc )
		IMPLEMENT_CASE( WH_GETMESSAGE,      GetMsgProc )
		IMPLEMENT_CASE( WH_CALLWNDPROC,     CallWndProc )
		IMPLEMENT_CASE( WH_CBT,             CbtProc )
		IMPLEMENT_CASE( WH_SYSMSGFILTER,    SysMsgProc )
		IMPLEMENT_CASE( WH_MOUSE,           MouseProc )
		IMPLEMENT_CASE( WH_HARDWARE,        HardwareProc )
		IMPLEMENT_CASE( WH_DEBUG,           DebugProc )
		IMPLEMENT_CASE( WH_SHELL,           ShellProc )
		IMPLEMENT_CASE( WH_FOREGROUNDIDLE,  ForegroundIdleProc )

		#if defined( WH_CALLWNDPROCRET )
			IMPLEMENT_CASE( WH_CALLWNDPROCRET, CallWndRetProc )
		#endif

		#if defined( WH_KEYBOARD_LL )
			IMPLEMENT_CASE( WH_KEYBOARD_LL, LowLevelKeyboardProc )
		#endif

		#if defined( WH_MOUSE_LL )
			IMPLEMENT_CASE( WH_MOUSE_LL, LowLevelMouseProc )
		#endif

		default:
			pHookProc = NULL;
			break;
	}
	#undef IMPLEMENT_CASE

	// Add the hook to the list of hooks:
	POSITION HookPos;
	if (( HookPos = our_HookList[ HookType ].Find( this )) == 0 )
		our_HookList[ HookType ].AddTail( this );

	// Install the actual hook:
	if ( !our_HookList[ HookType ].IsEmpty() && our_hHooks[ HookType ] == NULL )
		our_hHooks[ HookType ] = SetWindowsHookEx( HookType, pHookProc, NULL, ::GetCurrentThreadId() );

	CheckHookApi( our_hHooks[ HookType ] != NULL );
}



//=============================================================================
void CWindowsHook::UninstallHook( int HookType )
	throw ( CWindowsHookError, assertion_error )
//=============================================================================
{
	ASSERT_HOOKTYPE( HookType );

	// Remove the hook from the list of hooks:
	POSITION HookPos;
	if (( HookPos = our_HookList[ HookType ].Find( this )) != 0 )
		our_HookList[ HookType ].RemoveAt( HookPos );

	// Uninstall the actual hook:
	if ( our_HookList[ HookType ].IsEmpty() && our_hHooks[ HookType ] != NULL ) {
		if ( UnhookWindowsHookEx( our_hHooks[ HookType ] ))
			our_hHooks[ HookType ] = NULL;
	}		
	CheckHookApi( our_hHooks[ HookType ] == NULL );
}


//=============================================================================
LRESULT CALLBACK CWindowsHook::CommonHookProc( int HookType, int nCode, WPARAM wParam, LPARAM lParam,
	TEvent4< int, int, WPARAM, LPARAM > CWindowsHook::*pEvent )
//=============================================================================
{
	ASSERT_HOOKTYPE( HookType );
	AIDKIT_ASSERT( our_hHooks[ HookType ] != NULL );

	LRESULT Result = 0;

	// As far as I could check it, all of the windows hooks have to behave in
	// the following way (excerpt from the dokumentation):
	// "If nCode is less than zero, the hook procedure must pass the message to
	// the CallNextHookEx function without further processing and should return
	// the value returned by CallNextHookEx":

	if ( nCode < 0 ) {
		Result = CallNextHookEx( our_hHooks[ HookType ], nCode, wParam, lParam );
	} else {
		// Iterate over all hooks and call the OnHook-callback method:
		
		POSITION HookPos = our_HookList[ HookType ].GetHeadPosition();
		while ( HookPos != 0 ) {
			CWindowsHook *pHook = our_HookList[ HookType ].GetNext( HookPos );
			AIDKIT_ASSERT( pHook != NULL );
			( pHook->*pEvent ).Announce( HookType, nCode, wParam, lParam );
		}
		// After all the internal hooks have been called, call the next windows
		// managed hook:
		Result = CallNextHookEx( our_hHooks[ HookType ], nCode, wParam, lParam );
	}
	return ( Result );
}


#define IMPLEMENT_PROC( HookType, HookProc, Event ) \
	LRESULT CALLBACK CWindowsHook::HookProc( int nCode, WPARAM wParam, LPARAM lParam ) \
		{ return ( CommonHookProc( HookType, nCode, wParam, lParam, &CWindowsHook::Event )); }

IMPLEMENT_PROC( WH_JOURNALRECORD,   JournalRecordProc,   JournalRecordEvt )
IMPLEMENT_PROC( WH_JOURNALPLAYBACK, JournalPlaybackProc, JournalPlaybackEvt )
IMPLEMENT_PROC( WH_KEYBOARD,        KeyboardProc,        KeyboardEvt )
IMPLEMENT_PROC( WH_GETMESSAGE,      GetMsgProc,          GetMessageEvt )
IMPLEMENT_PROC( WH_CALLWNDPROC,     CallWndProc,         CallWndProcEvt )
IMPLEMENT_PROC( WH_CBT,             CbtProc,             CbtEvt )
IMPLEMENT_PROC( WH_SYSMSGFILTER,    SysMsgProc,          SysMsgEvt )
IMPLEMENT_PROC( WH_MOUSE,           MouseProc,           MouseEvt )
IMPLEMENT_PROC( WH_HARDWARE,        HardwareProc,        HardwareEvt )
IMPLEMENT_PROC( WH_DEBUG,           DebugProc,           DebugEvt )
IMPLEMENT_PROC( WH_SHELL,           ShellProc,           ShellEvt )
IMPLEMENT_PROC( WH_FOREGROUNDIDLE,  ForegroundIdleProc,  ForegroundIdleEvt )

#ifdef WH_CALLWNDPROCRET
	IMPLEMENT_PROC( WH_CALLWNDPROCRET, CallWndRetProc, CallWndRetEvt )
#endif

#ifdef WH_KEYBOARD_LL
	IMPLEMENT_PROC( WH_KEYBOARD_LL, LowLevelKeyboardProc, LowLevelKeyboardEvt )
#endif

#ifdef WH_MOUSE_LL
	IMPLEMENT_PROC( WH_MOUSE_LL, LowLevelMouseProc, LowLevelMouseEvt )
#endif
		

} // namespace AidKit
