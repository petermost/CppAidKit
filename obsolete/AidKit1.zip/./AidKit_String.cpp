#include "AidKit_String.hpp"
#include "AidKit_Memory.hpp"
#include "AidKit_Warnings.hpp"
#include <ctype.h>
#include <algorithm>
#include <string.h>
#include <limits>

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### String
//###
//#############################################################################
//#############################################################################
//#############################################################################

const string_t EMPTY_STRING;



//=============================================================================
const string_t string_vprintf( const char_t format[], va_list arguments )
//=============================================================================
{
	// We can't declare the memory static, because it wouldn't be thread safe:
	memory< char_t > buffer( 80 );

	size_t length = memory_vprintf( &buffer, format, arguments );
	return ( string_t( buffer, length ));
}


//=============================================================================
const string_t string_printf( const char_t format[], ... )
//=============================================================================
{
	va_list arguments;

	va_start( arguments, format );
	string_t output = string_vprintf( format, arguments );
	va_end( arguments );

	return ( output );
}


//=============================================================================
inline bool is_not_space( char_t c )
//=============================================================================
{
	return ( !is_space( c ));
}


//=============================================================================
const string_t trim_left( const string_t &s )
//=============================================================================
{
	return ( string_t( find_if( s.begin(), s.end(), is_not_space ), s.end() ));
}


//=============================================================================
const string_t trim_right( const string_t &s )
//=============================================================================
{
	return ( string_t( s.begin(), find_if( s.rbegin(), s.rend(), is_not_space ).base() ));
}



//=============================================================================
const string_t trim_left( const string_t &s, char_t c )
//=============================================================================
{
	return ( string_t( find_if( s.begin(), s.end(), bind1st( not_equal_to< char_t >(), c )), s.end() ));
}


//=============================================================================
const string_t trim_right( const string_t &s, char_t c )
//=============================================================================
{
	return ( string_t( s.begin(), find_if( s.rbegin(), s.rend(), bind1st( not_equal_to< char_t >(), c )).base() ));
}


//=============================================================================
const string_t encode_crlf( const string_t &s )
//=============================================================================
{
	string_t d;

	for ( string_t::const_iterator it = s.begin(); it != s.end(); ++it ) {
		switch ( *it ) {
			case TEXT( '\r' ):
				d.append( TEXT( "\\r" ));
				break;

			case TEXT( '\n' ):
				d.append( TEXT( "\\n" ));
				break;

			default:
				d.push_back( *it );
				break;
		}
	}
	return ( d );
}



//=============================================================================
const string_t decode_crlf( const string_t &s )
//=============================================================================
{
	string_t d;

	for ( string_t::const_iterator it = s.begin(); it != s.end(); ++it ) {
		if ( *it == TEXT( '\\' ) && ++it != s.end() ) {
			switch ( *it ) {
				case TEXT( 'r' ):
					d.push_back( TEXT( '\r' ));
					break;

				case TEXT( 'n' ):
					d.push_back( TEXT( '\n' ));
					break;

				default:
					d.push_back( TEXT( '\\' ));
					d.push_back( *it );
					break;
			}
		} else
			d.push_back( *it );
	}
	return ( d );
}



//=============================================================================
const string_t encode_base64( const string_t &s )
//=============================================================================
{
	string_t Encoded;

	return ( encode_base64( s.data(), s.length(), &Encoded ) ? Encoded : EMPTY_STRING );
}



//=============================================================================
const string_t decode_base64( const string_t &s )
//=============================================================================
{
	size_t EncodedLength;
	CMemory Buffer( s.length() * 2 );

	if (( EncodedLength = decode_base64( s, Buffer.Start(), Buffer.Size() )) > 0 )
		return ( string_t(( const char_t * ) Buffer.Start(), EncodedLength ));
	else
		return ( EMPTY_STRING );
}




/*===========================================================================*/
char_t *chrcat( char_t *s, char_t c )
/*===========================================================================*/
{
	return ( str_n_cat( s, &c, 1 ));
}






template < typename TInt >
	//=============================================================================
	char_t *IntToStr( register TInt i, char_t *s, int base )
	//=============================================================================
	{
		register TInt n;
		register char_t *p = s;

		if ( i < 0 ) {
			*p++ = TEXT( '-' );
			i = -i;
		}
		char_t *d = p;
		do {
			if (( n = i % base ) > 9 )
				*p++ = n - 10 + TEXT( 'A' );
			else
				*p++ = n + TEXT( '0' );

		} while (( i /= base ) > 0 );

		reverse( d, p );
		*p++ = TEXT( '\0' );

		return ( s );
	}


//=============================================================================
char_t *itoa( int i, char_t *s, int base )
//=============================================================================
{
	return ( IntToStr( i, s, base ));
}



//=============================================================================
const string_t itos( int i, int base )
//=============================================================================
{
	char_t sz[ 33 + 1 ];

	return ( string_t( IntToStr( i, sz, base )));
}


//=============================================================================
const string_t ltos( long l, int base )
//=============================================================================
{
	char_t sz[ 33 + 1 ];

	return ( string_t( IntToStr( l, sz, base )));
}




template < typename TInt >
	//=============================================================================
	TInt StrToInt( TInt ( *strtoi )( const char_t *, char_t **, int ),
		const char_t *pStart, int Base, char_t **ppEnd )
			throw ( CStdError )
	//=============================================================================
	{
		// We clear errno to detect wether the conversion has failed. The returned
		// error indication from strtoi() could also be a valid value!

		errno = ENONE;

		TInt Result = strtoi( pStart, ppEnd, Base );
		if ( numeric_limits< TInt >::is_signed ) {
			if ( Result == numeric_limits< TInt >::min() || Result == numeric_limits< TInt >::max() && errno != ENONE )
				throw ( CStdError( errno ));
		} else {
			if ( Result == numeric_limits< TInt >::max() && errno != ENONE )
				throw ( CStdError( errno ));
		}
		return ( Result );
	}



//=============================================================================
long int StrToL( const char_t *pStart, int Base, char_t **ppEnd )
	throw ( CStdError )
//=============================================================================
{
	return ( StrToInt( strtol, pStart, Base, ppEnd ));
}


//=============================================================================
unsigned long StrToUL( const char_t *pStart, int Base, char_t **ppEnd )
	throw ( CStdError )
//=============================================================================
{
	return ( StrToInt( strtoul, pStart, Base, ppEnd ));
}


//=============================================================================
long long int StrToLL( const char_t *pStart, int Base, char_t **ppEnd )
	throw ( CStdError )
//=============================================================================
{
	return ( StrToInt( strtoll, pStart, Base, ppEnd ));
}


//=============================================================================
unsigned long long int StrToULL( const char_t *pStart, int Base, char_t **ppEnd )
	throw ( CStdError )
//=============================================================================
{
	return ( StrToInt( strtoull, pStart, Base, ppEnd ));
}


//=============================================================================
int stoi( const string_t &s )
	throw ( CStdError )
//=============================================================================
{
	return ( StrToL( s.c_str() ));
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### is_mixed_pattern_match / is_upper_pattern_match
//###
//#############################################################################
//#############################################################################
//#############################################################################

/* +++Date last modified: 02-Nov-1995 */

/*
**  XSTRCMP.C - Simple string pattern matching functions using DOS
**              wildcards ('?' & '*').
**
**  Derived from code by Arjan Kentner (submitted by Steve Summit),
**  modified by Bob Stout.
*/

//=============================================================================
bool is_mixed_pattern_match( const char_t value[], const char_t pattern[] )
//=============================================================================
{
	switch ( *pattern ) {
		case TEXT( '\0' ):
			return ( !*value );

		case TEXT( '*' ):
			return ( is_mixed_pattern_match( value, pattern + 1 ) || *value && is_mixed_pattern_match( value + 1, pattern ));

		case TEXT( '?' ):
			return ( *value && is_mixed_pattern_match( value + 1, pattern + 1 ));

		default:
			return (( *pattern == *value ) && is_mixed_pattern_match( value + 1,  pattern + 1 ));
	  }
}




//=============================================================================
bool is_upper_pattern_match( const char_t value[], const char_t pattern[] )
//=============================================================================
{
	switch ( *pattern ) {
		case TEXT( '\0' ):
			return ( !*value );

		case TEXT( '*' ):
			return ( is_upper_pattern_match( value, pattern + 1 ) || *value && is_upper_pattern_match( value + 1, pattern ));

		case TEXT( '?' ):
			return ( *value && is_upper_pattern_match( value + 1, pattern + 1 ));

		default:
			return ( to_upper( *pattern ) == to_upper( *value )) && is_upper_pattern_match( value + 1, pattern + 1 );
	  }
}



/*

// is_cntrl:

template < >
	int is_cntrl( char c )
		{ return ( iscntrl( c )); }

template < >
	int is_cntrl( wchar_t c )
		{ return ( iswcntrl( c )); }

template int is_cntrl( char c );
template int is_cntrl( wchar_t c );

// str_n_cpy:

template < >
	char *str_n_cpy( char *d, const char *s, size_t max )
		{ return ( strncpy( d, s, max )); }

template < >
	wchar_t *str_n_cpy( wchar_t *d, const wchar_t *s, size_t max )
		{ return ( wcsncpy( d, s, max )); }

template char *str_n_cpy( char *, const char *, size_t );
template wchar_t *str_n_cpy( wchar_t *, const wchar_t *, size_t );




// str_n_cat:

template < >
	char *str_n_cat( char *d, const char *s, size_t max )
		{ return ( strncat( d, s, max )); }

template < >
	wchar_t *str_n_cat( wchar_t *d, const wchar_t *s, size_t max )
		{ return ( wcsncat( d, s, max )); }

template char *str_n_cat( char *d, const char *s, size_t max );
template wchar_t *str_n_cat( wchar_t *d, const wchar_t *s, size_t max );



// str_cmp:

template < >
	int str_cmp( const char *src1, const char *src2 )
		{ return ( strcmp( src1, src2 )); }

template < >
	int str_cmp( const wchar_t *src1, const wchar_t *src2 )
		{ return ( wcscmp( src1, src2 )); }

template int str_cmp( const char *src1, const char *src2 );
template int str_cmp( const wchar_t *src1, const wchar_t *src2 );



// str_chr:

template < >
	char *str_chr( char *s, int c )
		{ return ( strchr( s, c )); }

template < >
	const char *str_chr( const char *s, int c )
		{ return ( strchr( s, c )); }

template < >
	wchar_t *str_chr( wchar_t *s, int c )
		{ return ( wcschr( s, c )); }

template < >
	const wchar_t *str_chr( const wchar_t *s, int c )
		{ return ( wcschr( s, c )); }
	
template char *str_chr( char *s, int c );
template const char *str_chr( const char *s, int c );

template wchar_t *str_chr( wchar_t *s, int c );
template const wchar_t *str_chr( const wchar_t *s, int c );


// str_r_chr:

template < >
	char *str_r_chr( char *s, int c )
		{ return ( strrchr( s, c )); }

template < >
	const char *str_r_chr( const char *s, int c )
		{ return ( strrchr( s, c )); }

template < >
	wchar_t *str_r_chr( wchar_t *s, int c )
		{ return ( wcsrchr( s, c )); }

template < >
	const wchar_t *str_r_chr( const wchar_t *s, int c )
		{ return ( wcsrchr( s, c )); }

template char *str_r_chr( char *s, int c );
template const char *str_r_chr( const char *s, int c );

template wchar_t *str_r_chr( wchar_t *s, int c );
template const wchar_t *str_r_chr( const wchar_t *s, int c );


// str_len:
		
template < >
	size_t str_len( const char *s )
		{ return ( strlen( s )); }

template < >
	size_t str_len( const wchar_t *s )
		{ return ( wcslen( s )); }

template size_t str_len( const char *s );
template size_t str_len( const wchar_t *s );

// str_str:

template < >
	char *str_str( char *s1, const char *s2 )
		{ return ( strstr( s1, s2 )); }

template < >
	const char *str_str( const char *s1, const char *s2 )
		{ return ( strstr( s1, s2 )); }

template < >
	wchar_t *str_str( wchar_t *s1, const wchar_t *s2 )
		{ return ( wcsstr( s1, s2 )); }

template < >
	const wchar_t *str_str( const wchar_t *s1, const wchar_t *s2 )
		{ return ( wcsstr( s1, s2 )); }


template wchar_t *str_str( wchar_t *s1, const wchar_t *s2 );
template const wchar_t *str_str( const wchar_t *s1, const wchar_t *s2 );

template char *str_str( char *s1, const char *s2 );
template const char *str_str( const char *s1, const char *s2 );

*/


} // namespace AidKit
