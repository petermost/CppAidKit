#ifndef AIDKIT_STL_MAP_CPP
#define AIDKIT_STL_MAP_CPP

#include "AidKit.hpp"
#include "AidKit_StlMap.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### uni_map
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < typename key, typename value, typename compare >
	//=============================================================================
	uni_map< key, value, compare >::uni_map( void )
	//=============================================================================
	{
	}



template < typename key, typename value, typename compare >
	//=============================================================================
	uni_map< key, value, compare >::uni_map( const entry entries[], size_t count )
	//=============================================================================
	{
		typedef typename uni_map::value_type value_type;

		for ( size_t i = 0; i < count; ++i )
			insert( value_type( entries[ i ].my_key, entries[ i ].my_value ));
	}



template < typename key, typename value, typename compare >
	//=============================================================================
	const value &uni_map< key, value, compare >::operator[]( const key &Key ) const
		throw ( std::out_of_range )
	//=============================================================================
	{
		typename uni_map::const_iterator Iterator = find( Key );

		if ( Iterator == this->end() )
			throw ( std::out_of_range( "invalid uni_map<> subscript" ));

		return ( Iterator->second );
	}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### bi_map
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < typename value1, typename value2, typename compare1, typename compare2 >
	//=============================================================================
	bi_map< value1, value2, compare1, compare2 >::bi_map( void )
	//=============================================================================
	{
	}


template < typename value1, typename value2, typename compare1, typename compare2 >
	//=============================================================================
	bi_map< value1, value2, compare1, compare2 >::bi_map( const entry entries[], size_t count )
	//=============================================================================
	{
		for ( size_t i = 0; i < count; ++i ) {
			my_1to2map.insert( value1to2map_t::value_type( entries[ i ].my_value1, entries[ i ].my_value2 ));
			my_2to1map.insert( value2to1map_t::value_type( entries[ i ].my_value2, entries[ i ].my_value1 ));
		}
	}


template < typename value1, typename value2, typename compare1, typename compare2 >
	//=============================================================================
	const value2 &bi_map< value1, value2, compare1, compare2 >::operator [] ( const value1 &value ) const
		throw ( std::out_of_range )
	//=============================================================================
	{
		return ( my_1to2map[ value ] );
	}


template < typename value1, typename value2, typename compare1, typename compare2 >
	//=============================================================================
	const value1 &bi_map< value1, value2, compare1, compare2 >::operator [] ( const value2 &value ) const
		throw ( std::out_of_range )
	//=============================================================================
	{
		return ( my_2to1map[ value ] );
	}

} // namespace AidKit

#endif // AIDKIT_STL_MAP_CPP
