#ifndef AIDKIT_SDK_HELPER_HPP
#define AIDKIT_SDK_HELPER_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_WinError.hpp"

#include <afxwin.h>

namespace AidKit {

	enum EModuleFlags {
		fModuleIsEXE = 1 << 0,
		fModuleIsDLL = 1 << 1,
		fModuleIsGUI = 1 << 2,
		fModuleIsCUI = 1 << 3,
	};

	unsigned GetModuleFlags( HMODULE hModule = 0 );

	bool IsGUI( void );
	bool IsCUI( void );

	bool IsEXE( void );
	bool IsDLL( void );

	BOOL SetWindowStyle(   CWnd *pWnd, DWORD Style,   BOOL Update = TRUE );
	BOOL SetWindowStyleEx( CWnd *pWnd, DWORD StyleEx, BOOL Update = TRUE );

	BOOL ResizeWindow( CWnd *pWnd, const CSize &NewSize,   BOOL Update = TRUE );
	BOOL GrowWindow(   CWnd *pWnd, const CSize &DeltaSize, BOOL Update = TRUE );

	BOOL MoveWindow(  CWnd *pWnd, const CPoint &NewPosition,   BOOL Update = TRUE );
	BOOL SlideWindow( CWnd *pWnd, const CPoint &DeltaPosition, BOOL Update = TRUE );

	BOOL UpdateWindowData( CWnd *pWnd, BOOL SaveAndValidate = TRUE );
	BOOL EnableWindow( CWnd *pWnd, BOOL Enable = TRUE );


	class CWinError;

	// COM - Helper:
	HRESULT InitializeCom( void )
		throw ( CWinError );

	HRESULT UninitializeCom( void )
		throw ( CWinError );

	BOOL IsComInitialized( void );



	void SetDesktopWallpaper( const char_t WallpaperName[] )
		throw ( CWinError );

	void XSetDesktopWallpaper( const char_t WallpaperName[] )
		throw ( CWinError );

	int GetWindowTitleLength( HWND hWnd )
		throw ( CWinError );

	CString GetWindowTitle( HWND hWnd )
		throw ( CWinError );
	
	CString GetProgramPath( void )
		throw ( CWinError );



	void QueryDraggedFiles( HDROP hDrop, CStringArray *pFileNames );

	// This defines the flags which are beeing sent with WM_KEYDOWN, WM_KEYUP etc:
	struct KEY_MESSAGE_FLAGS {
		KEY_MESSAGE_FLAGS( LPARAM lParam = 0 );
		LPARAM operator = ( LPARAM lParam );
		operator LPARAM( void ) const;

		unsigned RepeatCount      : 16;
		unsigned ScanCode         : 8;
		unsigned IsExtendedKey    : 1;
		unsigned Reserved         : 4;
		unsigned ContextCode      : 1;
		unsigned PreviousKeyState : 1;
		unsigned TransitionState  : 1;
	};

}

#endif
