#ifndef AIDKIT_DEFERRED_FUNCTION_IMP_CPP
#define AIDKIT_DEFERRED_FUNCTION_IMP_CPP

#include "AidKit_DeferredFunction.hpp"
#include <stddef.h>

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TDeferredFunction
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < typename CCallee >
	typename TDeferredFunction< CCallee >::Dispatcher_t *TDeferredFunction< CCallee >::our_pDispatcher = NULL;


template < typename CCallee >
	//=============================================================================
	void TDeferredFunction< CCallee >::Dispatch( CCallee *pCallee, TDeferredFunction< CCallee > *pFunction )
	//=============================================================================
	{
		if ( our_pDispatcher != NULL )
			( *our_pDispatcher )( pCallee, this );
		else
			pFunction->Execute();
	}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TDeferredFunction
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < typename CCallee >
	//=============================================================================
	void TDeferredFunction0< CCallee >::Execute( void )
	//=============================================================================
	{
		if ( my_pMethod != NULL )
			( my_pCallee->*my_pMethod )();
		else
			( *my_pFunction )();
	}


template < typename CCallee, typename P1 >
	//=============================================================================
	void TDeferredFunction1< CCallee, P1 >::Execute( void )
	//=============================================================================
	{
		if ( my_pMethod != NULL )
			( my_pCallee->*my_pMethod )( my_p1 );
		else
			( *my_pFunction )( my_p1 );
	}


template < typename CCallee, typename P1, typename P2 >
	//=============================================================================
	void TDeferredFunction2< CCallee, P1, P2 >::Execute( void )
	//=============================================================================
	{
		if ( my_pMethod != NULL )
			( my_pCallee->*my_pMethod )( my_p1, my_p2 );
		else
			( *my_pFunction )( my_p1, my_p2 );
	}


template < typename CCallee, typename P1, typename P2, typename P3 >
	//=============================================================================
	void TDeferredFunction3< CCallee, P1, P2, P3 >::Execute( void )
	//=============================================================================
	{
		if ( my_pMethod != NULL )
			( my_pCallee->*my_pMethod )( my_p1, my_p2, my_p3 );
		else
			( *my_pFunction )( my_p1, my_p2, my_p3 );
	}


template < typename CCallee, typename P1, typename P2, typename P3, typename P4 >
	//=============================================================================
	void TDeferredFunction4< CCallee, P1, P2, P3, P4 >::Execute( void )
	//=============================================================================
	{
		if ( my_pMethod != NULL )
			( my_pCallee->*my_pMethod )( my_p1, my_p2, my_p3. my_p4 );
		else
			( *my_pFunction )( my_p1, my_p2, my_p3, my_p4 );
	}

} // namespace AidKit

#endif
