#include "AidKit_Compiler_Gcc.hpp"

#if !defined( AIDKIT_GCC_2 )

#include <cxxabi.h>

using namespace std;
using namespace abi;
using namespace __gnu_cxx;

namespace AidKit {

//=============================================================================
terminate_handler install_verbose_terminate_handler( void )
//=============================================================================
{
	return ( set_terminate( __verbose_terminate_handler ));
}



//=============================================================================
unexpected_handler install_verbose_unexpected_handler( void )
//=============================================================================
{
	return ( set_unexpected( __verbose_terminate_handler ));
}

} // namespace AidKit

#endif
