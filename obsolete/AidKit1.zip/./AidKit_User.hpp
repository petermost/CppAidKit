#ifndef AIDKIT_USER_HPP
#define AIDKIT_USER_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CUserBasics {
	//-----------------------------------------------------------------------------
		public:
			CUserBasics( void );
			virtual ~CUserBasics( void );

		protected:
			virtual string_t DoGetName( void ) = 0;
			virtual string_t DoGetHomeDirectory( void ) = 0;
	};

}

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_User.hpp"
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_User.hpp"
#endif

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CUser : public CNativeUser {
	//-----------------------------------------------------------------------------
		public:
			string_t Name( void ) const;
			string_t HomeDirectory( void ) const;

		private:
	};

}

#endif
