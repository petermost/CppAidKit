#include "AidKit_SocketHelper.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CFdSet
//###
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
CFdSet::CFdSet( void )
//=============================================================================
{
	FD_ZERO( this );

	my_Highest = 0;
}



//=============================================================================
void CFdSet::Set( socket_t s )
	throw ( assertion_error )
//=============================================================================
{
	// If we don't check for a valid socket then we are getting a segmentation fault!
	AIDKIT_ASSERT( s != INVALID_SOCKET );

	FD_SET( s, this );

	my_Highest = max( my_Highest, s );
}


// Don't support CFdSet::Clr because it creates a lot of problems in calculating
// the highest Fd!


//=============================================================================
bool CFdSet::IsSet( socket_t s ) const
	throw ( assertion_error )
//=============================================================================
{
	// If we don't check for a valid socket then we are getting a segmentation fault!
	AIDKIT_ASSERT( s != INVALID_SOCKET );

	return ( FD_ISSET( s, this ) != 0 );
}



//=============================================================================
socket_t CFdSet::Highest( void ) const
//=============================================================================
{
	return ( my_Highest );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSelectable
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CSelectable::CSelectable( void )
//=============================================================================
{
}



//=============================================================================
CSelectable::~CSelectable( void )
//=============================================================================
{
}


//=============================================================================
int CSelectable::ReadableHandle( void ) const
//=============================================================================
{
	return ( -1 );
}


//=============================================================================
int CSelectable::WritableHandle( void ) const
//=============================================================================
{
	return ( -1 );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### Select
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
int Select( CFdSet *pInputSet, CFdSet *pOutputSet, CFdSet *pExceptSet, milliseconds_t Timeout )
//=============================================================================
{
	socket_t HighestSocket = 0; // Don't use INVALID_SOCKET (doesn't work under windows)

	// Calculate the highest socket number:

	if ( pInputSet != NULL )
		HighestSocket = max( HighestSocket, pInputSet->Highest() );

	if ( pOutputSet != NULL )
		HighestSocket = max( HighestSocket, pOutputSet->Highest() );

	if ( pExceptSet != NULL )
		HighestSocket = max( HighestSocket, pExceptSet->Highest() );

	// Prepare the timeout parameter:

	timeval TimeVal, *pTimeVal;

	if ( Timeout != INFINITE_MILLISECONDS ) {
		ConvertMilliseconds( Timeout, &TimeVal );
		pTimeVal = &TimeVal;
	} else
		pTimeVal = NULL;

	// Do the actual select:

	int nResult = select( HighestSocket + 1, pInputSet, pOutputSet, pExceptSet, pTimeVal );

	return ( nResult );
}

/*
//=============================================================================
socket_t PrepareSelect( const vector< socket_t > *pInputFiles, fd_set **ppInputSet,
	const vector< socket_t > *pOutputFiles, fd_set **ppOutputSet,
	const vector< socket_t > *pExceptFiles, fd_set **ppExceptSet,
	milliseconds_t Timeout, timeval **ppTimeVal )
//=============================================================================
{
	socket_t nLastFile = INVALID_SOCKET;

	// Prepare the input-fd's:

	if ( pInputFiles != NULL )
		nLastFile = max( nLastFile, TransferFilesToSet( pInputFiles, *ppInputSet ));
	else
		*ppInputSet = NULL;

	// Prepare the output-fd's:

	if ( pOutputFiles != NULL )
		nLastFile = max( nLastFile, TransferFilesToSet( pOutputFiles, *ppOutputSet ));
	else
		*ppOutputSet = NULL;

	// Prepare the except-fd's:

	if ( pExceptFiles != NULL )
		nLastFile = max( nLastFile, TransferFilesToSet( pExceptFiles, *ppExceptSet ));
	else
		*ppExceptSet = NULL;

	// Prepare the timeout:

	if ( Timeout != INFINITE_MILLISECONDS )
		ConvertMilliseconds( Timeout, *ppTimeVal );
	else
		*ppTimeVal = NULL;

	return ( nLastFile );
}

//=============================================================================
int EvaluateSelect( int nResult,
	const fd_set *pInputSet, vector< socket_t > *pInputFiles,
	const fd_set *pOutputSet, vector< socket_t > *pOutputFiles,
	const fd_set *pExceptSet, vector< socket_t > *pExceptFiles )
//=============================================================================
{
	if ( nResult > 0 ) {
		if ( pInputSet != NULL ) {
			AIDKIT_ASSERT( pInputFiles != NULL );
			ExtractFilesFromSet( pInputSet, pInputFiles );
		}
		if ( pOutputSet != NULL ) {
			AIDKIT_ASSERT( pOutputFiles != NULL );
			ExtractFilesFromSet( pOutputSet, pOutputFiles );
		}
		if ( pExceptSet != NULL ) {
			AIDKIT_ASSERT( pExceptFiles != NULL );
			ExtractFilesFromSet( pExceptSet, pExceptFiles );
		}
	}
	return ( nResult );
}


//=============================================================================
socket_t TransferFilesToSet( const vector< socket_t > *pFiles, fd_set *FileSet )
//=============================================================================
{
	vector< socket_t >::const_iterator itFile;
	socket_t nLastFile = INVALID_SOCKET;

	FD_ZERO( FileSet );
	for ( itFile = pFiles->begin(); itFile != pFiles->end(); ++itFile ) {
		AIDKIT_ASSERT( *itFile != INVALID_SOCKET ); // avoid segmentation fault!
		FD_SET( *itFile, FileSet );
		nLastFile = max( *itFile, nLastFile );
	}
	return ( nLastFile );
}


//=============================================================================
void ExtractFilesFromSet( const fd_set *FileSet, vector< socket_t > *pFiles )
//=============================================================================
{
	vector< socket_t >::iterator itFile;

	// Mark the not selected files:

	for ( itFile = pFiles->begin(); itFile != pFiles->end(); ++itFile ) {
		if ( !FD_ISSET( *itFile, FileSet ))
			*itFile = INVALID_SOCKET; // Mark for removal
	}
	// Remove the marked files:

	itFile = remove( pFiles->begin(), pFiles->end(), INVALID_SOCKET );
	pFiles->erase( itFile, pFiles->end() );
}
*/

} // namespace AidKit

