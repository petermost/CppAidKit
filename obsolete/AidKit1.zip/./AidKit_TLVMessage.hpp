#ifndef AIDKIT_TLV_MESSAGE_HPP
#define AIDKIT_TLV_MESSAGE_HPP

#include "AidKit.hpp"
#include "AidKit_Types.hpp"
#include "AidKit_Socket.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Function.hpp"
#include "AidKit_Memory.hpp"

#include <string>
#include <vector>
#include <stdexcept>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CTLVTransmitter {
	//-----------------------------------------------------------------------------
		public:
			CTLVTransmitter( CSocketConnection *pConnection,
				milliseconds_t BlockWaitingTime = INFINITE_MILLISECONDS,
				milliseconds_t CharWaitingTime = INFINITE_MILLISECONDS,
				bool IsNotifiable = false );

			~CTLVTransmitter( void );

			// Send header/value methods:

			bool SendHeader( INT32 Tag, INT32 Length )
				throw ( CSocketError, assertion_error );

			bool SendValue( INT32 Length, const void *pValue )
				throw ( CSocketError, assertion_error );

			// Receive header/value methods:

			bool ReceiveHeader( INT32 *pTag, INT32 *pLength )
				throw ( CSocketError, assertion_error );

			bool ReceiveValue( INT32 Length, void *pValue )
				throw ( CSocketError, assertion_error );

			// Send/Receive data methods:

			bool SendData( INT32 Length, file_t hDataFile, off_t *pDataOffset )
				throw ( CSocketError, assertion_error );

			bool SendData( INT32 Length, const TCall2< size_t, void *, size_t > &Produce,
				CMemory *pScratchBuffer )
					throw ( CSocketError, assertion_error );

			bool ReceiveData( INT32 Length, const TCall2< size_t, const void *, size_t > &Consume,
				CMemory *pScratchBuffer )
					throw ( CSocketError, assertion_error );

		private:
			CTLVTransmitter( const CTLVTransmitter & );
			CTLVTransmitter &operator = ( const CTLVTransmitter & );

			const milliseconds_t my_BWT; ///< BlockWaitingTime
			const milliseconds_t my_CWT; ///< CharWaitingTime
			const bool my_IsNotifiable;

			CSocketConnection *const my_pConnection;
	};


	//-----------------------------------------------------------------------------
	class CTLVTransmitterHelper : public CTLVTransmitter {
	//-----------------------------------------------------------------------------
		public:
			CTLVTransmitterHelper( CSocketConnection *pConnection,
				milliseconds_t BlockWaitingTime = INFINITE_MILLISECONDS,
				milliseconds_t CharWaitingTime = INFINITE_MILLISECONDS );

			bool ReceiveIntegerValues( INT32 Length, std::vector< INT32 > *pValues )
				throw ( CSocketError, assertion_error, std::bad_alloc );

			bool ReceiveStringValue( INT32 Length, string_t *pValue )
				throw ( CSocketError, assertion_error, std::bad_alloc );
	};







	template < typename CValue >
		//-----------------------------------------------------------------------------
		class TValueTraits {
		//-----------------------------------------------------------------------------
			public:
				static void Reserve( std::vector< CValue > *pValues, size_t Length );

				static size_t Write( void *pMemory, size_t MemorySize, const CValue &Value );
				static size_t Read( const void *pMemory, size_t MemorySize, CValue *pValue );

				static size_t Size( const CValue &Value );
		};

	template < typename CTag, typename CLength, typename CValue, typename CTraits = TValueTraits< CValue > >
		//-----------------------------------------------------------------------------
		class TTLV {
		//-----------------------------------------------------------------------------
			public:
				TTLV( CTag Tag = CTag(), const void *pValue = NULL, CLength Length = CLength() );

				void Reset( void );

				TTLV &operator += ( const CValue &Value );

				size_t ReadMemory( const void *pMemory, size_t MemorySize );
				size_t WriteMemory( void *pMemory, size_t MemorySize ) const;

				CTag Tag( void ) const;
				CLength Length( void ) const;
				size_t Size( void ) const;
				size_t Count( void ) const;

				const CValue &At( size_t i ) const;
				const CValue *Find( CTag Tag ) const;

			private:
				CTag my_Tag;
				std::vector< CValue > my_Value;
		};



	//-----------------------------------------------------------------------------
	class CTLVField {
	//-----------------------------------------------------------------------------
		public:
			CTLVField( INT32 Tag = 0, const void *pValue = NULL, size_t ValueLength = 0 );
			~CTLVField( void );

			void Reset( void );

			size_t ReadMemory( const void *pMemory, size_t MemorySize );
			size_t WriteMemory( void *pMemory, size_t MemorySize ) const;

			INT32 Tag( void ) const;
			INT32 Length( void ) const;
			size_t Size( void ) const;
			size_t Count( void ) const;

			INT32 LengthForInt16( void ) const;
			INT32 LengthForInt32( void ) const;

			BYTE At( size_t Index = 0 ) const
				throw ( std::out_of_range );

			INT16 AsInt16At( size_t Index = 0 ) const
				throw ( std::out_of_range );

			INT32 AsInt32At( size_t Index = 0 ) const
				throw ( std::out_of_range );

			string_t AsString( void ) const;

		private:
			TTLV< INT32, INT32, BYTE > my_Content;
	};


	//-----------------------------------------------------------------------------
	class CTLVMessage {
	//-----------------------------------------------------------------------------
		public:
			CTLVMessage( INT32 Tag = 0 );
			~CTLVMessage( void );

			void Reset( void );

			CTLVMessage &operator += ( const CTLVField & );

			size_t ReadMemory( const void *pMemory, size_t BufferLength );
			size_t WriteMemory( void *pMemory, size_t MemorySize ) const;

			INT32 Tag( void ) const;
			INT32 Length( void ) const;
			size_t Size( void ) const;
			size_t Count( void ) const;

			const CTLVField &At( size_t Index ) const
				throw ( std::out_of_range );

			const CTLVField *Find( INT32 FieldTag ) const;

		private:
			TTLV< INT32, INT32, CTLVField > my_Fields;
	};

}

#endif
