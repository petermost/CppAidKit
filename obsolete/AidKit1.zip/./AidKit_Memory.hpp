#ifndef AIDKIT_MEMORY_HPP
#define AIDKIT_MEMORY_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Memory.hpp"

#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Memory.hpp"

#endif

#include <new>
#include <memory.h>
#include <stdexcept>
#include <stdarg.h>

#include "AidKit_StlFunctional.hpp"

// A safer placement-new operator:

void *operator new( size_t ObjectSize, void *pMemory, size_t MemorySize )
	throw ( std::bad_alloc );

void operator delete( void *Object, void *pMemory, size_t MemorySize )
	throw();

namespace AidKit {

	inline void *memclr( void *p, size_t n )
		{ return ( memset( p, 0, n )); }

	// A replacement for auto_ptr :

	template < typename type >
		//---------------------------------------------------------------------
		class memory_ptr {
		//---------------------------------------------------------------------
			public:
				memory_ptr( type *p )
					{ my_pointer = p; }

				~memory_ptr( void )
					{ delete my_pointer; }

				type *release( void )
					{ type *p = my_pointer; my_pointer = 0; return ( p ); }

				type &operator * ( void ) const
					{ return ( *my_pointer ); }

				type *operator -> ( void ) const
					{ return ( my_pointer ); }

				operator type * ( void ) const
					{ return ( my_pointer ); }

			private:
				memory_ptr( const memory_ptr & );
				memory_ptr &operator = ( const memory_ptr & );

				type *my_pointer;
		};


	//---------------------------------------------------------------------
	class CMemory {
	//---------------------------------------------------------------------
		public:
			CMemory( size_t Size = 0)
				throw ( std::bad_alloc );

			~CMemory( void )
				throw();

			void Resize( size_t NewSize )
				throw ( std::bad_alloc );

			void *Start( void ) const
				{ return ( my_pAddress ); }

			size_t Size( void ) const
				{ return ( my_nSize ); }

		private:
			CMemory( const CMemory & );
			CMemory &operator = ( const CMemory & );

			void *my_pAddress;
			size_t my_nSize;
	};


	template < typename type >
		//---------------------------------------------------------------------
		class memory {
		//---------------------------------------------------------------------
			public:
				memory( size_t size )
					{ my_address = static_cast< type * >( malloc(( my_size = size ) * sizeof( type ))); }

				~memory( void )
					{ free( my_address ); }

				void resize( size_t size )
					{ my_address = static_cast< type * >( realloc( my_address, ( my_size = size ) * sizeof( type ))); } 

				type *begin( void ) const
					{ return ( my_address ); }

				type *end( void ) const
					{ return ( my_address + my_size ); }

				size_t size( void ) const
					{ return ( my_size ); }

				operator type * ( void ) const
					{ return ( begin() ); }

			private:
				memory( const memory & );
				memory &operator = ( const memory & );

				type *my_address;
				size_t my_size;
		};


	size_t memory_vprintf( memory< char_t > *output, const char_t format[], va_list arguments );


	template < typename Type >
		//=============================================================================
		void TurnMemory( Type *pType )
		//=============================================================================
		{
			char Value;
			char *pBegin = reinterpret_cast< char * >( pType );
			char *pEnd = pBegin + sizeof( *pType ) - 1;

			while ( pBegin < pEnd ) {
				Value = *pBegin;
				*pBegin++ = *pEnd;
				*pEnd-- = Value;
			}
		}



	template< typename Type >
		//=============================================================================
		size_t memory_advance( const void **ppMemory, size_t *pMemorySize, size_t Count = 1 )
		//=============================================================================
		{
			*ppMemory = static_cast< const Type * >( *ppMemory ) + Count;
			*pMemorySize -= sizeof( Type ) * Count;

			return ( sizeof( Type ) * Count );
		}



	template< typename Type >
		//=============================================================================
		size_t memory_advance( void **ppMemory, size_t *pMemorySize, size_t Count = 1 )
		//=============================================================================
		{
			*ppMemory = static_cast< Type * >( *ppMemory ) + Count;
			*pMemorySize -= sizeof( Type ) * Count;

			return ( sizeof( Type ) * Count );
		}



	template< typename Type >
		//=============================================================================
		size_t memory_read( const void **ppMemory, Type *pValue )
		//=============================================================================
		{
			*pValue = **reinterpret_cast< const Type ** >( ppMemory );
			*ppMemory = reinterpret_cast< const Type * >( *ppMemory ) + 1;

			return ( sizeof( Type ));
		}


	template< typename Type >
		//=============================================================================
		size_t memory_write( void **ppMemory, const Type &Value )
		//=============================================================================
		{
			**reinterpret_cast< Type ** >( ppMemory ) = Value;
			*ppMemory = reinterpret_cast< Type * >( *ppMemory ) + 1;

			return ( sizeof( Type ));
		}







	template< typename Type >
		//=============================================================================
		size_t memory_read( const void **ppMemory, size_t *pMemorySize, Type *pValue )
			throw ( std::length_error )
		//=============================================================================
		{
			if ( sizeof( Type ) > *pMemorySize )
				throw ( std::length_error( "memory_read" ));

			size_t Size = memory_read( ppMemory, pValue );
			*pMemorySize -= Size;

			return ( Size );
		}

	template< typename Type >
		//=============================================================================
		size_t memory_write( void **ppMemory, size_t *pMemorySize, const Type &Value )
			throw ( std::length_error )
		//=============================================================================
		{
			if ( sizeof( Type ) > *pMemorySize )
				throw ( std::length_error( "memory_write" ));

			size_t Size = memory_write( ppMemory, Value );
			*pMemorySize -= Size;

			return ( Size );
		}





	template < typename Type >
		//=============================================================================
		size_t memory_read( const void **ppMemory, size_t *pMemorySize, Type *pValue, size_t nValueCount )
			throw ( std::length_error )
		//=============================================================================
		{
			size_t nLength = 0;
			while ( nValueCount-- > 0 ) {
				nLength += memory_read( ppMemory, pMemorySize, pValue++ );
			}
			return ( nLength );
		}

	size_t memory_read( const void **ppMemory, size_t *pMemorySize, void *pValue, size_t nSize )
		throw ( std::length_error );





	template < typename Type >
		//=============================================================================
		size_t memory_write( void **ppMemory, size_t *pMemorySize, const Type *pValue, size_t nValueCount )
			throw ( std::length_error )
		//=============================================================================
		{
			size_t nLength = 0;
			while ( nValueCount-- > 0 ) {
				nLength += memory_write(  ppMemory, pMemorySize, *pValue++ );
			}
			return ( nLength );
		}

	size_t memory_write( void **ppMemory, size_t *pMemorySize, const void *pValue, size_t nSize )
		throw ( std::length_error );





	template< typename CClass >
		//=============================================================================
		void Construct( CClass **ppClass, void *pMemory, size_t nMemorySize )
			throw ( std::bad_alloc )
		//=============================================================================
		{
			*ppClass = new( pMemory, nMemorySize )CClass();
		}



	template< typename CClass >
		//=============================================================================
		void Destruct( CClass **ppClass )
		//=============================================================================
		{
			( *ppClass )->~CClass();
			*ppClass = 0;
		}

}

#endif
