#ifndef AIDKIT_WINDOWS_HOOK_HPP
#define AIDKIT_WINDOWS_HOOK_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_WinError.hpp"

#include <afxwin.h>
#include <afxtempl.h>

namespace AidKit {

	typedef TWinError< class CWindowsHook > CWindowsHookError;

	HHOOK InstallWindowsHook( int HookType, HOOKPROC, HINSTANCE hLibrary, DWORD ThreadID = 0 )
		throw ( CWindowsHookError );

	void UninstallWindowsHook( HHOOK hHook )
		throw ( CWindowsHookError );


	//-----------------------------------------------------------------------------
	class CWindowsHook {
	//-----------------------------------------------------------------------------
		public:
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > JournalRecordEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > JournalPlaybackEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > KeyboardEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > GetMessageEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > CallWndProcEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > CbtEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > SysMsgEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > MouseEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > HardwareEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > DebugEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > ShellEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > ForegroundIdleEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > CallWndRetEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > LowLevelKeyboardEvt;
			TEvent4< int /* HookType */, int /* Code */, WPARAM, LPARAM > LowLevelMouseEvt;

			CWindowsHook( void );
			~CWindowsHook( void );

			/// Installs a local hook for the current thread.
			/// @attention With this implementation it is not possible to install global hooks!
			void InstallHook( int HookType )
				throw ( CWindowsHookError );

			/// Uninstalls the hook for the given hook type. The other hooks remain active.
			void UninstallHook( int HookType )
				throw ( CWindowsHookError );

		private:
			static LRESULT CALLBACK CommonHookProc( int HookType, int nCode, WPARAM, LPARAM,
				TEvent4< int, int, WPARAM, LPARAM > CWindowsHook::*pEvent );

			static LRESULT CALLBACK JournalRecordProc(    int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK JournalPlaybackProc(  int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK KeyboardProc(         int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK GetMsgProc(           int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK CallWndProc(          int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK CbtProc(              int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK SysMsgProc(           int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK MouseProc(            int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK HardwareProc(         int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK DebugProc(            int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK ShellProc(            int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK ForegroundIdleProc(   int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK CallWndRetProc(       int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK LowLevelKeyboardProc( int nCode, WPARAM, LPARAM );
			static LRESULT CALLBACK LowLevelMouseProc(    int nCode, WPARAM, LPARAM );

			static HHOOK our_hHooks[];
			static CList< CWindowsHook *, CWindowsHook * > our_HookList[];
	};

}

#endif
