#include "AidKit_Time.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Memory.hpp"
#include "AidKit_String.hpp"

#include <time.h>
#include <stdio.h>

namespace AidKit {

const string_t ISO_DATE_FORMAT( TEXT( "%Y-%m-%d" ));
const string_t ISO_TIME_FORMAT( TEXT( "%H:%M:%S" ));

//=============================================================================
DateTime CurrentDateTime( void )
//=============================================================================
{
	// Query the current time:

	timeval currentTime;
	gettimeofday( &currentTime, NULL );

	// Convert it to the DateTime structure:

	DateTime currentDateTime;
	localtime_r( &currentTime.tv_sec, &currentDateTime );
	currentDateTime.usec = currentTime.tv_usec;

	return ( currentDateTime );
}


//=============================================================================
string_t FormatDateTime( const string_t &Format, const DateTime &currentDateTime )
//=============================================================================
{
	memory< char > Buffer( Format.length() * 2 );

	// If strftime fails, it returns 0 which ensures that in the error case we
	// return an empty string:

	size_t BufferLength = str_f_time( Buffer, Buffer.size(), Format.c_str(), &currentDateTime );

	return ( string_t( Buffer, BufferLength ));
}



//=============================================================================
string_t ISODate( const DateTime &currentDateTime )
//=============================================================================
{
	return ( FormatDateTime( ISO_DATE_FORMAT, currentDateTime ));
}



//=============================================================================
string_t ISODate( void )
//=============================================================================
{
	return ( ISODate( CurrentDateTime() ));
}



//=============================================================================
string_t ISOTime( const DateTime &currentDateTime, ESecondsFraction Fraction, bool WithTimezone )
//=============================================================================
{
	string_t TimeFormat;
	TimeFormat.resize( 80 );

	TimeFormat = ISO_TIME_FORMAT;

	switch ( Fraction ) {
		case eFraction_Milliseconds:
			TimeFormat += string_printf( TEXT( ".%03lu" ), currentDateTime.usec / 1000 );
			break;

		case eFraction_Microseconds:
			TimeFormat += string_printf( TEXT( ".%06lu" ), currentDateTime.usec );
			break;

		case eFraction_None:
		default:
			break;
	}
	if ( WithTimezone ) {
		TimeFormat += " %z";
	}
	return ( FormatDateTime( TimeFormat, currentDateTime ));
}


//=============================================================================
string_t ISOTime( ESecondsFraction Fraction, bool WithTimezone )
//=============================================================================
{
	return ( ISOTime( CurrentDateTime(), Fraction, WithTimezone ));
}


//=============================================================================
string_t ISODateTime( ESecondsFraction Fraction, bool WithTimezone )
//=============================================================================
{
	const string_t BLANK( TEXT( " " ));

	DateTime currentDateTime = CurrentDateTime();

	return ( ISODate( currentDateTime ) + BLANK + ISOTime( currentDateTime, Fraction, WithTimezone ));
}



//#############################################################################
//#############################################################################
//#############################################################################
//
// Convert functions from milliseconds to timeval, timespec:
//
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
timeval *ConvertMilliseconds( milliseconds_t Milliseconds, timeval *pTimeVal )
	throw ()
//=============================================================================
{
	pTimeVal->tv_sec  = Milliseconds / 1000;
	pTimeVal->tv_usec = ( Milliseconds % 1000 ) * 1000;

	return ( pTimeVal );
}



//=============================================================================
milliseconds_t ConvertTime( const timeval *pTimeVal, milliseconds_t *pMilliseconds )
	throw ()
//=============================================================================
{
	*pMilliseconds  = pTimeVal->tv_sec * 1000;
	*pMilliseconds += pTimeVal->tv_usec / 1000;

	return ( *pMilliseconds );
}


} // namespace AidKit


/*
//=============================================================================
void CurrentDateTime( struct tm *pDateTime, unsigned long *usec )
//=============================================================================
{
	timeval Time;

	gettimeofday( &Time, NULL );
	localtime_r( &Time.tv_sec, pDateTime );
	*usec = Time.tv_usec;
}



//=============================================================================
void CurrentDateTime( struct tm *pDateTime, unsigned short *msec )
//=============================================================================
{
	unsigned long usec;

	CurrentDateTime( pDateTime, &usec );
	*msec = usec / 1000;
}


//=============================================================================
string_t ISOTime( const struct tm &DateTime, unsigned short msec, bool WithTimezone )
//=============================================================================
{
	// Prepare the time format with the already included milliseconds:

	char_t TimeFormat[ 40 ];

	if ( WithTimezone )
		sn_print_f( TimeFormat, countof( TimeFormat ), TEXT( "%%H:%%M:%%S.%03hu %%z" ), msec );
	else
		sn_print_f( TimeFormat, countof( TimeFormat ), TEXT( "%%H:%%M:%%S.%03hu" ), msec );

	// Create the iso time:

	char_t ISOTime[ 40 ];
	size_t ISOTimeLength = str_f_time( ISOTime, countof( ISOTime ), TimeFormat, &DateTime );
	AIDKIT_ASSERT( ISOTimeLength > 0 );

	return ( string_t( ISOTime, ISOTimeLength ));
}


//=============================================================================
string_t ISOTime( ESecondsFraction Fraction, bool WithTimezone )
//=============================================================================
{
	DateTime currentDateTime;

	if ( Fraction == eFraction_Milliseconds ) {
		unsigned short msec;

		currentDateTime = CurrentDateTime( &DateTime, &msec );
		return ( ISOTime( DateTime, msec, WithTimezone ));
	} else {
		unsigned long usec;

		CurrentDateTime( &DateTime, &usec );
		return ( ISOTime( DateTime, usec, WithTimezone ));
	}
}


//=============================================================================
string_t ISODateTime( ESecondsFraction Fraction, bool WithTimezone )
//=============================================================================
{
	const string_t BLANK( TEXT( " " ));

	tm DateTime;

	if ( Fraction == eFraction_Milliseconds ) {
		unsigned short msec;

		CurrentDateTime( &DateTime, &msec );
		return ( ISODate( DateTime ) + BLANK + ISOTime( DateTime, msec, WithTimezone ));
	} else {
		unsigned long usec;

		CurrentDateTime( &DateTime, &usec );
		return ( ISODate( DateTime ) + BLANK + ISOTime( DateTime, usec, WithTimezone ));
	}
}
*/
