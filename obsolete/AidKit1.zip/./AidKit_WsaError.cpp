#include "AidKit_WsaError.hpp"
#include "AidKit_Misc.hpp"
#include <afxtempl.h>
#include <winsock2.h>
#include <winerror.h>
#include "AidKit_Warnings.hpp"

namespace AidKit {

typedef CMap< DWORD, DWORD, CString, const CString & > CMapDWordToString;

struct SMapEntry {
	DWORD Code;
	const char_t *pszDescription;
};

#define MAP_ENTRY( Code, Description ) \
	{ Code, TEXT( Description ) TEXT( " (" ) TEXT( #Code ) TEXT( ")" ) }

static const SMapEntry my_RawErrorMap[] = {
	MAP_ENTRY( WSAEACCES,              "Permission denied" ),
	MAP_ENTRY( WSAEADDRINUSE,          "Address already in use" ),
	MAP_ENTRY( WSAEADDRNOTAVAIL,       "Cannot assign requested address" ),
	MAP_ENTRY( WSAEAFNOSUPPORT,        "Address family not supported by protocol family" ),
	MAP_ENTRY( WSAEALREADY,            "Operation already in progress" ),
	MAP_ENTRY( WSAECONNABORTED,        "Software caused connection abort" ),
	MAP_ENTRY( WSAECONNREFUSED,        "Connection refused" ),
	MAP_ENTRY( WSAECONNRESET,          "Connection reset by peer" ),
	MAP_ENTRY( WSAEDESTADDRREQ,        "Destination address required" ),
	MAP_ENTRY( WSAEFAULT,              "Bad address" ),
	MAP_ENTRY( WSAEHOSTDOWN,           "Host is down" ),
	MAP_ENTRY( WSAEHOSTUNREACH,        "No route to host" ),
	MAP_ENTRY( WSAEINPROGRESS,         "Operation now in progress" ),
	MAP_ENTRY( WSAEINTR,               "Interrupted function call" ),
	MAP_ENTRY( WSAEINVAL,              "Invalid argument" ),
	MAP_ENTRY( WSAEISCONN,             "Socket is already connected" ),
	MAP_ENTRY( WSAEMFILE,              "Too many open files" ),
	MAP_ENTRY( WSAEMSGSIZE,            "Message too long" ),
	MAP_ENTRY( WSAENETDOWN,            "Network is down" ),
	MAP_ENTRY( WSAENETRESET,           "Network dropped connection on reset" ),
	MAP_ENTRY( WSAENETUNREACH,         "Network is unreachable" ),
	MAP_ENTRY( WSAENOBUFS,             "No buffer space available" ),
	MAP_ENTRY( WSAENOPROTOOPT,         "Bad protocol option" ),
	MAP_ENTRY( WSAENOTCONN,            "Socket is not connected" ),
	MAP_ENTRY( WSAENOTSOCK,            "Socket operation on non-socket" ),
	MAP_ENTRY( WSAEOPNOTSUPP,          "Operation not supported" ),
	MAP_ENTRY( WSAEPFNOSUPPORT,        "Protocol family not supported" ),
	MAP_ENTRY( WSAEPROCLIM,            "Too many processes" ),
	MAP_ENTRY( WSAEPROTONOSUPPORT,     "Protocol not supported" ),
	MAP_ENTRY( WSAEPROTOTYPE,          "Protocol wrong type for socket" ),
	MAP_ENTRY( WSAESHUTDOWN,           "Cannot send after socket shutdown" ),
	MAP_ENTRY( WSAESOCKTNOSUPPORT,     "Socket type not supported" ),
	MAP_ENTRY( WSAETIMEDOUT,           "Connection timed out" ),
	MAP_ENTRY( WSATYPE_NOT_FOUND,      "Class type not found" ),
	MAP_ENTRY( WSAEWOULDBLOCK,         "Resource temporarily unavailable" ),
	MAP_ENTRY( WSAHOST_NOT_FOUND,      "Host not found" ),
	MAP_ENTRY( WSA_INVALID_HANDLE,     "Specified event object handle is invalid" ),
	MAP_ENTRY( WSAEINVALIDPROCTABLE,   "Invalid procedure table from service provider" ),
	MAP_ENTRY( WSAEINVALIDPROVIDER,    "Invalid service provider version number" ),
	MAP_ENTRY( WSA_IO_INCOMPLETE,      "Overlaped I/O event object not in signaled state" ),
	MAP_ENTRY( WSA_IO_PENDING,         "Overlapped operations will complete later" ),
	MAP_ENTRY( WSA_NOT_ENOUGH_MEMORY,  "Insufficient memory available" ),
	MAP_ENTRY( WSANOTINITIALISED,      "Successful WSAStartup not yet performed" ),
	MAP_ENTRY( WSANO_DATA,             "Valid name, no data record of requested type" ),
	MAP_ENTRY( WSANO_RECOVERY,         "This is a non-recoverable error" ),
	MAP_ENTRY( WSAEPROVIDERFAILEDINIT, "Unable to initialize a service provider" ),
	MAP_ENTRY( WSASYSCALLFAILURE, 	   "System call failure" ),
	MAP_ENTRY( WSASYSNOTREADY,         "Network subsystem is unavailable" ),
	MAP_ENTRY( WSATRY_AGAIN,           "Non-authoritative host not found" ),
	MAP_ENTRY( WSAVERNOTSUPPORTED,     "WINSOCK.DLL version out of range" ),
	MAP_ENTRY( WSAEDISCON,             "Graceful shutdown in progress" ),
	MAP_ENTRY( WSA_OPERATION_ABORTED,  "Overlapped operation aborted" ),
};

static BOOL our_IsErrorMapInitialized = FALSE;
static CMapDWordToString our_ErrorMap;


//============================================================================= 
static void InitializeErrorMap( void )
//============================================================================= 
{
	size_t i;

	if ( !our_IsErrorMapInitialized ) {
		for ( i = 0; i < countof( my_RawErrorMap ); ++i )
			our_ErrorMap.SetAt( my_RawErrorMap[ i ].Code, CString( my_RawErrorMap[ i ].pszDescription ));

		our_IsErrorMapInitialized = TRUE;
	}
}







//============================================================================= 
CString WSAGetLastErrorString( DWORD WSALastError )
//============================================================================= 
{
	InitializeErrorMap();

	CString Description;
	our_ErrorMap.Lookup( WSALastError, Description );
	return ( Description );
}




//============================================================================= 
static CString WSALookupErrorString( DWORD Error )
//============================================================================= 
{
	CString Description;

	if (( Description = WSAGetLastErrorString( Error )).IsEmpty() )
		if (( Description = GetLastErrorString( Error )).IsEmpty() )
			Description = GetLastErrorCodeString( Error );

	return ( Description );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWsaError
//###
//#############################################################################
//#############################################################################
//#############################################################################


//============================================================================= 
DWORD CWsaError::LastError( void )
	throw()
//============================================================================= 
{
	return ( ::WSAGetLastError() );
}


//============================================================================= 
CWsaError::CWsaError( DWORD WSALastError )
	throw()
		: CWinError( WSALastError )
//============================================================================= 
{
	my_Reason = WSALastError;
}



//============================================================================= 
CWsaError::CWsaError( const CWsaError &Other )
	throw()
		: CWinError( Other )
//============================================================================= 
{
	my_Reason      = Other.my_Reason;
	my_Description = Other.my_Description;
}


//============================================================================= 
DWORD CWsaError::Reason( void ) const
	throw()
//============================================================================= 
{
	return ( my_Reason );
}



//============================================================================= 
const char_t *CWsaError::Description( void ) const
	throw()
//============================================================================= 
{
	if ( my_Description.IsEmpty() )
		my_Description = WSALookupErrorString( my_Reason );

	return ( my_Description );
}




} // namespace AidKit
