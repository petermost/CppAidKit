#ifndef AIDKIT_LEAN_WINDOWS_HPP
#define AIDKIT_LEAN_WINDOWS_HPP

#define VC_EXTRALEAN
#define WIN32_LEAN_AND_MEAN
#define NOCRYPT
#define NOGDI
#define NOSERVICE
#define NOMCX
#define NOIME
#include <windows.h>

#endif
