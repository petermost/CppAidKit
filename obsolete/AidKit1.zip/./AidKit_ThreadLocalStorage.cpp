#include "AidKit_ThreadLocalStorage.hpp"

#ifndef AIDKIT_THREAD_LOCAL_STORAGE_CPP
#define AIDKIT_THREAD_LOCAL_STORAGE_CPP

namespace AidKit {

template< typename CValue >
	//=============================================================================
	TThreadLocalStorage< CValue >::TThreadLocalStorage( void )
	//=============================================================================
	{
	}



template< typename CValue >
	//=============================================================================
	TThreadLocalStorage< CValue >::~TThreadLocalStorage( void )
	//=============================================================================
	{
	}



template< typename CValue >
	//=============================================================================
	const CValue &TThreadLocalStorage< CValue >::Store( const CValue &Value )
	//=============================================================================
	{
		TThreadLock< CStorageMap > pStorage( &my_Storage );

		pStorage->operator[]( GetCurrentThreadId() ) = Value;
		return ( Value );
	}



template< typename CValue >
	//=============================================================================
	bool TThreadLocalStorage< CValue >::Erase( void )
	//=============================================================================
	{
		TThreadLock< CStorageMap > pStorage( &my_Storage );

		return ( pStorage->erase( GetCurrentThreadId() ) > 0 );
	}



template< typename CValue >
	//=============================================================================
	const CValue &TThreadLocalStorage< CValue >::Retrieve( void ) const
	//=============================================================================
	{
		TThreadLock< CStorageMap > pStorage( &my_Storage );

		return ( pStorage->operator[]( GetCurrentThreadId() ));
	}

} // namespace AidKit

#endif
