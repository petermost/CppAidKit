#ifndef AIDKIT_INI_FILE_HPP
#define AIDKIT_INI_FILE_HPP

#include "AidKit.hpp"
#include "AidKit_File.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Preferences.hpp"

#include <map>
#include <string>

namespace AidKit {

	class CStdFile;

	//-----------------------------------------------------------------------------
	class CIniFile : public CPreferences {
	//-----------------------------------------------------------------------------
		public:
			CIniFile( void );
			~CIniFile( void );

			virtual bool Load( CStdFile *pFile );
			virtual bool Save( CStdFile *pFile );

			void Reset( void );

			virtual bool WriteString( const string_t &Section, const string_t &Key, const string_t &Value );
			virtual bool ReadString(  const string_t &Section, const string_t &Key, string_t *pValue );

		protected:
			// Methods to manipulate sections:

			bool CreateSection( const string_t &Section );
			bool EraseSection(  const string_t &Section );
			bool FindSection(   const string_t &Section );

			// Methods to manipulate entries:

			bool WriteEntry( const string_t &Key, const string_t &Value );
			bool EraseEntry( const string_t &Key );
			bool ReadEntry(  const string_t &Key, string_t *pValue ) const;
			
		private:
			void DoLoad( CStdFile *pFile )
				throw ( CStdFileError );

			void DoSave( CStdFile *pFile ) const
				throw ( CStdFileError );

			typedef std::map< string_t, string_t > CSection;
			typedef std::map< string_t, CSection > CSettings;
			
			CSettings my_Settings;
			CSettings::iterator my_itCurrentSection;
	};

}

#endif
