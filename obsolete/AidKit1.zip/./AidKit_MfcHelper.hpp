#ifndef AIDKIT_MFC_HELPER_HPP
#define AIDKIT_MFC_HELPER_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_WinError.hpp"

#include <stack>
#include <afxcmn.h>
#include <afxtempl.h>

class CDataExchange;
class CCheckListBox;
class CIPAddressCtrl;
class CString;
class CStringArray;
class CEdit;
class CListCtrl;
class CListBox;
class CComboBox;
class CRichEditCtrl;

namespace AidKit {

	template < typename TYPE, typename ARG_TYPE >
		class TArray : public CArray< TYPE, ARG_TYPE > {
			public:
				TArray( void )
				{
				}

				TArray( const TArray &Other )
				{
					Copy( Other );
				}
				
				TArray &operator = ( const TArray &Other )
				{
					Copy( Other );
					return ( *this );
				}
		};


	struct CStringInteger {
		CStringInteger( const CString &s, int i ) : String( s ), Integer( i )
			{ }

		CStringInteger( void ) : Integer( 0 )
			{ }

		CString String;
		int Integer;
	};


	struct CStringPointer {
		CStringPointer( const CString &s, void *p = 0 ) : String( s ), Pointer( p )
			{ }

		CStringPointer( void ) : Pointer( 0 )
			{ }

		CString String;
		void *Pointer;
	};


	typedef CArray< CStringInteger, CStringInteger & > CStringIntegerArray;
	typedef CArray< CStringPointer, CStringPointer & > CStringPointerArray;

	// Each DDX-Function is including the CDataExchange so it can behave correctly.
	// This way we can avoid to have to write something like this in DoDataExchange():
	// if ( pDX->m_bSaveAndValidate )
	//     DDX_Text_Read( ... );

	// DDX for CCheckListBox:
	void DDX_Text_Read( CDataExchange *pDX, const CCheckListBox &ListBox, CStringIntegerArray *pStringChecks );
	void DDX_Text_Write( CDataExchange *pDX, CCheckListBox *pListBox, const CStringIntegerArray &StringChecks );
	void DDX_Text( CDataExchange *pDX, CCheckListBox &rListBox,  CStringIntegerArray &rStringChecks );
	
	// DDX for CListBox:
	void DDX_Text_Read( CDataExchange *pDX, const CListBox &ListBox, CStringArray *pStrings );
	void DDX_Text_Write( CDataExchange *pDX, CListBox *pListBox, const CStringArray &Strings );
	void DDX_Text( CDataExchange *pDX, CListBox &rListBox, CStringArray &rStrings );

	// DDX for CComboBox:
	void DDX_Text_Read( CDataExchange *pDX, const CComboBox &ComboBox, CStringPointerArray *pStringPointers );
	void DDX_Text_Write( CDataExchange *pDX, CComboBox *pComboBox, const CStringPointerArray &StringPointers );
	void DDX_Text( CDataExchange *pDX, CComboBox &rComboBox, CStringPointerArray &rStringPointers );
	
	void DDX_Text_Read( CDataExchange *pDX, const CComboBox &ComboBox, CStringIntegerArray *pStringIntegers );
	void DDX_Text_Write( CDataExchange *pDX, CComboBox *pComboBox, const CStringIntegerArray &StringIntegers );
	void DDX_Text( CDataExchange *pDX, CComboBox &rComboBox, CStringIntegerArray &rStringIntegers );

	// DDX for CIPAddressCtl:
	void DDX_Text_Read( CDataExchange *pDX, const CIPAddressCtrl &AddressCtl, CString *pValue );
	void DDX_Text_Write( CDataExchange *pDX, CIPAddressCtrl *pAddressCtl, const CString &Value );
	void DDX_Text( CDataExchange *pDX, CIPAddressCtrl &rAddressCtl, CString &rValue );

	// DDX for CListCtrl:
	void DDX_Text_Read( CDataExchange *pDX, const CListCtrl &ListCtl, CStringArray *pStrings );
	void DDX_Text_Write( CDataExchange *pDX, CListCtrl *pListCtl, const CStringArray &Strings );
	void DDX_Text( CDataExchange *pDX, CListCtrl &rListCtl, CStringArray &rStrings );

	//-----------------------------------------------------------------------------
	class CEditHelper {
	//-----------------------------------------------------------------------------
		public:
			CEditHelper( CEdit *EditCtrl );

			// These functions are propably faster, because they append
			// the text as a block:

			void AppendText( const char_t Text[] );
			void AppendNewLine( void );

			// These functions are probaly slower, bcause they insert
			// each character seperatly:

			void InsertText( const char_t Text[] );
			void InsertNewLine( void );

		private:
			CEdit *my_EditCtrl;
	};

	typedef TWinError< class CRichEditHelper > CRichEditHelperError;

	//-----------------------------------------------------------------------------
	class CRichEditHelper {
	//-----------------------------------------------------------------------------
		public:
			static const int kDefaultFormat;

			CRichEditHelper( CRichEditCtrl *pRichEdit );

			long StreamIn( CString Content, int Format = kDefaultFormat )
				throw ( CRichEditHelperError );

			long StreamOut( CString *pContent, int Format = kDefaultFormat )
				throw ( CRichEditHelperError );

		private:
			CRichEditCtrl *my_pRichEdit;
	};



	//-----------------------------------------------------------------------------
	class CTreeBuilder {
	//-----------------------------------------------------------------------------
		public:
			CTreeBuilder( CTreeCtrl *pTree );

			HTREEITEM CreateBranch( const char_t Inscription[] );
			HTREEITEM CreateLeaf( const char_t Inscription[] );
			void CloseBranch( void );

		private:
			CTreeCtrl *my_pTree;
			HTREEITEM my_hParent;
			std::stack< HTREEITEM > my_Parents;
	};


}

#endif
