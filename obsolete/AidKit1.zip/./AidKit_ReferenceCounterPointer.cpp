#ifndef AIDKIT_REFERENCE_COUNTER_POINTER_CPP
#define AIDKIT_REFERENCE_COUNTER_POINTER_CPP

#include "AidKit_ReferenceCounter.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TReferenceCounterPointer
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < typename CType >
	//=============================================================================
	TReferenceCounterPointer< CType >::TReferenceCounterPointer( CType *pObject )
	//=============================================================================
	{
		if (( my_pObject = pObject ) != 0 )
			my_pObject->AcquireReference();
	}



template < typename CType >
	//=============================================================================
	TReferenceCounterPointer< CType >::TReferenceCounterPointer( const TReferenceCounterPointer &OtherPtr )
	//=============================================================================
	{
		if (( my_pObject = OtherPtr.my_pObject ) != 0 )
			my_pObject->AcquireReference();
	}



template < typename CType >
	//=============================================================================
	TReferenceCounterPointer< CType >::~TReferenceCounterPointer( void )
	//=============================================================================
	{
		if ( my_pObject != 0 )
			my_pObject->ReleaseReference();
	}



template < typename CType >
	//=============================================================================
	CType *TReferenceCounterPointer< CType >::operator = ( CType *pObject )
	//=============================================================================
	{
		if ( my_pObject != pObject ) {
			if ( my_pObject != 0 )
				my_pObject->ReleaseReference();

			if (( my_pObject = pObject ) != 0 )
				my_pObject->AcquireReference();
		}
		return ( my_pObject );
	}
	


template < typename CType >
	//=============================================================================
	TReferenceCounterPointer< CType > &TReferenceCounterPointer< CType >::operator = ( const TReferenceCounterPointer &OtherPtr )
	//=============================================================================
	{
		if ( my_pObject != OtherPtr.my_pObject ) {
			if ( my_pObject != 0 )
				my_pObject->ReleaseReference();

			if (( my_pObject = OtherPtr.my_pObject ) != 0 )
				my_pObject->AcquireReference();
		}
		return ( *this );
	}



template < typename CType >
	//=============================================================================
	CType *TReferenceCounterPointer< CType >::operator->( void ) const
	//=============================================================================
	{
		return ( my_pObject );
	}



template < typename CType >
	//=============================================================================
	CType &TReferenceCounterPointer< CType >::operator * ( void ) const
	//=============================================================================
	{
		return ( *my_pObject );
	}


template < typename CType >
	//=============================================================================
	TReferenceCounterPointer< CType >::operator CType * ( void ) const
	//=============================================================================
	{
		return ( my_pObject );
	}

} // namespace AidKit

#endif
