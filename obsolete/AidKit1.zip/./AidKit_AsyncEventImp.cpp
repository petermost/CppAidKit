#ifndef AIDKIT_ASYNC_EVENT_IMP_CPP
#define AIDKIT_ASYNC_EVENT_IMP_CPP

#include "AidKit_AsyncEvent.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TAsyncEvent1
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < typename P1 >
	//=============================================================================
	void TAsyncEvent1< P1 >::Announce( P1 p1 ) const
	//=============================================================================
	{
		SParameters Parameters = { p1 };
		my_Parameters.push_back( Parameters );

		Dispatch( this );
	}


template < typename P1 >
	//=============================================================================
	void TAsyncEvent1< P1 >::Relay( void ) const
	//=============================================================================
	{
		for ( typename CParameters::const_iterator itParameter = my_Parameters.begin();
			itParameter != my_Parameters.end(); ++itParameter ) {
				TEvent1< P1 >::Announce( itParameter->my_Parameter1 );
		}
		my_Parameters.clear();
	}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TAsyncEvent2
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < typename P1, typename P2 >
	//=============================================================================
	void TAsyncEvent2< P1, P2 >::Announce( P1 p1, P2 p2 ) const
	//=============================================================================
	{
		SParameters Parameters = { p1, p2 };
		my_Parameters.push_back( Parameters );

		Dispatch( this );
	}


template < typename P1, typename P2 >
	//=============================================================================
	void TAsyncEvent2< P1, P2 >::Relay( void ) const
	//=============================================================================
	{
		for ( typename CParameters::const_iterator itParameter = my_Parameters.begin();
			itParameter != my_Parameters.end(); ++itParameter ) {
				TEvent2< P1, P2 >::Announce( itParameter->my_Parameter1, itParameter->my_Parameter2 );
		}
		my_Parameters.clear();
	}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TAsyncEvent3
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < typename P1, typename P2, typename P3 >
	//=============================================================================
	void TAsyncEvent3< P1, P2, P3 >::Announce( P1 p1, P2 p2, P3 p3 ) const
	//=============================================================================
	{
		SParameters Parameters = { p1, p2, p3 };
		my_Parameters.push_back( Parameters );

		Dispatch( this );
	}


template < typename P1, typename P2, typename P3 >
	//=============================================================================
	void TAsyncEvent3< P1, P2, P3 >::Relay( void ) const
	//=============================================================================
	{
		for ( typename CParameters::const_iterator itParameter = my_Parameters.begin();
			itParameter != my_Parameters.end(); ++itParameter ) {
				TEvent3< P1, P2, P3 >::Announce( itParameter->my_Parameter1, itParameter->my_Parameter2, itParameter->my_Parameter3 );
		}
		my_Parameters.clear();
	}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TAsyncEvent4
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < typename P1, typename P2, typename P3, typename P4 >
	//=============================================================================
	void TAsyncEvent4< P1, P2, P3, P4 >::Announce( P1 p1, P2 p2, P3 p3, P4 p4 ) const
	//=============================================================================
	{
		SParameters Parameters = { p1, p2, p3, p4 };
		my_Parameters.push_back( Parameters );

		Dispatch( this );
	}

template < typename P1, typename P2, typename P3, typename P4 >
	//=============================================================================
	void TAsyncEvent4< P1, P2, P3, P4 >::Relay( void ) const
	//=============================================================================
	{
		for ( typename CParameters::const_iterator itParameter = my_Parameters.begin();
			itParameter != my_Parameters.end(); ++itParameter ) {
				TEvent4< P1, P2, P3, P4 >::Announce( itParameter->my_Parameter1, itParameter->my_Parameter2, itParameter->my_Parameter3, itParameter->my_Parameter4 );
		}
		my_Parameters.clear();
	}



} // namespace AidKit

#endif
