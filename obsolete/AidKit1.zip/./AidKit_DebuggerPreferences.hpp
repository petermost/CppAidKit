#ifndef AIDKIT_DEBUGGER_PREFERENCES_HPP
#define AIDKIT_DEBUGGER_PREFERENCES_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_IniFile.hpp"
#include "AidKit_Debugger.hpp"

#include <map>

namespace AidKit {

	class CDebugger;

	//-----------------------------------------------------------------------------
	class CDebuggerPreferences : public CDebuggerSettings {
	//-----------------------------------------------------------------------------
		public:
			CDebuggerPreferences( const string_t &FileName,
				bool IsGlobalTraceEnabled = true, bool IsGlobalDumpEnabled = true );

			~CDebuggerPreferences( void );

			bool Load( void );
			bool Save( void );

			virtual bool IsTraceEnabled( const CDebugger *, bool DefaultValue );
			virtual bool IsDumpEnabled( const CDebugger *, bool DefaultValue );

		private:
			bool my_IsGlobalTraceEnabled;
			bool my_IsGlobalDumpEnabled;

			CIniFile my_IniFile;
			time_t my_IniFileDate;
			string_t my_IniFileName;
	};

} // namespace AidKit

#endif
