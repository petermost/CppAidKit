#ifndef AIDKIT_TEMPLATES_HPP
#define AIDKIT_TEMPLATES_HPP

#include "AidKit.hpp"
#include <stddef.h>
#include <utility>

namespace AidKit {

	// We have to undef min and max because, otherwise the preprocessor would
	// replace the template names!

	#if defined( min )
		#undef min
	#endif

	#if defined( max )
		#undef max
	#endif

	template< typename CValue >
		//=============================================================================
		inline const CValue &min( const CValue &Value1, const CValue &Value2 )
		//=============================================================================
		{
			return (( Value1 < Value2 ) ? Value1 : Value2 );
		}



	template< typename CValue >
		//=============================================================================
		inline const CValue &max( const CValue &Value1, const CValue &Value2 )
		//=============================================================================
		{
			return (( Value1 > Value2 ) ? Value1 : Value2 );
		}

	
	
	template < typename CValue >
		//=============================================================================
		const CValue Exchange( CValue *pValue, const CValue &NewValue )
		//=============================================================================
		{
			CValue OldValue( *pValue );
			*pValue = NewValue;
			return ( OldValue );
		}


	template < typename CType >
		//=============================================================================
		inline void Erase( CType *pType, size_t TypeSize = sizeof( CType ))
		//=============================================================================
		{
			memset( pType, 0, TypeSize );
		}


	template < typename CInputIterator, typename COutputIterator, typename CPadValue >
		//=============================================================================
		COutputIterator pad_left( CInputIterator InputBegin, CInputIterator InputEnd,
			COutputIterator OutputBegin, COutputIterator OutputEnd, const CPadValue &PadValue )
		//=============================================================================
		{
			while ( InputEnd != InputBegin && OutputEnd != OutputBegin )
				*--OutputEnd = *--InputEnd;

			while ( OutputEnd != OutputBegin )
				*--OutputEnd = PadValue;

			return ( OutputEnd );
		}



	template < typename CInputIterator, typename COutputIterator, typename CPadValue >
		//=============================================================================
		COutputIterator pad_right( CInputIterator InputBegin, CInputIterator InputEnd,
			COutputIterator OutputBegin, COutputIterator OutputEnd, const CPadValue &PadValue )
		//=============================================================================
		{
			while ( InputBegin != InputEnd && OutputBegin != OutputEnd )
				*OutputBegin++ = *InputBegin++;

			while ( OutputBegin != OutputEnd )
				*OutputBegin++ = PadValue;

			return ( OutputBegin );
		}

	template < typename InputIterator >
		//=============================================================================
		std::pair< InputIterator, InputIterator > find_difference( InputIterator itFirst1, InputIterator itLast1,
			InputIterator itFirst2, InputIterator itLast2 )
		//=============================================================================
		{
			while ( itFirst1 != itLast1 && itFirst2 != itLast2 ) {
				if ( *itFirst1 < *itFirst2 ) {
					return ( std::make_pair( itFirst1, itLast1 ));
				}
				else if (  *itFirst2 < *itFirst1 ) {
					return ( std::make_pair( itFirst2, itLast2 ));
				}
				else {
					++itFirst1;
					++itFirst2;
				}
			}
			return ( std::make_pair( itFirst1, itLast1 ));
		}


	template < typename CDerivedClass, typename CBaseClass >
		//-----------------------------------------------------------------------------
		class TConversion {
		//-----------------------------------------------------------------------------
			public:
				class CFalse {
					char my_Dummy[ 1 ];
				};

				class CTrue {
					char my_Dummy[ 2 ];
				};

				static CTrue IsDerived( CBaseClass );
				static CFalse IsDerived( ... );
				static CDerivedClass ConstructDerived( void );

				enum {
					Exists = ( sizeof( IsDerived( ConstructDerived() )) == sizeof( CTrue ))
				};
		};

	#define IS_DERIVED( DerivedClass, BaseClass ) \
		( AidKit::TConversion< DerivedClass, BaseClass >::Exists )

} // namespace AidKit

#endif
