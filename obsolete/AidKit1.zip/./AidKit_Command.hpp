#ifndef AIDKIT_COMMAND_HPP
#define AIDKIT_COMMAND_HPP

#include "AidKit.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CCommand {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CCommand( void );

			virtual void Execute( void ) = 0;
	};


	//-----------------------------------------------------------------------------
	template < typename F >
	//-----------------------------------------------------------------------------
		class TGenericCommand : public CCommand {
			public:
				TGenericCommand( F Function )
					: my_Function( Function )
						{ }

				virtual void Execute( void )
					{ my_Function(); }

			private:
				F my_Function;
		};
}

#endif
