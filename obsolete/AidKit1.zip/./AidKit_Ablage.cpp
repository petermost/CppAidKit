
/*

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///                                                                         ///
///           Converter function between WCHAR's and char's                 ///
///                                                                         ///
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////



//=============================================================================
char wchar2char( register WCHAR wc )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	return ( wchar_to_char( wc ));
#else
	return ( wc );
#endif
}



//=============================================================================
WCHAR char2wchar( register char c )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	return ( char_to_wchar( c ));
#else
	return ( c );
#endif
}



//=============================================================================
char *wtext2text( char text[], const WCHAR wtext[], size_t count )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	return ( wtexto_text( text, wtext, count ));
#else
	assert( count >= strlen( wtext ));
	strncpy( text, wtext, count );
	return ( text );
#endif
}



//=============================================================================
WCHAR *text2wtext( WCHAR wtext[], const char text[], size_t count )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	return ( texto_wtext( wtext, text, count ));
#else
	assert( count >= strlen( text ));
	strncpy( wtext, text, count );
	return ( wtext );
#endif
}



//=============================================================================
std::string &wstring2string( std::string *string, const WSTRING &wstring )
//=============================================================================
{
	wtext2string( string, wstring.data(), wstring.length() );

	return ( *string );
}



//=============================================================================
WSTRING &string2wstring( WSTRING *wstring, const std::string &string )
//=============================================================================
{
	text2wstring( wstring, string.data(), string.length() );

	return ( *wstring );
}




//=============================================================================
const char *wtext2text( const WCHAR wtext[] )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	return ( wtexto_text( wtext ));
#else
	return ( wtext );
#endif
}

	



//=============================================================================
const WCHAR *text2wtext( const char text[] )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	return ( texto_wtext( text ));
#else
	return ( text );
#endif
}

*/














/*
//=============================================================================
template < typename type_name >
	type_name *remalloc( type_name *old_memory, size_t new_memory_size, size_t *old_memory_size )
	//=============================================================================
	{
		type_name *new_memory;

		if ( new_memory_size > *old_memory_size ) {
			if (( new_memory = static_cast< type_name * >( realloc( old_memory, new_memory_size ))) != NULL ) {
				old_memory      = new_memory;
				*old_memory_size = new_memory_size;
			}
		}
		return ( old_memory );
	}




//=============================================================================
const char *wtext2text( const WCHAR wtext[] )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	// The documentation states: "If there are two bytes in the multibyte output
	// string for every wide character in the input string (including the wide
	// character NULL), the result is guaranteed to fit."

	static size_t length = max( 100u, ( WSTRLEN( wtext ) + 1 ) * 2 );
	static char *text = static_cast< char * >( malloc( length ));
	
	text = remalloc( text, ( WSTRLEN( wtext ) + 1 ) * 2, &length );
	wcstombs( text, wtext, length );
	return ( text );

#else

	return ( wtext );

#endif
}



//=============================================================================
const WCHAR *text2wtext( const char text[] )
//=============================================================================
{
#if defined( AIDKIT_UNICODE )
	
	static size_t wtext_length = max( 100u, strlen( text ) + 1 );
	static WCHAR *wtext = static_cast< WCHAR * >( malloc( wtext_length ));

	wtext = remalloc( wtext, strlen( text ) + 1, &wtext_length );
	mbstowcs( wtext, text, wtext_length );
	return ( wtext );

#else

	return ( text );

#endif
}
*/

/*
//=============================================================================
CLogFile::CLogFile( const size_t MaxLineCount, const size_t MaxLineLength )
	: my_MaxLineCount( MaxLineCount ), my_MaxLineLength( MaxLineLength + 1 ) // +1 for '\n'
//=============================================================================
{
	my_pLine = new char_t[ my_MaxLineLength ];
	my_File = NULL;
}


//=============================================================================
CLogFile::~CLogFile( void )
//=============================================================================
{
	delete[] my_pLine;
	assert( my_File == NULL ); // Didn't call Close?
}


//=============================================================================
void CLogFile::Open( const char_t Filename[], size_t nFirstLine )
	throw ( file_error )
//=============================================================================
{
	// We can't use "a+" because before each write it ALWAYS seeks to the end!

	if (( my_File = f_open( Filename, TEXT( "r+" ))) == NULL )
		if (( my_File = f_open( Filename, TEXT( "w+" ))) == NULL )
			throw ( file_error::LastError() );

	// First position at the end of the file:

	file_seek( my_File, 0, SEEK_END );

	// Position at the first line we should write to, but make sure we don't
	// move past the end, because then it get's filled with '\0' characters!

	if ( nFirstLine > 0 ) {
		size_t nLineCount = file_tell( my_File ) / my_MaxLineLength;
		if ( nFirstLine < nLineCount )
			file_seek( my_File, ( nFirstLine - 1 ) * my_MaxLineLength, SEEK_SET );
	}
}



//=============================================================================
void CLogFile::Close( void )
	throw ( file_error )
//=============================================================================
{
	file_close( my_File );
	my_File = NULL;
}



//=============================================================================
void CLogFile::Write( const char_t Line[] )
	throw ( file_error )
//=============================================================================
{
	// First check wether we already reached the limit (otherwise if the file is
	// already at it's limit it would grow by one line):

	size_t nLineCount = file_tell( my_File ) / my_MaxLineLength;
	if ( nLineCount >= my_MaxLineCount )
		file_seek( my_File, 0, SEEK_SET );

	// Create a padded line:

	char_t *pEnd = pad_right( &Line[ 0 ], &Line[ str_len( Line ) ], &my_pLine[ 0 ], &my_pLine[ my_MaxLineLength - 1 ], TEXT( ' ' ));
	*pEnd = '\n';

	// Finaly write it to the file:

	file_write( my_File, my_pLine, my_MaxLineLength );
	file_flush( my_File );
}
*/
