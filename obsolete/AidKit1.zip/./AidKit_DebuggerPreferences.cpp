#include "AidKit_DebuggerPreferences.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_File.hpp"

// using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDebuggerPreferences
//###
//#############################################################################
//#############################################################################
//#############################################################################


static const string_t GLOBAL_DEBUGGER_NAME( TEXT( "" ));
static const string_t GLOBAL_TRACE_KEY_NAME( TEXT( "Trace" ));
static const string_t GLOBAL_DUMP_KEY_NAME( TEXT( "Dump" ));

static const string_t TRACE_KEY_NAME( TEXT( "Trace" ));
static const string_t DUMP_KEY_NAME( TEXT( "Dump" ));

//=============================================================================
CDebuggerPreferences::CDebuggerPreferences( const string_t &FileName,
	bool IsGlobalTraceEnabled, bool IsGlobalDumpEnabled )
//=============================================================================
{
	AIDKIT_ASSERT( FileName.length() > 0 );

	my_IsGlobalTraceEnabled = IsGlobalTraceEnabled;
	my_IsGlobalDumpEnabled  = IsGlobalDumpEnabled;

	my_IniFileName = FileName;
	my_IniFileDate = 0;

	// We don't need to load it the first time (will be done in => LoadModifications)!
}



//=============================================================================
CDebuggerPreferences::~CDebuggerPreferences( void )
//=============================================================================
{
	Save();
}



//=============================================================================
bool CDebuggerPreferences::Load( void )
//=============================================================================
{
	bool IsLoaded = false;

	if ( IsLoaded = CDebugger::IsDebugging() ) {
		bool IsEnabled;
		CStdFile File( my_IniFileName, "rt" );
		if ( IsLoaded = my_IniFile.Load( &File )) {

			// Read the GLOBAL settings, which control all debuggers:

			if ( my_IniFile.ReadBool( GLOBAL_DEBUGGER_NAME, GLOBAL_TRACE_KEY_NAME, &IsEnabled ))
				my_IsGlobalTraceEnabled = IsEnabled;

			if ( my_IniFile.ReadBool( GLOBAL_DEBUGGER_NAME, GLOBAL_DUMP_KEY_NAME, &IsEnabled ))
				my_IsGlobalDumpEnabled = IsEnabled;
		}
	}
	return ( IsLoaded );
}


//=============================================================================
bool CDebuggerPreferences::Save( void )
//=============================================================================
{
	bool IsSaved = false;

	if ( IsSaved = CDebugger::IsDebugging() ) {
		bool IsEnabled;

		// Write the GLOBAL settings, which control all debuggers:

		IsEnabled = my_IsGlobalTraceEnabled;
		my_IniFile.WriteBool( GLOBAL_DEBUGGER_NAME, GLOBAL_TRACE_KEY_NAME, IsEnabled );

		IsEnabled = my_IsGlobalDumpEnabled;
		my_IniFile.WriteBool( GLOBAL_DEBUGGER_NAME, GLOBAL_DUMP_KEY_NAME, IsEnabled );

		CStdFile File( my_IniFileName, "wt" );
		IsSaved = my_IniFile.Save( &File );
	}
	return ( IsSaved );
}



//=============================================================================
static bool IsSwitchEnabled( CIniFile *pIniFile, const CDebugger *pDebugger,
	const string_t &KeyName, bool IsGlobalEnabled, bool DefaultValue )
//=============================================================================
{
	bool IsEnabled;

	// If no value has been enabled in the INI-file, then use the default value:

	if ( pIniFile->ReadBool( pDebugger->Name(), KeyName, &IsEnabled ))
		return ( IsGlobalEnabled && IsEnabled );
	else {
		pIniFile->WriteBool( pDebugger->Name(), KeyName, DefaultValue );
		return ( DefaultValue );
	}
}



//=============================================================================
static bool LoadModifications( CDebuggerPreferences *pPreferences,
	const string_t &IniFileName, time_t *pIniFileDate )
//=============================================================================
{
	bool IsModified = false;
	CFileSystem FileSystem;

	try {
		CFileInfo Info = FileSystem.FileInfo( IniFileName );

		if ( Info.ModificationTime != *pIniFileDate ) {
			IsModified = pPreferences->Load();
			*pIniFileDate = Info.ModificationTime;
		}
	} catch ( const CFileSystemError & ) {
		; // Ignore file not found errors.
	}
	return ( IsModified );
}



//=============================================================================
bool CDebuggerPreferences::IsTraceEnabled( const CDebugger *pDebugger, bool DefaultValue )
//=============================================================================
{
	if ( CDebugger::IsDebugging() ) {
		LoadModifications( this, my_IniFileName, &my_IniFileDate );
		return ( IsSwitchEnabled( &my_IniFile, pDebugger, TRACE_KEY_NAME, my_IsGlobalTraceEnabled, DefaultValue ));
	} else
		return ( false );
}



//=============================================================================
bool CDebuggerPreferences::IsDumpEnabled( const CDebugger *pDebugger, bool DefaultValue )
//=============================================================================
{
	if ( CDebugger::IsDebugging() ) {
		LoadModifications( this, my_IniFileName, &my_IniFileDate );
		return ( IsSwitchEnabled( &my_IniFile, pDebugger, DUMP_KEY_NAME, my_IsGlobalDumpEnabled, DefaultValue ));
	} else
		return ( false );
}

} // namespace AidKit
