#include "AidKit_Socket.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Memory.hpp"
#include "AidKit_SocketHelper.hpp"

using namespace std;

namespace AidKit {

using namespace Unix;

//=============================================================================
int CheckSocketApi( int nResult )
	throw ( CSocketError )
//=============================================================================
{
	if ( nResult == SOCKET_ERROR )
		throw ( CSocketError::LastError() );
	
	return ( nResult );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSocketUtil
//###
//#############################################################################
//#############################################################################
//#############################################################################

const char_t CSocketUtil::PROTOCOL_NAME_TCP[] = TEXT( "tcp" );
const char_t CSocketUtil::PROTOCOL_NAME_UDP[] = TEXT( "udp" );


//=============================================================================
port_t CSocketUtil::ServicePort( const char_t ServiceName[], const char_t ProtocolName[] )
	throw ( CSocketError )
//=============================================================================
{
	servent *pServiceEntry;

	if (( pServiceEntry = getservbyname( text( ServiceName ), text( ProtocolName ))) != NULL )
		return ( ntohs( pServiceEntry->s_port ));
	else
		throw ( CSocketError::LastError() );

}



//=============================================================================
int CSocketUtil::SocketType( const char_t ProtocolName[] )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	int SocketType = SOCK_STREAM;

	if ( str_cmp( ProtocolName, PROTOCOL_NAME_TCP ) == 0 )
		SocketType = SOCK_STREAM;
	else if ( str_cmp( ProtocolName, PROTOCOL_NAME_UDP ) == 0 )
		SocketType = SOCK_DGRAM;
	else
		AIDKIT_ASSERT( false );

	return ( SocketType );
}



//=============================================================================
int CSocketUtil::ProtocolType( const char_t ProtocolName[] )
	throw ( CSocketError )
//=============================================================================
{
	int ProtocolType;
	protoent *pProtocolEntry;

	if (( pProtocolEntry = getprotobyname( text( ProtocolName ))) != NULL )
		ProtocolType = pProtocolEntry->p_proto;
	else
		throw ( CSocketError::LastError() );

	return ( ProtocolType );
}



//=============================================================================
string_t CSocketUtil::HostName( void )
	throw ( CSocketError )
//=============================================================================
{
	char_t Name[ 255 ];

	CheckSocketApi( gethostname( Name, countof( Name )));

	return ( string_t( Name ));
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSocketBasics
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CSocketBasics::~CSocketBasics( void )
	throw()
//=============================================================================
{
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSocket
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CSocket::CSocket( void )
	throw ( CSocketError )
//=============================================================================
{
	my_hSocket = INVALID_SOCKET;
}



//=============================================================================
CSocket::~CSocket( void )
	throw()
//=============================================================================
{
	try {
		if ( IsOpen() )
			Close();
	} catch ( ... ) {
		;
	}
}




//=============================================================================
bool CSocket::Open( EType eType )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( !IsOpen() );

	int DomainType = PF_INET;
	switch ( eType ) {
		case eTypeInetV4:
			DomainType = PF_INET;
			break;

		case eTypeInetV6:
			DomainType = PF_INET6;
			break;

		case eTypeLocal:
			DomainType = PF_UNIX;
			break;
	}
	int SocketType   = CSocketUtil::SocketType(   CSocketUtil::PROTOCOL_NAME_TCP );
	int ProtocolType = CSocketUtil::ProtocolType( CSocketUtil::PROTOCOL_NAME_TCP );
	
	my_hSocket = socket( DomainType, SocketType, ProtocolType );
	if ( my_hSocket == INVALID_SOCKET )
		throw ( CSocketError::LastError() );

	return ( true );
}



//=============================================================================
bool CSocket::IsOpen( void ) const
	throw()
//=============================================================================
{
	return ( my_hSocket != INVALID_SOCKET );
}



//=============================================================================
void CSocket::Shutdown( EDirection eDirection )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	CheckSocketApi( DoShutdown( my_hSocket, eDirection ));
}



//=============================================================================
bool CSocket::Close( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	CheckSocketApi( DoClose( my_hSocket ));
	my_hSocket = INVALID_SOCKET;

	return ( !IsOpen() );
}


//=============================================================================
void CSocket::Notify( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_Selector.Notify();
}



//=============================================================================
bool CSocket::IsNotified( void )
	throw()
//=============================================================================
{
	return ( my_Selector.IsNotified() );
}



//=============================================================================
void CSocket::SetOption( EOption eOption, int nOptionValue )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	int nOption;

	switch ( eOption ) {
		case eOptionReuseAddress:
			nOption = SO_REUSEADDR;
			break;

		case eOptionSendBufferSize:
			nOption = SO_SNDBUF;
			break;

		case eOptionReceiveBufferSize:
			nOption = SO_RCVBUF;
			break;

		case eOptionKeepAlive:
			nOption = SO_KEEPALIVE;
			break;

		default:
			throw ( CSocketError( EINVAL ));
			break;

	}
	CheckSocketApi( DoSetSocketOption( my_hSocket, SOL_SOCKET, nOption, &nOptionValue, sizeof( nOptionValue )));
}



//=============================================================================
int CSocket::GetOption( EOption eOption )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	int nOption;
	int nOptionValue = 0;

	switch ( eOption ) {
		case eOptionError:
			nOption = SO_ERROR;
			break;

		case eOptionSendBufferSize:
			nOption = SO_SNDBUF;
			break;

		case eOptionReceiveBufferSize:
			nOption = SO_RCVBUF;
			break;

		case eOptionKeepAlive:
			nOption = SO_KEEPALIVE;
			break;
		default:
			throw ( CSocketError( EINVAL ));
			break;
	}
	socklen_t nOptionSize = sizeof( nOptionValue );
	CheckSocketApi( DoGetSocketOption( my_hSocket, SOL_SOCKET, nOption, &nOptionValue, &nOptionSize ));

	return ( nOptionValue );
}



//=============================================================================
void CSocket::SetTcpOption( ETcpOption eOption, int nOptionValue )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
#if defined( AIDKIT_LINUX )
	AIDKIT_ASSERT( IsOpen() );

	int nOption;

	switch ( eOption ) {
		case eTcpOptionKeepAliveTime:
			nOption = TCP_KEEPIDLE;
			break;

		case eTcpOptionKeepAliveInterval:
			nOption = TCP_KEEPINTVL;
			break;

		case eTcpOptionKeepAliveProbes:
			nOption = TCP_KEEPCNT;
			break;

		case eTcpOptionCork:
			nOption = TCP_CORK;
			break;

		default:
			throw ( CSocketError( EINVAL ));
			break;

	}
	CheckSocketApi( DoSetSocketOption( my_hSocket, SOL_TCP, nOption, &nOptionValue, sizeof( nOptionValue )));

#endif
}



//=============================================================================
int CSocket::GetTcpOption( ETcpOption eOption )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	int nOption;
	int nOptionValue = 0;

#if defined( AIDKIT_LINUX )

	switch ( eOption ) {
		case eTcpOptionKeepAliveTime:
			nOption = TCP_KEEPIDLE;
			break;

		case eTcpOptionKeepAliveInterval:
			nOption = TCP_KEEPINTVL;
			break;

		case eTcpOptionKeepAliveProbes:
			nOption = TCP_KEEPCNT;
			break;

		case eTcpOptionCork:
			nOption = TCP_CORK;
			break;

		default:
			throw ( CSocketError( EINVAL ));
			break;
	}
	socklen_t nOptionSize = sizeof( nOptionValue );
	CheckSocketApi( DoGetSocketOption( my_hSocket, SOL_TCP, nOption, &nOptionValue, &nOptionSize ));

#endif

	return ( nOptionValue );
}



//=============================================================================
CSocket::EMode CSocket::IOControl( EMode eMode )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	EMode OldMode;

	CheckSocketApi( DoIOControl( my_hSocket, eMode, &OldMode ));

	return ( OldMode );
}



//=============================================================================
int CSocket::Select( CFdSet *pInputSet, CFdSet *pOutputSet, CFdSet *pExceptSet,
	milliseconds_t Timeout, bool IsNotifiable )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	// Do the actual select:
	try {
		int nResult = my_Selector.Select( pInputSet, pOutputSet, pExceptSet,
			Timeout, IsNotifiable );
		return ( nResult );
	}
	catch ( const CSelectorError &SelectorError ) {
		throw ( CSocketError( SelectorError ));
	}
}




//=============================================================================
bool CSocket::Connect( const char_t HostName[], port_t nPort )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );
	AIDKIT_ASSERT( HostName != NULL && str_len( HostName ) > 0 );

	sockaddr_in Address;
	memclr( &Address, sizeof( Address ));

	hostent *pHostEntry = NULL;
	if (( pHostEntry = gethostbyname( text( HostName ))) != NULL ) {
		memcpy( &Address.sin_addr, pHostEntry->h_addr, pHostEntry->h_length );
	} else {
		Address.sin_addr = DoNameToAddress( HostName );
	}
	Address.sin_family = AF_INET;
	Address.sin_port = htons( nPort );

	return ( DoTryConnect( my_hSocket, reinterpret_cast< const sockaddr * >( &Address ), sizeof( Address )));
}



//=============================================================================
void CSocket::Bind( port_t nPort, const char_t HostName[] )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	sockaddr_in Address;
	memclr( &Address, sizeof( Address ));

	hostent *pHostEntry = NULL;
	if ( HostName != NULL && str_len( HostName ) > 0 ) {
		if (( pHostEntry = gethostbyname( text( HostName ))) != NULL ) {
			memcpy( &Address.sin_addr, pHostEntry->h_addr, pHostEntry->h_length );
		} else {
			Address.sin_addr = DoNameToAddress( HostName );
		}
	} else {
		Address.sin_addr.s_addr = INADDR_ANY;
	}
	Address.sin_family = AF_INET;
	Address.sin_port = htons( nPort );

	CheckSocketApi( bind( my_hSocket, reinterpret_cast< const sockaddr * >( &Address ), sizeof( Address )));
}



//=============================================================================
void CSocket::Listen( int nBackLog )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	CheckSocketApi( listen( my_hSocket, nBackLog ));
}



//=============================================================================
CSocket *CSocket::Accept( CSocket *pSocket, in_addr *pAddress )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );
	AIDKIT_ASSERT( !pSocket->IsOpen() );

	sockaddr_in Address;
	memclr( &Address, sizeof( Address ));
	socklen_t nAddressSize = sizeof( Address );

	socket_t hNewSocket = accept( my_hSocket, reinterpret_cast< sockaddr * >( &Address ), &nAddressSize );
	if ( hNewSocket != INVALID_SOCKET ) {
		pSocket->my_hSocket = hNewSocket;
		if ( pAddress != NULL )
			*pAddress = Address.sin_addr;
	} else
		throw ( CSocketError::LastError() );

	return ( pSocket );
}




//=============================================================================
size_t CSocket::Receive( void *pData, size_t nDataSize, unsigned Flags /* = eReceiveFlag_None */ )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	// AIDKIT_ASSERT( IsOpen() );

	unsigned ReceiveFlags = 0;

	if ( Flags != eReceiveFlag_None ) {
		if ( Flags & eReceiveFlag_OOB )
			ReceiveFlags |= MSG_OOB;

		if ( Flags & eReceiveFlag_WaitAll )
			ReceiveFlags |= MSG_WAITALL;

		if ( Flags & eReceiveFlag_NoSignal )
			ReceiveFlags |= MSG_NOSIGNAL;

		if ( Flags & eReceiveFlag_Peek )
			ReceiveFlags |= MSG_PEEK;
	}
	return ( DoReceive( my_hSocket, pData, nDataSize, ReceiveFlags ));
}



//=============================================================================
size_t CSocket::Send( const void *pData, size_t nDataSize, unsigned Flags /* = eSendFlag_None */ )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	// AIDKIT_ASSERT( IsOpen() );

	unsigned SendFlags = 0;

	if ( Flags != eSendFlag_None ) {
		if ( Flags & eSendFlag_OOB )
			SendFlags |= MSG_OOB;

		if ( Flags & eSendFlag_DontWait )
			SendFlags |= MSG_DONTWAIT;

		if ( Flags & eSendFlag_NoSignal )
			SendFlags |= MSG_NOSIGNAL;
	}
	return ( DoSend( my_hSocket, pData, nDataSize, SendFlags ));
}


//=============================================================================
size_t CSocket::Send( file_t hFile, off_t *pOffset, size_t Count )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	// AIDKIT_ASSERT( IsOpen() );

	return ( DoSend( my_hSocket, hFile, pOffset, Count ));
}


//=============================================================================
SSocketPeer CSocket::Peer( void ) const
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( IsOpen() );

	// Query the peer data:

	sockaddr_in Address;
	socklen_t AddressSize = sizeof( Address );

	CheckSocketApi( getpeername( my_hSocket, reinterpret_cast< sockaddr * >( &Address ), &AddressSize ));

	// Convert them to a 'readable' format:

	SSocketPeer SocketPeer;
	SocketPeer.Name = DoAddressToName( Address.sin_addr );
	SocketPeer.Port = ntohs( Address.sin_port );

	return ( SocketPeer );
}



//=============================================================================
port_t CSocket::Port( void ) const
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	sockaddr_in Address;
	socklen_t nAddressSize = sizeof( Address );

	CheckSocketApi( getsockname( my_hSocket, reinterpret_cast< sockaddr * >( &Address ), &nAddressSize ));

	return ( ntohs( Address.sin_port ));
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSocketBase
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CSocketBase::CSocketBase( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
}



//=============================================================================
CSocketBase::~CSocketBase( void )
	throw ()
//=============================================================================
{
}


//=============================================================================
void CSocketBase::Notify( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_Socket.Notify();
}




//=============================================================================
bool CSocketBase::IsNotified( void )
	throw()
//=============================================================================
{
	return ( my_Socket.IsNotified() );
}



//=============================================================================
bool CSocketBase::IsConnected( void ) const
	throw()
//=============================================================================
{
	return ( my_Socket.IsOpen() );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSocketConnection
//###
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
CSocketConnection::CSocketConnection( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
}



//=============================================================================
CSocketConnection::~CSocketConnection( void )
	throw()
//=============================================================================
{
}



//=============================================================================
void CSocketConnection::Shutdown( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_Socket.Shutdown();
}



//=============================================================================
void CSocketConnection::SetOption( CSocket::EOption eOption, int Value )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_Socket.SetOption( eOption, Value );
}



//=============================================================================
void CSocketConnection::SetTcpOption( CSocket::ETcpOption eOption, int Value )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_Socket.SetTcpOption( eOption, Value );
}



//=============================================================================
CSocket::EMode CSocketConnection::IOControl( CSocket::EMode eMode )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_Socket.IOControl( eMode ));
}




//=============================================================================
void CSocketConnection::Disconnect( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_Socket.Close();
}



//=============================================================================
bool CSocketConnection::CanSend( milliseconds_t Timeout, bool IsNotifiable )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	CFdSet OutputSet;
	OutputSet.Set( my_Socket );

	return ( my_Socket.Select( NULL, &OutputSet, NULL, Timeout, IsNotifiable ) > 0 );
}



//=============================================================================
bool CSocketConnection::CanReceive( milliseconds_t Timeout, bool IsNotifiable )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	CFdSet InputSet;
	InputSet.Set( my_Socket );

	return ( my_Socket.Select( &InputSet, NULL, NULL, Timeout, IsNotifiable ) > 0 );
}



//=============================================================================
bool CSocketConnection::CanTransmit( bool *pCanSend, bool *pCanReceive,
	milliseconds_t Timeout, bool IsNotifiable )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	CFdSet OutputSet, InputSet;
	OutputSet.Set( my_Socket );
	InputSet.Set( my_Socket );

	int Result;
	if (( Result = my_Socket.Select( &InputSet, &OutputSet, NULL, Timeout, IsNotifiable )) > 0 ) {
		*pCanSend    = OutputSet.IsSet( my_Socket );
		*pCanReceive = InputSet.IsSet( my_Socket );
	}
	return ( Result > 0 );
}



//=============================================================================
size_t CSocketConnection::Send( const void *pData, size_t nDataSize, unsigned Flags )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_Socket.Send( pData, nDataSize, Flags ));
}



//=============================================================================
size_t CSocketConnection::Send( file_t hDataFile, off_t *pDataOffset, size_t nDataSize )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_Socket.Send( hDataFile, pDataOffset, nDataSize ));
}




//=============================================================================
size_t CSocketConnection::Receive( void *pData, size_t nDataSize, unsigned Flags )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_Socket.Receive( pData, nDataSize, Flags ));
}



//=============================================================================
size_t CSocketConnection::Read( void *pData, size_t nDataSize )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	const unsigned FLAGS = CSocket::eReceiveFlag_NoSignal | CSocket::eReceiveFlag_WaitAll;

	size_t nCount, nRead = 0;

	if ( nDataSize > 0 ) {
		do {
			if (( nCount = my_Socket.Receive( pData, nDataSize, FLAGS )) > 0 ) {
				nRead += nCount;

				pData = static_cast< char * >( pData ) + nCount;
				nDataSize = nDataSize - nCount;
			} else
				break;

		} while ( nDataSize > 0 );
	}
	return ( nRead );
}



//=============================================================================
size_t CSocketConnection::Read( void *pData, size_t nDataSize,
	milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime,
	bool IsNotifiable )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	const unsigned FLAGS = CSocket::eReceiveFlag_NoSignal;

	size_t nCount, nRead = 0;

	if ( nDataSize > 0 && CanReceive( BlockWaitingTime, IsNotifiable )) {
		do {
			if (( nCount = my_Socket.Receive( pData, nDataSize, FLAGS )) > 0 ) {
				nRead += nCount;

				pData = static_cast< char * >( pData ) + nCount;
				nDataSize = nDataSize - nCount;
			} else
				break;

		} while ( nDataSize > 0 && CanReceive( CharWaitingTime, IsNotifiable ));
	}
	return ( nRead );
}



//=============================================================================
size_t CSocketConnection::Write( const void *pData, size_t nDataSize )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	const unsigned FLAGS = CSocket::eSendFlag_NoSignal;

	size_t nCount, nWritten = 0;

	if ( nDataSize > 0 ) {
		do {
			if (( nCount = my_Socket.Send( pData, nDataSize, FLAGS )) > 0 ) {
				nWritten += nCount;

				pData = static_cast< const char * >( pData ) + nCount;
				nDataSize = nDataSize - nCount;
			} else
				break;

		} while ( nDataSize > 0 );
	}
	return ( nWritten );
}



//=============================================================================
size_t CSocketConnection::Write( const void *pData, size_t nDataSize,
	milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime,
	bool IsNotifiable )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	const unsigned FLAGS = CSocket::eSendFlag_NoSignal | CSocket::eSendFlag_DontWait;

	size_t nCount, nWritten = 0;

	if ( nDataSize > 0 && CanSend( BlockWaitingTime, IsNotifiable )) {
		do {
			if (( nCount = my_Socket.Send( pData, nDataSize, FLAGS )) > 0 ) {
				nWritten += nCount;

				pData = static_cast< const char * >( pData ) + nCount;
				nDataSize = nDataSize - nCount;
			} else
				break;

		} while ( nDataSize > 0 && CanSend( CharWaitingTime, IsNotifiable ));
	}
	return ( nWritten );
}



//=============================================================================
size_t CSocketConnection::Write( file_t hDataFile, off_t *pDataOffset, size_t nDataSize,
	milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime,
	bool IsNotifiable )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	size_t nCount, nWritten = 0;

	if ( nDataSize > 0 && CanSend( BlockWaitingTime, IsNotifiable )) {
		do {
			if (( nCount = my_Socket.Send( hDataFile, pDataOffset, nDataSize )) > 0 ) {
				nWritten += nCount;

				// sendfile is doing: *pDataOffset += nCount
				nDataSize -= nCount;
			} else
				break;

		} while ( nDataSize > 0 && CanSend( CharWaitingTime, IsNotifiable ));
	}
	return ( nWritten );
}


//=============================================================================
SSocketPeer CSocketConnection::Peer( void ) const
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_Socket.Peer() );
}



//=============================================================================
port_t CSocketConnection::Port( void ) const
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_Socket.Port() );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CClientSocket
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CClientSocket::CClientSocket( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
}



//=============================================================================
CClientSocket::~CClientSocket( void )
	throw()
//=============================================================================
{
}



//=============================================================================
bool CClientSocket::Connect( const char_t HostName[], port_t nPort, milliseconds_t Timeout )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	int nError;
	bool IsConnected = false;
	CSocket::EMode OldMode;

	try {
		my_Socket.Open();
		OldMode = my_Socket.IOControl( CSocket::eModeUnblock );

		if ( ! ( IsConnected = my_Socket.Connect( HostName, nPort ))) {
			CFdSet OutputSet;
			OutputSet.Set( my_Socket );
			if ( my_Socket.Select( NULL, &OutputSet, NULL, Timeout ) > 0 ) {
				if (( nError = my_Socket.GetOption( CSocket::eOptionError )) != 0 ) {
					my_Socket.Close();
					throw ( CSocketError( nError ));
				} else {
					IsConnected = true;
					my_Socket.IOControl( OldMode );
				}
			} else {
				if ( my_Socket.IsOpen() )
					my_Socket.Close();
			}
		}
	}
	catch ( const exception & ) {
		if ( my_Socket.IsOpen() )
			my_Socket.Close();

		throw;
	}
	return ( IsConnected );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CServerSocket
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CServerSocket::CServerSocket( void  )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	my_eState = eStateClosed;
}



//=============================================================================
CServerSocket::~CServerSocket( void )
	throw()
//=============================================================================
{
}



//=============================================================================
port_t CServerSocket::Bind( port_t nPort, const char_t HostName[] )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_eState == eStateClosed );

	my_Socket.Open();

	// Tell the socket to reuse an address:

	my_Socket.SetOption( CSocket::eOptionReuseAddress );

	// Do the actual binding:

	my_Socket.Bind(( nPort == INVALID_PORT ) ? 0 : nPort, HostName ); // Should bind chose a port number?

	// Retrieve the assigned port number:

	if ( nPort == INVALID_PORT )
		nPort = my_Socket.Port();

	my_eState = eStateBound;

	return ( nPort );
}



//=============================================================================
void CServerSocket::Listen( int nMaxListener )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_eState == eStateBound );

	my_Socket.Listen( nMaxListener );

	my_eState = eStateListening;
}



//=============================================================================
CSocketConnection *CServerSocket::Accept( CSocketConnection *pSocket, milliseconds_t Timeout )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_eState == eStateListening );

	CFdSet InputSet;
	InputSet.Set( my_Socket );
	if ( my_Socket.Select( &InputSet, NULL, NULL, Timeout ) > 0 ) {
		my_Socket.Accept( &pSocket->my_Socket );
		return ( pSocket );
	} else
		return ( NULL );
}



//=============================================================================
void CServerSocket::Refuse( void )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	// I'm assuming, that only a closed socket will prevent further connection attempts:

	my_Socket.Close();

	my_eState = eStateClosed;
}



//=============================================================================
bool CServerSocket::IsBound( void ) const
	throw()
//=============================================================================
{
	return ( my_eState == eStateBound );
}



//=============================================================================
bool CServerSocket::IsListening( void ) const
	throw()
//=============================================================================
{
	return ( my_eState == eStateListening );
}


} // namespace AidKit
