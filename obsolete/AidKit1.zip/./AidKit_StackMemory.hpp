#ifndef AIDKIT_STACK_MEMORY_HPP
#define AIDKIT_STACK_MEMORY_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <stddef.h>

namespace AidKit {

	// To use this template, write something like:
	// typedef TStackMemory< 100 > AllocateStackMemory;
	// then you can call it like:
	// void *p = AllocateStackMemory( 50 );

	template < size_t Size, typename CType = char_t >
		//-----------------------------------------------------------------------------
		class TStackMemory {
		//-----------------------------------------------------------------------------
			public:
				TStackMemory( size_t Size );
				~TStackMemory( void );

				operator CType *( void );

			private:
				CType my_Memory[ Size ];
				CType *my_pMemory;
		};

}

#include "AidKit_StackMemory.cpp"

#endif
