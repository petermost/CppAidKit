#ifndef AIDKIT_TOOLTIP_HPP
#define AIDKIT_TOOLTIP_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
#include <afxcmn.h>

/////////////////////////////////////////////////////////////////////////////
// CToolTipGadget window
namespace AidKit {

	class CToolTipGadget : public CToolTipCtrl {
		public:
			CToolTipGadget();
			virtual ~CToolTipGadget();

		protected:
			//{{AFX_VIRTUAL(CToolTipGadget)
			//}}AFX_VIRTUAL

			//{{AFX_MSG(CToolTipGadget)
			afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
			afx_msg void OnDestroy();
			//}}AFX_MSG

			DECLARE_MESSAGE_MAP()

		private:
			TEventHandler1< CToolTipGadget, MSG * > my_RelayEventHandler;
	};

}

//{{AFX_INSERT_LOCATION}}

#endif
