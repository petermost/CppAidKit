#ifndef AIDKIT_DEFERRED_FUNCTION_HPP
#define AIDKIT_DEFERRED_FUNCTION_HPP

#include "AidKit.hpp"
#include "AidKit_Function.hpp"
#include "AidKit_Templates.hpp"
#include <stddef.h>

namespace AidKit {


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TDeferredFunction, TDeferredFunction
//###
//#############################################################################
//#############################################################################
//#############################################################################



//#############################################################################
//
// CDeferredFunctionCommand, TDeferredFunction
//
//#############################################################################

	//-----------------------------------------------------------------------------
	class CDeferredFunctionCommand {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CDeferredFunctionCommand( void );

			virtual void Execute( void ) = 0;
	};


template < typename CCallee >
	//-----------------------------------------------------------------------------
	class TDeferredFunction  : public CDeferredFunctionCommand {
	//-----------------------------------------------------------------------------
		public:
			typedef TCall2< void, CCallee *, TDeferredFunction< CCallee > * > Dispatcher_t;
			
			static Dispatcher_t *ExchangeDispatcher( Dispatcher_t *pDispatcher )
				{ return ( Exchange( &our_pDispatcher, pDispatcher )); }

			void Dispatch( CCallee *pCallee, TDeferredFunction< CCallee > *pCall );

		private:
			static Dispatcher_t *our_pDispatcher;
	};



//#############################################################################
//
// TDeferredFunction0
//
//#############################################################################

template < typename CCallee >
	//-----------------------------------------------------------------------------
	class TDeferredFunction0 : public TCall0< void >, public TDeferredFunction< CCallee > {
	//-----------------------------------------------------------------------------
		public:
			TDeferredFunction0( CCallee *pCallee, void ( CCallee::*pMethod )( void ))
				{ my_pCallee = pCallee; my_pMethod = pMethod; my_pFunction = NULL; }

			TDeferredFunction0( void ( *pFunction )( void ))
				{ my_pCallee = NULL; my_pMethod = NULL, my_pFunction = pFunction; }

			virtual void operator()( void )
				{ Dispatch( my_pCallee, this ); }

			virtual void Execute( void );

		private:
			CCallee *my_pCallee;
			void ( CCallee::*my_pMethod )( void );
			void ( *my_pFunction )( void );
	};
			

//#############################################################################
//
// TDeferredFunction1
//
//#############################################################################

template < typename CCallee, typename P1 >
	//-----------------------------------------------------------------------------
	class TDeferredFunction1 : public TCall1< void, P1 >, public TDeferredFunction< CCallee > {
	//-----------------------------------------------------------------------------
		public:
			TDeferredFunction1( CCallee *pCallee, void ( CCallee::*pMethod )( P1 ))
				{ my_pCallee = pCallee; my_pMethod = pMethod; my_pFunction = NULL; }

			TDeferredFunction1( void ( *pFunction )( P1 ))
				{ my_pCallee = NULL; my_pMethod = NULL, my_pFunction = pFunction; }

			virtual void operator()( P1 p1 )
				{ my_p1 = p1; Dispatch( my_pCallee, this ); }

			virtual void Execute( void );

		private:
			CCallee *my_pCallee;
			void ( CCallee::*my_pMethod )( P1 );
			void ( *my_pFunction )( P1 );
			P1 my_p1;
	};



//#############################################################################
//
// TDeferredFunction2
//
//#############################################################################

template < typename CCallee, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TDeferredFunction2 : public TCall2< void, P1, P2 >, public TDeferredFunction< CCallee > {
	//-----------------------------------------------------------------------------
		public:
			TDeferredFunction2( CCallee *pCallee, void ( CCallee::*pMethod )( P1, P2 ))
				{ my_pCallee = pCallee; my_pMethod = pMethod; my_pFunction = NULL; }

			TDeferredFunction2( void ( *pFunction )( P1, P2 ))
				{ my_pCallee = NULL; my_pMethod = NULL; my_pFunction = pFunction;}

			virtual void operator()( P1 p1, P2 p2 )
				{ my_p1 = p1; my_p2 = p2; Dispatch( my_pCallee, this ); }

			virtual void Execute( void );

		private:
			CCallee *my_pCallee;
			void ( CCallee::*my_pMethod )( P1, P2 );
			void ( *my_pFunction )( P1, P2 );
			P1 my_p1;
			P2 my_p2;
	};




//#############################################################################
//
// TDeferredFunction3
//
//#############################################################################

template < typename CCallee, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TDeferredFunction3 : public TCall3< void, P1, P2, P3 >, public TDeferredFunction< CCallee > {
	//-----------------------------------------------------------------------------
		public:
			TDeferredFunction3( CCallee *pCallee, void ( CCallee::*pMethod )( P1, P2, P3 ))
				{ my_pCallee = pCallee; my_pMethod = pMethod; my_pFunction = NULL; }

			TDeferredFunction3( void ( *pFunction )( P1, P2, P3 ))
				{ my_pCallee = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( P1 p1, P2 p2, P3 p3 )
				{ my_p1 = p1; my_p2 = p2; my_p3 = p3; Dispatch( my_pCallee, this ); }

			virtual void Execute( void );

		private:
			CCallee *my_pCallee;
			void ( CCallee::*my_pMethod )( P1, P2, P3 );
			void ( *my_pFunction )( P1, P2, P3 );
			P1 my_p1;
			P2 my_p2;
			P3 my_p3;
	};




//#############################################################################
//
// TDeferredFunction4
//
//#############################################################################

template < typename CCallee, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TDeferredFunction4 : public TCall4< void, P1, P2, P3, P4 >, public TDeferredFunction< CCallee > {
	//-----------------------------------------------------------------------------
		public:
			TDeferredFunction4( CCallee *pCallee, void ( CCallee::*pMethod )( P1, P2, P3, P4 ))
				{ my_pCallee = pCallee; my_pMethod = pMethod; my_pFunction = NULL; }

			TDeferredFunction4( void ( *pFunction )( P1, P2, P3, P4 ))
				{ my_pCallee = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( P1 p1, P2 p2, P3 p3, P4 p4 )
				{ my_p1 = p1; my_p2; my_p3; my_p4; Dispatch( my_pCallee, this ); }

			virtual void Execute( void );

		private:
			CCallee *my_pCallee;
			void ( CCallee::*my_pMethod )( P1, P2, P3, P4 );
			void ( *my_pFunction )( P1, P2, P3, P4 );
			P1 my_p1;
			P2 my_p2;
			P3 my_p3;
			P4 my_p4;
	};

}

#include "AidKit_DeferredFunctionImp.cpp"

#endif
