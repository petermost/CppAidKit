#ifndef AIDKIT_STL_MAP_HPP
#define AIDKIT_STL_MAP_HPP


#include "AidKit.hpp"

#ifdef AIDKIT_MSC
	#pragma warning( disable : 4786 )
#endif

#include "AidKit_StlFunctional.hpp" // For specialization of less<>.
#include <map>
#include <stdexcept>

namespace AidKit {

	template < typename key, typename value, typename compare = std::less< key > >
		//-----------------------------------------------------------------------------
		class uni_map : public std::map< key, value, compare > {
		//-----------------------------------------------------------------------------
			public:
				struct entry {
					key my_key;
					value my_value;
				};

				uni_map( void );
				uni_map( const entry entries[], size_t count );

				const value &operator[]( const key &key ) const
					throw ( std::out_of_range );
		};


	template < typename value1, typename value2,
		typename compare1 = std::less< value1 >, typename compare2 = std::less< value2 > >
		//-----------------------------------------------------------------------------
		class bi_map {
		//-----------------------------------------------------------------------------
			public:
				struct entry {
					value1 my_value1;
					value2 my_value2;
				};
				bi_map( void );
				bi_map( const entry entries[], size_t count );

				const value2 &operator [] ( const value1 &value ) const
					throw ( std::out_of_range );

				const value1 &operator [] ( const value2 &value ) const
					throw ( std::out_of_range );

			private:
				typedef uni_map< value1, value2, compare1 > value1to2map_t;
				value1to2map_t my_1to2map;

				typedef uni_map< value2, value1, compare2 > value2to1map_t;
				value2to1map_t my_2to1map;

		};

} // namespace AidKit

#include "AidKit_StlMap.cpp"

#endif // AIDKIT_STL_MAP_HPP
