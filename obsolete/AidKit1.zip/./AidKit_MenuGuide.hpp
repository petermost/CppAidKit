#ifndef AIDKIT_MENU_GUIDE_HPP
#define AIDKIT_MENU_GUIDE_HPP

#include "AidKit.hpp"
#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CMenuItem {
	//-----------------------------------------------------------------------------
		public:
			CMenuItem( CMenu *pMenu, UINT ItemPos );
			~CMenuItem( void );

			void SetString( const CString &String );

			UINT GetID( void ) const;
			UINT GetState( void ) const;
			const CString GetString( void ) const;

			BOOL IsPopup( void ) const;
			BOOL IsSeparator( void ) const;

		private:
			CMenu *my_pMenu;
			UINT  my_ItemPos;
	};



	//-----------------------------------------------------------------------------
	class CMenuVisitor {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CMenuVisitor( void );

			virtual bool VisitItem( CMenuItem *pMenuItem ) = 0;
	};



	//-----------------------------------------------------------------------------
	class CMenuGuide {
	//-----------------------------------------------------------------------------
		public:
			CMenuGuide( void );
			~CMenuGuide( void );

			bool Tour( CMenu *pMenu, CMenuVisitor *pVisitor );

		private:
	};

}

#endif
