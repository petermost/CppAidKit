#ifndef AIDKIT_WND_ITERATOR_HPP
#define AIDKIT_WND_ITERATOR_HPP

#include "AidKit.hpp"
#include <stddef.h>

class CWnd;

namespace AidKit {

//-----------------------------------------------------------------------------
class CWndIterator {
//-----------------------------------------------------------------------------
	public:
		CWndIterator( const CWnd *pParentWnd );
		CWndIterator( const CWndIterator & );
		CWndIterator &operator = ( const CWndIterator & );
		~CWndIterator( void );

		bool operator != ( const CWnd *pEnd )
			{ return ( my_pChildWnd != NULL ); }

		CWndIterator &operator ++ ( void );
		CWndIterator operator ++ ( int );

		CWnd *operator * ( void ) const
			{ return ( my_pChildWnd ); }

		CWnd *operator -> ( void ) const
			{ return ( my_pChildWnd ); }

	private:
		CWnd *my_pChildWnd;
};

}

#endif
