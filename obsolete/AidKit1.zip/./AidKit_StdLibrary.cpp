#include "AidKit_StdLibrary.hpp"

using namespace std;

namespace AidKit {


} // namespace AidKit


/*
//=============================================================================
FILE *xfile_open( const char_t *filename, const char_t *mode )
	throw ( CStdFileError )
//=============================================================================
{
	FILE *file = NULL;

	try {
		file = file_open( filename, mode );
	}
	catch ( CStdFileError &error ) {
		error << TEXT( "xfile_open" ) << filename << mode << endl;
		throw;
	}
	return ( file );
}

//=============================================================================
size_t xfile_read( FILE *file, void *buffer, size_t size, size_t count )
	throw ( CStdFileError )
//=============================================================================
{
	size_t read = 0;

	try {
		read = file_read( file, buffer, size, count );
	}
	catch ( CStdFileError &error ) {
		error << TEXT( "fread" ) << size << count << endl;
		throw;
	}
	return ( read );
}



//=============================================================================
size_t xfile_write( FILE *file, const void *buffer, size_t size, size_t count )
	throw( CStdFileError )
//=============================================================================

{
	size_t written = 0;

	try {
		written = file_write( file, buffer, size, count );
	}
	catch ( CStdFileError &error ) {
		error << TEXT( "fwrite" ) << size << count << endl;
		throw;
	}
	return ( written );
}


//=============================================================================
long xfile_tell( FILE *file )
	throw ( CStdFileError )
//=============================================================================
{
	long position = 0;

	try {
		position = file_tell( file );
	}
	catch ( CStdFileError &error ) {
		error << TEXT( "ftell" ) << endl;
		throw;
	}
	return ( position );
}




*/
