#include "AidKit_Picture.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CPicture
//###
//#############################################################################
//#############################################################################
//#############################################################################


BEGIN_MESSAGE_MAP(CPicture, CStatic)
	//{{AFX_MSG_MAP(CPicture)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


//=============================================================================
CPicture::CPicture( void )
//=============================================================================
{
}



//=============================================================================
CPicture::~CPicture( void )
//=============================================================================
{
}



//=============================================================================
void CPicture::OnPaint() 
//=============================================================================
{

	// TODO: Add your message handler code here
	
	CDC MemoryDC;
	CRect ClientRect;
	BITMAP Bitmap;
	CBitmap *pOldBitmap, *pBitmap;
	
	if (( pBitmap = CBitmap::FromHandle( GetBitmap() )) != NULL ) {
		CPaintDC dc(this); // device context for painting
		VERIFY( MemoryDC.CreateCompatibleDC( &dc ));
		pOldBitmap = MemoryDC.SelectObject( pBitmap );

		// Draw the bitmap. If the bitmap is smaller as the client area then
		// draw it in its orignal size:
		GetClientRect( &ClientRect );
		VERIFY( pBitmap->GetBitmap( &Bitmap ));
		if ( Bitmap.bmWidth < ClientRect.Width() || Bitmap.bmHeight < ClientRect.Height() ) { 
			dc.BitBlt( 0, 0, ClientRect.Width(), ClientRect.Height(),
				&MemoryDC, 0, 0, SRCCOPY );
		} else {
			dc.StretchBlt( 0, 0, ClientRect.Width(), ClientRect.Height(),
				&MemoryDC, 0, 0, Bitmap.bmWidth, Bitmap.bmHeight, SRCCOPY );
		}
		MemoryDC.SelectObject( pOldBitmap );
	} else
		CStatic::OnPaint();
}


//=============================================================================
void CPicture::PreSubclassWindow() 
//=============================================================================
{
	// TODO: Add your specialized code here and/or call the base class

	VERIFY( ModifyStyle( SS_ENHMETAFILE, SS_BITMAP ));
	
	CStatic::PreSubclassWindow();
}

} // namespace AidKit
