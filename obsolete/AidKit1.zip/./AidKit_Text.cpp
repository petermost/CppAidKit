#include "AidKit_Text.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Debug.hpp"
#include <stdarg.h>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CText
//###
//#############################################################################
//#############################################################################
//#############################################################################

static const CText::ELanguage kDefaultLanguage = CText::eEnglish;

CText::ELanguage CText::our_CurrentLanguage = kDefaultLanguage;

//=============================================================================
CText::ELanguage CText::SelectLanguage( ELanguage NewLanguage )
//=============================================================================
{
	ELanguage OldLanguage = our_CurrentLanguage;

	our_CurrentLanguage = NewLanguage;

	return ( OldLanguage );
}



//=============================================================================
CText::ELanguage CText::CurrentLanguage( void )
//=============================================================================
{
	return ( our_CurrentLanguage );
}




//=============================================================================
static void InitializeExternalTexts( const char_t *pTexts[], size_t nTextCount,
	const char_t *pText, CText::ELanguage Language, va_list Arguments )
//=============================================================================
{
	while ( nTextCount-- > 0 )
		pTexts[ nTextCount ] = NULL;

	while ( pText != NULL ) {
		AIDKIT_ASSERT( Language >= CText::eEnglish && Language <= CText::kMaxLanguages );
		AIDKIT_ASSERT( pTexts[ Language ] == NULL ); // A text for this language was already given.
		pTexts[ Language ] = pText;

		pText    = va_arg( Arguments, const char_t * );
		Language = static_cast< CText::ELanguage >( va_arg( Arguments, int ));
	}
}




//=============================================================================
CText::CText( const char_t *pText, ELanguage Language, ... )
//=============================================================================
{
	va_list Arguments;

	my_Identifier = 0;

	va_start( Arguments, Language );
	InitializeExternalTexts( my_pExternalTexts, countof( my_pExternalTexts ),
		pText, Language, Arguments );
	va_end( Arguments );
}



//=============================================================================
CText::CText( unsigned Identifier, const char_t *pText, ELanguage Language, ... )
//=============================================================================
{
	va_list Arguments;

	my_Identifier = Identifier;

	va_start( Arguments, Language );
	InitializeExternalTexts( my_pExternalTexts, countof( my_pExternalTexts ),
		pText, Language, Arguments );
	va_end( Arguments );
}



//=============================================================================
CText::CText( unsigned Identifier, const char_t CollectionName[] )
//============================================================================
{
	const CTextCollection *pCollection = NULL;
	const CText *pText = NULL;

	if (( pCollection = CTextCollection::FindCollection( CollectionName )) != NULL ) {
		if (( pText = pCollection->FindText( Identifier )) != NULL )
			*this = *pText;
	}
	AIDKIT_ASSERT( pCollection != NULL && pText != NULL );

}


//=============================================================================
CText::~CText( void )
//=============================================================================
{
}



//=============================================================================
const char_t *CText::c_str( void ) const
//=============================================================================
{
	return ( c_str_at( our_CurrentLanguage ));
}



//=============================================================================
const char_t *CText::c_str_at( ELanguage Language ) const
//=============================================================================
{
	const char_t *pText = my_pExternalTexts[ Language ];

	if ( pText == NULL ) {
		pText = my_pExternalTexts[ kDefaultLanguage ];
		AIDKIT_ASSERT( pText != NULL );
			// There has to be at least a default text!
	}
	return ( pText );
}






//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTextCollection
//###
//#############################################################################
//#############################################################################
//#############################################################################

CTextCollection::CCollectionMap *CTextCollection::our_pCollections = NULL;

//=============================================================================
CTextCollection::CTextCollection( const char_t Name[],
	const CText Text[], size_t TextCount )
//=============================================================================
{
	my_pName = Name;
	my_pText = Text;
	my_nTextCount = TextCount;

	if ( our_pCollections == NULL )
		our_pCollections = new CCollectionMap;

	our_pCollections->insert( CCollectionMap::value_type( Name, this ));
}



//=============================================================================
CTextCollection::~CTextCollection( void )
//=============================================================================
{
	our_pCollections->erase( my_pName );
	if ( our_pCollections->empty() ) {
		delete our_pCollections;
		our_pCollections = NULL;
	}
}



//=============================================================================
const CTextCollection *CTextCollection::FindCollection( const char_t Name[] )
//=============================================================================
{
	CCollectionMap::const_iterator CollectionIter;
	const CTextCollection *pCollection = NULL;

	if (( CollectionIter = our_pCollections->find( Name )) != our_pCollections->end() )
		pCollection = CollectionIter->second;

	return ( pCollection );
}



//=============================================================================
const CText *CTextCollection::FindText( unsigned Identifier ) const
//=============================================================================
{
	const CText *pText = NULL;
	
	for ( size_t i = 0; i < my_nTextCount; ++i ) {
		if (( pText = &my_pText[ i ] )->my_Identifier == Identifier )
			break;
	}
	return ( pText );
}


} // namespace AidKit


