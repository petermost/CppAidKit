#ifndef AIDKIT_LOG_FILE_HPP
#define AIDKIT_LOG_FILE_HPP

#include "AidKit.hpp"
#include "AidKit_File.hpp"
#include "AidKit_Event.hpp"

#include <queue>

namespace AidKit {

	typedef TStdError< class CLogFile > CLogFileError;

	//-----------------------------------------------------------------------------
	class CLogFile {
	//-----------------------------------------------------------------------------
		public:
			TEvent2< CLogFile *, long /* CurrentSize */ > OverflowEvt;

			CLogFile( const long MAX_FILE_SIZE );
			~CLogFile( void );

			void Open( const string_t &Filename, const string_t &FirstMessage = EMPTY_STRING )
				throw ( std::exception );

			void Close( const string_t &LastMessage = EMPTY_STRING )
				throw ( std::exception );

			void Write( const string_t &Message )
				throw ( std::exception );

			bool IsOpen( void ) const
				throw ( std::exception );

			const string_t &Name( void ) const
				throw ( std::exception );

		protected:
			void WriteUnchecked( const string_t &Message )
				throw ( std::exception );

		private:
			const long my_MAX_FILE_SIZE;

			CStdFile my_File;
	};


	//-----------------------------------------------------------------------------
	class CLogFileArchive {
	//-----------------------------------------------------------------------------
		public:
			TEvent2< CLogFileArchive *, const string_t & /* LogFileName */ > OverflowEvt;

			CLogFileArchive( const size_t MAX_ENTRIES );

			void Store( const string_t &LogFileName );

		private:
			const size_t my_MAX_ENTRIES;
			std::queue< string_t > my_Entries;
	};
}

#endif
