#ifndef AIDKIT_WND_EXTENSION_HPP
#define AIDKIT_WND_EXTENSION_HPP

#include "AidKit.hpp"
#include "AidKit_WinHelper.hpp"
#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CWndExtension {
	//-----------------------------------------------------------------------------
		public:
			CWndExtension( CWnd * );
			~CWndExtension( void );

			BOOL SetStyle( DWORD Style, BOOL Update = TRUE )
				{ return ( SetWindowStyle( my_pWnd, Style, Update )); }
				// See also ModifyStyle.

			BOOL SetStyleEx( DWORD ExStyle, BOOL Update = TRUE )
				{ return ( SetWindowStyleEx( my_pWnd, ExStyle, Update )); }
				// See also ModifyStyleEx

			BOOL Resize( const CSize &NewSize )
				{ return ( ResizeWindow( my_pWnd, NewSize )); }

			BOOL Grow( const CSize &DeltaSize )
				{ return ( GrowWindow( my_pWnd, DeltaSize )); }

			BOOL Move( const CPoint &NewPosition )
				{ return ( MoveWindow( my_pWnd, NewPosition )); }

			BOOL Slide( const CPoint &DeltaPosition )
				{ return ( SlideWindow( my_pWnd, DeltaPosition )); }

			BOOL UpdateData( BOOL SaveAndValidate = TRUE )
				{ return ( UpdateWindowData( my_pWnd, SaveAndValidate )); }

			BOOL Enable( BOOL Enable = TRUE )
				{ return ( EnableWindow( my_pWnd, Enable )); }

		private:
			CWnd *my_pWnd;
	};

}

#endif
