#include "AidKit_LogFile.hpp"
#include "AidKit_Time.hpp"
#include "AidKit_Templates.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CLogFile
//###
//#############################################################################
//#############################################################################
//#############################################################################

static const string_t BLANK( TEXT( " " ));
static const string_t LF( TEXT( "\n" ));



//=============================================================================
CLogFile::CLogFile( const long MAX_FILE_SIZE )
	: my_MAX_FILE_SIZE( MAX_FILE_SIZE )
//=============================================================================
{
}



//=============================================================================
CLogFile::~CLogFile( void )
//=============================================================================
{
}



//=============================================================================
void CLogFile::Open( const string_t &Filename, const string_t &FirstMessage )
	throw ( exception )
//=============================================================================
{
	try {
		my_File.Open( Filename, TEXT( "ab" ));

		// To ensure that the first message is not overflowing the log, we write it
		// unchecked.

		WriteUnchecked( FirstMessage );
	}
	catch ( const CStdFileError &FileError ) {
		throw ( CLogFileError( FileError ));
	}
}



//=============================================================================
void CLogFile::Close( const string_t &LastMessage )
	throw ( exception )
//=============================================================================
{
	try {
		// To ensure that the last message is not triggering a recursive call on the
		// oversized event, we write it unchecked.

		WriteUnchecked( LastMessage );

		my_File.Close();
	}
	catch ( const CStdFileError &FileError ) {
		throw ( CLogFileError( FileError ));
	}
}



//=============================================================================
void CLogFile::WriteUnchecked( const string_t &Message )
	throw ( exception )
//=============================================================================
{
	try {
		// Compose the line (this way is probably faster then
		// PrintF( TEXT( "%s %s\n" ), ISODateTime().c_str(), Message.c_str() )

		string_t Line = ISODateTime( eFraction_Microseconds );
		Line += BLANK;
		Line += Message;
		Line += LF;

		// Write the message to the file:

		my_File.Write( Line.data(), Line.length() ); 
		my_File.Flush();
	}
	catch ( const CStdFileError &FileError ) {
		throw ( CLogFileError( FileError ));
	}
}



//=============================================================================
void CLogFile::Write( const string_t &Message )
	throw ( exception )
//=============================================================================
{
	try {
		WriteUnchecked( Message );

		// Check the file size:

		long CurrentSize;
		if (( CurrentSize = my_File.Tell()) > my_MAX_FILE_SIZE ) {
			OverflowEvt.Announce( this, CurrentSize );
		}
	}
	catch ( const CStdFileError &FileError ) {
		throw ( CLogFileError( FileError ));
	}
}



//=============================================================================
bool CLogFile::IsOpen( void ) const
	throw ( exception )
//=============================================================================
{
	try {
		return ( my_File.IsOpen() );
	}
	catch ( const CStdFileError &FileError ) {
		throw ( CLogFileError( FileError ));
	}
}



//=============================================================================
const string_t &CLogFile::Name( void ) const
	throw ( exception )
//=============================================================================
{
	try {
		return ( my_File.Name() );
	}
	catch ( const CStdFileError &FileError ) {
		throw ( CLogFileError( FileError ));
	}
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CLogFileArchive
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CLogFileArchive::CLogFileArchive( const size_t MAX_ENTRIES )
	: my_MAX_ENTRIES( MAX_ENTRIES )
//=============================================================================
{
}



//=============================================================================
void CLogFileArchive::Store( const string_t &LogFileName )
//=============================================================================
{
	my_Entries.push( LogFileName );
	while ( my_Entries.size() > my_MAX_ENTRIES ) {
		string_t OldLogFileName = my_Entries.front();
		my_Entries.pop();
		OverflowEvt.Announce( this, OldLogFileName );
	}
}


} // namespace AidKit
