#ifndef AIDKIT_WSA_ERROR_HPP
#define AIDKIT_WSA_ERROR_HPP

#pragma comment( lib, "Ws2_32.lib" )

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_WinError.hpp"
#include <winsock2.h>

namespace AidKit {
	
	CString WSAGetLastErrorString( DWORD WSALastError );

	//-----------------------------------------------------------------------------
	class CWsaError : public CWinError {
	//-----------------------------------------------------------------------------
		public:
			static DWORD LastError( void )
				throw();

			explicit CWsaError( DWORD WSALastError = NO_ERROR )
				throw();

			CWsaError( const CWsaError &Other )
				throw();

			virtual DWORD Reason( void ) const
				throw();
				// For a complete list of error codes see winsock2.h

			virtual const char_t *Description( void ) const
				throw();

		private:
			CWsaError &operator = ( const CWsaError & );

			DWORD   my_Reason;
			mutable CString my_Description;
	};

}

#endif
