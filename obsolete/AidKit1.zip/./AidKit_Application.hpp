#ifndef AIDKIT_APPLICATION_HPP
#define AIDKIT_APPLICATION_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Application.hpp"
	namespace AidKit {
		typedef CWindowsApplication CNativeApplication;
	}
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Application.hpp"
	namespace AidKit {
		typedef CUnixApplication CNativeApplication;
	}
#endif

#include "AidKit_IniFile.hpp"
#include "AidKit_User.hpp"

namespace AidKit {

	class CPreferences;

	//-----------------------------------------------------------------------------
	class CApplication : public CNativeApplication {
	//-----------------------------------------------------------------------------
		public:
			static CApplication *Instance( void );

			CApplication( const char_t Name[] = 0 );
			virtual ~CApplication( void );

			bool main( int argc, char_t *argv[] );
			int exit( int ExitCode );
				// Call  main, exit if you have a normal console application.

			bool LoadSettings( void );
			bool SaveSettings( void );
				// Tries to load/save the debugger settings (only
				// in debug build) and the user settings.
			
			CPreferences *UserPreferences( void );
			CPreferences *DebuggerPreferences( void );

			CUser User( void ) const;

			const char_t *Name( void ) const;
			const char_t *Directory( void ) const;

		protected:
			virtual bool OnStartup( void );
			virtual bool OnShutdown( void );

		private:
			static CApplication *our_pInstance;
			
			CIniFile my_UserPreferences;
			CIniFile my_DebuggerPreferences;

			CUser my_User;
			mutable string_t my_Name;
			mutable string_t my_Directory;
	};

}

#endif // AIDKIT_APPLICATION_HPP
