#ifndef AIDKIT_ATOMIC_HPP
#define AIDKIT_ATOMIC_HPP

#include "AidKit.hpp"

namespace AidKit {

	class CAtomicBasics {
		public:
			CAtomicBasics( void ) throw();
			virtual ~CAtomicBasics( void ) throw();

		protected:
			virtual int DoPreIncrement( void ) throw() = 0;
			virtual int DoPreDecrement( void ) throw() = 0;
			virtual int DoPostIncrement( void ) throw() = 0;
			virtual int DoPostDecrement( void ) throw() = 0;
	};

}

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Atomic.hpp"

	namespace AidKit {
		typedef CWinAtomicBasics CNativeAtomicBasics;
	}

#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Atomic.hpp"

	namespace AidKit {
		typedef CUnxAtomicBasics CNativeAtomicBasics;
	}
#endif

namespace AidKit {

	class CAtomic : public CNativeAtomicBasics {
		public:
			CAtomic( int Value ) throw()
				: CNativeAtomicBasics( Value )
				{ }

			~CAtomic( void ) throw()
				{ }

			int PreIncrement( void ) throw()
				{ return ( DoPreIncrement() ); }

			int PreDecrement( void ) throw()
				{ return ( DoPreDecrement() ); }

			int PostIncrement( void ) throw()
				{ return ( DoPostIncrement() ); }

			int PostDecrement( void ) throw()
				{ return ( DoPostDecrement() ); }



			int operator ++ ( void ) throw()
				{ return ( PreIncrement() ); }

			int operator -- ( void ) throw()
				{ return ( PreDecrement() ); }

			int operator ++ ( int )  throw()
				{ return ( PostIncrement() ); }

			int operator -- ( int ) throw()
				{ return ( PostDecrement() ); }
	};

}

#endif
