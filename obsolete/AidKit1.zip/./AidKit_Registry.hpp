#ifndef AIDKIT_REGISTRY_HPP
#define AIDKIT_REGISTRY_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_WinError.hpp"

#include <afxwin.h>
#include <string>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CRegistry {
	//-----------------------------------------------------------------------------
		public:
			CRegistry( void );
			~CRegistry( void );

			bool Open( HKEY hRootKey, const char_t SubKeyName[] );
			bool Close( void );

			bool WriteInteger( const char_t ValueName[], int Integer );
			bool ReadInteger(  const char_t ValueName[], int *pInteger ) const;

			bool WriteString( const char_t ValueName[], const string_t &String );
			bool ReadString(  const char_t ValueName[], string_t *pString ) const;

			bool WriteBinary( const char_t ValueName[], const void *Binary, size_t BinarySize );
			bool ReadBinary(  const char_t ValueName[], void *pBinary, size_t BinarySize ) const;

			bool ReadValueInfo( const char_t ValueName[], int *pValueType, size_t *pValueSize ) const;

		private:
			bool WriteData( const char_t DataName[], int DataType, const void *Data, size_t DataSize );
			bool ReadData(  const char_t DataName[], int DataType, void *pData, size_t DataSize ) const;

			HKEY my_hKey;
	};

	
	class COutput;

	typedef TWinError< class CRegistry > CRegistryError;

	//-----------------------------------------------------------------------------
	class CXRegistry {
	//-----------------------------------------------------------------------------
		public:
			CXRegistry( void )
				throw ( void );

			~CXRegistry( void )
				throw ( void );

			void Open( HKEY hRootKey, const char_t SubKeyName[] )
				throw ( CRegistryError );

			void Close( void )
				throw ( CRegistryError );

			void WriteInteger( const char_t ValueName[], int Value )
				throw ( CRegistryError );

			int ReadInteger( const char_t ValueName[] ) const
				throw ( CRegistryError );

			void WriteString( const char_t ValueName[], const string_t &Value )
				throw ( CRegistryError );

			const string_t ReadString( const char_t ValueName[] ) const
				throw ( CRegistryError );

			void WriteBinary( const char_t ValueName[], const void *Value, size_t ValueSize )
				throw ( CRegistryError );

			void ReadBinary( const char_t ValueName[], void *pValue, size_t ValueSize ) const
				throw ( CRegistryError );

			void ReadValueInfo( const char_t ValueName[], int *pValueType, size_t *pValueSize ) const
				throw ( CRegistryError );

			friend COutput &operator << ( COutput &, const CXRegistry & );

		private:
			CRegistry my_Registry;
			string_t my_SubKeyName;
	};

	COutput &operator << ( COutput &, const CXRegistry & );

}

#endif
