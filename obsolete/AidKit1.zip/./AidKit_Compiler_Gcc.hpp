#ifndef AIDKIT_COMPILER_GCC_HPP
#define AIDKIT_COMPILER_GCC_HPP

#include "AidKit.hpp"

#if !defined( AIDKIT_GCC_2 )

#include <string>
#include <exception>

namespace AidKit {

	std::terminate_handler install_verbose_terminate_handler( void );
	std::unexpected_handler install_verbose_unexpected_handler( void );

}
#endif

#endif
