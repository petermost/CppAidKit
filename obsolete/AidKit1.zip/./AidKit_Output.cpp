#include "AidKit_Output.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_StackMemory.hpp"
#include <stdio.h>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### COutput
//###
//#############################################################################
//#############################################################################
//#############################################################################

const size_t MAX_VALUE_SIZE = 30;

//=============================================================================
COutput::COutput( void )
//=============================================================================
{
}



//=============================================================================
COutput::~COutput( void )
//=============================================================================
{
}



//=============================================================================
COutput &COutput::WriteBoolean( bool Value, const type_info &ValueType )
//=============================================================================
{
	const char_t TRUE_TEXT[] = TEXT( "true" );
	const char_t FALSE_TEXT[] = TEXT( "false" );

	switch ( Value ) {
		case false:
			DoWrite( FALSE_TEXT, countof( FALSE_TEXT ) - 1, ValueType );
			break;

		case true:
			DoWrite( TRUE_TEXT, countof( TRUE_TEXT ) - 1, ValueType );
			break;
	}
	return ( *this );
}



//=============================================================================
COutput &COutput::WriteCharacter( char_t Value, const type_info &ValueType )
//=============================================================================
{
	return ( DoWrite( &Value, 1, ValueType ));
}



//=============================================================================
COutput &COutput::WriteString( const char_t Value[], const type_info &ValueType )
//=============================================================================
{
	return ( DoWrite( Value, str_len( Value ), ValueType ));
}



//=============================================================================
COutput &COutput::WriteString( const string_t &Value, const type_info &ValueType )
//=============================================================================
{
	return ( DoWrite( Value.data(), Value.length(), ValueType ));
}




//=============================================================================
COutput &COutput::WriteInteger( long Value, const type_info &ValueType )
//=============================================================================
{
	char_t szValue[ MAX_VALUE_SIZE ];
	size_t ValueLength = sn_print_f( szValue, countof( szValue ), TEXT( "%ld" ), Value );

	return ( DoWrite( szValue, ValueLength, ValueType ));
}



//=============================================================================
COutput &COutput::WriteInteger( unsigned long Value, const type_info &ValueType )
//=============================================================================
{
	char_t szValue[ MAX_VALUE_SIZE ];
	size_t ValueLength = sn_print_f( szValue, countof( szValue ), TEXT( "%lu" ), Value );

	return ( DoWrite( szValue, ValueLength, ValueType ));
}


//=============================================================================
COutput &COutput::WriteFloat( double Value, const type_info &ValueType )
//=============================================================================
{
	char szValue[ MAX_VALUE_SIZE ];
	size_t ValueLength = sn_print_f( szValue, countof( szValue ), TEXT( "%g" ), Value );

	return ( DoWrite( szValue, ValueLength, ValueType ));
}



//=============================================================================
COutput &COutput::WritePointer( const void *pValue, const type_info &ValueType )
//=============================================================================
{
	char_t szValue[ MAX_VALUE_SIZE ];
	size_t ValueLength = sn_print_f( szValue, countof( szValue ), TEXT( "%p" ), pValue );

	return ( DoWrite( szValue, ValueLength, ValueType ));
}



//=============================================================================
COutput &COutput::WriteType( const type_info &Value, const type_info &ValueType )
//=============================================================================
{
	return ( DoWrite( Value.name(), str_len( Value.name() ), ValueType ));
}


//=============================================================================
COutput &COutput::Flush( void )
//=============================================================================
{
	return ( DoFlush() );
}

} // namespace AidKit




/*

//=============================================================================
COutput &COutput::WriteCharacter( wchar_t Value, const type_info &ValueType )
//=============================================================================
{
	return ( DoWrite( &Value, 1, ValueType ));
}



//=============================================================================
COutput &COutput::WriteString( const wchar_t Value[], const type_info &ValueType )
//=============================================================================
{
	return ( DoWrite( Value, wcslen( Value ), ValueType ));
}


//=============================================================================
COutput &COutput::DoWrite( const wchar_t Value[], size_t ValueLength, const type_info &ValueType )
//=============================================================================
{
	typedef TStackMemory< 100, char_t > alloca;

	const size_t wcstombs_failure = -1;

	char_t *pNewValue = alloca( ValueLength * sizeof( *Value ));
	size_t NewValueLength = wcstombs( pNewValue, Value, ValueLength );
	return (( NewValueLength != wcstombs_failure ) ? DoWrite( pNewValue, NewValueLength, ValueType ) : *this );
}

  COutput &operator << ( COutput &rOutput, const wchar_t Value[] )
	{ return ( rOutput.WriteString( Value, typeid( Value ))); }


COutput &operator << ( COutput &rOutput, const std::wstring &Value )
	{ return ( rOutput.WriteString( Value.c_str(), typeid( Value ))); }

COutput &operator << ( COutput &rOutput, wchar_t Value )
	{ return ( rOutput.WriteCharacter( Value, typeid( Value ))); }

*/
