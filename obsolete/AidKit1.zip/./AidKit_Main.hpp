#ifndef AIDKIT_MAIN_HPP
#define AIDKIT_MAIN_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Main.hpp"
	namespace AidKit {
		using namespace Windows;
	}
#elif defined( AIDKIT_UNIX )
	// #include "Unix/AidKit_Unix_Main.hpp"
	namespace AidKit {
		using namespace Unix;
	}
#endif


namespace AidKit {


}

#endif
