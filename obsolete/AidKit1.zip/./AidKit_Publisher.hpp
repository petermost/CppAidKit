#ifndef AIDKIT_PUBLISHER_HPP
#define AIDKIT_PUBLISHER_HPP

#pragma warning( disable : 4786 ) // identifier was truncated to '255' characters in the browser information
#include <list>

namespace AidKit {

	class CSubscriber;

template < typename CSubscriber >
	//-----------------------------------------------------------------------------
	class TPublisher {
	//-----------------------------------------------------------------------------
		public:
			TPublisher( void );
			virtual ~TPublisher( void );

			bool Subscribe( CSubscriber *pSubscriber );
			bool Unsubscribe( CSubscriber *pSubscriber );

		private:
			std::list< CSubscriber * > my_Subscribers;
	};

template < typename CPublisher >
	//-----------------------------------------------------------------------------
	class TSubscriber {
	//-----------------------------------------------------------------------------
		public:
			TSubscriber( void );
			virtual ~TSubscriber( void );

		private:
			friend CPublisher;

			CPublisher *my_pPublisher;
	};

} // namespace AidKit

#endif
