#ifndef AIDKIT_UNIX_PROCESS_HPP
#define AIDKIT_UNIX_PROCESS_HPP

#include "../AidKit.hpp"
#include "../AidKit_Debug.hpp"
#include "../AidKit_Unicode.hpp"
#include "../AidKit_StdError.hpp"
#include "AidKit_Unix_Pipe.hpp"
#include "AidKit_Unix_Selector.hpp"

#include <unistd.h>
#include <signal.h>
#include <vector>

namespace AidKit {

	namespace Unix {

		typedef TStdError< class CProcess > CProcessError;

		//---------------------------------------------------------------------
		class CProcess {
		//---------------------------------------------------------------------
			public:
				CProcess( void )
					throw();

				~CProcess( void )
					throw();

				/// Start a new process with the given parameters.
				void Execute( const char_t Process[], const char_t *argv[] )
					throw ( CProcessError, assertion_error );

				/// Write data to the input of the started process.
				size_t WriteStdIn( const void *Data, size_t DataSize )
					throw ( CProcessError );

				/// Read data from the output of the started process.
				size_t ReadStdOut( void *Data, size_t DataSize )
					throw ( CProcessError );

				/// Read data from the error output of the started process.
				size_t ReadStdErr( void *Data, size_t DataSize )
					throw ( CProcessError );

				void Notify( void )
					throw ( CProcessError );

				void Kill( void )
					throw ( CProcessError );

				/// Waits until the process has stopped.
				int Wait( void )
					throw ( CProcessError );

				/// Waits until the process has stopped and free's all resources:
				int Stop( void )
					throw ( CProcessError );

				/// Check wether the process has stopped and get the exit value:
				bool HasStopped( int *pResult ) const
					throw ( CProcessError );

			private:
				static void InstallSignalHandler( void )
					throw ( CProcessError );

				static void UninstallSignalHandler( void )
					throw ( CProcessError );

				static void SignalHandler( int, siginfo_t *, void * )
					throw( CProcessError, assertion_error );

				static std::vector< CProcess * > our_Childs;
				static struct sigaction our_OldSignalAction;

				CProcess( const CProcess & );
				CProcess &operator = ( const CProcess & );

				// A CDebugger doesn't seem to work in the child process.
				// CDebugger my_Debugger;
				CSelector Selector;
				pid_t my_ChildProcess;
				CPipe my_StdInPipe;
				CPipe my_StdOutPipe;
				CPipe my_StdErrPipe;

		};

	}

}

#endif
