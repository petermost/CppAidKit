#include "../AidKit_Socket.hpp"
#include "../AidKit_Types.hpp"
#include "../AidKit_File.hpp"

#include <unistd.h>

#if defined( AIDKIT_LINUX )
	#include <endian.h>
	#include <byteswap.h>
	#include <sys/sendfile.h>
#endif

using namespace std;

namespace AidKit {

namespace Unix {

#if defined( AIDKIT_LINUX )
//=============================================================================
UINT64 ntohll( UINT64 nll )
//=============================================================================
{
	#if __BYTE_ORDER == __BIG_ENDIAN
		return ( nll );
	#elif __BYTE_ORDER == __LITTLE_ENDIAN
		return ( __bswap_64( nll ));
	#else
		#error "Unknown ENDIAN machine"
	#endif
}


//=============================================================================
UINT64 htonll( UINT64 hll )
//=============================================================================
{
	#if __BYTE_ORDER == __BIG_ENDIAN
		return ( hll );
	#elif __BYTE_ORDER == __LITTLE_ENDIAN
		return ( __bswap_64( hll ));
	#else
		#error "Unknown ENDIAN machine"
	#endif
}
#endif


/* The host byte order is the same as network byte order,
   so these functions are all just identity.
# define ntohl(x)       (x)
# define ntohs(x)       (x)
# define htonl(x)       (x)
# define htons(x)       (x)
# else
#  if __BYTE_ORDER == __LITTLE_ENDIAN
#   define ntohl(x)     __bswap_32 (x)
#   define ntohs(x)     __bswap_16 (x)
#   define htonl(x)     __bswap_32 (x)


#   define htons(x)     __bswap_16 (x)
#  endif
# endif
#endif
*/



} // namespace Unix

} // namespace AidKit

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CNativeSocketBasics
//###
//#############################################################################
//#############################################################################
//#############################################################################


namespace AidKit {

using namespace Unix;

#if defined( AIDKIT_LINUX )

	//=============================================================================
	inline ssize_t socket_receive( socket_t hSocket, void *pBuffer, size_t nSize, unsigned Flags )
	//=============================================================================
	{
		return ( recv( hSocket, pBuffer, nSize, Flags ));
	}



	//=============================================================================
	inline ssize_t socket_send( socket_t hSocket, const void *pBuffer, size_t nSize, unsigned Flags )
	//=============================================================================
	{
		return ( send( hSocket, pBuffer, nSize, Flags ));
	}



	//=============================================================================
	inline ssize_t socket_sendfile( socket_t hSocket, file_t hFile, off_t *pOffset, size_t nCount )
	//=============================================================================
	{
		return ( sendfile( hSocket, hFile, pOffset, nCount ));
	}

#elif defined( AIDKIT_BSD )

	//=============================================================================
	inline ssize_t socket_receive( socket_t hSocket, void *pBuffer, size_t nSize, unsigned Flags )
	//=============================================================================
	{
		return ( recv( hSocket, pBuffer, nSize, Flags ));
	}



	//=============================================================================
	inline ssize_t socket_send( socket_t hSocket, const void *pBuffer, size_t nSize, unsigned Flags )
	//=============================================================================
	{
		return ( send( hSocket, pBuffer, nSize, Flags ));
	}



	//=============================================================================
	inline ssize_t socket_sendfile( socket_t hSocket, file_t hFile, off_t *pOffset, size_t nCount )
	//=============================================================================
	{
		return ( sendfile( hFile, hSocket, *pOffset, nCount, NULL, pOffset, 0 ));
	}

#else

	#error "Don't know how to define socket_sendfile()!"

#endif



//=============================================================================
CNativeSocketBasics::CNativeSocketBasics( void )
	throw ( CSocketError )
//=============================================================================
{
	if (( my_OldSigPipeHandler = signal( SIGPIPE, SIG_IGN )) == SIG_ERR )
		throw ( CSocketError( EPIPE ));
}



//=============================================================================
CNativeSocketBasics::~CNativeSocketBasics( void )
	throw()
//=============================================================================
{
	signal( SIGPIPE, my_OldSigPipeHandler );
}





//=============================================================================
int CNativeSocketBasics::DoClose( socket_t hSocket )
	throw ( CSocketError )
//=============================================================================
{
	return ( close( hSocket ));
}



//=============================================================================
int CNativeSocketBasics::DoShutdown( socket_t hSocket, EDirection eDirection )
	throw ( CSocketError )
//=============================================================================
{
	int nDirection;
	
	switch ( eDirection ) {
		case eDirectionRead:
			nDirection = SHUT_RD;
			break;
	
		case eDirectionWrite:
			nDirection = SHUT_WR;
			break;
	
		case eDirectionReadWrite:
		default:
			nDirection = SHUT_RDWR;
			break;
	}
	return ( shutdown( hSocket, nDirection ));
}



//=============================================================================
int CNativeSocketBasics::DoIOControl( socket_t hSocket, EMode eMode, EMode *pOldMode )
	throw ( CSocketError )
//=============================================================================
{
	try {
		if ( IsFileBlocking( hSocket ))
			*pOldMode = eModeBlock;
		else
			*pOldMode = eModeUnblock;

		switch ( eMode ) {
			case eModeUnblock:
				UnblockFile( hSocket );
				break;

			case eModeBlock:
			default:
				BlockFile( hSocket );
				break;
		}
	}
	catch ( CStdError &rError ) {
		throw ( CSocketError( rError ));
	}
	return ( 0 );
}



//=============================================================================
bool CNativeSocketBasics::DoTryConnect( socket_t hSocket, const sockaddr *pAddress, socklen_t nAddressSize )
	throw ( CSocketError )
//=============================================================================
{
	int nResult, nError = 0;

	if (( nResult = connect( hSocket, pAddress, nAddressSize )) == 0 ) {
		return ( true );
	} else if ( nResult == -1 && ( nError = errno ) == EINPROGRESS ) {
		return ( false );
	} else {
		throw ( CSocketError( nError ));
	}
}



//=============================================================================
size_t CNativeSocketBasics::DoReceive( socket_t hSocket, void *pBuffer, size_t nBufferSize, unsigned Flags )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( CheckSocketApi( socket_receive( hSocket, pBuffer, nBufferSize, Flags )));
}


//=============================================================================
size_t CNativeSocketBasics::DoSend( socket_t hSocket, const void *pBuffer, size_t nBufferLength, unsigned Flags )
	throw ( CSocketError )
//=============================================================================
{
	return ( CheckSocketApi( socket_send( hSocket, pBuffer, nBufferLength, Flags )));
}



//=============================================================================
size_t CNativeSocketBasics::DoSend( socket_t hSocket, file_t hFile, off_t *pOffset, size_t Count )
	throw ( CSocketError )
//=============================================================================
{
	return ( CheckSocketApi( socket_sendfile( hSocket, hFile, pOffset, Count )));
}


//=============================================================================
int CNativeSocketBasics::DoSetSocketOption( socket_t hSocket, int nLevel,
	int nOptName, const void *pOptVal, socklen_t nOptLen )
		throw ( CSocketError )
//=============================================================================
{
	return ( setsockopt( hSocket, nLevel, nOptName, pOptVal , nOptLen ));
}



//=============================================================================
int CNativeSocketBasics::DoGetSocketOption( socket_t hSocket, int nLevel,
	int nOptName, void *pOptVal, socklen_t *pOptLen )
		throw ( CSocketError )
//=============================================================================
{
	return ( getsockopt( hSocket, nLevel, nOptName, pOptVal, pOptLen ));
}



//=============================================================================
in_addr CNativeSocketBasics::DoNameToAddress( const string_t &Name ) const
	throw ( CSocketError )
//=============================================================================
{
	in_addr Address;
	if ( inet_aton( Name.c_str(), &Address ) == 0 )
		throw( CSocketError( EINVAL ));
		
	return ( Address );
}



//=============================================================================
string_t CNativeSocketBasics::DoAddressToName( const in_addr &Address ) const
	throw ( CSocketError )
//=============================================================================
{
	char_t *pName = inet_ntoa( Address );
	if ( pName != NULL ) {
		string_t Name = pName;
		return ( Name );
	} else
		throw ( CSocketError( EINVAL ));
}

} // namespace AidKit


/*
//=============================================================================
int CNativeSocketBasics::DoSelect( socket_t hLastSocket, fd_set *pReadFDs,
	fd_set *pWriteFDs, fd_set *pExceptFDs, timeval *pTimeout )
		throw ( CSocketError )
//=============================================================================
{
	// #ifndef AIDKIT_LINUX
		//#error "select call which uses the feature of the updated remaining time is only supported under linux!"
	// #endif

	// Make sure we have valid read descriptor:

	fd_set ReadFDs;
	if ( pReadFDs == NULL ) {
		FD_ZERO( &ReadFDs );
		pReadFDs = &ReadFDs;
	}
	// Add the pipe to the read descriptor:

	int PipeFileNo = my_CancelPipe.ReadableFileNo();
	FD_SET( PipeFileNo, pReadFDs );
	hLastSocket = max( hLastSocket - 1, PipeFileNo );

	// Measure the time span of the select call:

	timeval StartTime, StopTime;

	gettimeofday( &StartTime, NULL );
	int nResult = select( hLastSocket + 1, pReadFDs, pWriteFDs, pExceptFDs, pTimeout );
	gettimeofday( &StopTime, NULL );

	// Update the remaining time:

	if ( pTimeout != NULL )
		*pTimeout = *pTimeout - ( StartTime - StopTime );

	if ( nResult > 0 ) {

		// Check wether the pipe was signaled and therefore the select was canceled:

		if ( FD_ISSET( PipeFileNo, pReadFDs )) {

			// We have to read the dummy value from the pipe:

			BYTE CancelMsg;
			my_CancelPipe.Read( &CancelMsg, sizeof( CancelMsg ));

			nResult = 0; // Same result as if the timeout had expired.
		}
	}
	FD_CLR( PipeFileNo, pReadFDs );
	return ( nResult );
}


//=============================================================================
void CNativeSocketBasics::DoCancel( socket_t )
	throw ( CSocketError )
//=============================================================================
{
	BYTE CancelMsg = 0xFF;

	// Use the pipe to cancel the select:
	my_CancelPipe.Write( &CancelMsg, sizeof( CancelMsg ));
}
*/
