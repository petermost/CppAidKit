#include "AidKit_Unix_Pipe.hpp"
#include "../AidKit_File.hpp"
#include <unistd.h>

static const size_t READABLE_FD_IDX = 0;
static const size_t WRITABLE_FD_IDX = 1;

namespace AidKit {

namespace Unix {

//=============================================================================
inline int CheckPipeApi( int nError )
	throw ( CPipeError )
//=============================================================================
{
	return ( check_err_no_api< CPipeError >( nError ));
}



//=============================================================================
CPipe::CPipe( void )
	throw ( CPipeError )
//=============================================================================
{
	my_PipeFDs[ READABLE_FD_IDX ] = my_PipeFDs[ WRITABLE_FD_IDX ] = -1;
}




//=============================================================================
CPipe::~CPipe( void )
	throw ()
//=============================================================================
{
	try {
		if ( my_PipeFDs[ READABLE_FD_IDX ] != -1 || my_PipeFDs[ WRITABLE_FD_IDX ] != -1 )
			Close();
	} catch ( ... ) {
		;
	}
}



//=============================================================================
void CPipe::Open( void )
	throw ( CPipeError )
//=============================================================================
{
	CheckPipeApi( pipe( my_PipeFDs ));
}


//=============================================================================
static inline void close_pipe( int *fd )
	throw()
//=============================================================================
{
	if ( *fd != -1 ) {
		close( *fd );
		*fd = -1;
	}
}

//=============================================================================
void CPipe::Close( void )
	throw ( CPipeError )
//=============================================================================
{
	close_pipe( &my_PipeFDs[ READABLE_FD_IDX ] );
	close_pipe( &my_PipeFDs[ WRITABLE_FD_IDX ] );
}



//=============================================================================
size_t CPipe::Write( const void *pData, size_t nDataSize )
	throw ( CPipeError )
//=============================================================================
{
	ssize_t nWritten = write( WritableFileNo(), pData, nDataSize );
	CheckPipeApi( nWritten );
	return ( nWritten );
}




//=============================================================================
size_t CPipe::Read( void *pData, size_t nDataSize )
	throw ( CPipeError )
//=============================================================================
{
	ssize_t nRead = read( ReadableFileNo(), pData, nDataSize );
	CheckPipeApi( nRead );
	return ( nRead );
}



//=============================================================================
int CPipe::ReadableFileNo( void ) const
//=============================================================================
{
	return ( my_PipeFDs[ READABLE_FD_IDX ] );
}



//=============================================================================
int CPipe::WritableFileNo( void ) const
//=============================================================================
{
	return ( my_PipeFDs[ WRITABLE_FD_IDX ] );
}

} // namespace Unix

} // namespace AidKit
