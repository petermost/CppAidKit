#ifndef AIDKIT_UNIX_USER_HPP
#define AIDKIT_UNIX_USER_HPP

#include "../AidKit.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CNativeUser : public CUserBasics {
	//-----------------------------------------------------------------------------
		public:
			CNativeUser( void );
			~CNativeUser( void );

		protected:
			virtual string_t DoGetName( void );
			virtual string_t DoGetHomeDirectory( void );
	};

}

#endif
