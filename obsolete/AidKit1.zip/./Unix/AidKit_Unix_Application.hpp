#ifndef AIDKIT_UNIX_APPLICATION
#define AIDKIT_UNIX_APPLICATION

#include "../AidKit_ApplicationBase.hpp"

namespace AidKit {

	class CUnixApplication : public CApplicationBase {
	};

}

#endif


