#ifndef AIDKIT_UNIX_SELECTOR_HPP
#define AIDKIT_UNIX_SELECTOR_HPP

#include "../AidKit.hpp"
#include "../AidKit_Time.hpp"
#include "../AidKit_Debug.hpp"
#include "../AidKit_StdError.hpp"
#include "AidKit_Unix_Pipe.hpp"

namespace AidKit {

	class CFdSet;

	namespace Unix {

		typedef TStdError< class CSelector > CSelectorError;

		//---------------------------------------------------------
	      class CSelector {
		//---------------------------------------------------------
			public:
				CSelector( void )
					throw ( CSelectorError );

				~CSelector( void )
					throw( CSelectorError );

				int Select( CFdSet *pInputSet, CFdSet *pOutputSet, CFdSet *pExceptSet,
					milliseconds_t Timeout, bool IsNotifiable )
						throw ( CSelectorError );

				void Notify( void )
					throw ( CSelectorError );

				bool IsNotified( void )
					throw();

			private:
				CPipe my_NotificationPipe;
				bool my_IsNotified;
		};

	}

}

#endif
