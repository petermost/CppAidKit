#ifndef AIDKIT_UNIX_STRING_HPP
#define AIDKIT_UNIX_STRING_HPP

// Add -lresolv (libresolv.a) to your makefile

#include "../AidKit_Unicode.hpp"

namespace AidKit {

	namespace Unix {

		size_t encode_base64( const void *data, size_t data_length, string_t *encoded_data );
		size_t decode_base64( const string_t &encoded_data, void *data, size_t data_length );

	}

}

#endif

