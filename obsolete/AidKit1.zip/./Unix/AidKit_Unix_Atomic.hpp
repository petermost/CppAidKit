#ifndef AIDKIT_UNIX_ATOMIC_HPP
#define AIDKIT_UNIX_ATOMIC_HPP

#include <bits/atomicity.h>

namespace AidKit {

	namespace Unix {

		class CAtomic {
			public:
				CAtomic( int Value = 0 ) throw()
					{ my_Value = Value; }

				~CAtomic( void ) throw()
					{ }

				void Add( int Value ) throw()
					{ __atomic_add( &my_Value, Value ); }

				_Atomic_word ExchangeAndAdd( int Value ) throw()
					{ return ( __exchange_and_add( &my_Value, Value )); }

			private:
				CAtomic( const CAtomic & );
				CAtomic &operator = ( const CAtomic & );

				_Atomic_word my_Value;
		};

	} // namespace Unix

	class CUnxAtomicBasics : public CAtomicBasics {
		public:
			CUnxAtomicBasics( int Value ) throw()
				: my_Value( Value )
					{ }

			~CUnxAtomicBasics( void ) throw()
				{ }

		protected:
			virtual int DoPreIncrement( void ) throw()
				{ return ( my_Value.ExchangeAndAdd( 1 ) + 1 ); }

			virtual int DoPreDecrement( void ) throw()
				{ return ( my_Value.ExchangeAndAdd( -1 ) - 1 ); }

			virtual int DoPostIncrement( void ) throw()
				{ return ( my_Value.ExchangeAndAdd( 1 )); }

			virtual int DoPostDecrement( void ) throw()
				{ return ( my_Value.ExchangeAndAdd( -1 )); }

		private:
			Unix::CAtomic my_Value;
	};

} // namespace AidKit

#endif
