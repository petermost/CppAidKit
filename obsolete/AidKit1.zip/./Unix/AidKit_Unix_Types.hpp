#ifndef UNIX_AIDKIT_TYPES_HPP
#define UNIX_AIDKIT_TYPES_HPP

#include <sys/types.h>

namespace AidKit {

	typedef int8_t  INT8;
	typedef int16_t INT16;
	typedef int32_t INT32;
	typedef int64_t INT64;

	typedef u_int8_t  UINT8;
	typedef u_int16_t UINT16;
	typedef u_int32_t UINT32;
	typedef u_int64_t UINT64;

}

#endif
