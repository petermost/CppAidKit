#include "../AidKit_Thread.hpp"
#include "../AidKit_Time.hpp"

#if defined( AIDKIT_LINUX )

	inline int thread_yield( void )
		{ return ( pthread_yield() ); }

#elif defined( AIDKIT_BSD )

	inline int thread_yield( void )
		{ pthread_yield(); return ( 0 ); }

#endif

namespace AidKit {

namespace Unix {


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CMutex
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
inline int CheckMutexErrNo( int nError )
//=============================================================================
	{ return ( check_err_no< CMutexError >( nError )); }



//=============================================================================
CMutex::CMutex( void )
	throw ( CMutexError )
//=============================================================================
{
	// Initialize the attributes:

	CheckMutexErrNo( pthread_mutexattr_init( &my_hAttributes ));
	CheckMutexErrNo( pthread_mutexattr_settype( &my_hAttributes, PTHREAD_MUTEX_RECURSIVE ));

	// Initialize the mutex:

	CheckMutexErrNo( pthread_mutex_init( &my_hMutex, &my_hAttributes ));
}



//=============================================================================
CMutex::~CMutex( void )
	throw ()
//=============================================================================
{
	// Destroy the mutex:

	pthread_mutex_destroy( &my_hMutex );

	// Destroy the attributes:

	pthread_mutexattr_destroy( &my_hAttributes );
}



//=============================================================================
void CMutex::Lock( void )
	throw ( CMutexError )
//=============================================================================
{
	CheckMutexErrNo( pthread_mutex_lock( &my_hMutex ));
}


//=============================================================================
bool CMutex::TryLock( void )
	throw ( CMutexError )
//=============================================================================
{
	int nError = pthread_mutex_trylock( &my_hMutex );
	if ( nError != ENONE && nError != EBUSY )
		throw ( CMutexError( nError ));

	return ( nError != EBUSY );
}


//=============================================================================
void CMutex::Unlock( void )
	throw ( CMutexError )
//=============================================================================
{
	CheckMutexErrNo( pthread_mutex_unlock( &my_hMutex ));
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CCondition
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
inline int CheckConditionErrNo( int nError )
//=============================================================================
	{ return ( check_err_no< CConditionError >( nError )); }



//=============================================================================
inline int CheckConditionErrNoApi( int nResult )
//=============================================================================
	{ return ( check_err_no_api< CConditionError >( nResult )); }



//=============================================================================
CCondition::CCondition( void )
	throw ( CConditionError )
//=============================================================================
{
	CheckConditionErrNo( pthread_cond_init( &my_hCondition, NULL ));
}



//=============================================================================
CCondition::~CCondition( void )
	throw()
//=============================================================================
{
	pthread_cond_destroy( &my_hCondition );
}



//=============================================================================
void CCondition::Signal( void )
	throw ( CConditionError )
//=============================================================================
{
	CheckConditionErrNo( pthread_cond_signal( &my_hCondition ));
}



//=============================================================================
void CCondition::Broadcast( void )
	throw ( CConditionError )
//=============================================================================
{

	CheckConditionErrNo( pthread_cond_broadcast( &my_hCondition ));
}



//=============================================================================
void CCondition::Wait( CMutex *pMutex )
	throw ( CConditionError )
//=============================================================================
{
	int nError = pthread_cond_wait( &my_hCondition, &pMutex->my_hMutex );

	CheckConditionErrNo( nError );
}



//=============================================================================
bool CCondition::TimedWait( CMutex *pMutex, milliseconds_t Milliseconds )
	throw ( CConditionError )
//=============================================================================
{
	timespec Timeout;

	int nError = pthread_cond_timedwait( &my_hCondition, &pMutex->my_hMutex, ConvertMilliseconds( Milliseconds, &Timeout ));
	if ( nError != ENONE && nError != ETIMEDOUT )
		throw ( CConditionError( nError ));

	return ( nError == ENONE );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CRWLock
//###
//#############################################################################
//#############################################################################
//#############################################################################

#if defined( AIDKIT_LINUX )

//=============================================================================
inline int CheckRWLockErrNo( int nError )
//=============================================================================
	{ return ( check_err_no< CRWLockError >( nError )); }



//=============================================================================
CRWLock::CRWLock( EType eType, EShareType eShareType )
	throw ( CRWLockError )
//=============================================================================
{
	int nType;

	CheckRWLockErrNo( pthread_rwlockattr_init( &my_hAttributes ));

	// Determine which type of accessor should be prefered:

	switch ( eType ) {
		case ePreferReader:
			nType = PTHREAD_RWLOCK_PREFER_READER_NP;
			break;

		case ePreferWriterNonRecursive:
			nType = PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP;
			break;
			
		case ePreferWriter:
		default:
			nType = PTHREAD_RWLOCK_PREFER_WRITER_NP;
			break;
	}
	CheckRWLockErrNo( pthread_rwlockattr_setkind_np( &my_hAttributes, nType ));

	// Determine which thread may access the lock:

	switch ( eShareType ) {
		case eProcessShared:
			nType = PTHREAD_PROCESS_SHARED;
			break;

		case eProcessPrivate:
		default:
			nType = PTHREAD_PROCESS_PRIVATE;
			break;
	}
	CheckRWLockErrNo( pthread_rwlockattr_setpshared( &my_hAttributes, nType ));

	// Initialize the lock:

	CheckRWLockErrNo( pthread_rwlock_init( &my_hLock, &my_hAttributes ));
}



//=============================================================================
CRWLock::~CRWLock( void )
	throw()
//=============================================================================
{
	pthread_rwlock_destroy( &my_hLock );
	pthread_rwlockattr_destroy( &my_hAttributes );
}



//=============================================================================
void CRWLock::RdLock( void )
	throw ( CRWLockError )
//=============================================================================
{
	CheckRWLockErrNo( pthread_rwlock_rdlock( &my_hLock ));
}



//=============================================================================
bool CRWLock::TryRdLock( void )
	throw ( CRWLockError )
//=============================================================================
{
	int nError = pthread_rwlock_tryrdlock( &my_hLock );
	if ( nError != ENONE && nError != EBUSY )
		throw ( CRWLockError( nError ));

	return ( nError == ENONE );
}



//=============================================================================
void CRWLock::WrLock( void )
	throw ( CRWLockError )
//=============================================================================
{
	CheckRWLockErrNo( pthread_rwlock_wrlock( &my_hLock ));
}



//=============================================================================
bool CRWLock::TryWrLock( void )
	throw ( CRWLockError )
//=============================================================================
{
	int nError = pthread_rwlock_trywrlock( &my_hLock );
	if ( nError != ENONE && nError != EBUSY )
		throw ( CRWLockError( nError ));

	return ( nError == ENONE );



}



//=============================================================================
void CRWLock::Unlock( void )
	throw ( CRWLockError )
//=============================================================================
{
	CheckRWLockErrNo( pthread_rwlock_unlock( &my_hLock ));
}

#endif


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CThread
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
inline int CheckThreadErrNo( int nError )
//=============================================================================
	{ return ( check_err_no< CThreadError >( nError )); }



//=============================================================================
CThread::CThread( EType eType )
	throw ( CThreadError )
//=============================================================================
{
	int nKind;
	switch ( eType ) {
		case eDetached:
			nKind = PTHREAD_CREATE_DETACHED;
			break;

		case eJoinable:
		default:
			nKind = PTHREAD_CREATE_JOINABLE;
			break;
	}
	CheckThreadErrNo( pthread_attr_init( &my_hAttributes ));
	CheckThreadErrNo( pthread_attr_setdetachstate( &my_hAttributes, nKind ));
}



//=============================================================================
CThread::~CThread( void )
	throw()
//=============================================================================
{
	pthread_attr_destroy( &my_hAttributes );
}



//=============================================================================
void *CThread::Entry( void *pParameter )
//=============================================================================
{
	CThread *pThread = static_cast< CThread * >( pParameter );

	return (( *pThread->my_pFunction )( pThread, pThread->my_pFunctionParameter ));
}



//=============================================================================
void CThread::Create( void * ( *pFunction )( CThread *pThread, void *pParameter ), void *pParameter )
	throw ( CThreadError )
//=============================================================================
{
	my_pFunction          = pFunction;
	my_pFunctionParameter = pParameter;

	CheckThreadErrNo( pthread_create( &my_hThread, &my_hAttributes, &Entry, this ));
}



//=============================================================================
void CThread::Kill( int Signal )
	throw ( CThreadError )
//=============================================================================
{
	CheckThreadErrNo( pthread_kill( my_hThread, Signal ));
}



//=============================================================================
void *CThread::Join( void )
	throw ( CThreadError )
//=============================================================================
{
	void *pResult = NULL;

	CheckThreadErrNo( pthread_join( my_hThread, &pResult ));
	return ( pResult );
}



//=============================================================================
void CThread::Detach( void )
	throw ( CThreadError )
//=============================================================================
{
	CheckThreadErrNo( pthread_detach( my_hThread ));
}



//=============================================================================
void CThread::Yield( void )
	throw ( CThreadError )
//=============================================================================
{
	CheckThreadErrNo( thread_yield() );
}



//=============================================================================
bool CThread::Equal( const pthread_t &hThread ) const
	throw()
//=============================================================================
{
	return ( pthread_equal( my_hThread, hThread ) != 0 );
}



//=============================================================================
pthread_t CThread::Self( void ) const
	throw()
//=============================================================================
{
	return ( my_hThread );
}


} // namespace Unix



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CNativeThread
//###
//#############################################################################
//#############################################################################
//#############################################################################

using namespace Unix;

//=============================================================================
CNativeThread::CNativeThread( void )
//=============================================================================
{
	my_IsStarted = false;
	my_IsStopped = true;
}



//=============================================================================
CNativeThread::~CNativeThread( void )
//=============================================================================
{
	// The Join will already be called in DoWait !

	/*
	try {
		// If the thread was started we have to join, to avoid resource leaks:

		if ( my_IsStarted ) {
			my_Kernel.Join();
		}
	}
	catch ( ... ) {
		;
	}
	*/
}



//=============================================================================
void CNativeThread::Signal( int Signal )
	throw ( CThreadError )
//=============================================================================
{
	my_Kernel.Kill( Signal );
}



//=============================================================================
void *CNativeThread::Entry( Unix::CThread *, void *pParameter )
//=============================================================================
{
	CNativeThread *pKernel = static_cast< CNativeThread * >( pParameter );

	pKernel->my_StopMutex.Lock();
	pKernel->my_IsStopped = false;
	pKernel->my_StopMutex.Unlock();

	// Signal that the thread has started:

	pKernel->my_StartMutex.Lock();
	pKernel->my_IsStarted = true;
	pKernel->my_StartCondition.Signal();
	pKernel->my_StartMutex.Unlock();

	( *pKernel->my_pFunction )( pKernel->my_pFunctionParameter );

	// After the thread has returned we signal the condition:
	pKernel->my_StopMutex.Lock();
	pKernel->my_IsStopped = true;
	pKernel->my_StopCondition.Signal();
	pKernel->my_StopMutex.Unlock();

	return ( NULL );
}


//=============================================================================
bool CNativeThread::DoStart( void ( *pFunction )( void * ), void *pParameter )
//=============================================================================
{
	bool IsStarted = false;

	my_pFunction          = pFunction;
	my_pFunctionParameter = pParameter;

	// Wait until the thread has started:

	my_StartMutex.Lock();
	my_Kernel.Create( &Entry, this );
	if ( ! ( IsStarted = my_IsStarted )) {
		my_StartCondition.Wait( &my_StartMutex );
		IsStarted = my_IsStarted;
	}
	my_StartMutex.Unlock();

	return ( IsStarted );
}


//=============================================================================
bool CNativeThread::DoWait( milliseconds_t Milliseconds )
//=============================================================================
{
	bool IsStopped = false;

	// Wait until the thread has stopped:

	my_StopMutex.Lock();
	if ( ! ( IsStopped = my_IsStopped )) {
		my_StopCondition.TimedWait( &my_StopMutex, Milliseconds );
		IsStopped = my_IsStopped;
	}
	my_StopMutex.Unlock();

	if ( IsStopped )
		my_Kernel.Join(); // Shouldn't block at this point.

	return ( IsStopped );
}



//=============================================================================
bool CNativeThread::DoInfiniteWait( void )
//=============================================================================
{
	bool IsStopped = false;

	// Wait until the thread has stopped:

	my_StopMutex.Lock();
	if ( ! ( IsStopped = my_IsStopped )) {
		my_StopCondition.Wait( &my_StopMutex );
		IsStopped = my_IsStopped;
	}
	my_StopMutex.Unlock();

	if ( IsStopped )
		my_Kernel.Join(); // Shouldn't block at this point.

	return ( IsStopped );
}





//=============================================================================
void CNativeThread::DoYield( void )
//=============================================================================
{
	my_Kernel.Yield();
}




//=============================================================================
bool CNativeThread::DoSleep( milliseconds_t Milliseconds )
//=============================================================================
{
	my_SleepMutex.Lock();
	bool HasSlept = !my_SleepCondition.TimedWait( &my_SleepMutex, Milliseconds );
	my_SleepMutex.Unlock();

	return ( HasSlept );
}



//=============================================================================
void CNativeThread::DoInfiniteSleep( void )
//=============================================================================
{
	my_SleepMutex.Lock();
	my_SleepCondition.Wait( &my_SleepMutex );
	my_SleepMutex.Unlock();
}



//=============================================================================
void CNativeThread::DoWakeup( void )
//=============================================================================
{
	my_SleepCondition.Signal();
}



//=============================================================================
bool CNativeThread::IsSelf( void ) const
//=============================================================================
{
	pthread_t hCurrentThread = pthread_self();

	return ( my_Kernel.Equal( hCurrentThread ));
}


} // namespace AidKit
