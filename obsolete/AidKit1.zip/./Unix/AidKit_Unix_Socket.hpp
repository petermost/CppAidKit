#ifndef AIDKIT_UNIX_SOCKET_HPP
#define AIDKIT_UNIX_SOCKET_HPP

#include "../AidKit.hpp"
#include "../AidKit_Time.hpp"
#include "../AidKit_Types.hpp"
#include "../AidKit_Debug.hpp"

#include <netdb.h>     // getservbyname
#include <arpa/inet.h> // inet_ntoa
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>

#if defined( AIDKIT_LINUX )
	typedef sighandler_t signal_handler_t;
#elif defined( AIDKIT_BSD )
	typedef __sighandler_t *signal_handler_t;
#else
	#error "Don't know how to define sighandler_t!"
#endif

struct timeval;

namespace AidKit {

	namespace Unix {

		UINT64 ntohll( UINT64 network_long_long );
		UINT64 htonll( UINT64 host_long_long );

	}  // namespace Unix

	typedef int socket_t;
	typedef int file_t;

	const socket_t INVALID_SOCKET = -1;
	const int SOCKET_ERROR = -1;

	typedef TStdError< class CSocket > CSocketError;

	//---------------------------------------------------------
	class CNativeSocketBasics : public CSocketBasics {
	//---------------------------------------------------------
		public:
			CNativeSocketBasics( void )
				throw ( CSocketError );

			~CNativeSocketBasics( void )
				throw();

			int DoClose( socket_t hSocket )
				throw ( CSocketError );

			int DoShutdown( socket_t hSocket, EDirection eDirection )
				throw ( CSocketError );

			int DoIOControl( socket_t hSocket, EMode eMode, EMode *pOldMode )
				throw ( CSocketError );

			bool DoTryConnect( socket_t hSocket, const sockaddr *pAddress, socklen_t nAddressLength )
				throw ( CSocketError );

			size_t DoReceive( socket_t hSocket, void *pBuffer, size_t nBufferSize, unsigned Flags )
				throw ( CSocketError, assertion_error );
				
			size_t DoSend( socket_t hSocket, const void *pBuffer, size_t nBufferLength, unsigned Flags )
				throw ( CSocketError );

			size_t DoSend( socket_t hSocket, file_t hFile, off_t *pOffset, size_t Count )
				throw ( CSocketError );

			int DoSetSocketOption( socket_t hSocket, int nLevel,
				int nOptName, const void *pOptVal, socklen_t OptLen )
					throw ( CSocketError );

			int DoGetSocketOption( socket_t hSocket, int nLevel,
				int nOptName, void *pOptVal, socklen_t *pOptLen )
					throw ( CSocketError );

			in_addr DoNameToAddress( const string_t &Name ) const
				throw ( CSocketError );
				
			string_t DoAddressToName( const in_addr &Address ) const
				throw ( CSocketError );
				
		private:
			signal_handler_t my_OldSigPipeHandler;
	};

} // namespace AidKit

#endif
