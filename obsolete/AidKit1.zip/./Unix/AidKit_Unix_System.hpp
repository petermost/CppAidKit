#ifndef AIDKIT_UNIX_SYSTEM_HPP
#define AIDKIT_UNIX_SYSTEM_HPP

#include "../AidKit.hpp"
#include "../AidKit_Unicode.hpp"
#include <limits.h>

namespace AidKit {
	
	const UNICHAR kDirectorySeparator = UNITEXT( '/' );

	const size_t kMaxPath = PATH_MAX;
}

#endif

