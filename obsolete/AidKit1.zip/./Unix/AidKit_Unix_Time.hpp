#ifndef AIDKIT_UNIX_TIME_HPP
#define AIDKIT_UNIX_TIME_HPP

#include "../AidKit.hpp"
#include "../AidKit_StdError.hpp"
#include <sys/time.h>

struct timespec;

namespace AidKit {

	namespace Unix {

	timeval GetTimeOfDay( void )
		throw ( CStdError );

	string_t TimeStamp( const timeval &CurrentTime );

	//-----------------------------------------------------------------------------
	class CProfiler {
	//-----------------------------------------------------------------------------
		public:
			CProfiler( void );
			~CProfiler( void );

			void Enable( void );
			void Disable( void );

		private:
			itimerval my_TimerValue;
	};


	//-----------------------------------------------------------------------------
	class CPerformanceAnalyzer {
	//-----------------------------------------------------------------------------
		public:
			CPerformanceAnalyzer( void );

			void Start( void );
			void Stop( void );

			unsigned long Measure( size_t Amount )
				{ return ( my_Amount += Amount ); }

			unsigned long Amount( void ) const
				{ return ( my_Amount ); }

			unsigned long Throughput( void ) const;

		private:
			timeval my_StartTime;
			timeval my_StopTime;
			unsigned long my_Amount;
	};


		// Time functions:

		timespec *ConvertMilliseconds( milliseconds_t Milliseconds, timespec *pTimeSpec )
			throw ( CStdError );


		timeval operator - ( const timeval &Time1, const timeval &Time2 );
		timeval operator + ( const timeval &Time1, const timeval &Time2 );

		//=============================================================================
		inline unsigned long long int ReadTimeStampCounter( void )
		//=============================================================================
		{
			unsigned long long int TimeStampCounter;
			__asm__ __volatile__("rdtsc" : "=A" (TimeStampCounter) : );

			return ( TimeStampCounter );
		}

	} // namespace Unix

} // namespace AidKit

#endif
