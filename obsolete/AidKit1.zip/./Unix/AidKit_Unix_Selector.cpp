#include "AidKit_Unix_Selector.hpp"
#include "../AidKit_Types.hpp"
#include "../AidKit_SocketHelper.hpp"

using namespace std;

namespace AidKit {

namespace Unix {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSelector
//###
//#############################################################################
//#############################################################################
//#############################################################################


static const int NOTIFICATION = 0x12345678;

//=============================================================================
inline int CheckSelectorError( int nError )
	throw ( CSelectorError )
//=============================================================================
{
	return ( check_err_no_api< CSelectorError >( nError ));
}



//=============================================================================
CSelector::CSelector( void )
	throw ( CSelectorError )
//=============================================================================
{
	my_IsNotified = false;

	try {
		my_NotificationPipe.Open();
	}
	catch ( const CPipeError &PipeError ) {
		throw ( CSelectorError( PipeError ));
	}
}



//=============================================================================
CSelector::~CSelector( void )
	throw( CSelectorError )
//=============================================================================
{
	try {
		my_NotificationPipe.Close();
	}
	catch ( const CPipeError &PipeError ) {
		if ( !uncaught_exception() )
			throw ( CSelectorError( PipeError ));
	}
}



//=============================================================================
int CSelector::Select( CFdSet *pInputSet, CFdSet *pOutputSet, CFdSet *pExceptSet,
	milliseconds_t Timeout, bool IsNotifiable )
		throw ( CSelectorError )
//=============================================================================
{
	try {
		CFdSet InputSet;
		if ( IsNotifiable ) {
			// Add the pipe to the input files:

			if ( pInputSet == NULL ) {
				pInputSet = &InputSet;
			}
			pInputSet->Set( my_NotificationPipe.ReadableFileNo() );
		}
		int nResult = CheckSelectorError( ::AidKit::Select( pInputSet, pOutputSet, pExceptSet, Timeout ));
		if ( IsNotifiable && nResult > 0 ) {

			// Was a notification send:

			if ( pInputSet->IsSet( my_NotificationPipe.ReadableFileNo() )) {

				// Read the notification from the pipe to avoid that it fills up
				// and eventually would block:

				int Notification;
				my_NotificationPipe.Read( &Notification, sizeof( Notification ));

				nResult = 0; // Same result as if the timeout had expired.

				// We don't need to remove the pipe fd because the caller can't detect it!
			}
		}
		return ( nResult );
	}
	catch ( const CPipeError &PipeError ) {
		throw ( CSelectorError( PipeError ));
	}
}



//=============================================================================
void CSelector::Notify( void )
	throw ( CSelectorError )
//=============================================================================
{
	try {
		// Only write to the pipe if we are not already notified:

		if ( !my_IsNotified ) {
			my_IsNotified = true;

			// Use the pipe to notify the select:
	
			const int Notification = NOTIFICATION;
			my_NotificationPipe.Write( &Notification, sizeof( Notification ));
		}
	}
	catch ( const CPipeError &PipeError ) {
		throw ( CSelectorError( PipeError ));
	}
}



//=============================================================================
bool CSelector::IsNotified( void )
	throw()
//=============================================================================
{
	// Query and reset the notification flag:

	bool IsNotified = my_IsNotified;
	my_IsNotified = false;

	return ( IsNotified );
}

} // namespace Unix

} // namespace AidKit
