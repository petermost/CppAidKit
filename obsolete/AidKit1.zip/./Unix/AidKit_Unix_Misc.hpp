#ifndef AIDKIT_UNIX_MISC_HPP
#define AIDKIT_UNIX_MISC_HPP

#include "../AidKit.hpp"

namespace AidKit {

	namespace Unix {

	}

}

#endif
