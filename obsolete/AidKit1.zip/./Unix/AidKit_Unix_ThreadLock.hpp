#ifndef AIDKIT_UNIX_THREADLOCK_HPP
#define AIDKIT_UNIX_THREADLOCK_HPP

#include "../AidKit_ThreadLock.hpp"
#include "../AidKit_Thread.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CUnixThreadGuard : public CThreadGuardBasics {
	//-----------------------------------------------------------------------------
		public:
			CUnixThreadGuard( void );
			~CUnixThreadGuard( void );

		protected:
			virtual thread_t DoLock( void );
			virtual void DoUnlock( void );

		private:
			CUnixThreadGuard( const CUnixThreadGuard & );
			CUnixThreadGuard &operator = ( const CUnixThreadGuard & );

			Unix::CMutex my_Mutex;
	};

}

#endif
