#ifndef AIDKIT_UNIX_HPP
#define AIDKIT_UNIX_HPP

// To get snprintf from stdio.h we need to define this symbol:

#ifndef __USE_ISOC99
	#define __USE_ISOC99
#endif

#endif
