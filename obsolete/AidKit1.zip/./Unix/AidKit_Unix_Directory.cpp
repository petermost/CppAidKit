#include "AidKit_Unix_Directory.hpp"
#include "../AidKit_String.hpp"

using namespace std;

namespace AidKit {

namespace Unix {

//=============================================================================
vector< string_t > ParseDirectory( const string_t &DirectoryName, const string_t &Pattern )
	throw ( CDirectoryError )
//=============================================================================
{
	string_t Filename;
	vector< string_t > Filenames;
	CDirectory Directory( DirectoryName );
	while ( Directory.Read( &Filename )) {
		if ( is_mixed_pattern_match( Filename.c_str(), Pattern.c_str() )) {
			Filenames.push_back( Filename );
		}
	}
	return ( Filenames );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectory
//###
//#############################################################################
//#############################################################################
//#############################################################################

#define CONSTRUCTOR() \
	my_hDir = NULL

//=============================================================================
inline int CheckDirApi( int nError )
	throw ( CDirectoryError )
//=============================================================================
{
	return ( check_err_no_api< CDirectoryError >( nError ));
}


//=============================================================================
CDirectory::CDirectory( void )
	throw()
//=============================================================================
{
	CONSTRUCTOR();
}



//=============================================================================
CDirectory::CDirectory( const string_t &Name, CDirectoryError *pError )
	throw ( assertion_error )
//=============================================================================
{
	CONSTRUCTOR();

	Open( Name, pError );
}



//=============================================================================
CDirectory::CDirectory( const string_t &Name )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	CONSTRUCTOR();

	Open( Name );
}



//=============================================================================
CDirectory::~CDirectory( void )
	throw()
//=============================================================================
{
	try {
		if ( my_hDir != NULL )
			Close();
	} catch ( ... ) {
		;
	}
}


//=============================================================================
bool CDirectory::Open( const string_t &Name, CDirectoryError *pError )
	throw ( assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( pError != NULL );
	AIDKIT_ASSERT( my_hDir == NULL );

	if (( my_hDir = opendir( Name.c_str() )) == NULL)
		*pError = CDirectoryError::LastError();

	return ( my_hDir != NULL );
}




//=============================================================================
void CDirectory::Open( const string_t &Name )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	CDirectoryError Error;

	if ( !Open( Name, &Error ))
		throw ( Error );
}



//=============================================================================
bool CDirectory::Close( void )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_hDir != NULL );

	CheckDirApi( closedir( my_hDir ));
	my_hDir = NULL;

	return ( true );
}



//=============================================================================
bool CDirectory::Read( string_t *pFilename )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( pFilename != NULL );
	AIDKIT_ASSERT( my_hDir != NULL );

	int nError;
	dirent *pEntry;

	if (( nError = readdir_r( my_hDir, &my_Entry, &pEntry )) == 0 ) {
		if ( pEntry != NULL ) {
			*pFilename = pEntry->d_name;
			return ( true );
		} else
			return ( false );
	} else
		throw ( CDirectoryError( nError ));
}



//=============================================================================
void CDirectory::Rewind( void )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_hDir != NULL );

	rewinddir( my_hDir );
}



//=============================================================================
off_t CDirectory::Tell( void )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_hDir != NULL );

	return ( CheckDirApi( telldir( my_hDir )));
}



//=============================================================================
void CDirectory::Seek( off_t Location )
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_hDir != NULL );

	seekdir( my_hDir, Location );
}



//=============================================================================
int CDirectory::FileNo( void ) const
	throw ( CDirectoryError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_hDir != NULL );

	return ( CheckDirApi( dirfd( my_hDir )));
}



} // namespace Unix

} // namespace AidKit
