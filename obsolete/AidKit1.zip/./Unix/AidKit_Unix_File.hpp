#ifndef AIDKIT_UNIX_FILE_HPP
#define AIDKIT_UNIX_FILE_HPP

#include "../AidKit.hpp"
#include "../AidKit_StdError.hpp"

#include <unistd.h>

namespace AidKit {

	typedef TStdError< class CFile > CFileError;

	namespace Unix {

		
		// File functions:

		bool IsFileBlocking( int nFile )
			throw ( CStdError );

		void UnblockFile( int nFile )
			throw ( CStdError );

		void BlockFile( int nFile )
			throw ( CStdError );


		typedef ssize_t ( WriteFunction )( int, const void *, size_t );
		size_t WriteFile( int nFile, const void *pData, size_t nDataSize, WriteFunction * = &write )
			throw ( CStdError );

		typedef ssize_t ( ReadFunction )( int, void *, size_t );
		size_t ReadFile( int nFile, void *pData, size_t nDataSize, ReadFunction * = &read )
			throw ( CStdError );



		size_t WriteSocket( int nSocket, const void *pData, size_t nDataSize )
			throw ( CStdError );

		size_t ReadSocket( int nSocket, void *pData, size_t nDataSize )
			throw ( CStdError );



		size_t WritePipe( int nPipe, const void *pData, size_t nDataSize )
			throw ( CStdError );

		size_t ReadPipe( int nPipe, void *pData, size_t nDataSize )
			throw ( CStdError );

	} // namespace Unix

	//-----------------------------------------------------------------------------
	class CUnxFileSystemBasics : public CFileSystemBasics {
	//-----------------------------------------------------------------------------
		public:
			virtual CFileInfo DoFileInfo( const string_t &FileName ) const
				throw ( CFileSystemError );

			virtual CFileInfo DoFileInfo( int nFile ) const
				throw ( CFileSystemError );
	};
}

#endif
