#include "../AidKit_String.hpp"
#include "../AidKit_Memory.hpp"
#include "../AidKit_Debug.hpp"

// For a BSD system, those 4 includes are NEEDED before socket.h compiles!
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <resolv.h>

namespace AidKit {

namespace Unix {


//=============================================================================
size_t encode_base64( const void *Data, size_t DataLength, string_t *EncodedData )
//=============================================================================
{
	AIDKIT_ASSERT( Data != NULL );

	int EncodedLength = 0;
	CMemory Buffer( DataLength * 2 );

	if ( DataLength > 0 ) {
		while (( EncodedLength = b64_ntop(( const u_char * )Data, DataLength, ( char * )Buffer.Start(), Buffer.Size() )) == -1 )
			Buffer.Resize( Buffer.Size() * 2 );

		EncodedData->assign(( const char_t * ) Buffer.Start(), EncodedLength );
	}
	return ( EncodedLength );
}



//=============================================================================
size_t decode_base64( const string_t &EncodedData, void *Data, size_t DataLength )
//=============================================================================
{
	AIDKIT_ASSERT( Data != NULL );

	int DecodedLength = 0;

	if ( !EncodedData.empty() ) {
		DecodedLength = b64_pton( EncodedData.c_str(), ( u_char * )Data, DataLength );
	}
	return (( DecodedLength != -1 ) ? DecodedLength : 0 );
}


} // namespace Unix

} // namespace AidKit

