#include "AidKit_Unix_Process.hpp"
#include "../AidKit_SocketHelper.hpp"
// #include "../AidKit_StlHelper.hpp"

#include <stdio.h>
#include <signal.h>
#include <sys/wait.h>

using namespace std;

namespace AidKit {

namespace Unix {

/*
//=============================================================================
string_t ExecuteProcess( const char_t ExecutableFilename[], const char_t *argv[], milliseconds_t Timeout )
	throw ( CProcessError )
//=============================================================================
{
	char_t Buffer[ 1000 ];
	size_t nBufferLength;

	CProcess Process;
	string_t Answer;

	try {
		Process.Start( ExecutableFilename, argv );
		if (( nBufferLength = Process.Read( Buffer, sizeof( Buffer ), Timeout )) > 0 )
			Answer.assign( Buffer, nBufferLength );
		Process.Wait();
	} catch ( CProcessError &rError ) {
		// if the process didn't respond in time then we kill it:
		if ( rError == ETIMEDOUT ) {
			Process.Kill();
		}
		throw;
	}
	return ( Answer );
}
*/

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CProcess
//###
//#############################################################################
//#############################################################################
//#############################################################################

vector< CProcess * > CProcess::our_Childs;
struct sigaction CProcess::our_OldSignalAction;

//=============================================================================
inline int CheckProcessApi( int nResult )
	throw ( CProcessError )
//=============================================================================
{
	return ( check_err_no_api< CProcessError >( nResult ));
}



//=============================================================================
static void cleanup_this( pid_t *pChildProcess, CPipe *pStdInPipe, CPipe *pStdOutPipe, CPipe *pStdErrPipe )
	throw()
//=============================================================================
{
	if ( *pChildProcess != -1 ) {
		waitpid( *pChildProcess, NULL, WUNTRACED | WNOHANG );
		*pChildProcess = -1;
	}
	pStdInPipe->Close();
	pStdOutPipe->Close();
	pStdErrPipe->Close();
}


//=============================================================================
void CProcess::SignalHandler( int nSignal, siginfo_t *pSignalInfo, void * )
	throw( CProcessError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( nSignal == SIGCHLD );

	vector< CProcess * >::iterator itProcess;

	// Check wether it is our child:

	for ( itProcess = our_Childs.begin(); itProcess != our_Childs.end(); ++itProcess ) {
		if (( *itProcess )->my_ChildProcess == pSignalInfo->si_pid ) {
			( *itProcess )->Notify();
			our_Childs.erase( itProcess );
			break;
		}
	}
}


//=============================================================================
void CProcess::InstallSignalHandler( void )
	throw ( CProcessError )
//=============================================================================
{
	if ( our_Childs.empty() ) {
		struct sigaction SignalAction = struct sigaction();
		SignalAction.sa_sigaction = SignalHandler;
		SignalAction.sa_flags = SA_SIGINFO;

		CheckProcessApi( ::sigaction( SIGCHLD, &SignalAction, &our_OldSignalAction ));
	}
}



//=============================================================================
void CProcess::UninstallSignalHandler( void )
	throw ( CProcessError )
//=============================================================================
{
	if ( our_Childs.empty() ) {
		CheckProcessApi( ::sigaction( SIGCHLD, &our_OldSignalAction, NULL ));
	}
}



//=============================================================================
CProcess::CProcess( void )
	throw()
//=============================================================================
{
	InstallSignalHandler();

	my_ChildProcess = -1;
}



//=============================================================================
CProcess::~CProcess( void )
	throw()
//=============================================================================
{
	// We don't AIDKIT_ASSERT the pipes, because we assume that if the process wasn't stopped
	// then the pipes haven't either.

	try {
		cleanup_this( &my_ChildProcess, &my_StdInPipe, &my_StdOutPipe, &my_StdErrPipe );

		UninstallSignalHandler();
	}
	catch ( ... ) {
		;
	}
}



//=============================================================================
void CProcess::Execute( const char_t Process[], const char_t *argv[] )
	throw ( CProcessError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_ChildProcess == -1 ); // Already running?

	try {
		our_Childs.push_back( this );

		my_StdInPipe.Open();
		my_StdOutPipe.Open();
		my_StdErrPipe.Open();
		if ( CheckProcessApi( my_ChildProcess = fork() ) == 0 ) {
			try {
				// Redirect stdin, stdout and stderror to the pipe:
				CheckProcessApi( dup2( my_StdInPipe.ReadableFileNo(), fileno( stdin )));
				CheckProcessApi( dup2( my_StdOutPipe.WritableFileNo(), fileno( stdout )));
				CheckProcessApi( dup2( my_StdErrPipe.WritableFileNo(), fileno( stderr )));

				// Execute the process:
				CheckProcessApi( execvp( Process, const_cast< char_t * const * >( argv )));
				abort(); // Should not have been reached!
			}
			catch ( const CStdError &Error )  {
				_exit( Error ); // Return the error so we can query it with waitpid().
			}
			catch ( ... ) {
				_exit( EINVAL );
			}
		} else {
			 // Parent branch (Nothing to do).
		}
	}
	catch ( const CPipeError &PipeError ) {
		cleanup_this( &my_ChildProcess, &my_StdInPipe, &my_StdOutPipe, &my_StdErrPipe );
		throw ( CProcessError( PipeError ));
	}
	catch ( const exception & ) {
		cleanup_this( &my_ChildProcess, &my_StdInPipe, &my_StdOutPipe, &my_StdErrPipe );
		throw;
	}
}



//=============================================================================
size_t CProcess::WriteStdIn( const void *Data, size_t DataSize )
	throw ( CProcessError )
//=============================================================================
{
	size_t nWritten = 0;
	CFdSet OutputSet;

	try {
		OutputSet.Set( my_StdInPipe.WritableFileNo() );
		if ( Selector.Select( NULL, &OutputSet, NULL, INFINITE_MILLISECONDS, false ) > 0 ) {
			nWritten = my_StdInPipe.Write( Data, DataSize );
		}
		return ( nWritten );
	}
	catch ( const CStdError &Error ) {
		throw ( CProcessError( Error ));
	}
}



//=============================================================================
size_t CProcess::ReadStdOut( void *Data, size_t DataSize )
	throw ( CProcessError )
//=============================================================================
{
	size_t nRead = 0;
	CFdSet InputSet;

	try {
		InputSet.Set( my_StdOutPipe.ReadableFileNo() );
		if ( Selector.Select( &InputSet, NULL, NULL, INFINITE_MILLISECONDS, false ) > 0 ) {
			nRead = my_StdOutPipe.Read( Data, DataSize );
		}
		return ( nRead );
	}
	catch ( CStdError &rError ) {
		throw ( CProcessError( rError ));
	}
}



//=============================================================================
size_t CProcess::ReadStdErr( void *Data, size_t DataSize )
	throw ( CProcessError )
//=============================================================================
{
	size_t nRead = 0;
	CFdSet InputSet;

	try {
		InputSet.Set( my_StdErrPipe.ReadableFileNo() );
		if ( Selector.Select( &InputSet, NULL, NULL, INFINITE_MILLISECONDS, false ) > 0 ) {
			nRead = my_StdErrPipe.Read( Data, DataSize );
		}
		return ( nRead );
	}
	catch ( CStdError &rError ) {
		throw ( CProcessError( rError ));
	}
}



//=============================================================================
void CProcess::Notify( void )
	throw ( CProcessError )
//=============================================================================
{
	Selector.Notify();
}



//=============================================================================
void CProcess::Kill( void )
	throw ( CProcessError )
//=============================================================================
{
	CheckProcessApi( kill( my_ChildProcess, SIGINT ));
	cleanup_this( &my_ChildProcess, &my_StdInPipe, &my_StdOutPipe, &my_StdErrPipe );
}



//=============================================================================
int CProcess::Wait( void )
	throw ( CProcessError )
//=============================================================================
{
	int Status = 0;

	// Wait until the process has ended:

	CheckProcessApi( waitpid( my_ChildProcess, &Status, WUNTRACED ));

	return ( WIFEXITED( Status ) ? WEXITSTATUS( Status ) : -1 );
}



//=============================================================================
int CProcess::Stop( void )
	throw ( CProcessError )
//=============================================================================
{
	int ExitValue = Wait();

	cleanup_this( &my_ChildProcess, &my_StdInPipe, &my_StdOutPipe, &my_StdErrPipe );

	return ( ExitValue );
}



//=============================================================================
bool CProcess::HasStopped( int *pResult ) const
	throw ( CProcessError )
//=============================================================================
{
	int nStatus;
	pid_t ExitedProcess;

	ExitedProcess = CheckProcessApi( waitpid( my_ChildProcess, &nStatus, WNOHANG | WUNTRACED ));
	if ( ExitedProcess == my_ChildProcess && WIFEXITED( nStatus )) {
		*pResult = WEXITSTATUS( nStatus );
	}
	return ( ExitedProcess == my_ChildProcess );
}


} // namespace Unix

} // namespace AidKit


/*
//=============================================================================
string_t CProcess::Response( milliseconds_t Timeout )
	throw ( CProcessError )
//=============================================================================
{
	vector< int > Pipes;
	ssize_t nBufferLength;
	char Buffer[ 1000 ];
	string_t Response;
	int nSelected;

	// Wait for an answer to the command (might be arriving via stdin or stderr):
	Pipes.push_back( my_StdOutPipe[ READ_FD_IDX ] );
	Pipes.push_back( my_StdErrPipe[ READ_FD_IDX ] );

	if (( nSelected = Select( &Pipes, NULL, NULL, Timeout )) > 0 ) {

		// Retrieve the response:
		for ( vector< int >::iterator itPipe = Pipes.begin(); itPipe != Pipes.end(); ++itPipe ) {
			if (( nBufferLength = ReadPipe( *itPipe, Buffer, sizeof( Buffer ))) > 0 )
				Response.append( Buffer, nBufferLength );

			if ( *itPipe == my_StdErrPipe[ READ_FD_IDX ] )
				throw ( CProcessError( EINVAL, Response.c_str() ));
		}
	} else if ( nSelected == 0 ) {
		// We can't simply return an empty string for a timeout value, because
		// an empty response is also valid:
		throw ( CProcessError( ETIMEDOUT ));
	}
	return ( Response );
}
*/
/*
//=============================================================================
int spawnve( const char_t Process[], const char_t *argv[], const char_t *env[] )
//=============================================================================
{
	pid_t Child;

	if (( Child = fork()) == 0 ) {
		return ( execve( Process, const_cast< char_t * const * >( argv ), const_cast< char_t *const * >( env )));
	}
	else if ( Child > 0 ) {
		return ( waitpid( Child, NULL, WUNTRACED ));
	}
	else
		return ( Child );
}
*/

/*

*/
