#ifndef AIDKIT_UNIX_PIPE_HPP
#define AIDKIT_UNIX_PIPE_HPP

#include "../AidKit.hpp"
#include "../AidKit_StdError.hpp"
#include <stddef.h>

namespace AidKit {

	namespace Unix {

		typedef TStdError< class CPipe > CPipeError;

		//---------------------------------------------------------
		class CPipe {
		//---------------------------------------------------------
			public:
				CPipe( void )
					throw ( CPipeError );

				~CPipe( void )
					throw();

				void Open( void )
					throw ( CPipeError );

				void Close( void )
					throw ( CPipeError );

				size_t Write( const void *pData, size_t nDataSize )
					throw ( CPipeError );

				size_t Read( void *pData, size_t nDataSize )
					throw( CPipeError );

				int WritableFileNo( void ) const;
				int ReadableFileNo( void ) const;

			private:
				CPipe( const CPipe & );
				CPipe &operator = ( const CPipe & );

				int my_PipeFDs[ 2 ];
		};

	}

}

#endif
