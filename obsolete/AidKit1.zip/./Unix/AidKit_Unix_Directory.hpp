#ifndef AIDKIT_UNIX_DIRECTORY_HPP
#define AIDKIT_UNIX_DIRECTORY_HPP

#include "../AidKit.hpp"
#include "../AidKit_Debug.hpp"
#include "../AidKit_StdError.hpp"

#include <dirent.h>
#include <sys/types.h>
#include <vector>

namespace AidKit {

	namespace Unix {

		typedef TStdError< class CDirectory > CDirectoryError;

		std::vector< string_t > ParseDirectory( const string_t &DirectoryName,
			const string_t &Pattern )
				throw ( CDirectoryError );

		//-----------------------------------------------------------------------------
		class CDirectory {
		//-----------------------------------------------------------------------------
			public:
				CDirectory( void )
					throw();

				CDirectory( const string_t &Name, CDirectoryError *pError )
					throw ( assertion_error );

				CDirectory( const string_t &Name )
					throw ( CDirectoryError, assertion_error );

				~CDirectory( void )
					throw();

				bool Open( const string_t &Name, CDirectoryError *pError )
					throw ( assertion_error );

				void Open( const string_t &Name )
					throw ( CDirectoryError, assertion_error );

				bool Close( void )
					throw ( CDirectoryError, assertion_error );

				bool Read( string_t *pFilename )
					throw ( CDirectoryError, assertion_error );

				void Rewind( void )
					throw ( CDirectoryError, assertion_error );

				off_t Tell( void )
					throw ( CDirectoryError, assertion_error );

				void Seek( off_t )
					throw ( CDirectoryError, assertion_error );

				int FileNo( void ) const
					throw ( CDirectoryError, assertion_error );

			private:
				DIR *my_hDir;
				dirent my_Entry;
		};

	}

}

#endif

