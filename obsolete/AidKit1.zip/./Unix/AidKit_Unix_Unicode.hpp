#ifndef AIDKIT_UNIX_UNICODE_HPP
#define AIDKIT_UNIX_UNICODE_HPP

#if !defined( TEXT )
	#if defined( AIDKIT_UNICODE )
		#define TEXT( Text ) L##Text
	#else
		#define TEXT( Text ) Text
	#endif
#endif

// stdio.h
/* #if defined( AIDKIT_UNICODE )
	#define UNISNPRINTF  swprintf
	#define UNIVSNPRINTF vswprintf
#else
	#define UNISNPRINTF  snprintf
	#define UNIVSNPRINTF vsnprintf
#endif */

#endif
