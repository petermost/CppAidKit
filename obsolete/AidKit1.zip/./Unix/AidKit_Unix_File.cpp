#include "../AidKit_File.hpp"
#include "../AidKit_Types.hpp"
#include "../AidKit_Debug.hpp"

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>

namespace AidKit {

namespace Unix {

//#############################################################################
//#############################################################################
//#############################################################################
//
// Block/Unblock-File
//
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
bool IsFileBlocking( int nFile )
	throw ( CStdError )
//=============================================================================
{
	int Flags = CheckErrNoApi( fcntl( nFile, F_GETFL ));
	return (( Flags & O_NONBLOCK ) == 0 );
}



//=============================================================================
void UnblockFile( int nFile )
	throw ( CStdError )
//=============================================================================
{
	int Flags = CheckErrNoApi( fcntl( nFile, F_GETFL ));
	Flags |= O_NONBLOCK;
	CheckErrNoApi( fcntl( nFile, F_SETFL, Flags ));
}



//=============================================================================
void BlockFile( int nFile )
	throw ( CStdError )
//=============================================================================
{
	int Flags = CheckErrNoApi( fcntl( nFile, F_GETFL ));
	Flags &= ~O_NONBLOCK;
	CheckErrNoApi( fcntl( nFile, F_SETFL, Flags ));
}


//#############################################################################
//#############################################################################
//#############################################################################
//
// Write/Read-File
//
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
size_t WriteFile( int nFile, const void *pData, size_t nDataSize, WriteFunction *pDoWrite )
	throw ( CStdError )
//=============================================================================
{
	ssize_t nCount;
	size_t nWritten = 0;

	while (( nCount = ( *pDoWrite )( nFile, pData, nDataSize )) > 0 && nCount <= nDataSize ) {
		pData = static_cast< const BYTE * >( pData ) + nCount;
		nDataSize -= nCount;
		nWritten += nCount;
	}
	if ( nCount == ERROR )
		throw ( CStdError::LastError() );

	return ( nWritten );
}



//=============================================================================
size_t ReadFile( int nFile, void *pData, size_t nDataSize, ReadFunction *pDoRead )
	throw ( CStdError )
//=============================================================================
{
	ssize_t nCount;
	size_t nRead = 0;

	while (( nCount = ( *pDoRead )( nFile, pData, nDataSize )) > 0  && nCount <= nDataSize ) {
		pData = static_cast< BYTE * >( pData ) + nCount;
		nDataSize -= nCount;
		nRead += nCount;
	}
	if ( nCount == ERROR )
		throw ( CStdError::LastError() );

	return ( nRead );
}



//#############################################################################
//#############################################################################
//#############################################################################
//
// Write/Read-Socket
//
//#############################################################################
//#############################################################################
//#############################################################################


#if defined( MSG_NOSIGNAL )
	#define SOCKET_FLAGS MSG_DONTWAIT | MSG_NOSIGNAL
#else
	#define SOCKET_FLAGS MSG_DONTWAIT
#endif

//=============================================================================
static ssize_t DoWriteSocket( int nSocket, const void *pData, size_t nDataSize )
//=============================================================================
{
	int nCount;

	if (( nCount = send( nSocket, pData, nDataSize,  SOCKET_FLAGS )) == ERROR ) {
		if ( errno == EWOULDBLOCK )
			nCount = 0;
	}
	return ( nCount );
}



//=============================================================================
static ssize_t DoReadSocket( int nSocket, void *pData, size_t nDataSize )
//=============================================================================
{
	int nCount;

	if (( nCount = recv( nSocket, pData, nDataSize, SOCKET_FLAGS )) == ERROR ) {
		if ( errno == EWOULDBLOCK )
			nCount = 0;
	}
	return ( nCount );
}



//=============================================================================
size_t WriteSocket( int nSocket, const void *pData, size_t nDataSize )
	throw ( CStdError )
//=============================================================================
{
	return ( WriteFile( nSocket, pData, nDataSize, &DoWriteSocket ));
}



//=============================================================================
size_t ReadSocket( int nSocket, void *pData, size_t nDataSize )
	throw ( CStdError )
//=============================================================================
{
	return ( ReadFile( nSocket, pData, nDataSize, &DoReadSocket ));
}


//#############################################################################
//#############################################################################
//#############################################################################
//
// Write/Read Pipe
//
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
static ssize_t DoWritePipe( int nPipe, const void *pData, size_t nDataSize )
	throw ( CStdError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( !IsFileBlocking( nPipe ));

	int nCount;

	if (( nCount = write( nPipe, pData, nDataSize )) == ERROR ) {
		if ( errno == EWOULDBLOCK )
			nCount = 0;
	}
	return ( nCount );
}


//=============================================================================
static ssize_t DoReadPipe( int nPipe, void *pData, size_t nDataSize )
	throw ( CStdError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( !IsFileBlocking( nPipe ));

	int nCount;

	if (( nCount = read( nPipe, pData, nDataSize )) == ERROR ) {
		if ( errno == EWOULDBLOCK )
			nCount = 0;
	}
	return ( nCount );
}





//=============================================================================
size_t WritePipe( int nPipe, const void *pData, size_t nDataSize )
	throw ( CStdError )
//=============================================================================
{
	UnblockFile( nPipe );
	size_t nCount = WriteFile( nPipe, pData, nDataSize, &DoWritePipe );
	BlockFile( nPipe );

	return ( nCount );
}



//=============================================================================
size_t ReadPipe( int nPipe, void *pData, size_t nDataSize )
	throw ( CStdError )
//=============================================================================
{
	UnblockFile( nPipe );
	size_t nCount = ReadFile( nPipe, pData, nDataSize, &DoReadPipe );
	BlockFile( nPipe );

	return ( nCount );
}

} // namespace Unix


//#############################################################################
//#############################################################################
//#############################################################################
//
// CUnxFileBasics
//
//#############################################################################
//#############################################################################
//#############################################################################

template < typename FileRepresentation >
	//=============================================================================
	CFileInfo QueryFileStatus( int ( *QueryStatus )( FileRepresentation, struct stat * ),
		FileRepresentation fileRepresentation )
			throw ( CFileSystemError )
	//=============================================================================
	{
		struct stat FileStatus;
		CFileInfo FileInfo;

		if ( QueryStatus( fileRepresentation, &FileStatus ) == 0 ) {
			FileInfo.Size = FileStatus.st_size;
			FileInfo.ModificationTime = FileStatus.st_mtime;
		} else {
			throw ( CFileSystemError::LastError() );
		}
		return ( FileInfo );
	}



//=============================================================================
CFileInfo CUnxFileSystemBasics::DoFileInfo( const string_t &FileName ) const
	throw ( CFileSystemError )
//=============================================================================
{
	return ( QueryFileStatus< const char * >( &stat, FileName.c_str() ));
}



//=============================================================================
CFileInfo CUnxFileSystemBasics::DoFileInfo( int nFile ) const
	throw ( CFileSystemError )
//=============================================================================
{
	return ( QueryFileStatus< int >( &fstat, nFile ));
}



/*
//=============================================================================
CFileInfo CUnxFileSystemBasics::DoFileInfo( const string_t &FileName ) const
	throw ( CFileSystemError )
//=============================================================================
{
	struct stat FileStat;

	if ( stat( FileName.c_str(), &FileStat ) == -1 )
		throw ( CFileSystemError::LastError() );

	CFileInfo FileInfo;
	FileInfo.Size = FileStat.st_size;
	FileInfo.ModificationTime = FileStat.st_mtime;

	return ( FileInfo );
}
*/

} // namespace AidKit
