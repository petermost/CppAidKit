#include "../AidKit_Time.hpp"
#include "../AidKit_Misc.hpp"

#include <time.h>
#include <sys/time.h>

namespace AidKit {

namespace Unix {

//=============================================================================
timeval GetTimeOfDay( void )
	throw ( CStdError )
//=============================================================================
{
	timeval TimeOfDay = struct timeval();

	CheckErrNoApi( gettimeofday( &TimeOfDay, NULL ));

	return ( TimeOfDay );
}

//=============================================================================
string_t TimeStamp( const timeval &CurrentTime )
//=============================================================================
{
	struct tm DateTime;

	// Convert the current time to the tm structure:

	localtime_r( &CurrentTime.tv_sec, &DateTime );

	// Prepare the format with already included microseconds:

	char_t StampFormat[ 40 ];
	sn_print_f( StampFormat, countof( StampFormat ), TEXT( "%%Y%%m%%d%%H%%M%%S%06lu" ), CurrentTime.tv_usec );

	// Generate the actual stamp:

	char_t Stamp[ 80 ];
	size_t StampLength = str_f_time( Stamp, countof( Stamp ), StampFormat, &DateTime );

	return ( string_t( Stamp, StampLength ));
}




//#############################################################################
//#############################################################################
//#############################################################################
//
// CProfiler
//
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CProfiler::CProfiler( void )
//=============================================================================
{
	getitimer( ITIMER_PROF, &my_TimerValue );
}


//=============================================================================
CProfiler::~CProfiler( void )
//=============================================================================
{
	Disable();
}


//=============================================================================
void CProfiler::Enable( void )
//=============================================================================
{
	// Enable profiling via gprof for threads: (http://sam.zoy.org/writings/programming/gprof.html)

	setitimer( ITIMER_PROF, &my_TimerValue, NULL );
}


//=============================================================================
void CProfiler::Disable( void )
//=============================================================================
{
	itimerval NullValue = struct itimerval();

	setitimer( ITIMER_PROF, &NullValue, NULL );
}



//#############################################################################
//#############################################################################
//#############################################################################
//
// CPerformanceAnalyzer
//
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
CPerformanceAnalyzer::CPerformanceAnalyzer( void )
//=============================================================================
{
	my_StartTime = my_StopTime = timeval();
	my_Amount = 0;
}



//=============================================================================
void CPerformanceAnalyzer::Start( void )
//=============================================================================
{
	my_Amount = 0;
	gettimeofday( &my_StartTime, NULL );
}


//=============================================================================
void CPerformanceAnalyzer::Stop( void )
//=============================================================================
{
	gettimeofday( &my_StopTime, NULL );
}


//=============================================================================
unsigned long CPerformanceAnalyzer::Throughput( void ) const
//=============================================================================
{
	timeval Duration = my_StopTime - my_StartTime;
	if ( Duration.tv_sec == 0 )
		return ( 0 );
	else
		return (( my_Amount / Duration.tv_sec ) * 8 / 1024 / 1024 );
}


//#############################################################################
//#############################################################################
//#############################################################################
//
// Convert functions from milliseconds to timeval, timespec:
//
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
timespec *ConvertMilliseconds( milliseconds_t Milliseconds, timespec *pTimeSpec )
	throw ( CStdError )
//=============================================================================
{
	timeval TimeVal;
	CheckErrNoApi( gettimeofday( &TimeVal, NULL ));
	TIMEVAL_TO_TIMESPEC( const_cast< const timeval * >( &TimeVal ), pTimeSpec );

	pTimeSpec->tv_sec  += Milliseconds / 1000;
	pTimeSpec->tv_nsec += ( Milliseconds % 1000 ) * 1000000;

	return ( pTimeSpec );
}



//=============================================================================
timeval operator + ( const timeval &Time1, const timeval &Time2 )
//=============================================================================
{
	timeval Result;

	timeradd( &Time1, &Time2, &Result );
	return ( Result );
}



//=============================================================================
timeval operator - ( const timeval &Time1, const timeval &Time2 )
//=============================================================================
{
	timeval Result;

	timersub( &Time1, &Time2, &Result );
	return ( Result );
}


} // namespace Unix

} // namespace AidKit
