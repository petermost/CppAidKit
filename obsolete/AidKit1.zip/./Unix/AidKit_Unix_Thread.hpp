#ifndef AIDKIT_UNIX_THREAD_HPP
#define AIDKIT_UNIX_THREAD_HPP

#include "../AidKit_Thread.hpp"
#include "../AidKit_StdError.hpp"
#include "../AidKit_Types.hpp"

// #define __USE_UNIX98
#include <pthread.h>
#include <sys/time.h>

// If this header is beeing includes then threads are beeing used. So make sure
// we don't call any thread unsafe functions:

// #define localtime localtime_r
// #define asctime asctime_r


namespace AidKit {

	namespace Unix {

		typedef TStdError< class CMutex > CMutexError;

		//---------------------------------------------------------------------
		class CMutex {
		//---------------------------------------------------------------------
			public:
				CMutex( void )
					throw ( CMutexError );

				~CMutex( void )
					throw();

				void Lock( void )
					throw ( CMutexError );

				bool TryLock( void )
					throw ( CMutexError );

				void Unlock( void )
					throw ( CMutexError );

			private:
				friend class CCondition;

				CMutex( const CMutex & );
				CMutex &operator = ( const CMutex & );

				pthread_mutex_t my_hMutex;
				pthread_mutexattr_t my_hAttributes;
		};


		typedef TStdError< class CCondition > CConditionError;

		//---------------------------------------------------------------------
		class CCondition {
		//---------------------------------------------------------------------
			public:
				CCondition( void )
					throw ( CConditionError );

				~CCondition( void )
					throw();

				void Signal( void )
					throw ( CConditionError );

				void Broadcast( void )
					throw ( CConditionError );

				void Wait( CMutex *pMutex )
					throw ( CConditionError );

				bool TimedWait( CMutex *pMutex, milliseconds_t Milliseconds )
					throw ( CConditionError );

			private:
				CCondition( const CCondition & );
				CCondition &operator = ( const CCondition & );

				pthread_cond_t my_hCondition;
		};

		typedef TStdError< class CRWLock > CRWLockError;

		//---------------------------------------------------------------------
		class CRWLock {
		//---------------------------------------------------------------------
			public:
				enum EType {
					ePreferReader,
					ePreferWriter,
					ePreferWriterNonRecursive
				};

				enum EShareType {
					eProcessShared,
					eProcessPrivate
				};

				CRWLock( EType eType = ePreferWriter, EShareType eShare = eProcessPrivate )
					throw ( CRWLockError );

				~CRWLock( void )
					throw();

				// Acquire read lock:

				void RdLock( void )
					throw ( CRWLockError );

				bool TryRdLock( void )
					throw ( CRWLockError );

				// Acquire write lock:

				void WrLock( void )
					throw ( CRWLockError );

				bool TryWrLock( void )
					throw ( CRWLockError );

				// Release the acquired lock:

				void Unlock( void )
					throw ( CRWLockError );

			private:
				pthread_rwlock_t my_hLock;
				pthread_rwlockattr_t my_hAttributes;
		};



		typedef TStdError< class CThread > CThreadError;

		//---------------------------------------------------------------------
		class CThread {
		//---------------------------------------------------------------------
			public:
				enum EType {
					eDetached, eJoinable
				};

				CThread( EType eType = eJoinable )
					throw ( CThreadError );

				~CThread( void )
					throw();

				void Create( void * ( *pFunction )( CThread *pThread, void *pParameter ), void *pParameter )
					throw ( CThreadError );

				void Kill( int Signal )
					throw ( CThreadError );

				void *Join( void )
					throw ( CThreadError );

				void Detach( void )
					throw ( CThreadError );

				void Yield( void )
					throw ( CThreadError );

				bool Equal( const pthread_t &hThread ) const
					throw ();

				pthread_t Self( void ) const
					throw ();

			private:
				CThread( const CThread & );
				CThread &operator = ( const CThread & );

				static void *Entry( void *pParameter );

				pthread_t my_hThread;
				pthread_attr_t my_hAttributes;

				void  * ( *my_pFunction )( CThread *pThread, void *pParameter );
				void *my_pFunctionParameter;
		};

	} // namespace Unix

	//---------------------------------------------------
	class CNativeThread : public CThreadBasics {
	//---------------------------------------------------
		public:
			CNativeThread( void );
			virtual ~CNativeThread( void );

			void Signal( int Signal )
				throw ( Unix::CThreadError );

		protected:
			virtual bool DoStart( void ( *pFunction )( void *pParameter ), void *pParameter );
			virtual bool DoWait( milliseconds_t Milliseconds );
			virtual bool DoInfiniteWait( void );

			virtual void DoYield( void );
			virtual bool DoSleep( milliseconds_t Milliseconds );
			virtual void DoInfiniteSleep( void );
			virtual void DoWakeup( void );

			virtual bool IsSelf( void ) const;

		private:
			CNativeThread( const CNativeThread & );
			CNativeThread &operator = ( const CNativeThread & );

			static void *Entry( Unix::CThread *pThread, void *pParameter );

			Unix::CThread my_Kernel;

			Unix::CMutex my_StartMutex;
			Unix::CCondition my_StartCondition;
			bool my_IsStarted;

			Unix::CMutex my_StopMutex;
			Unix::CCondition my_StopCondition;
			bool my_IsStopped;

			Unix::CMutex my_SleepMutex;
			Unix::CCondition my_SleepCondition;
	};


} // namespace AidKit

#endif
