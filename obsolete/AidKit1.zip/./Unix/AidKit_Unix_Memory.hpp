#ifndef AIDKIT_UNIX_MEMORY_HPP
#define AIDKIT_UNIX_MEMORY_HPP

#include "../AidKit.hpp"

#if defined( AIDKIT_LINUX )
	#include <alloca.h>
#elif defined( AIDKIT_BSD )
	#include <stdlib.h>
#else
	#error "Don't know which header to include for alloca()!"
#endif


namespace AidKit {

}

#endif
