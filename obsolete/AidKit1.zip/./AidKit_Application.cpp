#include "AidKit_Application.hpp"
#include "AidKit_IniFile.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_FilePath.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CApplication
//###
//#############################################################################
//#############################################################################
//#############################################################################

CApplication *CApplication::our_pInstance = NULL;

//=============================================================================
CApplication *CApplication::Instance( void )
//=============================================================================
{
	AIDKIT_ASSERT( our_pInstance != NULL );

	return ( our_pInstance );
}



//=============================================================================
CApplication::CApplication( const char_t Name[] )
	: CNativeApplication( Name )
//=============================================================================
{
	AIDKIT_ASSERT( our_pInstance == NULL ); // Another instance does already exist!
	our_pInstance = this;
}



//=============================================================================
CApplication::~CApplication( void )
//=============================================================================
{
	AIDKIT_ASSERT( our_pInstance != NULL ); // Huh?
	our_pInstance = NULL;
}



//=============================================================================
bool CApplication::main( int argc, char_t *argv[] )
//=============================================================================
{
	if ( !OnStartup() )
		return ( false );

	return ( true );
}



//=============================================================================
int CApplication::exit( int ExitCode )
//=============================================================================
{
	if ( !OnShutdown() )
		return ( EXIT_FAILURE );

	return ( ExitCode );
}



//=============================================================================
bool CApplication::OnStartup( void )
//=============================================================================
{
	if ( !LoadSettings() )
		return ( false );

	return ( CNativeApplication::OnStartup() );
}



//=============================================================================
bool CApplication::OnShutdown( void )
//=============================================================================
{
	if ( !SaveSettings() )
		return ( false );

	return ( CNativeApplication::OnShutdown() );
}



//=============================================================================
bool CApplication::LoadSettings( void )
//=============================================================================
{
	string_t Dir( Directory() );

	if ( IsDebugging() ) {
		string_t DebuggerIniFileName = Dir + CDebugger::kIniFileName;
		my_DebuggerPreferences.Open( DebuggerIniFileName.c_str() );
		CDebugger::LoadDebuggerSettings( DebuggerPreferences() );
	}
	string_t UserIniFileName = Dir + my_User.Name() + TEXT( ".ini" );
	my_UserPreferences.Open( UserIniFileName.c_str() );

	return ( true );
}



//=============================================================================
bool CApplication::SaveSettings( void )
//=============================================================================
{	
	if ( IsDebugging() ) {
		CDebugger::SaveDebuggerSettings( DebuggerPreferences() );
		my_DebuggerPreferences.Close();
	}
	my_UserPreferences.Close();

	return ( true );
}



//=============================================================================
const char_t *CApplication::Name( void ) const
//=============================================================================
{
	if ( my_Name.empty() ) {
		CFilePath ApplicationPath( Path() );
		my_Name = ApplicationPath.Name();
	}
	return ( my_Name.c_str() );
}



//=============================================================================
const char_t *CApplication::Directory( void ) const
//=============================================================================
{
	if ( my_Directory.empty() ) {
		CFilePath ApplicationPath( Path() );
		my_Directory = ApplicationPath.Directory();
	}
	return ( my_Directory.c_str() );
}



//=============================================================================
CPreferences *CApplication::UserPreferences( void )
//=============================================================================
{
	return ( &my_UserPreferences );
}


//=============================================================================
CPreferences *CApplication::DebuggerPreferences( void )
//=============================================================================
{
	return ( &my_DebuggerPreferences );
}


} // namespace AidKit
