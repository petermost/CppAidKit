#include "AidKit_MFCHelper.hpp"
#include "AidKit_WinError.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Debug.hpp"

#include <afxwin.h>
#include <afxcmn.h>
#include "AidKit_Warnings.hpp"



template < typename CListContainer, typename CArray, typename CGetter >
	//=============================================================================
	void GetListContainerEntries( const CListContainer &ListContainer, CArray *pValues, CGetter Get )
	//=============================================================================
	{
		int i, Count;
		
		if (( Count = ListContainer.GetCount()) >= 0 ) {
			try {
				// Reserve enough space in the array:

				pValues->SetSize( Count );

				// Get the entrys and store them in the array:

				for ( i = 0; i < Count; ++i )
					Get( ListContainer, i, &pValues->ElementAt( i ));

			} catch ( CException *e ) {
				e->Delete();
			}
		}
	}




template < typename CListContainer, typename CArray, typename CSetter >
	//=============================================================================
	void SetListContainerEntries( CListContainer *pListContainer, const CArray &Values, CSetter Set )
	//=============================================================================
	{
		int i, Count;

		if (( Count = Values.GetSize()) > 0 ) {
			try {
				pListContainer->ResetContent();

				// Copy the values from the array to the control:

				for ( i = 0; i < Count; ++i )
					Set( pListContainer, i, Values.GetAt( i ));

			} catch ( CException *e ) {
				e->Delete();
			}
		}
	}



namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### DDX - CListBox
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
static inline void GetListBoxString( const CListBox &ListBox, int i, CString *pString )
//=============================================================================
{
	ListBox.GetText( i, *pString );
}



//=============================================================================
static inline void SetListBoxString( CListBox *pListBox, int /* i */, const CString &String )
//=============================================================================
{
	if ( pListBox->AddString( String ) == LB_ERRSPACE )
		AfxThrowMemoryException();
}



//=============================================================================
void DDX_Text_Read( CDataExchange *pDX, const CListBox &ListBox, CStringArray *pStrings )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		GetListContainerEntries( ListBox, pStrings, GetListBoxString );
}



//=============================================================================
void DDX_Text_Write( CDataExchange *pDX, CListBox *pListBox, const CStringArray &Strings )
//=============================================================================
{
	if ( !pDX->m_bSaveAndValidate )
		SetListContainerEntries( pListBox, Strings, SetListBoxString );			
}


//=============================================================================
void DDX_Text( CDataExchange *pDX, CListBox &rListBox, CStringArray &rStrings )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		DDX_Text_Read( pDX, rListBox, &rStrings );
	else
		DDX_Text_Write( pDX, &rListBox, rStrings );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### DDX - CCheckListBox
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
static inline void GetListBoxCheck( const CCheckListBox &ListBox, int i, int *pCheck )
//=============================================================================
{
	*pCheck = const_cast< CCheckListBox & >( ListBox ).GetCheck( i );
}



//=============================================================================
static inline void SetListBoxCheck( CCheckListBox *pListBox, int i, int Check )
//=============================================================================
{
	pListBox->SetCheck( i, Check );
}



//=============================================================================
static inline void GetListBoxStringCheck( const CCheckListBox &ListBox, int i, CStringInteger *pStringInteger )
//=============================================================================
{
	GetListBoxString( ListBox, i, &pStringInteger->String );
	GetListBoxCheck(  ListBox, i, &pStringInteger->Integer );
}



//=============================================================================
static inline void SetListBoxStringCheck( CCheckListBox *pListBox, int i, const CStringInteger &StringInteger )
//=============================================================================
{
	SetListBoxString( pListBox, i, StringInteger.String  );
	SetListBoxCheck(  pListBox, i, StringInteger.Integer );
}



//=============================================================================
void DDX_Text_Read( CDataExchange *pDX, const CCheckListBox &ListBox, CStringIntegerArray *pStringChecks )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		GetListContainerEntries( ListBox, pStringChecks, GetListBoxStringCheck );
}




//=============================================================================
void DDX_Text_Write( CDataExchange *pDX, CCheckListBox *pListBox, const CStringIntegerArray &StringChecks )
//=============================================================================
{
	if ( !pDX->m_bSaveAndValidate )
		SetListContainerEntries( pListBox, StringChecks, SetListBoxStringCheck );
}



//=============================================================================
void DDX_Text( CDataExchange *pDX, CCheckListBox &rListBox, CStringIntegerArray &rStringChecks )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		DDX_Text_Read( pDX, rListBox, &rStringChecks );
	else
		DDX_Text_Write( pDX, &rListBox, rStringChecks );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### DDX - CComboBox
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
static void SetComboBoxStringPointer( CComboBox *pComboBox, int i,
	const CStringPointer &StringPointer )
//=============================================================================
{
	if ( pComboBox->AddString( StringPointer.String ) == CB_ERRSPACE )
		AfxThrowMemoryException();

	if ( pComboBox->SetItemDataPtr( i, StringPointer.Pointer ) == CB_ERR )
		AfxThrowResourceException();
}



//=============================================================================
static void SetComboBoxStringInteger( CComboBox *pComboBox, int i,
	const CStringInteger &StringInteger )
//=============================================================================
{
	if ( pComboBox->AddString( StringInteger.String ) == CB_ERRSPACE )
		AfxThrowMemoryException();

	COMPILER_ASSERT( sizeof( StringInteger.Integer ) <= sizeof( DWORD ));
		// Make sure the integer does fit into a DWORD.

	AIDKIT_ASSERT( StringInteger.Integer >= 0 );
		// Is neccessary so we can detect errors if we retrieve
		// an integer from the combo box!

	if ( pComboBox->SetItemData( i, StringInteger.Integer ) == CB_ERR )
		AfxThrowResourceException();
}



//=============================================================================
static void GetComboBoxString( const CComboBox &ComboBox, int i, CString *pString )
//=============================================================================
{
	pString->Empty();
	ComboBox.GetLBText( i, *pString );
}
	


//=============================================================================
static void GetComboBoxStringPointer( const CComboBox &ComboBox, int i,
	CStringPointer *pStringPointer )
//=============================================================================
{
	const void *CB_ERRPOINTER = reinterpret_cast< void * >( -1 );

	register void *pPointer;

	GetComboBoxString( ComboBox, i, &pStringPointer->String );

	if (( pPointer = ComboBox.GetItemDataPtr( i )) != CB_ERRPOINTER )
		pStringPointer->Pointer = pPointer;
	else
		pStringPointer->Pointer = NULL;
}



//=============================================================================
static void GetComboBoxStringInteger( const CComboBox &ComboBox, int i,
	CStringInteger *pStringInteger )
//=============================================================================
{
	register DWORD Integer;

	GetComboBoxString( ComboBox, i, &pStringInteger->String );

	if (( Integer = ComboBox.GetItemData( i )) != CB_ERR )
		pStringInteger->Integer = Integer;
	else
		pStringInteger->Integer = 0;
}



//=============================================================================
void DDX_Text_Read( CDataExchange *pDX, const CComboBox &ComboBox, CStringIntegerArray *pStringIntegers )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		GetListContainerEntries( ComboBox, pStringIntegers, GetComboBoxStringInteger );
}



//=============================================================================
void DDX_Text_Write( CDataExchange *pDX, CComboBox *pComboBox, const CStringIntegerArray &StringIntegers )
//=============================================================================
{
	if ( !pDX->m_bSaveAndValidate )
		SetListContainerEntries( pComboBox, StringIntegers, SetComboBoxStringInteger );
}



//=============================================================================
void DDX_Text( CDataExchange *pDX, CComboBox &rComboBox, CStringIntegerArray &rStringIntegers )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		DDX_Text_Read( pDX, rComboBox, &rStringIntegers );
	else
		DDX_Text_Write( pDX, &rComboBox, rStringIntegers );
}	


//=============================================================================
void DDX_Text_Read( CDataExchange *pDX, const CComboBox &ComboBox, CStringPointerArray *pStringPointers )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		GetListContainerEntries( ComboBox, pStringPointers, GetComboBoxStringPointer );
}


//=============================================================================
void DDX_Text_Write( CDataExchange *pDX, CComboBox *pComboBox, const CStringPointerArray &StringPointers )
//=============================================================================
{
	if ( !pDX->m_bSaveAndValidate )
		SetListContainerEntries( pComboBox, StringPointers, SetComboBoxStringPointer );
}



//=============================================================================
void DDX_Text( CDataExchange *pDX, CComboBox &rComboBox, CStringPointerArray &rStringPointers )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		DDX_Text_Read( pDX, rComboBox, &rStringPointers );
	else
		DDX_Text_Write( pDX, &rComboBox, rStringPointers );
}




//#############################################################################
//#############################################################################
//#############################################################################
//###
//### DDX - CIPAddressCtl
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
void DDX_Text_Read( CDataExchange *pDX, const CIPAddressCtrl &AddressCtl, CString *pValue )
//=============================================================================
{
	BYTE Field0 = 0, Field1 = 0, Field2 = 0, Field3 = 0;

	if ( pDX->m_bSaveAndValidate ) {
		const_cast< CIPAddressCtrl & >( AddressCtl ).GetAddress( Field0, Field1, Field2, Field3 );
		pValue->Format( TEXT( "%d.%d.%d.%d" ), Field0, Field1, Field2, Field3 );
	}
}



//=============================================================================
void DDX_Text_Write( CDataExchange *pDX, CIPAddressCtrl *pAddressCtl, const CString &Value )
//=============================================================================
{
	int Field0 = 0, Field1 = 0, Field2 = 0, Field3 = 0;
	
	if ( !pDX->m_bSaveAndValidate ) {
		scan_f( Value, TEXT( "%d.%d.%d.%d" ), &Field0, &Field1, &Field2, &Field3 );
		#pragma warning( disable : 4244 ) // conversion from 'int' to 'unsigned char', possible loss of data
		pAddressCtl->SetAddress( Field0, Field1, Field2, Field3 );
	}
}


//=============================================================================
void DDX_Text( CDataExchange *pDX, CIPAddressCtrl &rAddressCtl, CString &rValue )
//=============================================================================
{

	if ( pDX->m_bSaveAndValidate )
		DDX_Text_Read( pDX, rAddressCtl, &rValue );
	else
		DDX_Text_Write( pDX, &rAddressCtl, rValue );
}
		



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### DDX - CListCtrl
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
void DDX_Text_Read( CDataExchange *pDX, const CListCtrl &ListCtl, CStringArray *pStrings )
//=============================================================================
{
	char_t Buffer[ 200 ];
	LVITEM Item;

	if ( pDX->m_bSaveAndValidate ) {
		Item.mask = LVIF_TEXT;
		Item.iSubItem = 0;
		Item.pszText = Buffer;
		Item.cchTextMax = countof( Buffer );

		pStrings->RemoveAll();
		int nItemCount = ListCtl.GetItemCount();
		for ( int nItem = 0; nItem < nItemCount; ++nItem ) {
			Item.iItem = nItem;
			if ( ListCtl.GetItem( &Item ))
				pStrings->Add( Item.pszText );
		}
	}
}



//=============================================================================
void DDX_Text_Write( CDataExchange *pDX, CListCtrl *pListCtl, const CStringArray &Strings )
//=============================================================================
{
	if ( !pDX->m_bSaveAndValidate ) {
		pListCtl->DeleteAllItems();
		for ( int nItem = 0; nItem < Strings.GetSize(); ++nItem )
			pListCtl->InsertItem( pListCtl->GetItemCount(), Strings.GetAt( nItem ));
	}
}



//=============================================================================
void DDX_Text( CDataExchange *pDX, CListCtrl &rListCtl, CStringArray &rStrings )
//=============================================================================
{
	if ( pDX->m_bSaveAndValidate )
		DDX_Text_Read( pDX, rListCtl, &rStrings );
	else
		DDX_Text_Write( pDX, &rListCtl, rStrings );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CEditHelper
//###
//#############################################################################
//#############################################################################
//#############################################################################


static const char_t kNewLineChars[] = TEXT( "\r\n" );

/*===========================================================================*/
CEditHelper::CEditHelper( CEdit *EditCtrl )
/*===========================================================================*/
{
	my_EditCtrl = EditCtrl;
}



/*===========================================================================*/
void CEditHelper::AppendText( const char_t Text[] )
/*===========================================================================*/
{
	my_EditCtrl->SetSel( -1, -1 );
	my_EditCtrl->ReplaceSel( Text );
	my_EditCtrl->SendMessage( EM_SCROLLCARET );
}



/*===========================================================================*/
void CEditHelper::AppendNewLine( void )
/*===========================================================================*/
{
	AppendText( kNewLineChars );
}



/*===========================================================================*/
void CEditHelper::InsertText( const char_t Text[] )
/*===========================================================================*/
{
	char_t c;

	while (( c = *Text++ ) != '\0' )
		my_EditCtrl->PostMessage( WM_CHAR, c );
}


/*===========================================================================*/
void CEditHelper::InsertNewLine( void )
/*===========================================================================*/
{
	InsertText( kNewLineChars );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CRichEditHelper
//###
//#############################################################################
//#############################################################################
//#############################################################################

const int CRichEditHelper::kDefaultFormat = SF_RTF | SFF_PLAINRTF;

//=============================================================================
CRichEditHelper::CRichEditHelper( CRichEditCtrl *pRichEdit )
//=============================================================================
{
	my_pRichEdit = pRichEdit;
}


//=============================================================================
static DWORD CALLBACK StreamInCallback( DWORD Cookie, LPBYTE pBuffer, LONG nLength, LONG *pCount )
//=============================================================================
{
	CString *pContent = reinterpret_cast< CString * >( Cookie );

	// Determine how much bytes to copy and copy them:

	nLength = min( nLength, pContent->GetLength() );
	memcpy( pBuffer, static_cast< const void * >( *pContent ), nLength * sizeof( char_t ));

	// Indicate how much byte were copied and remove them from the original:

	*pCount = nLength;
	pContent->Delete( 0, nLength );

	return ( 0 );
}

//=============================================================================
long CRichEditHelper::StreamIn( CString Content, int Format )
	throw ( CRichEditHelperError )
//=============================================================================
{
	COMPILER_ASSERT( sizeof( DWORD ) >= sizeof( CString * ));

	EDITSTREAM StreamData = { 0 };
	StreamData.dwCookie    = reinterpret_cast< DWORD >( &Content );
	StreamData.dwError     = NO_ERROR;
	StreamData.pfnCallback = &StreamInCallback;

	#ifdef AIDKIT_UNICODE
		Format |= SF_UNICODE;
	#else
		Format &= ~SF_UNICODE;
	#endif

	long CharacterCount = my_pRichEdit->StreamIn( Format, StreamData );
	CheckWinError( StreamData.dwError );

	return ( CharacterCount );
}




//=============================================================================
static DWORD CALLBACK StreamOutCallback( DWORD Cookie, LPBYTE pBuffer, LONG nLength, LONG *pCount )
//=============================================================================
{
	CString *pContent = reinterpret_cast< CString * >( Cookie );
	*pContent = CString( reinterpret_cast< const char_t * >( pBuffer ), nLength / sizeof( char_t ));
	*pCount = pContent->GetLength();

	return ( 0 );
}


//=============================================================================
long CRichEditHelper::StreamOut( CString *pContent, int Format )
	throw ( CRichEditHelperError )
//=============================================================================
{
	COMPILER_ASSERT( sizeof( DWORD ) >= sizeof( CString * ));

	EDITSTREAM StreamData = { 0 };
	StreamData.dwCookie    = reinterpret_cast< DWORD >( pContent );
	StreamData.dwError     = NO_ERROR;
	StreamData.pfnCallback = &StreamOutCallback;

	// According to the documentation, this flag is not used for StreamOut. But
	// just to be on the safe side:

	#ifdef AIDKIT_UNICODE
		Format |= SF_UNICODE;
	#else
		Format &= ~SF_UNICODE;
	#endif

	long CharacterCount = my_pRichEdit->StreamOut( Format, StreamData );
	CheckWinError( StreamData.dwError );

	return ( CharacterCount );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTreeBuilder
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CTreeBuilder::CTreeBuilder( CTreeCtrl *pTree )
//=============================================================================
{
	my_pTree        = pTree;
	my_hParent      = TVI_ROOT;
}



//=============================================================================
HTREEITEM CTreeBuilder::CreateBranch( const char_t Inscription[] )
//=============================================================================
{
	HTREEITEM hNewParent = my_pTree->InsertItem( Inscription, my_hParent );
	my_Parents.push( my_hParent );
	my_hParent = hNewParent;
	return ( hNewParent );
}



//=============================================================================
HTREEITEM CTreeBuilder::CreateLeaf( const char_t Inscription[] )
//=============================================================================
{
	return ( my_pTree->InsertItem( Inscription, my_hParent ));
}



//=============================================================================
void CTreeBuilder::CloseBranch( void )
//=============================================================================
{
	my_hParent = my_Parents.top();
	my_Parents.pop();
}


} // namespace AidKit

/*
void DDX_Text( CDataExchange *pDX, CListCtrl &List, CStringArray &Strings )
{
	// It makes no sense to get data from the list control:

	if ( pDX->m_bSaveAndValidate )
		Strings.RemoveAll();
	else {
		// Prevent flickering:

		List.LockWindowUpdate();
		for ( int i = 0; i < Strings.GetSize(); ++i )
			List.InsertItem( List.GetItemCount(), Strings.GetAt( i ));
		List.UnlockWindowUpdate();
		Strings.RemoveAll();
	}
}


void DDX_Text( CDataExchange *pDX, CCheckListBox &ListBox, CStringArray &Strings,
	CIntegerArray &Checks )
{
	int Check;
	CString Text;
	int i, Count;
	
	if ( pDX->m_bSaveAndValidate ) {
		if (( Count = ListBox.GetCount()) != LB_ERR ) {
			try {
				// Reserve enough space in the arrays:

				Strings.SetSize( Count );
				Checks.SetSize( Count );

				// Get the entrys and store them in the arrays:

				for ( i = 0; i < Count; ++i ) {
					ListBox.GetText( i, Text );
					Check = ListBox.GetCheck( i );

					Strings.SetAt( i, Text );
					Checks.SetAt( i, Check );
				}
			} catch ( CMemoryException *e ) {
				e->Delete();
			}
		}
	} else {
		ListBox.ResetContent();
		AIDKIT_ASSERT( Strings.GetSize() == Checks.GetSize() );
		Count = min( Strings.GetSize(), Checks.GetSize() );

		// Copy the values from the array to the control:

		for ( i = 0; i < Count; ++i ) {
			Text  = Strings.GetAt( i );
			Check = Checks.GetAt( i );

			ListBox.AddString( Text );
			ListBox.SetCheck( i, Check );
		}
	}
}


*/
