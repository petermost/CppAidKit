#ifndef AIDKIT_TEXT_HPP
#define AIDKIT_TEXT_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_MSC )
	#pragma warning( disable : 4786 )
#endif

#include "AidKit_Unicode.hpp"
#include <map>
#include <string>

/* Detect the current language:

LANGID DefaultLanguageID = GetUserDefaultLangID();
WORD PrimaryLanguageID = PRIMARYLANGID( DefaultLanguageID );
if ( PrimaryLanguageID == LANG_ARABIC )
	CText::SelectLanguage( CText::eArabic );
*/

namespace AidKit {

	class CTextCollection;

	//-----------------------------------------------------------------------------
	class CText {
	//-----------------------------------------------------------------------------
		public:
			enum ELanguage {
				eEnglish,
				eGerman,
				eFrench,
				eSpanish,
				eArabic,
				kMaxLanguages
			};
			static ELanguage SelectLanguage( ELanguage NewLanguage );
			static ELanguage CurrentLanguage( void );

			// Are safe:
			// CText( const CText &OtherText );
			// CText &operator = ( const CText &OtherText );

			CText( const char_t *pText, ELanguage Language, ... );
			CText( unsigned Identifier, const char_t *pText, ELanguage Language, ... );

			CText( unsigned Identifier, const char_t CollectionName[] );

			virtual ~CText( void );

			const char_t *c_str( void ) const;
			const char_t *c_str_at( ELanguage Language ) const;
			
			operator const char_t *( void ) const
				{ return ( c_str() ); }

		private:
			friend class CTextCollection;

			static ELanguage our_CurrentLanguage;

			unsigned my_Identifier;
			const char_t *my_pExternalTexts[ kMaxLanguages ];
	};


	//-----------------------------------------------------------------------------
	class CTextCollection {
	//-----------------------------------------------------------------------------
		public:
			CTextCollection( const char_t Name[], const CText Text[], size_t TextCount );
			~CTextCollection( void );

			const CText *FindText( unsigned Identifier ) const;
			static const CTextCollection *FindCollection( const char_t Name[] );

		private:
			typedef std::map< string_t, const CTextCollection * > CCollectionMap;
			static CCollectionMap *our_pCollections;

			CTextCollection( const CTextCollection & );
			CTextCollection &operator = ( const CTextCollection & );

			const char_t *my_pName;
			const CText *my_pText;
			size_t my_nTextCount;
	};

}

#endif
