#ifndef AIDKIT_SYSTEM_HPP
#define AIDKIT_SYSTEM_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <limits.h>

namespace AidKit {

#if defined( AIDKIT_WINDOWS )

	const char_t DIRECTORY_SEPARATOR = TEXT( '\\' );
	const size_t MAX_PATH_NAME_LENGTH = _MAX_PATH;

#elif defined( AIDKIT_UNIX )

	const char_t DIRECTORY_SEPARATOR = TEXT( '/' );
	const size_t MAX_PATH_NAME_LENGTH = PATH_MAX;

#endif


}

#endif
