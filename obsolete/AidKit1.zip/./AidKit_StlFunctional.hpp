#ifndef AIDKIT_STL_FUNCTIONAL_HPP
#define AIDKIT_STL_FUNCTIONAL_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <string.h>
#include <functional>
#include <iterator>
#include <ext/hash_map>

// Specialization of the less-template so we can use character pointer in
// the STL-container like map, set etc.

namespace std {

	template < >
		struct less< AidKit::char_t >
		{
			bool operator ()( const AidKit::char_t *s1, const AidKit::char_t *s2 ) const
			{
				return ( str_cmp( s1, s2 ) < 0 );
			}
		};

	template < >
		inline void advance( void *&p, ptrdiff_t n )
		{
			// static_cast< char * >( p ) += n;
			p = static_cast< char * >( p ) + n;
		}

	template < >
		inline void advance( const void *&p, ptrdiff_t n )
		{
			// static_cast< const char * >( p ) += n;
			p = static_cast< const char * >( p ) + n;
		}

}

namespace __gnu_cxx {

	template < >
		struct hash< std::string > {
			size_t operator()( const std::string &s) const
				{ return ( my_Hash( s.c_str() )); }

			private:
				hash< const char * > my_Hash;
		};

	template < >
		struct hash< const void * > {
			size_t operator()( const void *p ) const
				{ return ( my_Hash( reinterpret_cast< unsigned long >( p ))); }

			private:
				hash< unsigned long > my_Hash;
		};
}

namespace AidKit {

	// Can be used as stored function for map, set etc.

	struct less_ignore_case 
	{
		bool operator()( const char_t *string1, const char_t *string2 ) const
		{
			return ( str_i_cmp( string1, string2 ) < 0 );
		}
	};

}

#endif
