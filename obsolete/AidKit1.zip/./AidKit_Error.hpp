#ifndef AIDKIT_EXCEPTION_HPP
#define AIDKIT_EXCEPTION_HPP

#include "AidKit.hpp"
#include "AidKit_Output.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Warnings.hpp"

#ifdef AIDKIT_MSC
	#pragma warning( disable : 4786 ) // identifier was truncated to '255' characters in the browser information
#endif

#include <exception>
#include <typeinfo>
#include <string>
#include <vector>


#ifdef AIDKIT_MSC_5
	#pragma warning( disable: 4290 ) // C++ Exception Specification ignored
#endif

namespace AidKit {

	template < typename CCode, typename CDescription = string_t >
		//-----------------------------------------------------------------------------
		class TError : public std::exception {
		//-----------------------------------------------------------------------------
			public:
				TError( CCode Code = CCode(), const CDescription &Description = CDescription() ) throw()
					{ my_Code = Code; my_Description = Description; }

				TError( const TError &OtherError ) throw()
					: exception( OtherError )
					{ my_Code = OtherError.my_Code; my_Description = OtherError.my_Description; }

				~TError( void ) throw()
					{ }

				const CCode &Code( void ) const
					{ return ( my_Code ); }

				const CDescription &Description( void ) const
					{ return ( my_Description ); }

				virtual const char_t *what( void ) const
					throw()
						{ return ( my_Description.c_str() ); }

			private:
				CCode my_Code;
				CDescription my_Description;
		};
	
	//-----------------------------------------------------------------------------
	struct SErrorCall {
	//-----------------------------------------------------------------------------
		std::vector< string_t > Parameters;
	};


	//-----------------------------------------------------------------------------
	class CError : public std::exception, public COutput {
	//-----------------------------------------------------------------------------
		public:
			CError( void )
				throw();

			CError( const string_t &Description )
				throw();

			CError( const CError & )
				throw();

			CError &operator = ( const CError & )
				throw();

			~CError( void )
				throw();

			virtual const char *what( void ) const
				throw();

			virtual const string_t &Description( void ) const
				throw();

			void CallStack( std::vector< SErrorCall > *CallStack ) const;

		protected:
			virtual COutput &DoWrite( const char_t Value[], size_t ValueLength, const std::type_info &ValueType );
			virtual COutput &DoFlush( void );

		private:
			mutable std::string my_What; ///< Contains the _converted_ description.
			string_t my_Description; ///< Contains the error description.

			SErrorCall my_CurrentCall;
			std::vector< SErrorCall > my_CallStack;

	};

	// COutput &operator << ( COutput &rOutput, const std::type_info &TypeInfo );

	/* template < typename CClass >
		CError &operator << ( CError &rException, const CClass &Class )
		{
			return ( rException << typeid( Class ));
		}
	*/

}

#endif
