perl -pi -e 's/xxx/xxx/g' *.cpp
