#include "AidKit_StdIo.hpp"
#include "AidKit_Unicode.hpp"
#include <wchar.h>

namespace AidKit {

template < >
	FILE *f_open( const char *name, const char *mode )
		{ return ( fopen( name, mode )); }

#if defined( AIDKIT_WINDOWS )

	template < >
		FILE *f_open( const wchar_t *name, const wchar_t *mode )
			{ return ( _fwopen( name, mode )); }

#elif defined( AIDKIT_UNIX )

	template < >
		FILE *f_open( const wchar_t *name, const wchar_t *mode )
			{ return ( fopen( unitext( name ), unitext( mode ))); }

#endif

template FILE *f_open( const char *name, const char *mode );
template FILE *f_open( const wchar_t *name, const wchar_t *mode );

}
