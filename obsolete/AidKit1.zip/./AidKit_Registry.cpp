#include "AidKit_Registry.hpp"
#include "AidKit_WinError.hpp"
#include "AidKit_StackMemory.hpp"
#include "AidKit_Unicode.hpp"
#include <winerror.h>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CRegistry
//###
//#############################################################################
//#############################################################################
//#############################################################################

const char_t kStructureBegin[] = TEXT( "{ " );
const char_t kStructureEnd[]   = TEXT( " }" );

const int kErrorTypeMismatch = ERROR_INVALID_DATA;
const int kErrorInvalidDataLength = ERROR_OUTOFMEMORY;

const size_t kMaxValueLength = 256; // From MSDN Remarks.

//=============================================================================
CRegistry::CRegistry( void )
//=============================================================================
{
	my_hKey = 0;
}



//=============================================================================
CRegistry::~CRegistry( void )
//=============================================================================
{
	Close();
}



//=============================================================================
bool CRegistry::Open( HKEY hRootKey, const char_t SubKeyName[] )
//=============================================================================
{
	AIDKIT_ASSERT( hRootKey != 0 );
	AIDKIT_ASSERT( my_hKey == 0 );

	const REGSAM kAccess = KEY_CREATE_SUB_KEY | KEY_ENUMERATE_SUB_KEYS
		| KEY_EXECUTE | KEY_QUERY_VALUE | KEY_SET_VALUE;

	LONG Result = RegOpenKeyEx( hRootKey, SubKeyName, 0, kAccess, &my_hKey );

	if ( Result != ERROR_SUCCESS )
		SetLastError( Result );

	return ( Result == ERROR_SUCCESS );
}



//=============================================================================
bool CRegistry::Close( void )
//=============================================================================
{
	LONG Result;

	if ( my_hKey != 0 )
		Result = RegCloseKey( my_hKey );
	else
		Result = ERROR_SUCCESS;

	if ( Result == ERROR_SUCCESS )
		my_hKey = 0;
	else
		SetLastError( Result );

	return ( Result == ERROR_SUCCESS );
}



//=============================================================================
bool CRegistry::WriteData( const char_t DataName[], int DataType, const void *Data, size_t DataSize )
//=============================================================================
{
	AIDKIT_ASSERT( my_hKey != 0 );

	const DWORD kReserved = 0;
		
	LONG Result = RegSetValueEx( my_hKey, DataName, kReserved, DataType,
		reinterpret_cast< const BYTE * >( Data ), DataSize );

	if ( Result != ERROR_SUCCESS )
		SetLastError( Result );

	return ( Result == ERROR_SUCCESS );
}




//=============================================================================
bool CRegistry::ReadData( const char_t DataName[], int DataType, void *pData, size_t DataSize ) const
//=============================================================================
{
	AIDKIT_ASSERT( my_hKey != 0 );


	DWORD *kReserved = 0;

	DWORD dwDataSize = DataSize;
	DWORD dwDataType = DataType;
		
	LONG Result = RegQueryValueEx( my_hKey, DataName, kReserved, &dwDataType,
		reinterpret_cast< BYTE * >( pData ), &dwDataSize );

	AIDKIT_ASSERT( dwDataType == DataType );
	AIDKIT_ASSERT( dwDataSize <= DataSize );

	if ( Result != ERROR_SUCCESS )
		SetLastError( Result );

	return ( Result == ERROR_SUCCESS );
}


//=============================================================================
bool CRegistry::WriteInteger( const char_t ValueName[], int Integer )
//=============================================================================
{
	return ( WriteData( ValueName, REG_DWORD, &Integer, sizeof( Integer )));
}




//=============================================================================
bool CRegistry::ReadInteger( const char_t ValueName[], int *pInteger ) const
//=============================================================================
{
	size_t ValueSize;
	int ValueType;

	bool IsRead = false;
	
	if ( ReadValueInfo( ValueName, &ValueType, &ValueSize )) {
		if ( ValueType == REG_DWORD || ValueType == REG_DWORD_LITTLE_ENDIAN || ValueType == REG_DWORD_BIG_ENDIAN ) {
			if ( ValueSize <= sizeof( *pInteger ))
				IsRead = ReadData( ValueName, ValueType, pInteger, sizeof( *pInteger ));
		}
	}
	return ( IsRead );
}



//=============================================================================
bool CRegistry::WriteString( const char_t ValueName[], const string_t &String )
//=============================================================================
{
	return ( WriteData( ValueName, REG_SZ, String.c_str(), String.length() ));
}



//=============================================================================
bool CRegistry::ReadString( const char_t ValueName[], string_t *pString ) const
//=============================================================================
{
	typedef TStackMemory< kMaxValueLength > alloca;

	char_t *pStringBuffer;
	size_t ValueSize;
	int ValueType;

	bool IsRead = false;

	if ( ReadValueInfo( ValueName, &ValueType, &ValueSize )) {
		if ( ValueType == REG_SZ || ValueType == REG_MULTI_SZ || ValueType == REG_EXPAND_SZ ) {
			if ( ValueSize > 0 ) {
				pStringBuffer = alloca( ValueSize );
				if ( IsRead = ReadData( ValueName, ValueType, pStringBuffer, ValueSize ))
					*pString = pStringBuffer;
			}
		}
	}
	return ( IsRead );
}



//=============================================================================
bool CRegistry::WriteBinary( const char_t ValueName[], const void *Binary, size_t BinarySize )
//=============================================================================
{
	return ( WriteData( ValueName, REG_BINARY, Binary, BinarySize ));
}



//=============================================================================
bool CRegistry::ReadBinary( const char_t ValueName[], void *pBinary, size_t BinarySize ) const
//=============================================================================
{
	size_t ValueSize;
	int ValueType;

	bool IsRead = false;

	if ( ReadValueInfo( ValueName, &ValueType, &ValueSize )) {
		if ( ValueType == REG_BINARY ) {
			if ( ValueSize > 0 )
				IsRead = ReadData( ValueName, ValueType, pBinary, BinarySize );
		}
	}
	return ( IsRead );
}



//=============================================================================
bool CRegistry::ReadValueInfo( const char_t ValueName[], int *pValueType, size_t *pValueSize ) const
//=============================================================================
{
	AIDKIT_ASSERT( my_hKey != 0 );
	DWORD ValueType = REG_NONE;
	DWORD ValueSize = 0;

	LONG Result = RegQueryValueEx( my_hKey, ValueName, 0, &ValueType, NULL, &ValueSize );

	if ( Result == ERROR_SUCCESS ) {
		*pValueType = ValueType;
		*pValueSize = ValueSize;
	} else
		SetLastError( Result );

	return ( Result == ERROR_SUCCESS );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CXRegistry
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CXRegistry::CXRegistry( void )
	throw ( void )
//=============================================================================
{
}



//=============================================================================
CXRegistry::~CXRegistry( void )
	throw ( void )
//=============================================================================
{
}



//=============================================================================
void CXRegistry::Open( HKEY hRootKey, const char_t SubKeyName[] )
	throw ( CRegistryError )
//=============================================================================
{
	if ( my_Registry.Open( hRootKey, SubKeyName ))
		my_SubKeyName = SubKeyName;
	else {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::Open" << hRootKey << SubKeyName << endl;
		throw ( Error );
	}
}




//=============================================================================
void CXRegistry::Close( void )
	throw ( CRegistryError )
//=============================================================================
{
	if ( !my_Registry.Close() ) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegister::Close" << my_SubKeyName << endl;
		throw ( Error );
	}
}



//=============================================================================
void CXRegistry::WriteInteger( const char_t ValueName[], int Integer )
	throw ( CRegistryError )
//=============================================================================
{
	if ( !my_Registry.WriteInteger( ValueName, Integer )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::WriteInteger" << my_SubKeyName << ValueName << Integer << endl;
		throw ( Error );
	}
}



//=============================================================================
int CXRegistry::ReadInteger( const char_t ValueName[] ) const
	throw ( CRegistryError )
//=============================================================================
{
	int Integer = 0;

	if ( !my_Registry.ReadInteger( ValueName, &Integer )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::ReadInteger" << my_SubKeyName << ValueName << endl;
		throw ( Error );
	}
	return ( Integer );
}


//=============================================================================
void CXRegistry::WriteString( const char_t ValueName[], const string_t &String )
	throw ( CRegistryError )
//=============================================================================
{
	if ( !my_Registry.WriteString( ValueName, String )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::WriteString" << my_SubKeyName << ValueName << String << endl;
		throw ( Error );
	}
}



//=============================================================================
const string_t CXRegistry::ReadString( const char_t ValueName[] ) const
	throw ( CRegistryError )
//=============================================================================
{
	string_t String;

	if ( !my_Registry.ReadString( ValueName, &String )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::ReadString" << my_SubKeyName << ValueName << endl;
		throw ( Error );
	}
	return ( String );
}



//=============================================================================
void CXRegistry::WriteBinary( const char_t ValueName[], const void *Binary, size_t BinarySize )
	throw ( CRegistryError )
//=============================================================================
{
	if ( !my_Registry.WriteBinary( ValueName, Binary, BinarySize )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::WriteBinary" << my_SubKeyName << ValueName << Binary << BinarySize << endl;
		throw ( Error );
	}
}



//=============================================================================
void CXRegistry::ReadBinary( const char_t ValueName[], void *pBinary, size_t BinarySize )	const
	throw ( CRegistryError )
//=============================================================================
{
	if ( !my_Registry.ReadBinary( ValueName, pBinary, BinarySize )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::ReadBinary" << my_SubKeyName << ValueName << pBinary << BinarySize << endl;
		throw ( Error );
	}
}



//=============================================================================
void CXRegistry::ReadValueInfo( const char_t ValueName[], int *pValueType, size_t *pValueSize ) const
	throw ( CRegistryError )
//=============================================================================
{
	if ( !my_Registry.ReadValueInfo( ValueName, pValueType, pValueSize )) {
		CRegistryError Error( ::GetLastError() );
		Error << "CXRegistry::ReadValueInfo" << my_SubKeyName << ValueName << endl;
		throw ( Error );
	}
}



//=============================================================================
COutput &operator << ( COutput &rOutput, const CXRegistry &Registry )
//=============================================================================
{
	return ( rOutput << kStructureBegin << typeid( Registry.my_Registry ) << Registry.my_SubKeyName << kStructureEnd );
}

} // namespace AidKit
