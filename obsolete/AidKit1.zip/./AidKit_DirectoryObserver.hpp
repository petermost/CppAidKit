#ifndef AIDKIT_DIRECTORY_OBSERVER_HPP
#define AIDKIT_DIRECTORY_OBSERVER_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
#include "AidKit_AsyncEvent.hpp"
#include "AidKit_Thread.hpp"
#include "AidKit_Unicode.hpp"
#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CDirectoryObserver : protected CThread {
	//-----------------------------------------------------------------------------
		public:
			CDirectoryObserver( void );
			~CDirectoryObserver( void );

			BOOL Observe( const char_t DirectoryName[], TEventCall2< CDirectoryObserver *, const char_t * > *pHandler,
				unsigned NotFoundTimeout = 1000 );
			BOOL Unobserve( void );

		private:
			virtual void Do( void );

			TEventCall2< CDirectoryObserver *, const char_t * > *my_pHandler;
			TAsyncEvent2< CDirectoryObserver *, const char_t * > my_ChangedEvt;
			CString my_DirectoryName;
			unsigned my_NotFoundTimeout;
	};



}

#endif
