#ifndef AIDKIT_MISC_HPP
#define AIDKIT_MISC_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Misc.hpp"
	namespace AidKit {
		// using namespace Windows;
	}

#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Misc.hpp"
	namespace AidKit {
		// using namespace Unix;
	}

#endif

#include "AidKit_Unicode.hpp"
#include <string>
#include <stdarg.h>

namespace AidKit {

	const char_t *ProgramPath( void );

	unsigned count_bits( unsigned x );
	unsigned get_bits( unsigned x, unsigned p, unsigned n );


}


#define MAX( Value1, Value2 ) \
	((( Value1 ) > ( Value2 )) ? ( Value1 ) : ( Value2 ))

#define MIN( Value1, Value2 ) \
	((( Value1 ) < ( Value2 )) ? ( Value1 ) : ( Value2 ))


// By using '*array' we catch errors like countof( vector ), because the
// stl-containers don't define an 'operator *':

#define countof( array ) \
	( sizeof( array ) / sizeof( *( array )))

#define lengthof( StructName, FirstName, LastName ) \
	( offsetof( StructName, LastName ) - offsetof( StructName, FirstName ) + sizeof((( StructName *)0 )->LastName))

#define BIN8( b8, b7, b6, b5, b4, b3, b2, b1 ) \
	( b8 << 7 | b7 << 6 | b6 << 5 | b5 << 4 | b4 << 3 | b3 << 2 | b2 << 1 | b1 << 0 )

#endif
