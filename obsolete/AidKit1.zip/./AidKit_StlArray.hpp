#ifndef AIDKIT_STL_ARRAY_HPP
#define AIDKIT_STL_ARRAY_HPP

#include "AidKit.hpp"
#include <iterator>

namespace AidKit {

	// This template was inspired from the book: 'Generic Programming and the STL'
	// by Matthew H. Austern. In the book it is called block. A similar container is
	// in the book 'The C++ Programming Language' by Bjarne Stroustrup. There it is
	// called c_array.

	template < typename CType, size_t Size >
		class array {
			public:
				typedef CType value_type;
				
				typedef value_type       *pointer;
				typedef const value_type *const_pointer;
				typedef value_type       &reference;
				typedef const value_type &const_reference;

				typedef ptrdiff_t difference_type;
				typedef size_t    size_type;

				typedef pointer       iterator;
				typedef const_pointer const_iterator;

				typedef std::reverse_iterator< iterator, value_type >       reverse_iterator;
				typedef std::reverse_iterator< const_iterator, value_type > const_reverse_iterator;



				iterator begin()
					{ return ( my_Data ); }

				iterator end()
					{ return ( my_Data + Size ); }



				const_iterator begin() const
					{ return ( my_Data ); }

				const_iterator end() const
					{ return ( my_Data + Size ); }



				reverse_iterator rbegin()
					{ return ( reverse_iterator( end() )); }

				reverse_iterator rend()
					{ return ( reverse_iterator( begin() )); }



				const_reverse_iterator rbegin() const
					{ return ( const_reverse_iterator( end() )); }

				const_reverse_iterator rend() const
					{ return ( const_reverse_iterator( begin() )); }



				reference operator[] ( size_type Index )
					{ return ( my_Data[ Index ] ); }

				const_reference operator[] ( size_type Index ) const
					{ return ( my_Data[ Index ] ); }



				size_type size() const
					{ return ( Size ); }

				size_type max_size() const
					{ return ( Size ); }

				bool empty() const
					{ return ( Size == 0 ); }
			


				CType my_Data[ Size ];
		};

}

#endif
