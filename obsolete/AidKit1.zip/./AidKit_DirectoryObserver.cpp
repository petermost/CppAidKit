#include "AidKit_DirectoryObserver.hpp"
#include "AidKit_Misc.hpp"
#include <afxwin.h>
#include <afxmt.h>
#include "AidKit_Warnings.hpp"

namespace AidKit {

#define ASSERT_HANDLE( Handle ) AIDKIT_ASSERT(( Handle ) != UNINVALID_HANDLE_VALUE )

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectoryObserver
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CDirectoryObserver::CDirectoryObserver( void )
//=============================================================================
{
	my_pHandler = NULL;
	my_NotFoundTimeout = 0;
}



//=============================================================================
CDirectoryObserver::~CDirectoryObserver( void )
//=============================================================================
{
}



//=============================================================================
BOOL CDirectoryObserver::Observe( const char_t DirectoryName[], TEventCall2< CDirectoryObserver *, const char_t * > *pHandler,
	unsigned NotFoundTimeout )
//=============================================================================
{
	AIDKIT_ASSERT( my_pHandler == NULL );

	my_pHandler = pHandler;
	my_ChangedEvt.Subscribe( my_pHandler );
	my_DirectoryName   = DirectoryName;
	my_NotFoundTimeout = NotFoundTimeout;

	return ( Start() );
}



//=============================================================================
BOOL CDirectoryObserver::Unobserve( void )
//=============================================================================
{
	Stop();

	my_ChangedEvt.Unsubscribe( my_pHandler );
	my_pHandler = NULL;

	return ( TRUE );
}



//=============================================================================
void CDirectoryObserver::Do( void )
//=============================================================================
{
	AIDKIT_ASSERT( my_DirectoryName.GetLength() > 0 );

	const BOOL kWaitAll = TRUE;
	const BOOL kWatchSubTree = TRUE;
	const DWORD kNotifyFilter = FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME
		| FILE_NOTIFY_CHANGE_ATTRIBUTES | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE
		| FILE_NOTIFY_CHANGE_SECURITY;

	size_t HandleIdx;
	DWORD WaitResult;

	HANDLE hDirectory = INVALID_HANDLE_VALUE;
	HANDLE WaitHandles[] = { *GetCancelEvent(), INVALID_HANDLE_VALUE };
	
	while ( MayContinue() ) {
		if ( hDirectory == INVALID_HANDLE_VALUE ) {
			hDirectory = FindFirstChangeNotification( my_DirectoryName, !kWatchSubTree, kNotifyFilter );
			if ( hDirectory != INVALID_HANDLE_VALUE )
				WaitHandles[ 1 ] = hDirectory;
		}
		if ( hDirectory != INVALID_HANDLE_VALUE ) {
			WaitResult = WaitForMultipleObjects( countof( WaitHandles ), WaitHandles, !kWaitAll, INFINITE );
			if ( WaitResult != WAIT_FAILED ) {
				HandleIdx = WaitResult - WAIT_OBJECT_0;
				if ( WaitHandles[ HandleIdx ] == hDirectory ) {
					my_ChangedEvt.Announce( this, static_cast< const char_t * >( my_DirectoryName ));

					if ( !FindNextChangeNotification( hDirectory )) {
						VERIFY( FindCloseChangeNotification( hDirectory ));
						hDirectory = INVALID_HANDLE_VALUE;
					}
				}
			}
		} else {
			// if we could not start the notification, then we try it again later:

			Sleep( my_NotFoundTimeout );
		}
	}
	if ( hDirectory != INVALID_HANDLE_VALUE )
		VERIFY( FindCloseChangeNotification( hDirectory ));
}

} // namespace AidKit
