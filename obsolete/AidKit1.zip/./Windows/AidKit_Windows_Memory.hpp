#ifndef AIDKIT_WINDOWS_MEMORY_HPP
#define AIDKIT_WINDOWS_MEMORY_HPP

#include "..\AidKit.hpp"

#include <malloc.h> // alloca

namespace AidKit {

}

#endif
