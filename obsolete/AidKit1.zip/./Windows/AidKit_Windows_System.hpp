#ifndef AIDKIT_WINDOWS_SYSTEM_HPP
#define AIDKIT_WINDOWS_SYSTEM_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <stdlib.h>

namespace AidKit {

	const UNICHAR kDirectorySeparator = UNITEXT( '\\' );

	const size_t kMaxPath = _MAX_PATH;

}

#endif

