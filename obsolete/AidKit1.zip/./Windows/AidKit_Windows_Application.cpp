#include "AidKit_Windows_Application.hpp"
#include "..\AidKit_Debug.hpp"
#include "..\AidKit_WinError.hpp"
#include "..\AidKit_WinHelper.hpp"
#include "..\AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CCommandLineParser
//###
//#############################################################################
//#############################################################################
//#############################################################################

//-----------------------------------------------------------------------------
class CCommandLineParser : public CCommandLineInfo {
//-----------------------------------------------------------------------------
	public:
		CCommandLineParser( void );
		void ParseParam( const char_t *pParam, BOOL IsFlag, BOOL IsLast );

		BOOL my_IsDebugged;
};


//=============================================================================
CCommandLineParser::CCommandLineParser( void )
//=============================================================================
{
	my_IsDebugged = false;
}



//=============================================================================
void CCommandLineParser::ParseParam( const char_t *pParam, BOOL IsFlag, BOOL IsLast )
//=============================================================================
{
	if ( IsFlag && str_i_cmp( pParam, TEXT( "Debug" )) == 0 )
		my_IsDebugged = true;
	else
		CCommandLineInfo::ParseParam( pParam, IsFlag, IsLast );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWindowsApplication
//###
//#############################################################################
//#############################################################################
//#############################################################################


static const UINT WM_RELAY = ::RegisterWindowMessage( TEXT( "AidKit.WindowsApplication.RelayEvent" ));

BEGIN_MESSAGE_MAP(CWindowsApplication, CWinApp)
	//{{AFX_MSG_MAP(CWindowsApplication)
	ON_REGISTERED_THREAD_MESSAGE( WM_RELAY, OnRelayAsyncEvent )
	//}}AFX_MSG
END_MESSAGE_MAP()



//=============================================================================
const CString CWindowsApplication::Path( void )
//=============================================================================
{
	return ( GetProgramPath() );
}



//=============================================================================
CWindowsApplication::CWindowsApplication( const char_t Name[] )
	: CWinApp( Name )
//=============================================================================
	, my_AsyncEventDispatcher( this, &CWindowsApplication::PostAsyncEvent )
{
	 // Must not be used in a DLL! It only makes problems like configuraton
	 // files beeing written twice and so on.

}



//=============================================================================
CWindowsApplication::~CWindowsApplication()
//=============================================================================
{
}



//=============================================================================
BOOL CWindowsApplication::MfcMain( int argc, char *argv[] )
//=============================================================================
{
	HINSTANCE hCurrentInstance = ::GetModuleHandle( NULL );
	HINSTANCE hPreviousInstance = NULL;
	LPTSTR CommandLine = ::GetCommandLine();
	int nShowCommand = 0;

	if ( !AfxWinInit( hCurrentInstance, hPreviousInstance, CommandLine, nShowCommand ))
		return ( FALSE );

	if ( !InitInstance() )
		return ( FALSE );

	return ( TRUE );
}



//=============================================================================
int CWindowsApplication::MfcExit( int ExitCode )
//=============================================================================
{
	int Result;

	if (( Result = ExitInstance()) != 0 )
		return ( Result );

	return ( ExitCode );
}



//=============================================================================
BOOL CWindowsApplication::WinMain( HINSTANCE hCurrentInstance, HINSTANCE hPreviousInstance,
	LPTSTR CommandLine, int nShowCommand )
//=============================================================================
{
	if ( !OnStartup() )
		return ( FALSE );

	return ( TRUE );
}



//=============================================================================
int CWindowsApplication::WinExit( int ExitCode )
//=============================================================================
{
	if ( !OnShutdown() )
		return ( EXIT_FAILURE );

	return ( ExitCode );
}




//=============================================================================
bool CWindowsApplication::OnStartup( void )
//=============================================================================
{
	if ( !CApplicationBase::OnStartup() )
		return ( false );

	TAsyncEvent::ExchangeDispatcher( &my_AsyncEventDispatcher );

	return ( true );
}



//=============================================================================
bool CWindowsApplication::OnShutdown( void )
//=============================================================================
{
	TAsyncEvent::ExchangeDispatcher( NULL );

	return ( CApplicationBase::OnShutdown() );
}





//=============================================================================
BOOL CWindowsApplication::InitInstance() 
//=============================================================================
{
	// Parse the command line for the debug switch:

	ASSERT( !IsDLL() );

	CCommandLineParser CommandLine;
	ParseCommandLine( CommandLine );
	if ( CommandLine.my_IsDebugged )
		EnableDebugging();

	if ( !CWinApp::InitInstance() )
		return ( FALSE );

	// if ( !AfxInitRichEdit() )
		// return ( FALSE );

	if ( !OnStartup() )
		return ( FALSE );

	return ( TRUE );
}



//=============================================================================
int CWindowsApplication::ExitInstance() 
//=============================================================================
{
	// TODO: Add your specialized code here and/or call the base class

	if ( !OnShutdown() )
		return ( EXIT_FAILURE );

	return ( CWinApp::ExitInstance() );
}




//=============================================================================
void CWindowsApplication::PostAsyncEvent( const TAsyncEvent *pAsyncEvent )
//=============================================================================
{
	// _Post_ a message to process the asynchron events in the main gui thread:

	COMPILER_ASSERT( sizeof( pAsyncEvent ) >= sizeof( LPARAM ));
	PostThreadMessage( WM_RELAY, 0, reinterpret_cast< LPARAM >( pAsyncEvent ));
}



//=============================================================================
void CWindowsApplication::OnRelayAsyncEvent( WPARAM, LPARAM lParam )
//=============================================================================
{
	TAsyncEvent *pAsyncEvent = reinterpret_cast< TAsyncEvent * >( lParam );
	pAsyncEvent->Relay();
}


//=============================================================================
bool CWindowsApplication::IsGUI( void ) const
//=============================================================================
{
	return ( AidKit::IsGUI() );
}



//=============================================================================
bool CWindowsApplication::IsCUI( void ) const
//=============================================================================
{
	return ( AidKit::IsCUI() );
}



//=============================================================================
bool CWindowsApplication::IsEXE( void ) const
//=============================================================================
{
	return ( AidKit::IsEXE() );
}



//=============================================================================
bool CWindowsApplication::IsDLL( void ) const
//=============================================================================
{
	return ( AidKit::IsDLL() );
}


} // namespace AidKit




/*

Working!

//=============================================================================
static BOOL HasConsole(void)
//=============================================================================
// Submitted By: David Gravereaux (2001/05/21)
// A GUI application that was started from the console is disconnected from it. We
// can use this info to tell if we are in a GUI or CUI application with this:
{
    HANDLE hConsole;
   
    hConsole = CreateFile( TEXT( "CONOUT$" ), GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if ( hConsole!= INVALID_HANDLE_VALUE )
        CloseHandle( hConsole );

	return ( hConsole != INVALID_HANDLE_VALUE );
}
*/




// Possible?

/* ApplicationType DetermineApplicationType( void )
{
	HANDLE hInput = GetStdHandle( STD_INPUT_HANDLE );
	HANDLE hOutput = GetStdHandle( STD_OUTPUT_HANDLE );
	HANDLE hError  = GetStdHandle( STD_ERROR_HANDLE );

	if ( hInput != INVALID_HANDLE_VALUE && hOutput != INVALID_HANDLE_VALUE && hError != INVALID_HANDLE_VALUE )
		return ( ApplicationCUI );
	else
		return ( ApplicationGUI );
} */





/* NOT working:

bool CApplication::IsConsole( void )
{
	bool IsConsole = ( GetStdHandle( STD_OUTPUT_HANDLE ) != UNINVALID_HANDLE_VALUE );

	return ( IsConsole );
}


bool CApplication::IsConsole( void )
{
	char ConsoleTitle[ 100 ];

	bool IsConsole = ( GetConsoleTitle( ConsoleTitle, countof( ConsoleTitle )) > 0 );

	return ( IsConsole );
}


bool CApplication::IsConsole( void )
{
	bool IsConsole = ( AfxGetAfxWndProc() == NULL );

	return ( IsConsole );
}


bool CApplication::IsConsole( void )
{
	return ( AfxGetMainWnd() == NULL );
}

bool CApplication::IsGraphic( void )
{
	return ( AfxGetMainWnd() != NULL );
}


*/
