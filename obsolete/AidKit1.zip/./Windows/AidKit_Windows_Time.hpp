#ifndef AIDKIT_WINDOWS_TIME_HPP
#define AIDKIT_WINDOWS_TIME_HPP

#include "..\AidKit.hpp"

namespace AidKit {

	namespace Windows {

	}

}

#endif
