#include "..\AidKit_Misc.hpp"
#include "..\AidKit_Memory.hpp"
#include <afx.h>
#include "..\AidKit_Warnings.hpp"

namespace AidKit {

namespace Windows {

//=============================================================================
const CString StringVPrintF( const char_t Format[], va_list Arguments )
//=============================================================================
{
	// We can't declare the memory static, because it wouldn't be thread safe:
	memory< char_t > Output( 80 );

	memory_printf( &Output, Format, Arguments );
	return ( CString( Output, Output.size() ));
}


//=============================================================================
const CString StringPrintF( const char_t Format[], ... )
//=============================================================================
{
	va_list Arguments;

	va_start( Arguments, Format );
	CString Output = StringVPrintF( Format, Arguments );
	va_end( Arguments );

	return ( Output );
}

} // namespace Windows

} // namespace AidKit
