#include "..\AidKit.hpp"
#include "AidKit_Windows_Debug.hpp"
#include "AidKit_Windows_Misc.hpp"
#include <afx.h>

namespace AidKit {

namespace Windows {

//=============================================================================
void debug_printf( const char_t Format[], ... )
//=============================================================================
{
	va_list Arguments;

	Sleep( 1 );

	va_start( Arguments, Format );
	::OutputDebugString( StringVPrintF( Format, Arguments ));
	::OutputDebugString( TEXT( "\n" ));
	va_end( Arguments );
}

} // namespace Windows

} // namespace AidKit
