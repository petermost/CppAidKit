#ifndef AIDKIT_WINDOWS_MAIN_HPP
#define AIDKIT_WINDOWS_MAIN_HPP

#include "..\AidKit_Unicode.hpp"
#include <afxwin.h>

#pragma comment( linker, "/warn:0" )
#pragma comment( linker, "/force:multiple" )

#ifdef AIDKIT_UNICODE
	#pragma comment( linker, "/entry:wWinMainCRTStartup" )
#else
	#pragma comment( linker, "/entry:WinMainCRTStartup" )
#endif


namespace AidKit {

	namespace Windows {
	
		int Main( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR pCmdLine, int nCmdShow );

		HINSTANCE GetInstanceHandle( void );

	}

}

/*
To use this module simply include it and write the following:

int WINAPI _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR pCmdLine, int nShowCmd )
{
	<YourApplicationClass> theApp;

	return ( AidKit::Main( hInstance, hPrevInstance, pCmdLine, nShowCmd ));
}

*/

#endif
