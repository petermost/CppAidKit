#ifndef AIDKIT_WINDOWS_SOCKET_HPP
#define AIDKIT_WINDOWS_SOCKET_HPP

#include "../AidKit.hpp"
#include "../AidKit_Types.hpp"
#include "../AidKit_WinError.hpp"

#include <winsock2.h>

namespace AidKit {

	namespace Windows {

		UINT64 ntohll( UINT64 network_long_long );
		UINT64 htonll( UINT64 host_long_long );

	}
	typedef SOCKET socket_t;
	typedef int socklen_t;
	typedef TWinError< class CSocket > CSocketError;

	//-----------------------------------------------------------------------------
	class CWinSocketBasics : public CSocketBasics {
	//-----------------------------------------------------------------------------
		public:
			CWinSocketBasics( void )
				throw ( CSocketError );
				
			~CWinSocketBasics( void )
				throw();
			
			int DoClose( socket_t hSocket )
				throw ( CSocketError );

			int DoIOControl( socket_t hSocket, EMode eMode )
				throw ( CSocketError );
				
			int DoShutdown( socket_t hSocket, EDirection eDirection )
				throw ( CSocketError );
				
			size_t DoReceive( socket_t hSocket, void *pBuffer, size_t nBufferSize )
				throw ( CSocketError );
				
			size_t DoSend( socket_t hSocket, const void *pBuffer, size_t nBufferLength )
				throw ( CSocketError );

			int DoSelect( socket_t hLastSocket, fd_set *pReadFds, fd_set *pWriteFds,
				fd_set *pExceptFds, timeval *pTimeout )
					throw ( CSocketError );

			void DoCancel( socket_t hSocket )
				throw ( CSocketError );

			int DoSetSocketOption( socket_t hSocket, int nLevel,
				int nOptName, const void *pOptVal, socklen_t OptLen )
					throw ( CSocketError );

			in_addr DoNameToAddress( const string_t &Name ) const
				throw ( CSocketError );
				
			string_t DoAddressToName( const in_addr &Address ) const
				throw ( CSocketError );
				
		private:
			static unsigned long our_StartupCounter;
				
	};
	
}

#endif

