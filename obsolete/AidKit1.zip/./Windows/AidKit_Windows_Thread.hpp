#ifndef AIDKIT_WINDOWS_THREAD_HPP
#define AIDKIT_WINDOWS_THREAD_HPP

#include "..\AidKit_WinError.hpp"
#include "..\AidKit_ThreadBase.hpp"
#include <afxmt.h>

// Stupid windows! defines Yield as an empty macro.
#ifdef Yield
	#undef Yield
#endif

class CWinThread;

namespace AidKit {

	namespace Windows {

		typedef TWinError< class CThread > CThreadError;

		//-----------------------------------------------------------------------------
		class CThread {
		//-----------------------------------------------------------------------------
			public:
				enum EType {
					eSuspended, eImmediately
				};

				CThread( EType eType = eImmediately )
					throw ( CThreadError );

				~CThread( void )
					throw();

				void Create( unsigned ( *pFunction )( CThread *pThread, void *pParameter ), void *pParameter )
					throw ( CThreadError );

				unsigned Wait( void )
					throw ( CThreadError );

				void Resume( void )
					throw ( CThreadError );

				void Suspend( void )
					throw ( CThreadError );

				HANDLE Handle( void ) const
					throw ();

				bool operator == ( DWORD nOtherThread ) const
					throw ();
			
			private:
				static unsigned Entry( void *Parameter );

				CWinThread *my_pWinThread;
				EType my_eType;



				unsigned ( *my_pFunction )( CThread *pThread, void *pParameter );
				void *my_pFunctionParameter;
		};
		
	} // namespace Windows


	//-----------------------------------------------------------------------------
	class CWindowsThread : public CThreadBase {
	//-----------------------------------------------------------------------------
		public:
			CWindowsThread( void );
			~CWindowsThread( void );

		protected:
			virtual bool DoStart( void ( *pFunction )( void *pParameter ), void *pParameter );
			virtual bool DoWait( milliseconds_t Milliseconds );
			virtual void DoInfiniteWait( void );

			virtual void DoYield( void );
			virtual bool DoSleep( milliseconds_t Milliseconds );
			virtual void DoInfiniteSleep( void );
			virtual void DoWakeup( void );

			virtual bool IsSelf( void ) const;
			CEvent *GetCancelEvent( void ) const;

		private:
			CWindowsThread( const CWindowsThread & );
			CWindowsThread &operator = ( const CWindowsThread & );

			static unsigned Entry( Windows::CThread *, void *Parameter );

			Windows::CThread my_Kernel;
			mutable CEvent my_CancelEvent;
	};


} // namespace AidKit

#endif

