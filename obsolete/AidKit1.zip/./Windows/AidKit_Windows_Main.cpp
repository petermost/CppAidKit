#include "AidKit_Windows_Main.hpp"
#include "..\AidKit_Unicode.hpp"

extern int AFXAPI AfxWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow);

namespace AidKit {

namespace Windows {

static HINSTANCE our_hInstance = NULL;
static HINSTANCE our_hPreviousInstance = NULL;
static LPTSTR    our_pCommandLine = NULL;
static int       our_nShowCommand = 0;



// Force the inclusion of AfxInitialize:
static BOOL ( AFXAPI *our_pAfxInitialize )( BOOL, DWORD ) = &::AfxInitialize;

//=============================================================================
int Main(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR pCmdLine, int nCmdShow)
//=============================================================================
{
	our_hInstance = hInstance;
	our_hPreviousInstance = hPrevInstance;
	our_pCommandLine = pCmdLine;
	our_nShowCommand = nCmdShow;

	return ( AfxWinMain( hInstance, hPrevInstance, pCmdLine, nCmdShow ));
}

//=============================================================================
HINSTANCE GetInstanceHandle( void )
//=============================================================================
{
	return (( our_hInstance != NULL ) ? our_hInstance : AfxGetInstanceHandle() );
}

} // namespace Windows

} // namespace AidKit



/*
extern "C" void wWinMainCRTStartup( void );
extern "C" void WinMainCRTStartup( void );

//=============================================================================
extern "C" void AidKit_wWinMainCRTStartup( void )
//=============================================================================
{
	wWinMainCRTStartup();
}		



//=============================================================================
extern "C" void AidKit_WinMainCRTStartup( void )
//=============================================================================
{
	WinMainCRTStartup();
}
*/
