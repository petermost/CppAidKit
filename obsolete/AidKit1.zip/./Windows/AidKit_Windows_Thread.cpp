#include "AidKit_Windows_Thread.hpp"
#include "..\AidKit_Warnings.hpp"
#include <afxwin.h>

const HANDLE NULL_HANDLE = NULL;

#define ASSERT_HANDLE( Handle )  ASSERT(( Handle ) != NULL_HANDLE )

namespace AidKit {

namespace Windows {


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CThread
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
inline BOOL CheckThreadError( BOOL Success )
//=============================================================================
	{ return ( check_win_api< CThreadError >( Success )); }


//=============================================================================
CThread::CThread( EType eType )
	throw ( CThreadError )
//=============================================================================
{
	my_pWinThread = NULL;
	my_eType = eType;
}



//=============================================================================
CThread::~CThread( void )
	throw()
//=============================================================================
{
	delete my_pWinThread;
}



//=============================================================================
unsigned CThread::Entry( void *pParameter )
//=============================================================================
{
	CThread *pThread = static_cast< CThread * >( pParameter );
	return (( *pThread->my_pFunction )( pThread, pThread->my_pFunctionParameter ));
}



//=============================================================================
void CThread::Create( unsigned ( *pFunction )( CThread *, void * ), void *pParameter )
	throw ( CThreadError )
//=============================================================================
{
	my_pFunction = pFunction;
	my_pFunctionParameter = pParameter;

	DWORD Flags;
	switch ( my_eType ) {
		case eSuspended:
			Flags = CREATE_SUSPENDED;
			break;

		case eImmediately:
		default:
			Flags = 0;
			break;
	}
	// The instance of CWinThread has to be heap based, because only the MFC
	// may delete this objects. If you try to delete it yourself, then an ASSERT
	// ThrdCore.cpp(110) fires!

	my_pWinThread = new CWinThread( &Entry, this );
	my_pWinThread->m_bAutoDelete = FALSE;
	CheckThreadError( my_pWinThread->CreateThread( Flags ));
}



//=============================================================================
unsigned CThread::Wait( void )
	throw ( CThreadError )
//=============================================================================
{
	DWORD nResult = 0;

	CheckThreadError( WaitForSingleObject( my_pWinThread->m_hThread, INFINITE ) != WAIT_FAILED );
	CheckThreadError( GetExitCodeThread( my_pWinThread->m_hThread, &nResult ));

	return ( nResult );
}




//=============================================================================
void CThread::Resume( void )
	throw ( CThreadError )
//=============================================================================
{
	DWORD nSuspendCount = ResumeThread( my_pWinThread->m_hThread );
	CheckThreadError( nSuspendCount != -1 );
}


//=============================================================================
void CThread::Suspend( void )
	throw ( CThreadError )
//=============================================================================
{
	DWORD nSuspendCount = SuspendThread( my_pWinThread->m_hThread );
	CheckThreadError( nSuspendCount != -1 );
}



//=============================================================================
HANDLE CThread::Handle( void ) const
	throw ()
//=============================================================================
{
	ASSERT( my_pWinThread != NULL );
	return ( my_pWinThread->m_hThread );
}



//=============================================================================
bool CThread::operator == ( DWORD nOtherThreadID ) const
	throw ()
//=============================================================================
{
	return ( my_pWinThread != NULL && my_pWinThread->m_nThreadID == nOtherThreadID );
}



/*
//=============================================================================
bool CThread::Suspend( void )
//=============================================================================
{
	DWORD SuspendCount = ::SuspendThread( my_pWinThread->m_hThread );
	bool IsSuspended = ( SuspendCount >= 0 && SuspendCount != 0xFFFFFFFFul );
	return ( IsSuspended );
}



//=============================================================================
bool CWindowsThread::Resume( void )
//=============================================================================
{
	DWORD SuspendCount = ::ResumeThread( my_pWinThread->m_hThread );

	bool IsSuspended = ( SuspendCount != 1 && SuspendCount != 0xFFFFFFFFul );
	return ( !IsSuspended );
}



//=============================================================================
bool CWindowsThread::IsRunning( void ) const
//=============================================================================
{
	DWORD ExitCode = 0;

	if ( my_pWinThread->m_hThread != NULL_HANDLE && ::GetExitCodeThread( my_pWinThread->m_hThread, &ExitCode ))
		return ( ExitCode == STILL_ACTIVE );
	else
		return ( false );
}
*/


} // namespace Windows


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWindowsThread
//###
//#############################################################################
//#############################################################################
//#############################################################################

using namespace Windows;

//=============================================================================
CWindowsThread::CWindowsThread( void )
	: my_CancelEvent( NULL, TRUE, FALSE, NULL )
//=============================================================================
{
}



//=============================================================================
CWindowsThread::~CWindowsThread( void )
//=============================================================================
{
}


//=============================================================================
unsigned CWindowsThread::Entry( Windows::CThread *, void *pParameter )
//=============================================================================
{
	CWindowsThread *pKernel = static_cast< CWindowsThread * >( pParameter );
	( *pKernel->my_pFunction )( pKernel->my_pFunctionParameter );

	return ( 0 );
}


//=============================================================================
bool CWindowsThread::DoStart( void ( *pFunction )( void * ), void *pParameter )
//=============================================================================
{
	my_pFunction          = pFunction;
	my_pFunctionParameter = pParameter;
	my_Kernel.Create( &Entry, this );

	return ( true );
}



//=============================================================================
bool CWindowsThread::DoWait( milliseconds_t Milliseconds )
//=============================================================================
{
	DWORD Result;
	MSG Message;
	HANDLE hThread = my_Kernel.Handle();

	// Wait for the thread to end but still relay messages from/to the GUI:

	do {
		Result = MsgWaitForMultipleObjects( 1, &hThread, FALSE, Milliseconds, QS_ALLINPUT );
		if ( Result == WAIT_OBJECT_0 + 1 ) {
			while ( PeekMessage( &Message, 0, 0, 0, PM_REMOVE )) {
				TranslateMessage( &Message );
				DispatchMessage( &Message );
			}
		}
	} while ( Result == WAIT_OBJECT_0 + 1 );

	return ( Result == WAIT_TIMEOUT );
}



//=============================================================================
void CWindowsThread::DoInfiniteWait( void )
//=============================================================================
{
	DoWait( INFINITE );
}



//=============================================================================
void CWindowsThread::DoYield( void )
//=============================================================================
{
	// If Sleep is getting called with a waiting time of 0 then the thread is giving
	// up its remaining time slice:
	::Sleep( 0 );
}


//=============================================================================
bool CWindowsThread::DoSleep( milliseconds_t Milliseconds )
//=============================================================================
{
	// We are not using CSingleLock to save the constructor call:

	return ( WaitForSingleObject( my_CancelEvent, Milliseconds ) == WAIT_TIMEOUT );
}



//=============================================================================
void CWindowsThread::DoInfiniteSleep( void )
//=============================================================================
{
	DoSleep( INFINITE );
}



//=============================================================================
void CWindowsThread::DoWakeup( void )
//=============================================================================
{
	my_CancelEvent.SetEvent();
}
	


//=============================================================================
bool CWindowsThread::IsSelf( void ) const
//=============================================================================
{
	return ( my_Kernel == GetCurrentThreadId() );
}



//=============================================================================
CEvent *CWindowsThread::GetCancelEvent( void ) const
//=============================================================================
{
	return ( &my_CancelEvent );
}


} // namespace AidKit
