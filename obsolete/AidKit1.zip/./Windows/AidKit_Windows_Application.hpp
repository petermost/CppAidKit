#ifndef AIDKIT_WINDOWS_APPLICATION_HPP
#define AIDKIT_WINDOWS_APPLICATION_HPP

#include "..\AidKit_Misc.hpp"
#include "..\AidKit_AsyncEvent.hpp"
#include "..\AidKit_Unicode.hpp"
#include "..\AidKit_ApplicationBase.hpp"

#include <afxwin.h>

namespace AidKit {

	class CWinError;

	//-----------------------------------------------------------------------------
	class CWindowsApplication : public CWinApp, public CApplicationBase {
	//-----------------------------------------------------------------------------
		public:
			CWindowsApplication( const char_t Name[] );
			~CWindowsApplication( void );

			BOOL MfcMain( int argc, char *argv[] );
			int MfcExit( int ExitCode );
				// Call MfcMain, MfcExit if you have a console application but wish
				// to use MFC stuff.

			BOOL WinMain( HINSTANCE hCurrentInstance, HINSTANCE hPreviousInstance, LPTSTR CommandLine, int nShowCommand );
			int WinExit( int ExitCode );
				// Call WinMain, WinExit if you have a normal windows application.

			virtual bool IsGUI( void ) const;
			virtual bool IsCUI( void ) const;
			virtual bool IsEXE( void ) const;
			virtual bool IsDLL( void ) const;

		protected:
			static const CString Path( void );

			virtual bool OnStartup( void );
			virtual bool OnShutdown( void );

			//{{AFX_VIRTUAL(CWindowsApplication)
			virtual BOOL InitInstance();
			virtual int ExitInstance();
			//}}AFX_VIRTUAL

			//{{AFX_MSG(CWindowsApplication)
			afx_msg void OnRelayAsyncEvent( WPARAM, LPARAM );
			//}}AFX_MSG
			DECLARE_MESSAGE_MAP()

		private:
			TMethod1< CWindowsApplication, const TAsyncEvent * > my_AsyncEventDispatcher;
			void PostAsyncEvent( const TAsyncEvent * );
	};

}

#endif
