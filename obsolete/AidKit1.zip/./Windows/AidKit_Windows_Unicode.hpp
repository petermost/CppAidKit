#ifndef AIDKIT_WINDOWS_UNICODE_HPP
#define AIDKIT_WINDOWS_UNICODE_HPP

#include <tchar.h> // _TEXT macro
#include <afxwin.h> // TEXT

// stdio.h:
#if defined( AIDKIT_UNICODE )
	#define UNISNPRINTF  _snwprintf
	#define UNIVSNPRINTF _vsnwprintf
#else
	#define UNISNPRINTF  _snprintf
	#define UNIVSNPRINTF _vsnprintf
#endif

// windows:
#if defined( AIDKIT_UNICODE )
	#define UNIWINMAIN wWinMain
	#define UNIMAIN    wmain
#else
	#define UNIWINMAIN WinMain
	#define UNIMAIN    main
#endif

#endif


