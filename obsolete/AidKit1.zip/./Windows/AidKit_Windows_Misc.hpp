#ifndef AIDKIT_WINDOWS_MISC_HPP
#define AIDKIT_WINDOWS_MISC_HPP

#include "..\AidKit.hpp"
#include "..\AidKit_Unicode.hpp"

#include <stdarg.h>

class CString;

namespace AidKit {

	namespace Windows {

		const CString StringPrintF( const char_t Format[], ... );
		const CString StringVPrintF( const char_t Format[], va_list Arguments );
	}

}

#endif
