#ifndef AIDKIT_WINDOWS_THREADLOCK_HPP
#define AIDKIT_WINDOWS_THREADLOCK_HPP

#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CWindowsThreadGuard {
	//-----------------------------------------------------------------------------
		public:
			CWindowsThreadGuard( void );
			~CWindowsThreadGuard( void );

			void Lock( void );
			void Unlock( void );

		private:
			CWindowsThreadGuard( const CWindowsThreadGuard & );
			CWindowsThreadGuard &operator = ( const CWindowsThreadGuard & );

			CRITICAL_SECTION my_CriticalSection;
	};

}

#endif
