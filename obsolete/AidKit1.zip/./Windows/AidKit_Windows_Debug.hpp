#ifndef AIDKIT_WINDOWS_DEBUG_HPP
#define AIDKIT_WINDOWS_DEBUG_HPP

#include "..\AidKit.hpp"
#include "..\AidKit_Unicode.hpp"

namespace AidKit {

	namespace Windows {

		void debug_printf( const char_t Format[], ... );

		#if defined( AIDKIT_I386 )
			#define debug_break() _asm { int 3 }
		#endif

	}

}

#endif
