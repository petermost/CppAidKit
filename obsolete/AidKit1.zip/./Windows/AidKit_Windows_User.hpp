#ifndef AIDKIT_WINDOWS_USER_HPP
#define AIDKIT_WINDOWS_USER_HPP

#include "../AidKit.hpp"
#include "../AidKit_WinError.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CWinUser : public CUserBasics {
	//-----------------------------------------------------------------------------
		public:
			CWinUser( void );
			~CWinUser( void );

		protected:
			virtual string_t DoGetName( void )
				throw ( CWinError );

			virtual string_t DoGetHomeDirectory( void )
				throw ( CWinError );
	};

}

#endif
