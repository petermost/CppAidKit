#include "..\AidKit_Socket.hpp"

#pragma comment( lib, "Ws2_32.lib" )

namespace AidKit {

namespace Windows {

//=============================================================================
UINT64 ntohll( UINT64 nll )
//=============================================================================
{
	#if defined( AIDKIT_I386 )
		UINT64 new_nll;
		_swab( reinterpret_cast< char * >( &nll ), reinterpret_cast< char * >( &new_nll ), sizeof( new_nll ));
		return ( new_nll );
	#else
		#error "Unknown ENDIAN machine"
	#endif
}



//=============================================================================
UINT64 htonll( UINT64 hll )
//=============================================================================
{
	#if defined( AIDKIT_I386 )
		UINT64 new_hll;
		_swab( reinterpret_cast< char * >( &hll ), reinterpret_cast< char * >( &new_hll ), sizeof( new_hll ));
		return ( new_hll );
	#else
		#error "Unknown ENDIAN machine"
	#endif
}

} // namespace Windows




} // namespace AidKit


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWinSocketBasics
//###
//#############################################################################
//#############################################################################
//#############################################################################

namespace AidKit {
	
unsigned long CWinSocketBasics::our_StartupCounter = 0;

//=============================================================================
CWinSocketBasics::CWinSocketBasics( void )
	throw ( CSocketError )
//=============================================================================
{
	if ( our_StartupCounter++ == 0 ) {
		WSADATA SocketVersion;
		int nResult = WSAStartup( MAKEWORD( 1, 0 ), &SocketVersion );
		if ( nResult != 0 )

			throw CSocketError( nResult );
	}
}


//=============================================================================
CWinSocketBasics::~CWinSocketBasics( void )
	throw()
//=============================================================================
{
	if ( --our_StartupCounter == 0 ) {
		WSACleanup();
	}
}



//=============================================================================
int CWinSocketBasics::DoClose( socket_t hSocket )
	throw ( CSocketError )
//=============================================================================
{
	return ( closesocket( hSocket ));
}



//=============================================================================
int CWinSocketBasics::DoIOControl( socket_t hSocket, EMode eMode )
	throw ( CSocketError )
//=============================================================================
{
	COMPILER_ASSERT( eModeBlock   == 0 );
	COMPILER_ASSERT( eModeUnblock == 1 );

	u_long Argument = eMode;

	return ( ioctlsocket( hSocket, FIONBIO, &Argument ));
}



//=============================================================================
int CWinSocketBasics::DoShutdown( socket_t hSocket, EDirection eDirection )
//=============================================================================
{
	int nDirection;
	
	switch ( eDirection ) {
		case eDirectionRead:
			nDirection = SD_RECEIVE;
			break;
	
		case eDirectionWrite:
			nDirection = SD_SEND;

			break;
	
		case eDirectionReadWrite:
		default:
			nDirection = SD_BOTH;
			break;
	}
	return ( shutdown( hSocket, nDirection ));
}



//=============================================================================
int CWinSocketBasics::DoSelect( socket_t hLastSocket, fd_set *pReadFds,
	fd_set *pWriteFds, fd_set *pExceptFds, timeval *pTimeout )
		throw ( CSocketError )
//=============================================================================
{
	return ( select( hLastSocket, pReadFds, pWriteFds, pExceptFds, pTimeout ));
}



//=============================================================================
void CWinSocketBasics::DoCancel( socket_t hSocket )
	throw ( CSocketError )
//=============================================================================
{
	#error CWinSocketBasics::DoCancel() is not yet implemented!
}


//=============================================================================
size_t CWinSocketBasics::DoReceive( socket_t hSocket, void *pBuffer, size_t nBufferSize )
	throw ( CSocketError )
//=============================================================================
{
	return ( CheckSocketApi( recv( hSocket, static_cast< char * >( pBuffer ), nBufferSize, 0 )));
}



//=============================================================================
size_t CWinSocketBasics::DoSend( socket_t hSocket, const void *pBuffer, size_t nBufferLength )
	throw ( CSocketError )
//=============================================================================
{
	return ( CheckSocketApi( send( hSocket, static_cast< const char * >( pBuffer ), nBufferLength, 0 )));
}


//=============================================================================
int CWinSocketBasics::DoSetSocketOption( socket_t hSocket, int nLevel,
	int nOptName, const void *pOptVal, socklen_t nOptLen )
		throw ( CSocketError )
//=============================================================================
{
	return ( setsockopt( hSocket, nLevel, nOptName, static_cast< const char * >( pOptVal ), nOptLen ));
}


//=============================================================================
in_addr CWinSocketBasics::DoNameToAddress( const string_t &Name ) const
	throw ( CSocketError )
//=============================================================================
{
	in_addr Address;
	Address.s_addr = inet_addr( text( Name.c_str() ));
	if ( Address.s_addr == INADDR_NONE )
		throw( CSocketError( WSAEINVAL ));

	return ( Address );
}



//=============================================================================
string_t CWinSocketBasics::DoAddressToName( const in_addr &Address ) const
	throw ( CSocketError )
//=============================================================================
{
	char *pName = inet_ntoa( Address );
	if ( pName == NULL )
		throw ( CSocketError( WSAEINVAL ));
		
	string_t Name = text( pName );
	return ( Name );
}

} // namespace AidKit
