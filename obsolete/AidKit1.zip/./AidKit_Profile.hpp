#ifndef AIDKIT_PROFILE_HPP
#define AIDKIT_PROFILE_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_WinError.hpp"

#pragma warning( disable : 4786 ) 
#include <string>
#include <vector>

class CStringArray;

namespace AidKit {

	void SplitSectionNames( const char_t SectionNames[], CStringArray *pSectionNames );
		// Can help to split the section names from GetprivateProfileSectionNames().

	//-----------------------------------------------------------------------------
	class CProfile {
	//-----------------------------------------------------------------------------
		public:
			CProfile( void );
			~CProfile( void );

			bool Open( const char_t FileName[] );
			bool Close( void );

			bool WriteInteger( const char_t Key[], const char_t ValueName[], int Value );
			bool ReadInteger(  const char_t Key[], const char_t ValueName[], int *Value ) const;

			bool WriteString(  const char_t Key[], const char_t ValueName[], const string_t &Value );
			bool ReadString(   const char_t Key[], const char_t ValueName[], string_t *Value ) const;

			bool WriteBinary( const char_t Key[], const char_t ValueName[], const void *Value, size_t ValueSize );
			bool ReadBinary(  const char_t Key[], const char_t ValueName[], void *Value, size_t ValueSize ) const;

			const char_t *FileName( void ) const;

		private:
			string_t my_FileName;
	};




	class COutput;
	typedef TWinError< class CProfile > CProfileError;

	//-----------------------------------------------------------------------------
	class CXProfile {
	//-----------------------------------------------------------------------------
		public:
			CXProfile( void )
				throw ( void );

			~CXProfile( void )
				throw ( void );

			void Open( const char_t FileName[] )
				throw ( CProfileError );

			void Close( void )
				throw ( CProfileError );

			void WriteInteger( const char_t Key[], const char_t ValueName[], int Value )
				throw ( CProfileError );

			int ReadInteger( const char_t Key[], const char_t ValueName[] ) const
				throw ( CProfileError );

			void WriteString( const char_t Key[], const char_t ValueName[], const string_t &Value )
				throw ( CProfileError );

			const string_t ReadString( const char_t Key[], const char_t ValueName[] ) const
				throw ( CProfileError );

			void WriteBinary( const char_t Key[], const char_t ValueName[], const void *Value, size_t ValueSize )
				throw ( CProfileError );

			void ReadBinary(  const char_t Key[], const char_t ValueName[], void *Value, size_t ValueSize ) const
				throw ( CProfileError );

			friend COutput &operator << ( COutput &, const CXProfile & );

		private:
			CProfile my_Profile;
			string_t my_ProfileName;
	};

	COutput &operator << ( COutput &, const CXProfile & );

	inline COutput &operator << ( COutput &o, const CXProfile *p )
		 { return ( o << *p ); }

}


#endif
