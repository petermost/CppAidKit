#include "AidKit_Unicode.hpp"
#include "AidKit_Memory.hpp"
#include <stdlib.h>
#include "AidKit_Warnings.hpp"

/*

	template< typename char_t > int arg_print_fmt( const char_t fmt[], va_list args );
	template<> int arg_print_fmt( const char fmt[], va_list args ) { return ( vprintf( fmt, args )); }
	template<> int arg_print_fmt( const wchar_t fmt[], va_list args ) { return ( vwprintf( fmt, args )); }

	template< typename char_t > int print_fmt( const char_t fmt[], ... )
	{
		va_list args;
		
		va_start( args, fmt );
		int n = arg_print_fmt( fmt, args );
		va_end( args );
		return ( n );
	}

*/

using namespace std;

namespace AidKit {


//=============================================================================
char_t char_to_unichar( wchar_t wc )
//=============================================================================
{
	#if defined( AIDKIT_UNICODE )
		return ( wc );
	#else
		char_t *c = static_cast< char_t * >( alloca( MB_CUR_MAX * sizeof( char_t )));
		wctomb( c, wc );
		return ( c[ 0 ] );
	#endif
}



//=============================================================================
wchar_t unichar_to_char( char_t c )
//=============================================================================
{
	#if defined( AIDKIT_UNICODE )
		return ( c );
	#else
		wchar_t wc;
		mbtowc( &wc, &c, 1 );
		return ( wc );
	#endif
}


//=============================================================================
wstring &text_to_wstring( wstring *wbuffer, const string &text )
//=============================================================================
{
	wbuffer->resize( text.length() );
	mbstowcs( const_cast< wchar_t * >( wbuffer->data() ), text.data(), text.length() );

	return ( *wbuffer );
}



//=============================================================================
wstring &wtext_to_wstring( wstring *wbuffer, const wstring &wtext )
//=============================================================================
{
	wbuffer->assign( wtext );

	return ( *wbuffer );
}



//=============================================================================
string &wtext_to_string( string *buffer, const wstring &wtext )
//=============================================================================
{
	buffer->resize( wtext.length() * MB_CUR_MAX );
	wcstombs( const_cast< char * >( buffer->data() ), wtext.data(), wtext.length() );

	return ( *buffer );
}



//=============================================================================
string &text_to_string( string *buffer, const string &text )
//=============================================================================
{
	buffer->assign( text );

	return ( *buffer );
}





//=============================================================================
string_t &text_to_unitext( string_t *buffer, const string &text )
//=============================================================================
{
	#if defined( AIDKIT_UNICODE )
		return ( text_to_wstring( buffer, text ));
	#else
		return ( text_to_string( buffer, text ));
	#endif
}



//=============================================================================
string &unitext_to_string( string *buffer, const string_t &itext )
//=============================================================================
{
	#if defined( AIDKIT_UNICODE )
		return ( wtext_to_string( buffer, itext ));
	#else
		return ( text_to_string( buffer, itext ));
	#endif
}

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### text
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
text::text( const string &text )
//=============================================================================
{
	text_to_wstring( &my_wbuffer, text );
	text_to_string( &my_buffer, text );
}


#if !defined( AIDKIT_GCC_2 )

//=============================================================================
text::text( const wstring &wtext )
//=============================================================================
{
	wtext_to_string( &my_buffer, wtext );
	wtext_to_wstring( &my_wbuffer, wtext );
}

#endif


//=============================================================================
text::~text( void )
//=============================================================================
{
}


//=============================================================================
text::operator const char * ( void ) const
//=============================================================================
{
	return ( my_buffer.c_str() );
}



#if !defined( AIDKIT_GCC_2 )

//=============================================================================
text::operator const wchar_t * ( void ) const
//=============================================================================
{
	return ( my_wbuffer.c_str() );
}

#endif

} // namespace AidKit


