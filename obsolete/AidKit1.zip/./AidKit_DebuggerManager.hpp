#ifndef AIDKIT_DEBUGGER_MANAGER_HPP
#define AIDKIT_DEBUGGER_MANAGER_HPP

#include "AidKit.hpp"

#if defined( AIDKIT_WINDOWS )

#include "AidKit_Unicode.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_FileObserver.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CDebuggerManager {
	//-----------------------------------------------------------------------------
		public:
			static CDebuggerManager *Instance( void );
			static void DestroyInstance( void );

			void ObserveSettings( void );
			void UnobserveSettings( void );

		protected:
			static CDebuggerManager *our_pInstance;

			CDebuggerManager( void );
			~CDebuggerManager( void );

			TEventHandler2< CDebuggerManager, CFileObserver *, const char_t * > my_SettingsChangedHandler;
			void OnSettingsChanged( CFileObserver *, const char_t *FileName );

		private:
			CDebuggerManager( const CDebuggerManager & );
			CDebuggerManager &operator = ( const CDebuggerManager & );

			TEventHandler1< CDebuggerManager, CDebugger * > my_LoadSettingsHandler;
			void OnLoadSettings( CDebugger *pDebugger );

			TEventHandler1< CDebuggerManager, const CDebugger * > my_SaveSettingsHandler;
			void OnSaveSettings( const CDebugger *pDebugger );

			CDebugger my_Debugger;
			CFileObserver my_IniFileObserver;
		};
}
#endif

#endif
