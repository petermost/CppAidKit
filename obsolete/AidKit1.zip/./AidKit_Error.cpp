#include "AidKit_Error.hpp"
#include <algorithm>
#include <malloc.h>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {


/*
//=============================================================================
CError::CError( int )
//=============================================================================
// CError is meant to be used as a base class. And because it is an exception
// it must be possible to make a copy (the copy constructor is getting called).
// But this also means, that the deriveded classes must also provide a copy
// constructor. The derived copy constructor has to call the copy constructor
// of the base class, but the compiler doesn't force you to. So if you forget to
// call the copy constructor of the base class the compiler is calling the default
// constructor (which we don't want).
// So if we are not providing a default constructor but this constructor, you have
// to choose which on you want to call and this way you can't forget.
{
}
*/


//=============================================================================
CError::CError( void )
	throw()
//=============================================================================
{
}



//=============================================================================
CError::CError( const string_t &Description )
	throw()
//=============================================================================
{
	my_Description = Description;
}




//=============================================================================
CError::CError( const CError &OtherError ) throw()
: exception( OtherError ), COutput( OtherError )
//=============================================================================
{
	my_What        = OtherError.my_What;
	my_Description = OtherError.my_Description;
	my_CurrentCall = OtherError.my_CurrentCall;
	my_CallStack   = OtherError.my_CallStack;
}




//=============================================================================
CError &CError::operator = ( const CError &OtherError )
	throw()
//=============================================================================
{
	exception::operator = ( OtherError );
	COutput::operator = ( OtherError );

	my_What        = OtherError.my_What;
	my_Description = OtherError.my_Description;
	my_CurrentCall = OtherError.my_CurrentCall;
	my_CallStack   = OtherError.my_CallStack;

	return ( *this );
}



//=============================================================================
CError::~CError( void )
	throw()
//=============================================================================
{
}



//=============================================================================
COutput &CError::DoWrite( const char_t Value[], size_t ValueLength,
	const std::type_info & )
//=============================================================================
{
	my_CurrentCall.Parameters.push_back( string_t( Value, ValueLength ));

	return ( *this );
}




//=============================================================================
COutput &CError::DoFlush( void )
//=============================================================================
{
	my_CallStack.push_back( my_CurrentCall );

	my_CurrentCall.Parameters.clear();

	return ( *this );
}




//=============================================================================
void CError::CallStack( std::vector< SErrorCall > *CallStack ) const
//=============================================================================
{
	CallStack->resize( my_CallStack.size() );
	std::copy( my_CallStack.begin(), my_CallStack.end(), CallStack->begin() );
}


//=============================================================================
const char *CError::what( void ) const
	throw()
//=============================================================================
{
	if ( my_What.empty() )
		my_What = text( Description() );

	return ( my_What.c_str() );
}



//=============================================================================
const string_t &CError::Description( void ) const
	throw()
//=============================================================================
{
	return ( my_Description );
}


/*
//=============================================================================
COutput &operator << ( COutput &rOutput, const std::type_info &TypeInfo )
//=============================================================================
{
	size_t ValueLength = strlen( TypeInfo.name() );

	return ( rOutput.Write( text( TypeInfo.name() ), ValueLength, typeid( TypeInfo )));
}
*/


} // namespace AidKit
