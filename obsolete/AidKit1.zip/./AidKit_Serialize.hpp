#ifndef AIDKIT_SERIALIZE_HPP
#define AIDKIT_SERIALIZE_HPP

#include "AidKit.hpp"
#include "AidKit_Error.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Static.hpp"

#include <set>
#include <map>
#include <typeinfo>

namespace AidKit {

class CDeserializer;

//-----------------------------------------------------------------------------
class CDeserializable {
//-----------------------------------------------------------------------------
	public:
		CDeserializable( void );
		virtual ~CDeserializable( void );

		virtual bool Deserialize( CDeserializer * ) = 0;
		virtual void Assign( const CDeserializable & )
			throw ( std::bad_cast ) = 0;
};



class CSerializer;

//-----------------------------------------------------------------------------
class CSerializable {
//-----------------------------------------------------------------------------
	public:
		CSerializable( void );
		virtual ~CSerializable( void );

		virtual bool Serialize( CSerializer * ) const = 0;
		virtual string_t TypeName( void ) const = 0;
};


//-----------------------------------------------------------------------------
class CPersistentable : public CDeserializable, public CSerializable {
//-----------------------------------------------------------------------------
	public:
		CPersistentable( void );
		virtual ~CPersistentable( void );
};


//-----------------------------------------------------------------------------
class CSerializer {
//-----------------------------------------------------------------------------
	public:
		CSerializer( void );
		virtual ~CSerializer( void );

		bool Save( const CSerializable *pRoot );

		bool WriteBool(    const string_t &Name, bool Value );
		bool WriteInteger( const string_t &Name, int Value );
		bool WriteULong( const string_t &Name, unsigned long Value );
		bool WriteString(  const string_t &Name, const string_t &Value );
		bool WriteObject( const string_t &Name, const CSerializable *pObject );

	protected:
		virtual string_t DoGenerateObjectID( const CSerializable *pObject );

		virtual bool DoWriteBool(    const string_t &Section, const string_t &Name, bool Value ) = 0;
		virtual bool DoWriteInteger( const string_t &Section, const string_t &Name, int Value ) = 0;
		virtual bool DoWriteULong( const string_t &Section, const string_t &Name, unsigned long Value ) = 0;
		virtual bool DoWriteString(  const string_t &Section, const string_t &Name, const string_t &Value ) = 0;

	private:
		string_t my_Section;
		std::map< string_t, const CSerializable * > my_SerializedObjects;
};




//-----------------------------------------------------------------------------
class CDeserializer {
//-----------------------------------------------------------------------------
	public:
		typedef CDeserializable * ( DeserializableCreator_t )( void );

		static bool RegisterCreator( const string_t &TypeName, DeserializableCreator_t *pCreator );
		static CDeserializable *CreateObject( const string_t &TypeName );

		CDeserializer( void  );
		virtual ~CDeserializer( void );

		bool Load( CDeserializable *pRoot );

		bool ReadBool( const string_t &Name, bool *pValue );
		bool ReadBool( const string_t &Name, bool DefaultValue );

		bool ReadInteger( const string_t &Name, int *pValue );
		int ReadInteger(  const string_t &Name, int DefaultValue );

		bool ReadULong( const string_t &Name, unsigned long *pValue );
		unsigned long ReadULong(  const string_t &Name, unsigned long DefaultValue );

		bool ReadString(     const string_t &Name, string_t *pValue );
		string_t ReadString( const string_t &Name, const string_t &DefaultValue );

		bool ReadObject( const string_t &Name, CDeserializable *pObject );
		CDeserializable *ReadObject( const string_t &Name );

	protected:
		virtual CDeserializable *DoCreateObject( const string_t &ObjectID );

		virtual bool DoReadBool( const string_t &Section, const string_t &Name, bool *pValue ) = 0;
		virtual bool DoReadInteger( const string_t &Section, const string_t &Name, int *pValue ) = 0;
		virtual bool DoReadULong( const string_t &Section, const string_t &Name, unsigned long *pValue ) = 0;
		virtual bool DoReadString( const string_t &Section, const string_t &Name, string_t *pValue ) = 0;

	private:
		static TStatic< std::map< string_t, DeserializableCreator_t * > > our_CreatorMap;

		string_t my_Section;
		std::map< string_t, CDeserializable * > my_DeserializedObjects;
};



} // namespace AidKit

#endif
