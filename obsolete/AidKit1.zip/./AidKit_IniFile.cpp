#include "AidKit_IniFile.hpp"
#include "AidKit_String.hpp"
#include "AidKit_StdLibrary.hpp"

#include <cstdio>
#include <fstream>

#ifdef AIDKIT_MSC
	#pragma warning( disable : 4786 )
#endif

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CIniFile
//###
//#############################################################################
//#############################################################################
//#############################################################################

const string_t GLOBAL_SECTION_NAME( EMPTY_STRING );

//=============================================================================
CIniFile::CIniFile( void )
//=============================================================================
{
	Reset();
}


//=============================================================================
CIniFile::~CIniFile( void )
//=============================================================================
{
}



//=============================================================================
bool CIniFile::Load( CStdFile *pFile )
//=============================================================================
{
	bool IsLoaded = CPreferences::Load( pFile );

	if ( IsLoaded )
		DoLoad( pFile );

	return ( IsLoaded );
}



//=============================================================================
bool CIniFile::Save( CStdFile *pFile )
//=============================================================================
{
	bool IsSaved = CPreferences::Save( pFile );

	if ( IsSaved )
		DoSave( pFile );

	return ( IsSaved );
}



//=============================================================================
void CIniFile::Reset( void )
//=============================================================================
{
	my_Settings.clear();
	CreateSection( GLOBAL_SECTION_NAME );
}



//=============================================================================
bool CIniFile::WriteString( const string_t &Section, const string_t &Key, const string_t &Value )
//=============================================================================
{
	if ( !FindSection( Section ))
		CreateSection( Section );

	return ( WriteEntry( Key, Value ));
}



//=============================================================================
bool CIniFile::ReadString( const string_t &Section, const string_t &Key, string_t *pValue )
//=============================================================================
{
	return ( FindSection( Section ) && ReadEntry( Key, pValue ));
}




//=============================================================================
static bool IsSection( const string_t &Line, string_t *pSection )
//=============================================================================
{
	string_t::size_type Position;
	
	if ( Line[ 0 ] == TEXT( '[' ) && ( Position = Line.rfind( TEXT( ']' ))) != string_t::npos ) {
		*pSection = Line.substr( 1, Position - 1 );
		return ( true );
	} else {
		return ( false );
	}
}



//=============================================================================
static bool IsComment( const string_t &Line, string_t *pKey, string_t *pComment )
//=============================================================================
{
	if ( Line[ 0 ] == TEXT( ';' ) || Line[ 0 ] == TEXT( '#' )) {
		*pKey = Line.substr( 0, 1 );
		*pComment = Line.substr( 1 );
		return ( true );
	} else {
		return ( false );
	}
}



//=============================================================================
static bool IsValue( const string_t &Line, string_t *pKey, string_t *pValue )
//=============================================================================
{
	string_t::size_type Position;
	
	if (( Position = Line.find( TEXT( '=' ))) != string_t::npos ) {
		*pKey = Line.substr( 0, Position );
		*pValue = Line.substr( Position + 1 );
		return ( true );
	} else {
		return ( false );
	}
}



//=============================================================================
void CIniFile::DoLoad( CStdFile *pFile )
	throw ( CStdFileError )
//=============================================================================
{
	string_t Line;
	string_t Section, Comment, Key, Value;

	while ( pFile->GetLine( &Line, TEXT( '\n' ))) {
		if ( IsSection( Line, &Section )) {
			CreateSection( Section );
		}
		else if ( IsComment( Line, &Key, &Comment )) {
			string_t DecodedComment = decode_crlf( Comment );
			WriteEntry( Key, DecodedComment );
		}
		else if ( IsValue( Line, &Key, &Value )) {
			string_t DecodedValue = decode_crlf( Value );
			WriteEntry( Key, DecodedValue );
		}
	}
}



//=============================================================================
void CIniFile::DoSave( CStdFile *pFile ) const
	throw ( CStdFileError )
//=============================================================================
{
	CSettings::const_iterator itSection;
	CSection::const_iterator itEntry;

	for ( itSection = my_Settings.begin(); itSection != my_Settings.end(); ++itSection ) {
		/*
		// Open the file only if there is something to write:
		if ( !itSection->second.empty() ) {
			if ( !pFile->IsOpen() ) {
				pFile->Open( FileName , TEXT( "wt" ));
			}
			*/
			// We have to write the brackets, even if the section is empty, because
			// otherwise the next time we read the file we can't figure out where
			// those settings belong to:
			pFile->PrintF( TEXT( "[%s]\n" ), itSection->first.c_str() );
			for ( itEntry = itSection->second.begin(); itEntry != itSection->second.end(); ++itEntry ) {
				string_t EncodedValue = encode_crlf( itEntry->second );
				if ( itEntry->first[ 0 ] == TEXT( ';' ) || itEntry->first[ 0 ] == TEXT( '#' )) {
					pFile->PrintF( TEXT( "%s%s\n" ), itEntry->first.c_str(), EncodedValue.c_str() );
				} else {
					pFile->PrintF( TEXT( "%s=%s\n" ), itEntry->first.c_str(), EncodedValue.c_str() );
				}
			}
			pFile->PrintF( "\n" );
		// }
	}
}



//=============================================================================
bool CIniFile::CreateSection( const string_t &Section )
//=============================================================================
{
	pair< CSettings::iterator, bool > InsertPair;
	
	InsertPair = my_Settings.insert( CSettings::value_type( Section, CSection() ));
	my_itCurrentSection = InsertPair.first;
	
	return ( true );
}



//=============================================================================
bool CIniFile::EraseSection( const string_t &Section )
//=============================================================================
{
	CSettings::iterator itSection;
	
	if (( itSection = my_Settings.find( Section )) != my_Settings.end() ) {
		my_Settings.erase( itSection );
		
		if ( itSection == my_itCurrentSection ) // Did we erase the current section?
			FindSection( GLOBAL_SECTION_NAME );
	}
	return ( itSection != my_Settings.end() );
}



//=============================================================================
bool CIniFile::FindSection( const string_t &Section )
//=============================================================================
{
	CSettings::iterator itSection;
	
	if ( my_itCurrentSection->first == Section ) {
		itSection = my_itCurrentSection;
	} else {
		// If the section could not be found, then leave the current section unchanged:
		
		if (( itSection = my_Settings.find( Section )) != my_Settings.end() ) {
			my_itCurrentSection = itSection;
		}
	}
	return ( itSection != my_Settings.end() );
}



//=============================================================================
bool CIniFile::WriteEntry( const string_t &Key, const string_t &Value )
//=============================================================================
{
	pair< CSection::iterator, bool > InsertPair;
	
	InsertPair = my_itCurrentSection->second.insert( CSection::value_type( Key, Value ));
	InsertPair.first->second = Value;

	return ( true );
}



//=============================================================================
bool CIniFile::EraseEntry( const string_t &Key )
//=============================================================================
{
	my_itCurrentSection->second.erase( Key );

	return ( true );
}



//=============================================================================
bool CIniFile::ReadEntry( const string_t &Key, string_t *pValue ) const
//=============================================================================
{
	CSection::const_iterator itEntry;
	

	if (( itEntry = my_itCurrentSection->second.find( Key )) != my_itCurrentSection->second.end() )
		*pValue = itEntry->second;

	return ( itEntry != my_itCurrentSection->second.end() );
}

} // namespace AidKit


#if 0
int main( void )
{
	char Path[ 400 ];
	CIniFile Configuration;
	string_t Value;
	
	printf( "Current Directory = '%s'\n", getcwd( Path, sizeof( Path )));
	Configuration.Load( "/home/peter/Debugger.ini" );
	
	/* Configuration.CreateSection( "Debugger" );
	Configuration.WriteEntry( "Trace", "1" );
	Configuration.WriteEntry( "Dump", "0" );
	*/

	Configuration.Save( "/home/peter/Test.ini" );
		
	/* Configuration.CreateSection( "Debug" );
	
	Configuration.WriteEntry( ";", "Settings" );
	Configuration.WriteEntry( "Trace", "0" );
	Configuration.WriteEntry( "Dump", "1" );
	
	Configuration.Save( "Debugger.ini" );
	*/
	
	return ( 0 );
}
#endif
