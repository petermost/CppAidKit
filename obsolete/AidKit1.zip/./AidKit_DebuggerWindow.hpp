#ifndef AIDKIT_DEBUGGERWINDOW_HPP
#define AIDKIT_DEBUGGERWINDOW_HPP

#include "AidKit_Compiler.hpp"

#if defined( AIDKIT_WINDOWS )

#include "AidKit_DebuggerDisplay.hpp"
#include "AidKit_Unicode.hpp"

#include <afxwin.h>
#include <afxcmn.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CDebuggerDisplayGadget : public CListCtrl {
	//-----------------------------------------------------------------------------
		public:
			CDebuggerDisplayGadget( unsigned MaxEntries = 1000 ); 
			~CDebuggerDisplayGadget( void );

			BOOL Create( CWnd *ParentWnd, UINT ControlID = AFX_IDW_PANE_FIRST );

			void Write( const char_t Data[] );

		private:
			const unsigned my_MaxEntries;
			int my_EntriesCount;
	};


	//-----------------------------------------------------------------------------
	class CDebuggerWindow : public CFrameWnd, public CDebuggerDisplay {
	//-----------------------------------------------------------------------------
		public:
			static CDebuggerWindow *Instance( void );
			static void DestroyInstance( void );

			void Write( const char_t Data[] );

		private:
			CDebuggerWindow( void );
			virtual ~CDebuggerWindow( void );

			BOOL Create( void );

			static CDebuggerWindow *our_pSingleInstance;

			CMenu my_MainMenu;
			CMenu my_DebugMenu;
			CMenu my_HelpMenu;

			CDebuggerDisplayGadget my_DisplayGadget;

			afx_msg void OnCrash();
			afx_msg void OnAbout();
			afx_msg void OnClose();
			DECLARE_MESSAGE_MAP()
	};
}

#endif

#endif
