#ifndef AIDKIT_STORED_FUNCTION_HPP
#define AIDKIT_STORED_FUNCTION_HPP

// Don't try to add a return type as a template parameter! MSC can't handle
// return ( VoidFunction() ). One workaround would be with partial template
// specialication, but MSC doesn't support them either.

#include "AidKit.hpp"

namespace AidKit {


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CStoredFunction
//###
//#############################################################################
//#############################################################################
//#############################################################################

	//-----------------------------------------------------------------------------
	class CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			virtual ~CStoredFunction( void );

			virtual void operator()( void ) const = 0;
	};


//#############################################################################
//
// TGenericStoredFunction0, TGenericStoredMethod0, TStoredFunction0, TStoredMethod0
//
//#############################################################################

template < typename F >
	//-----------------------------------------------------------------------------
	class TGenericStoredFunction0 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredFunction0( F Function )
				: my_Function( Function )
					{ }

			void operator()( void ) const
				{ my_Function(); }

		private:
			F my_Function;
	};


template < typename C, typename M >
	//-----------------------------------------------------------------------------
	class TGenericStoredMethod0 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredMethod0( C pCallee, M pMethod )
				: my_pCallee( pCallee ), my_pMethod( pMethod )
					{ }

			void operator()( void ) const
				{ ( my_pCallee->*my_pMethod )(); }

		private:
			C my_pCallee;
			M my_pMethod;
	};


	//-----------------------------------------------------------------------------
	class TStoredFunction0 : public TGenericStoredFunction0< void ( * )( void ) > {
	//-----------------------------------------------------------------------------
		public:
			TStoredFunction0( void ( *pFunction )( void ))
				: TGenericStoredFunction0< void ( * )( void ) >( pFunction )
					{ }
	};


template < typename C >
	//-----------------------------------------------------------------------------
	class TStoredMethod0 : public TGenericStoredMethod0< C *, void ( C:: * )( void ) > {
	//-----------------------------------------------------------------------------
		public:
			TStoredMethod0( C *pCallee, void ( C::*pMethod )( void ))
				: TGenericStoredMethod0< C , void ( C:: * )( void ) >( pCallee, pMethod )
					{ }
	};


//#############################################################################
//
// TGenericStoredFunction1, TGenericStoredMethod1, TStoredFunction1, TStoredMethod1
//
//#############################################################################

template < typename F, typename P1 >
	//-----------------------------------------------------------------------------
	class TGenericStoredFunction1 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredFunction1( F Function, P1 p1 )
				: my_Function( Function ), my_p1( p1 )
					{ }

			void operator()( void ) const
				{ my_Function( my_p1 ); }

		private:
			F my_Function;
			P1 my_p1;
	};


template < typename C, typename M, typename P1 >
	//-----------------------------------------------------------------------------
	class TGenericStoredMethod1 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredMethod1( C pCallee, M pMethod, P1 p1 )
				: my_pCallee( pCallee ), my_pMethod( pMethod ), my_p1( p1 )
					{ }

			void operator()( void ) const
				{ ( my_pCallee->*my_pMethod )( my_p1 ); }

		private:
			C my_pCallee;
			M my_pMethod;
			P1 my_p1;
	};


template < typename P1 >
	//-----------------------------------------------------------------------------
	class TStoredFunction1 : public TGenericStoredFunction1< void ( * )( P1 ), P1 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredFunction1( void ( *pFunction )( P1 ), P1 p1 )
				: TGenericStoredFunction1< void ( * )( P1 ), P1 >( pFunction, p1 )
					{ }
	};


template < typename C, typename P1 >
	//-----------------------------------------------------------------------------
	class TStoredMethod1 : public TGenericStoredMethod1< C *, void ( C::* )( P1 ), P1 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredMethod1( C *pCallee, void ( C:: *pMethod )( P1 ), P1 p1 )
				: TGenericStoredMethod1< C *, void ( C::* )( P1 ), P1 >( pCallee, pMethod, p1 )
					{ }
	};


//#############################################################################
//
// TGenericStoredFunction2, TGenericStoredMethod2, TStoredFunction2, TStoredMethod2
//
//#############################################################################

template < typename F, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TGenericStoredFunction2 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredFunction2( F Function, P1 p1, P2 p2 )
				: my_Function( Function ), my_p1( p1 ), my_p2( p2 )
					{ }

			void operator()( void ) const
				{ my_Function( my_p1, my_p2 ); }

		private:
			F my_Function;
			P1 my_p1;
			P2 my_p2;
	};


template < typename C, typename M, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TGenericStoredMethod2 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredMethod2( C pCallee, M pMethod, P1 p1, P2 p2 )
				: my_pCallee( pCallee ), my_pMethod( pMethod ), my_p1( p1 ), my_p2( p2 )
					{ }

			void operator()( void ) const
				{ ( my_pCallee->*my_pMethod )( my_p1, my_p2 ); }

		private:
			C my_pCallee;
			M my_pMethod;
			P1 my_p1;
			P2 my_p2;
	};


template < typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TStoredFunction2 : public TGenericStoredFunction2< void ( * )( P1, P2 ), P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredFunction2( void ( *pFunction )( P1, P2 ), P1 p1, P2 p2 )
				: TGenericStoredFunction2< void ( * )( P1, P2 ), P1, P2 >( pFunction, p1, p2 )
					{ }
	};


template < typename C, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TStoredMethod2 : public TGenericStoredMethod2< C *, void ( C::* )( P1, P2 ), P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredMethod2( C *pCallee, void ( C::*pMethod )( P1, P2 ), P1 p1, P2 p2 )
				: TGenericStoredMethod2< C *, void ( C::* )( P1, P2 ), P1, P2 >( pCallee, pMethod, p1, p2 )
					{ }
	};


//#############################################################################
//
// TGenericStoredFunction3, TGenericStoredMethod3, TStoredFunction3, TStoredMethod3
//
//#############################################################################


template < typename F, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TGenericStoredFunction3 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredFunction3( F Function, P1 p1, P2 p2, P3 p3 )
				: my_Function( Function ), my_p1( p1 ), my_p2( p2 ), my_p3( p3 )
					{ }

			void operator()( void ) const
				{ my_Function( my_p1, my_p2, my_p3 ); }

		private:
			F my_Function;
			P1 my_p1;
			P2 my_p2;
			P3 my_p3;
	};


template < typename C, typename M, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TGenericStoredMethod3 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredMethod3( C pCallee, M pMethod, P1 p1, P2 p2, P3 p3 )
				: my_pCallee( pCallee ), my_pMethod( pMethod ), my_p1( p1 ), my_p2( p2 ), my_p3( p3 )
					{ }

			void operator()( void ) const
				{ ( my_pCallee->*my_pMethod )( my_p1, my_p2, my_p3 ); }

		private:
			C my_pCallee;
			M my_pMethod;
			P1 my_p1;
			P2 my_p2;
			P3 my_p3;
	};


template < typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TStoredFunction3 : public TGenericStoredFunction3< void ( * )( P1, P2, P3 ), P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredFunction3( void ( *pFunction )( P1, P2, P3 ), P1 p1, P2 p2, P3 p3 )
				: TGenericStoredFunction3< void ( * )( P1, P2, P3 ), P1, P2, P3 >( pFunction, p1, p2, p3 )
					{ }
	};


template < typename C, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TStoredMethod3 : public TGenericStoredMethod3< C *, void ( C::* )( P1, P2, P3 ), P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredMethod3( C *pCallee, void ( C::*pMethod )( P1, P2, P3 ), P1 p1, P2 p2, P3 p3 )
				: TGenericStoredMethod3< C *, void ( C::* )( P1, P2, P3 ), P1, P2, P3 >( pCallee, pMethod, p1, p2, p3 )
					{ }
	};




//#############################################################################
//
// TGenericStoredFunction4, TGenericStoredMethod4, TStoredFunction4, TStoredMethod4
//
//#############################################################################

template < typename F, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TGenericStoredFunction4 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredFunction4( F Function, P1 p1, P2 p2, P3 p3, P4 p4 )
				: my_Function( Function ), my_p1( p1 ), my_p2( p2 ), my_p3( p3 ), my_p4( p4 )
					{ }

			void operator()( void ) const
				{ my_Function( my_p1, my_p2, my_p3, my_p4 ); }

		private:
			F my_Function;
			P1 my_p1;
			P2 my_p2;
			P3 my_p3;
			P4 my_p4;
	};

template < typename C, typename M, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TGenericStoredMethod4 : public CStoredFunction {
	//-----------------------------------------------------------------------------
		public:
			TGenericStoredMethod4( C pCallee, M pMethod, P1 p1, P2 p2, P3 p3, P4 p4 )
				: my_pCallee( pCallee ), my_pMethod( pMethod ), my_p1( p1 ), my_p2( p2 ), my_p3( p3 ), my_p4( p4 )
					{ }

			void operator()( void ) const
				{ ( my_pCallee->*my_pMethod )( my_p1, my_p2, my_p3, my_p4 ); }

		private:
			C my_pCallee;
			M my_pMethod;
			P1 my_p1;
			P2 my_p2;
			P3 my_p3;
			P4 my_p4;
	};


template < typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TStoredFunction4 : public TGenericStoredFunction4< void ( * )( P1, P2, P3, P4 ), P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredFunction4( void ( *pFunction )( P1, P2, P3, P4 ), P1 p1, P2 p2, P3 p3, P4 p4 )
				: TGenericStoredFunction4< void ( * )( P1, P2, P3, P4 ), P1, P2, P3, P4 >( pFunction, p1, p2, p3, p4 )
					{ }
	};


template < typename C, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TStoredMethod4 : public TGenericStoredMethod4< C *, void ( C::* )( P1, P2, P3, P4 ), P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TStoredMethod4( C *pCallee, void ( C::*pMethod )( P1, P2, P3, P4 ), P1 p1, P2 p2, P3 p3, P4 p4 )
				: TGenericStoredMethod4< C *, void ( C::* )( P1, P2, P3, P4 ), P1, P2, P3, P4 >( pCallee, pMethod, p1, p2, p3, p4 )
					{ }
	};


} // namespace AidKit


#endif
