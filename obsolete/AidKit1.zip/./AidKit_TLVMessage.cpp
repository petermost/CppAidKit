#include "AidKit_TLVMessage.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Memory.hpp"
#include "AidKit_StlHelper.hpp"
// #include "AidKit_StdLibrary.hpp"

#include <algorithm>

using namespace std;

namespace AidKit {



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTLVTransmitter
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CTLVTransmitter::CTLVTransmitter( CSocketConnection *pConnection,
	milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime, bool IsNotifiable )
		: my_BWT( BlockWaitingTime ), my_CWT( CharWaitingTime )
		, my_IsNotifiable( IsNotifiable ), my_pConnection( pConnection )
//=============================================================================
{
}



//=============================================================================
CTLVTransmitter::~CTLVTransmitter( void )
//=============================================================================
{
}



//=============================================================================
bool CTLVTransmitter::SendHeader( INT32 Tag, INT32 Length )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	INT32 Buffer[ 2 ];

	// Write the tag, length to the memory and send it:

	void *pBuffer = Buffer;
	size_t BufferLength = sizeof( Buffer );

	memory_write( &pBuffer, &BufferLength, Tag );
	memory_write( &pBuffer, &BufferLength, Length );

	return ( my_pConnection->Write( Buffer, sizeof( Buffer ), my_BWT, my_CWT, my_IsNotifiable ) == sizeof( Buffer ));
}



//=============================================================================
bool CTLVTransmitter::SendValue( INT32 Length, const void *pValue )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( pValue != NULL );

	// Send the value:

	return ( Length > 0 && my_pConnection->Write( pValue, Length, my_BWT, my_CWT, my_IsNotifiable ) == Length );
}



//=============================================================================
bool CTLVTransmitter::ReceiveHeader( INT32 *pTag, INT32 *pLength )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	INT32 Buffer[ 2 ];

	// Receive the header and extract tag,length from the memory:

	size_t BufferLength = my_pConnection->Read( Buffer, sizeof( Buffer ), my_BWT, my_CWT, my_IsNotifiable );
	if ( BufferLength == sizeof( Buffer )) {
		const void *pBuffer = Buffer;
		memory_read( &pBuffer, &BufferLength, pTag );
		memory_read( &pBuffer, &BufferLength, pLength );

		return ( true );
	} else
		return ( false );
}



//=============================================================================
bool CTLVTransmitter::ReceiveValue( INT32 Length, void *pValue )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( pValue != NULL );

	// Receive the value:

	return ( Length > 0 && my_pConnection->Read( pValue, Length, my_BWT, my_CWT, my_IsNotifiable ) == Length );
}


//=============================================================================
bool CTLVTransmitter::SendData( INT32 Length, file_t hDataFile, off_t *pDataOffset )
	throw ( CSocketError, assertion_error )
//=============================================================================
{
	return ( my_pConnection->Write( hDataFile, pDataOffset, Length, my_BWT, my_CWT, my_IsNotifiable ) == Length );
}



//=============================================================================
bool CTLVTransmitter::SendData( INT32 Length, const TCall2< size_t, void *, size_t > &Produce,
	CMemory *pScratchBuffer )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( pScratchBuffer != NULL && pScratchBuffer->Size() > 0 );

	size_t MaxLength, nProduced, nWritten;

	while ( Length > 0 ) {
		MaxLength = MIN( Length, pScratchBuffer->Size() );
		if (( nProduced = Produce( pScratchBuffer->Start(), MaxLength )) > 0 ) {
			if (( nWritten = my_pConnection->Write( pScratchBuffer->Start(), nProduced, my_BWT, my_CWT, my_IsNotifiable )) > 0 )
				Length -= nWritten;
			else
				break;
		} else
			break;
	}
	return ( Length == 0 );
}



//=============================================================================
bool CTLVTransmitter::ReceiveData( INT32 Length, const TCall2< size_t, const void *, size_t > &Consume,
	CMemory *pScratchBuffer )
		throw ( CSocketError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( pScratchBuffer != NULL && pScratchBuffer->Size() > 0 );

	size_t MaxLength, nRead, nConsumed;

	while ( Length > 0 ) {
		MaxLength = MIN( Length, pScratchBuffer->Size() );
		if (( nRead = my_pConnection->Read( pScratchBuffer->Start(), MaxLength, my_BWT, my_CWT, my_IsNotifiable )) > 0 ) {
			if (( nConsumed = Consume( pScratchBuffer->Start(), nRead )) > 0 )
				Length -= nConsumed;
			else
				break;
		} else
			break;
	}
	return ( Length == 0 );
}






//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTLVTransmitterHelper
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CTLVTransmitterHelper::CTLVTransmitterHelper( CSocketConnection *pConnection,
	milliseconds_t BlockWaitingTime, milliseconds_t CharWaitingTime )
		: CTLVTransmitter( pConnection, BlockWaitingTime, CharWaitingTime )
//=============================================================================
{
}


//=============================================================================
bool CTLVTransmitterHelper::ReceiveIntegerValues( INT32 Length, vector< INT32 > *pValues )
	throw ( CSocketError, assertion_error, bad_alloc )
//=============================================================================
{
	INT32 Value;

	pValues->clear();

	CMemory Buffer( Length );
	if ( ReceiveValue( Length, Buffer.Start() )) {
		const void *pBuffer = Buffer.Start();
		size_t BufferSize = Buffer.Size();

		memory_read( &pBuffer, &BufferSize, &Value );
		pValues->push_back( Value );

		return ( true );
	} else
		return ( false );
}




//=============================================================================
bool CTLVTransmitterHelper::ReceiveStringValue( INT32 Length, string_t *pValue )
	throw ( CSocketError, assertion_error, bad_alloc )
//=============================================================================
{
	string_clear( pValue );
	pValue->reserve( Length );

	CMemory Buffer( Length );
	if ( ReceiveValue( Length, Buffer.Start() )) {
		pValue->append( reinterpret_cast< const char_t * >( Buffer.Start() ), Length );

		return ( true );
	} else
		return ( false );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TTLV
//###
//#############################################################################
//#############################################################################
//#############################################################################



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	TTLV< CTag, CLength, CValue, CTraits >::TTLV( CTag Tag, const void *pValue, CLength Length )
	//=============================================================================
	{
		my_Tag = Tag;
		if ( pValue != NULL && Length != CLength() ) {
			copy( static_cast< const CValue * >( pValue ), static_cast< const CValue * >( pValue ) + Length,
				back_inserter( my_Value ));
		}
	}


template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	void TTLV< CTag, CLength, CValue, CTraits >::Reset( void )
	//=============================================================================
	{
		my_Tag = CTag();
		my_Value.clear();
	}


template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	TTLV< CTag, CLength, CValue, CTraits > &TTLV< CTag, CLength, CValue, CTraits >::operator += ( const CValue &Value )
	//=============================================================================
	{
		my_Value.push_back( Value );

		return ( *this );
	}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	size_t TTLV< CTag, CLength, CValue, CTraits >::ReadMemory( const void *pMemory, size_t MemorySize )
	//=============================================================================
	{
		CLength Length;
		size_t Size = 0;
		
		Reset();

		if ( MemorySize >= sizeof( CTag ) + sizeof( CLength )) {

			// Read the header:

			Size += memory_read( &pMemory, &MemorySize, &my_Tag );
			Size += memory_read( &pMemory, &MemorySize, &Length );

			// Read the value:

			CTraits::Reserve( &my_Value, Length );
			while ( Length > 0 ) {
				CValue Value;
				size_t ValueSize = CTraits::Read( pMemory, MemorySize, &Value );
				*this += Value;
				Size += memory_advance< BYTE >( &pMemory, &MemorySize, ValueSize );
				Length -= ValueSize;
			}
		} else
			Size = 0;

		if ( Size == 0 )
			Reset();

		return ( Size );
	}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	size_t TTLV< CTag, CLength, CValue, CTraits >::WriteMemory( void *pMemory, size_t MemorySize ) const
	//=============================================================================
	{
		CLength Length;
		size_t Size = 0;

		if ( MemorySize >= sizeof( CTag ) + sizeof( CLength )) {

			// Write the header:

			Size += memory_write( &pMemory, &MemorySize, my_Tag );
			Length = this->Length();
			Size += memory_write( &pMemory, &MemorySize, Length );

			// Write the content:

			size_t ValueIdx = 0;
			while ( Length > 0 ) {
				const CValue &rValue = vector_at( my_Value, ValueIdx );
				size_t ValueSize = CTraits::Write( pMemory, MemorySize, rValue );
				Size += memory_advance< BYTE >( &pMemory, &MemorySize, ValueSize );
				Length -= ValueSize;
			}
		} else
			Size = 0;

		return ( Size );
}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	CTag TTLV< CTag, CLength, CValue, CTraits >::Tag( void ) const
	//=============================================================================
	{
		return ( my_Tag );
	}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	CLength TTLV< CTag, CLength, CValue, CTraits >::Length( void ) const
	//=============================================================================
	{
		size_t nLength = 0;

		for ( size_t i = 0; i < my_Value.size(); ++i )
			nLength += CTraits::Size( vector_at( my_Value, i ));

		return ( nLength );
	}


template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	size_t TTLV< CTag, CLength, CValue, CTraits >::Size( void ) const
	//=============================================================================
	{
		return ( sizeof( CTag ) + sizeof( CLength ) + Length() );
	}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	size_t TTLV< CTag, CLength, CValue, CTraits >::Count( void ) const
	//=============================================================================
	{
		return ( my_Value.size() );
	}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	const CValue &TTLV< CTag, CLength, CValue, CTraits >::At( size_t i ) const
	//=============================================================================
	{
		return ( vector_at( my_Value, i ));
	}



template < typename CTag, typename CLength, typename CValue, typename CTraits >
	//=============================================================================
	const CValue *TTLV< CTag, CLength, CValue, CTraits >::Find( CTag Tag ) const
	//=============================================================================
	{
		const CValue *pValue = NULL;
		typename vector< CValue >::const_iterator itValue;

		for ( itValue = my_Value.begin(); itValue != my_Value.end(); ++itValue ) {
			if ( itValue->Tag() == Tag ) {
				pValue = &*itValue;
				break;
			}
		}
		return ( pValue );
	}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTLVField
//###
//#############################################################################
//#############################################################################
//#############################################################################

template < >
	class TValueTraits< BYTE > {
		public:
			static void Reserve( vector< BYTE > *pValues, size_t Length )
				{ pValues->reserve( Length ); }

			static size_t Write( void *pMemory, size_t MemorySize, const BYTE &Value )
				{ return ( memory_write( &pMemory, &MemorySize, Value )); }

			static size_t Read( const void *pMemory, size_t MemorySize, BYTE *pValue )
				{ return ( memory_read( &pMemory, &MemorySize, pValue )); }

			static size_t Size( const BYTE &Value )
				{ return ( sizeof( Value )); }
		};


//=============================================================================
CTLVField::CTLVField( INT32 Tag, const void *pValue, size_t ValueLength )
	: my_Content( Tag, pValue, ValueLength )
//=============================================================================
{
}


//=============================================================================
CTLVField::~CTLVField( void )
//=============================================================================
{
}



//=============================================================================
INT32 CTLVField::Tag( void ) const
//=============================================================================
{
	return ( my_Content.Tag() );
}



//=============================================================================
INT32 CTLVField::Length( void ) const
//=============================================================================
{
	return ( my_Content.Length() );
}


//=============================================================================
size_t CTLVField::Size( void ) const
//=============================================================================
{
	return ( my_Content.Size() );
}



//=============================================================================
size_t CTLVField::Count( void ) const
//=============================================================================
{
	return ( my_Content.Count() );
}



//=============================================================================
INT32 CTLVField::LengthForInt16( void ) const
//=============================================================================
{
	return ( my_Content.Length() / sizeof( INT16 ));
}



//=============================================================================
INT32 CTLVField::LengthForInt32( void ) const
//=============================================================================
{
	return ( my_Content.Length() / sizeof( INT32 ));
}



//=============================================================================
BYTE CTLVField::At( size_t Index ) const
	throw ( out_of_range )
//=============================================================================
{
	return ( my_Content.At( Index ));
}



//=============================================================================
INT16 CTLVField::AsInt16At( size_t Index ) const
	throw ( out_of_range )
//=============================================================================
{
	if ( Index < LengthForInt16() ) {
		const INT16 *pInt16 = reinterpret_cast< const INT16 * >( &my_Content.At( 0 ));
		return ( pInt16[ Index ] );
	} else
		throw ( out_of_range( "AidKit::CTLVField::AsInt16At" ));
}




//=============================================================================
INT32 CTLVField::AsInt32At( size_t Index ) const
	throw ( out_of_range )
//=============================================================================
{
	if ( Index < LengthForInt32() ) {
		const INT32 *pInt32 = reinterpret_cast< const INT32 * >( &my_Content.At( 0 ));
		return ( pInt32[ Index ] );
	} else
		throw ( out_of_range( "AidKit::CTLVField::AsInt32At" ));
}



//=============================================================================
string_t CTLVField::AsString( void ) const
//=============================================================================
{
	return ( string_t( reinterpret_cast< const char_t * >( &my_Content.At( 0 )), my_Content.Length() / sizeof( char_t )));
}



//=============================================================================
size_t CTLVField::ReadMemory( const void *pMemory, size_t MemorySize )
//=============================================================================
{
	return ( my_Content.ReadMemory( pMemory, MemorySize ));
}


//=============================================================================
size_t CTLVField::WriteMemory( void *pMemory, size_t MemorySize ) const
//=============================================================================
{
	return ( my_Content.WriteMemory( pMemory, MemorySize ));
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTLVMessage
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < >
	class TValueTraits< CTLVField > {
		public:
			static void Reserve( vector< CTLVField > *, size_t )
				{ }

			static size_t Write( void *pMemory, size_t MemorySize, const CTLVField &Value )
				{ return ( Value.WriteMemory( pMemory, MemorySize )); }

			static size_t Read( const void *pMemory, size_t MemorySize, CTLVField *pValue )
				{ return ( pValue->ReadMemory( pMemory, MemorySize )); }

			static size_t Size( const CTLVField &Value )
				{ return ( Value.Size() ); }
	};



//=============================================================================
CTLVMessage::CTLVMessage( INT32 Tag )
	: my_Fields( Tag )
//=============================================================================
{
}


//=============================================================================
CTLVMessage::~CTLVMessage( void )
//=============================================================================
{
}



//=============================================================================
CTLVMessage &CTLVMessage::operator += ( const CTLVField &Field )
//=============================================================================
{
	my_Fields += Field;

	return ( *this );
}



//=============================================================================
void CTLVMessage::Reset( void )
//=============================================================================
{
	my_Fields.Reset();
}



//=============================================================================
size_t CTLVMessage::ReadMemory( const void *pMemory, size_t MemorySize )
//=============================================================================
{
	return ( my_Fields.ReadMemory( pMemory, MemorySize ));
}



//=============================================================================
size_t CTLVMessage::WriteMemory( void *pMemory, size_t MemorySize ) const
//=============================================================================
{
	return ( my_Fields.WriteMemory( pMemory, MemorySize ));
}



//=============================================================================
INT32 CTLVMessage::Tag( void ) const
//=============================================================================
{
	return ( my_Fields.Tag() );
}



//=============================================================================
INT32 CTLVMessage::Length( void ) const
//=============================================================================
{
	return ( my_Fields.Length() );
}



//=============================================================================
size_t CTLVMessage::Size( void ) const
//=============================================================================
{
	return ( my_Fields.Size() );
}



//=============================================================================
size_t CTLVMessage::Count( void ) const
//=============================================================================
{
	return ( my_Fields.Count() );
}



//=============================================================================
const CTLVField &CTLVMessage::At( size_t Index ) const
	throw ( out_of_range )
//=============================================================================
{
	return ( my_Fields.At( Index ));
}


//=============================================================================
const CTLVField *CTLVMessage::Find( INT32 FieldTag ) const
//=============================================================================
{
	return ( my_Fields.Find( FieldTag ));
}



} // namespace AidKit




/*
//=============================================================================
void CTLVField::set_content( const void *Value, size_t ContentLength, bool EraseFirst )
//=============================================================================
{
	if ( EraseFirst ) {
		my_Value.clear();
		my_Length = 0;
	}
	copy( static_cast< const BYTE * >( Value ), static_cast< const BYTE * >( Value ) + ContentLength, back_inserter( my_Value ));
	my_Length += ContentLength;

	Validate();
}
*/


/*
//=============================================================================
void CTLVField::AppendContent( const INT32 *Value, size_t ContentLength )
//=============================================================================
{
	set_content( Value, ContentLength * sizeof( INT32 ), false );
}
*/


