#include "AidKit_Compiler.hpp"

#if defined( AIDKIT_MSC )
	// #pragma warning( push, 4 )

	#pragma warning( disable : 4018 ) // signed/unsigned mismatch
	#pragma warning( disable : 4097 ) // typedef-name '...' used as synonym for class-name '...'
	#pragma warning( disable : 4503 ) // decorated name length exceeded, name was truncated
	#pragma warning( disable : 4511 ) // copy constructor could not be generated
	#pragma warning( disable : 4512 ) // assignment operator could not be generated
	#pragma warning( disable : 4514 ) // unreferenced inline function has been removed
	#pragma warning( disable : 4786 ) // identifier was truncated to '255' characters in the browser information
	#pragma warning( disable : 4245 ) // 'initializing' : conversion from '...' to '...', signed/unsigned mismatch
	#pragma warning( disable : 4355 ) // 'this' : used in base member initializer list
#endif
