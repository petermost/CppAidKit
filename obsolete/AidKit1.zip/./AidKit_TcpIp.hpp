#ifndef AIDKIT_TCPIP_HPP
#define AIDKIT_TCPIP_HPP

#include "AidKit.hpp"
#include "AidKit_Types.hpp"
#include "AidKit_Unicode.hpp"
#include <string>

struct hostent;

namespace AidKit {

	class CTcpIpAddress {
		public:
			CTcpIpAddress( void );
			CTcpIpAddress( const hostent *pHost, unsigned Port );
			CTcpIpAddress( const string_t &String, unsigned Port );
			CTcpIpAddress( BYTE Byte0, BYTE Byte1, BYTE Byte2, BYTE Byte3, unsigned Port );

			bool operator == ( const CTcpIpAddress &Other ) const;
			bool operator != ( const CTcpIpAddress &Other ) const;

			bool IsEmpty( void ) const;

			const string_t Host( void ) const;
			unsigned Port( void ) const;

			void AsBytes( BYTE *pByte0, BYTE *pByte1, BYTE *pByte2, BYTE *pByte3, unsigned *pPort ) const;

		private:
			int my_Field0, my_Field1, my_Field2, my_Field3;
			unsigned my_Port;
	};

}

#endif
