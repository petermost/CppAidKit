#include "AidKit_DebuggerManager.hpp"
#include "AidKit_Text.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_Application.hpp"
#include "AidKit_Preferences.hpp"
#include "AidKit_SingletonManager.hpp"
#include "AidKit_Warnings.hpp"

#if defined( AIDKIT_WINDOWS )

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDebuggerManager
//###
//#############################################################################
//#############################################################################
//#############################################################################

CDebuggerManager *CDebuggerManager::our_pInstance = NULL;

//=============================================================================
CDebuggerManager *CDebuggerManager::Instance( void )
//=============================================================================
{
	if ( our_pInstance == NULL ) {
		our_pInstance = new CDebuggerManager;
		CSingletonManager::Instance()->RegisterSingleton( &DestroyInstance );
	}
	return ( our_pInstance );
}



//=============================================================================
void CDebuggerManager::DestroyInstance( void )
//=============================================================================
{
	if ( our_pInstance != NULL ) {
		delete our_pInstance;
		our_pInstance = NULL;
		CSingletonManager::Instance()->UnregisterSingleton( &DestroyInstance );
	}
}


//=============================================================================
CDebuggerManager::CDebuggerManager( void )
	: my_Debugger( TEXT( "CDebuggerManager" ), false, false )
	, my_SettingsChangedHandler( this, &CDebuggerManager::OnSettingsChanged )
	, my_LoadSettingsHandler( this, &CDebuggerManager::OnLoadSettings )
	, my_SaveSettingsHandler( this, &CDebuggerManager::OnSaveSettings )
//=============================================================================
{
	if ( IsDebugging() ) {
		CDebugger::LoadSettingsEvt += my_LoadSettingsHandler;
		CDebugger::SaveSettingsEvt += my_SaveSettingsHandler;

	}
}



//=============================================================================
CDebuggerManager::~CDebuggerManager( void )
//=============================================================================
{
	if ( IsDebugging() ) {
		CDebugger::LoadSettingsEvt -= my_LoadSettingsHandler;
		CDebugger::SaveSettingsEvt -= my_SaveSettingsHandler;
	}
}



//=============================================================================
void CDebuggerManager::ObserveSettings( void )
//=============================================================================
{
	if ( IsDebugging() ) {
		my_IniFileObserver.Observe( CApplication::Instance()->DebuggerPreferences()->Name(), &my_SettingsChangedHandler );
	}
}



//=============================================================================
void CDebuggerManager::UnobserveSettings( void )
//=============================================================================
{
	if ( IsDebugging() ) {
		my_IniFileObserver.Unobserve();
	}
}



//=============================================================================
void CDebuggerManager::OnSettingsChanged( CFileObserver *, const char_t FileName[] )
//=============================================================================
{
	if ( IsDebugging() ) {
		CPreferences *pPreferences = CApplication::Instance()->DebuggerPreferences();
		AIDKIT_ASSERT( str_cmp( FileName, pPreferences->Name() ) == 0 );

		pPreferences->Load();
		CDebugger::LoadDebuggerSettings( pPreferences );
		CDebugger::SaveDebuggerSettings( pPreferences );

		my_IniFileObserver.IgnoreChanges( true );
		pPreferences->Save();
		my_IniFileObserver.IgnoreChanges( false );
	}
}



//=============================================================================
void CDebuggerManager::OnLoadSettings( CDebugger *pDebugger )
//=============================================================================
{
	if ( IsDebugging() ) {
		pDebugger->LoadSettings( CApplication::Instance()->DebuggerPreferences() );

		my_IniFileObserver.IgnoreChanges( true );
		pDebugger->SaveSettings( CApplication::Instance()->DebuggerPreferences() );
		my_IniFileObserver.IgnoreChanges( false );
	}
}



//=============================================================================
void CDebuggerManager::OnSaveSettings( const CDebugger *pDebugger )
//=============================================================================
{
	if ( IsDebugging() ) {
	}
}



} // namespace AidKit

#endif
