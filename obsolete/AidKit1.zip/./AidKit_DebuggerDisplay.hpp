#ifndef AIDKIT_DEBUGGER_DISPLAY_HPP
#define AIDKIT_DEBUGGER_DISPLAY_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <stdio.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CDebuggerDisplay {
	//-----------------------------------------------------------------------------
		public:
			CDebuggerDisplay( void );
			virtual ~CDebuggerDisplay( void );
			
			virtual void Write( const char_t Data[] );

		private:
			CDebuggerDisplay( const CDebuggerDisplay & );
			CDebuggerDisplay &operator = ( const CDebuggerDisplay & );
	};


	//-----------------------------------------------------------------------------
	class CDebuggerFile : public CDebuggerDisplay {
	//-----------------------------------------------------------------------------
		public:
			CDebuggerFile( FILE *File = NULL );
			~CDebuggerFile( void );

			virtual void Write( const char_t Data[] );

		private:
			CDebuggerFile( const CDebuggerFile & );
			CDebuggerFile &operator = ( const CDebuggerFile & );

			FILE *my_File;
	};

}

#endif
