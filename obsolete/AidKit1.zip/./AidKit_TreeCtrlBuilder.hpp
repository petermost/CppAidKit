#ifndef AIDLIB_TREE_CTRL_BUILDER_HPP
#define AIDLIB_TREE_CTRL_BUILDER_HPP

#include "AidLib.hpp"
#include <afxcmn.h>
#include <stack>

namespace AidLib {

	class CTreeCtrlBuilder {
		public:
			CTreeCtrlBuilder( CTreeCtrl *pTree );

			HTREEITEM CreateBranch( const char Inscription[] );
			HTREEITEM CreateLeaf( const char Inscription[] );
			void CloseBranch( void );

		private:
			CTreeCtrl *_pTree;
			HTREEITEM _hParent;
			std::stack< HTREEITEM > _Parents;
	};

} // namespace AidLib

#endif
