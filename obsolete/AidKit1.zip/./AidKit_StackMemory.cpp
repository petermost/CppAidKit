#ifndef AIDKIT_STACK_MEMORY_CPP
#define AIDKIT_STACK_MEMORY_CPP

#include "AidKit.hpp"
#include "AidKit_StackMemory.hpp"
#include "AidKit_Warnings.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### TStackMemory
//###
//#############################################################################
//#############################################################################
//#############################################################################


template < size_t TSize, typename CType >
	//=============================================================================
	TStackMemory< TSize, CType >::TStackMemory( size_t Size )
	//=============================================================================
	{
		my_pMemory = NULL;
		if ( Size > sizeof( my_Memory ))
			my_pMemory = static_cast< CType * >( malloc( Size ));
	}



template < size_t TSize, typename CType >
	//=============================================================================
	TStackMemory< TSize, CType >::~TStackMemory( void )
	//=============================================================================
	{
		free( my_pMemory );
	}



template < size_t TSize, typename CType >
	//=============================================================================
	TStackMemory< TSize, CType >::operator CType *( void )
	//=============================================================================
	{
		return (( my_pMemory != NULL ) ? my_pMemory : my_Memory );
	}

} // namespace AidKit

#endif
