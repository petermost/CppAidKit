#include "AidKit_Command.hpp"

namespace AidKit {

CCommand::~CCommand( void )
{
}


} // namespace AidKit
