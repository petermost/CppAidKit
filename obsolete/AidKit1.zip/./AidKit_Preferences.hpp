#ifndef AIDKIT_PREFERENCES_HPP
#define AIDKIT_PREFERENCES_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"

namespace AidKit {

	class CStdFile;

	//-----------------------------------------------------------------------------
	class CPreferences {
	//-----------------------------------------------------------------------------
		public:
			CPreferences( void );
			virtual ~CPreferences( void );

			virtual bool Load( CStdFile *pFile ) = 0;
			virtual bool Save( CStdFile *pFile ) = 0;

			virtual bool WriteBool( const string_t &Section, const string_t &Key, bool Value );
			virtual bool ReadBool( const string_t &Section, const string_t &Key, bool *pValue );

			virtual bool WriteInteger( const string_t &Section, const string_t &Key, int Value );
			virtual bool ReadInteger(  const string_t &Section, const string_t &Key, int *pValue );

			virtual bool WriteULong( const string_t &Section, const string_t &Key, unsigned long Value );
			virtual bool ReadULong(  const string_t &Section, const string_t &Key, unsigned long *pValue );

			virtual bool WriteString( const string_t &Section, const string_t &Key, const string_t &Value ) = 0;
			virtual bool ReadString(  const string_t &Section, const string_t &Key, string_t *pValue ) = 0;
	};

}

#endif

