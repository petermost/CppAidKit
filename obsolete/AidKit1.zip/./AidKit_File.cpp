#include "AidKit_File.hpp"

#include <stdexcept>

using namespace std;

namespace AidKit {

//=============================================================================
off_t FileSeek( int File, off_t Offset, int Whence )
	throw ( CStdFileError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( Whence == SEEK_SET || Whence == SEEK_CUR || Whence == SEEK_END );
	off_t Position;

	if (( Position = lseek( File, Offset, Whence )) == -1 )
		throw ( CStdFileError::LastError() );

	return ( Position );
}


//=============================================================================
off_t FileTell( int File )
	throw ( CStdFileError, assertion_error )
//=============================================================================
{
	return ( FileSeek( File, 0, SEEK_CUR ));
}



//=============================================================================
long FileSize( CStdFile *File )
	throw ( CStdFileError )
//=============================================================================
{
	long Size, OldPosition;

	OldPosition = File->Tell();
	File->Seek( 0, CStdFile::eWhenceEnd );
	Size = File->Tell();
	File->Seek( OldPosition, CStdFile::eWhenceSet );

	return ( Size );
}


//#############################################################################
//#############################################################################
//#############################################################################
//
// CFileInfo
//
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CFileInfo::CFileInfo( void )
//=============================================================================
{
	Size = 0;
	ModificationTime = 0;
}


//#############################################################################
//#############################################################################
//#############################################################################
//
// CFileSystemBasics
//
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CFileSystemBasics::~CFileSystemBasics( void )
//=============================================================================
{
}


//#############################################################################
//#############################################################################
//#############################################################################
//
// CFileSystem
//
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CFileInfo CFileSystem::FileInfo( const string_t &FileName ) const
	throw ( CFileSystemError )
//=============================================================================
{
	return ( DoFileInfo( FileName ));
}



//=============================================================================
CFileInfo CFileSystem::FileInfo( int nFile ) const
	throw ( CFileSystemError )
//=============================================================================
{
	return ( DoFileInfo( nFile ));
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CStdFile
//###
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
const string_t &CStdFile::Rename( const string_t &OldName, const string_t &NewName )
	throw ( CStdFileError )
//=============================================================================
{
	if ( rename( OldName.c_str(), NewName.c_str() ) == -1 )
		throw ( CStdFileError::LastError() );

	return ( NewName );
}



//=============================================================================
void CStdFile::Remove( const string_t &Filename )
	throw ( CStdFileError )
//=============================================================================
{
	if ( remove( Filename.c_str() ) == -1 )
		throw ( CStdFileError::LastError() );
}


//=============================================================================
CStdFile::CStdFile( FILE *File )
	throw( CStdFileError )
//=============================================================================
{
	my_File = File;
}



//=============================================================================
CStdFile::CStdFile( const string_t &Filename, const string_t &Mode )
	throw ( CStdFileError )
//=============================================================================
{
	my_File = NULL;

	Open( Filename, Mode );
}


//=============================================================================
CStdFile::~CStdFile( void )
	throw ( CStdFileError )
//=============================================================================
{
	try {
		if ( IsOpen() )
			Close();
	}
	catch ( const CStdFileError &Error  ) {
		if ( !uncaught_exception() )
			throw( Error );
	}
}


//=============================================================================
bool CStdFile::Open( const string_t &Filename, const string_t &Mode, CStdFileError *pError )
	throw ( assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( my_File == NULL );

	if (( my_File = fopen( Filename.c_str(), Mode.c_str() )) != NULL ) {
		my_Filename = Filename;
	} else {
		*pError = CStdFileError::LastError();
	}
	return ( my_File != NULL );
}



//=============================================================================
void CStdFile::Open( const string_t &Filename, const string_t &Mode )
	throw ( CStdFileError, assertion_error )
//=============================================================================
{
	CStdFileError Error;

	if ( !Open( Filename, Mode, &Error ))
		throw ( Error );
}



//=============================================================================
void CStdFile::Close( void )
	throw ( CStdFileError )
//=============================================================================
{
	if ( fclose( my_File ) == 0 ) {
		my_File = NULL;
		my_Filename.clear();
	} else
		throw ( CStdFileError::LastError() );
}



//=============================================================================
void CStdFile::SetVBuf( char *Buffer, size_t Size, EBufferingMode eMode )
	throw ( CStdFileError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( eMode == _IONBF || eMode == _IOLBF || eMode == _IOFBF );

	if ( setvbuf( my_File, Buffer, eMode, Size ) != 0 )
		throw ( CStdFileError::LastError() );
}



//=============================================================================
int CStdFile::GetC( void )
	throw ( CStdFileError )
//=============================================================================
{
	int c;

	if (( c = fgetc( my_File )) == EOF && ferror( my_File ))
		throw ( CStdFileError( EIO ));

	return ( c );
}



//=============================================================================
bool CStdFile::GetLine( string_t *pLine, char Delimiter )
	throw ( CStdFileError )
//=============================================================================
{
	int Character = 0;
	size_t MaxCharacter = pLine->max_size();

	pLine->clear();
	while ( MaxCharacter-- > 0 && ( Character = GetC()) != EOF && Character != Delimiter )
		*pLine += Character;

	return ( Character != EOF );
}




//=============================================================================
size_t CStdFile::Read( void *Buffer, size_t Size )
	throw ( CStdFileError )
//=============================================================================
{
	return ( Read( Buffer, 1, Size ));
}



//=============================================================================
size_t CStdFile::Read( void *Buffer, size_t Size, size_t Count )
	throw ( CStdFileError )
//=============================================================================
{
	size_t ReadCount = 0;

	if (( ReadCount = fread( Buffer, Size, Count, my_File )) == 0 && ferror( my_File ))
		throw ( CStdFileError::LastError() );

	return ( ReadCount );
}


//=============================================================================
size_t CStdFile::Write( const void *Buffer, size_t Size )
	throw ( CStdFileError )
//=============================================================================
{
	return ( Write( Buffer, 1, Size ));
}



//=============================================================================
size_t CStdFile::Write( const void *Buffer, size_t Size, size_t Count )
	throw ( CStdFileError )
//=============================================================================
{
	size_t WriteCount = 0;

	if (( WriteCount = fwrite( Buffer, Size, Count, my_File )) == 0 && ferror( my_File ))
		throw ( CStdFileError::LastError() );

	return ( WriteCount );
}



//=============================================================================
void CStdFile::Flush( void )
	throw ( CStdFileError )
//=============================================================================
{
	if ( fflush( my_File ) != 0 )
		throw ( CStdFileError::LastError() );
}



//=============================================================================
void CStdFile::Rewind( void )
	throw ( CStdFileError )
//=============================================================================
{
	rewind( my_File );
}



//=============================================================================
void CStdFile::ClearError( void )
	throw ( CStdFileError )
//=============================================================================
{
	clearerr( my_File );
}




//=============================================================================
long CStdFile::Tell( void )
	throw ( CStdFileError )
//=============================================================================
{
	long Position = 0;

	if (( Position = ftell( my_File )) == -1 )
		throw ( CStdFileError::LastError() );

	return ( Position );
}



//=============================================================================
void CStdFile::Seek( long Offset, EWhence Whence )
	throw ( CStdFileError, assertion_error )
//=============================================================================
{
	AIDKIT_ASSERT( Whence == SEEK_SET || Whence == SEEK_CUR || Whence == SEEK_END );

	if ( fseek( my_File, Offset, Whence ) != 0 )
		throw ( CStdFileError::LastError() );
}



//=============================================================================
int CStdFile::VPrintF( const char_t Format[], va_list Arguments )
	throw ( CStdFileError )
//=============================================================================
{
	int Count;

	if (( Count = vfprintf( my_File, Format, Arguments )) < 0 )
		throw ( CStdFileError::LastError() );

	return ( Count );
}



//=============================================================================
int CStdFile::PrintF( const char_t Format[], ... )
	throw ( CStdFileError )
//=============================================================================
{
	va_list Arguments;

	va_start( Arguments, Format );
	int Count = VPrintF( Format, Arguments );
	va_end( Arguments );

	return ( Count );
}


//=============================================================================
int CStdFile::FileNo( void )
	throw ( CStdFileError )
//=============================================================================
{
	int Descriptor;

	if (( Descriptor = fileno( my_File )) == -1 )
		throw ( CStdFileError::LastError() );

	return ( Descriptor );
}


//=============================================================================
const string_t &CStdFile::Name( void ) const
	throw()
//=============================================================================
{
	return ( my_Filename );
}



//=============================================================================
bool CStdFile::IsOpen( void ) const
	throw ()
//=============================================================================
{
	return ( my_File != NULL );
}

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CUnlockedStdFile
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CUnlockedStdFile::CUnlockedStdFile( FILE *File )
	throw ( CStdFileError )
: CStdFile( File )
//=============================================================================
{
}



//=============================================================================
CUnlockedStdFile::CUnlockedStdFile( const string_t &Filename, const string_t &Mode )
	throw ( CStdFileError )
: CStdFile( Filename, Mode )
//=============================================================================
{
}



//=============================================================================
size_t CUnlockedStdFile::Read( void *Buffer, size_t Size, size_t Count )
	throw ( CStdFileError )
//=============================================================================
{
	size_t ReadCount = 0;

	if (( ReadCount = fread_unlocked( Buffer, Size, Count, my_File )) == 0 && ferror( my_File ))
		throw ( CStdFileError::LastError() );

	return ( ReadCount );
}



//=============================================================================
size_t CUnlockedStdFile::Write( const void *Buffer, size_t Size, size_t Count )
	throw ( CStdFileError )
//=============================================================================
{
	size_t WriteCount = 0;

	if (( WriteCount = fwrite_unlocked( Buffer, Size, Count, my_File )) == 0 && ferror( my_File ))
		throw ( CStdFileError::LastError() );

	return ( WriteCount );
}

//=============================================================================
int CUnlockedStdFile::FileNo( void )
	throw ( CStdFileError )
//=============================================================================
{
	int Descriptor;

	if (( Descriptor = fileno_unlocked( my_File )) == -1 )
		throw ( CStdFileError::LastError() );

	return ( Descriptor );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSysFile
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
inline int CheckSysFileErrorApi( int nResult )
//=============================================================================
	{ return ( check_err_no_api< CSysFileError >( nResult )); }



//=============================================================================
CSysFile::CSysFile( int nFile )
	throw ( CSysFileError )
//=============================================================================
{
	my_nFile = nFile;
}



//=============================================================================
CSysFile::CSysFile( const string_t &Filename, int Flags, int Mode )
	throw ( CSysFileError )
//=============================================================================
{
	my_nFile = -1;

	Open( Filename, Flags, Mode );
}


//=============================================================================
CSysFile::~CSysFile( void )
	throw ( CSysFileError )
//=============================================================================
{
	try {
		if ( IsOpen() )
			Close();
	}
	catch ( const CSysFileError &Error  ) {
		if ( !uncaught_exception() )
			throw( Error );
	}
}



//=============================================================================
void CSysFile::Open( const string_t &Filename, int Flags, int Mode )
	throw ( CSysFileError )
//=============================================================================
{
	if (( my_nFile = open( Filename.c_str(), Flags, Mode )) == -1 )
		throw ( CSysFileError::LastError() );
}



//=============================================================================
void CSysFile::Close( void )
	throw ( CSysFileError )
//=============================================================================
{
	CheckSysFileErrorApi( close( my_nFile ));
	my_nFile = -1;
}



//=============================================================================
size_t CSysFile::Read( void *Buffer, size_t Size )
	throw ( CSysFileError )
//=============================================================================
{
	ssize_t ReadCount = 0;

	if (( ReadCount = read( my_nFile, Buffer, Size )) == -1 )
		throw ( CSysFileError::LastError() );

	return ( ReadCount );
}



//=============================================================================
size_t CSysFile::Write( const void *Buffer, size_t Size )
	throw ( CSysFileError )
//=============================================================================
{
	ssize_t WriteCount = 0;

	if (( WriteCount = write( my_nFile, Buffer, Size )) == -1 )
		throw ( CSysFileError::LastError() );

	return ( WriteCount );
}



//=============================================================================
bool CSysFile::IsOpen( void ) const
	throw ( CSysFileError )
//=============================================================================
{
	return ( my_nFile != -1 );
}


} // namespace AidKit
