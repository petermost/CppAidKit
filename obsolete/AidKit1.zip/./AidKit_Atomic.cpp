#include "AidKit_Atomic.hpp"

namespace AidKit {

CAtomicBasics::CAtomicBasics( void ) throw()
{
}



CAtomicBasics::~CAtomicBasics( void ) throw()
{
}

} // namespace AidKit
