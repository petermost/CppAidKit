#ifndef AIDKIT_DIALOG_HPP
#define AIDKIT_DIALOG_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
// #include "AidKit_Resource.h"
#include <afxwin.h>

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CDialogGadget : public CDialog {
	//-----------------------------------------------------------------------------
		public:
			CDialogGadget( void );
			CDialogGadget(LPCTSTR lpszTemplateName, CWnd* pParentWnd = NULL);
			CDialogGadget(UINT nIDTemplate, CWnd* pParentWnd = NULL);

			BOOL IsModal( void ) const;

			//{{AFX_DATA(CDialogGadget)
			// enum { IDD = IDD_EX_DIALOG };
			//}}AFX_DATA

			//{{AFX_VIRTUAL(CDialogGadget)
			virtual int DoModal();
			virtual BOOL PreTranslateMessage(MSG* pMsg);
			virtual void PostNcDestroy();
			//}}AFX_VIRTUAL

			TEvent1< MSG * > PreTranslateMessageEvt;

		protected:
			//{{AFX_MSG(CDialogGadget)
			virtual void OnOK();
			virtual void OnCancel();
			//}}AFX_MSG
			DECLARE_MESSAGE_MAP()

		private:
			void Construct( void );

			BOOL my_IsModal;
	};

}

#endif
