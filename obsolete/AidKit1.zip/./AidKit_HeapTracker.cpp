#include "AidKit_HeapTracker.hpp"
#include "AidKit_ThreadLock.hpp"

#include <algorithm>
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CHeapTracker
//###
//#############################################################################
//#############################################################################
//#############################################################################


// Fuer eine weiterfuehrende Diskussion ueber Heap-Verfolgung usw. Siehe:
// More Effective C++; Item 27: Requiring or prohibiting heap-based objects.

TStatic< TThreadResourceGuard< set< const void * > > >  CHeapTracker::our_MemoryPointers;

//=============================================================================
CHeapTracker::CHeapTracker( void )
//=============================================================================
{
}



//=============================================================================
CHeapTracker::~CHeapTracker( void )
//=============================================================================
{
}



//=============================================================================
void CHeapTracker::RememberMemory( const void *pMemory )
//=============================================================================
{
	TThreadResourceLock< set< const void * > > itSet( &our_MemoryPointers );

	if ( pMemory != NULL )
		itSet->insert( pMemory );
}



//=============================================================================
void CHeapTracker::ForgetMemory( const void *pMemory )
//=============================================================================
{
	TThreadResourceLock< set< const void * > > itSet( &our_MemoryPointers );

	if ( pMemory != NULL )
		itSet->erase( pMemory );
}
	


//=============================================================================
void *CHeapTracker::operator new ( size_t MemorySize )
//=============================================================================
{
	void *pMemory = ::operator new( MemorySize );

	RememberMemory( pMemory );

	return ( pMemory );
}



//=============================================================================
void CHeapTracker::operator delete ( void *pMemory )
//=============================================================================
{
	::operator delete( pMemory );

	ForgetMemory( pMemory );
}


#if defined( AIDKIT_MSC ) && defined( AIDKIT_DEBUG )

//=============================================================================
void *CHeapTracker::operator new( unsigned int Size,
	int BlockType, const char *FileName, int LineNumber )
//=============================================================================
{
	void *pMemory = ::operator new( Size, BlockType, FileName, LineNumber );

	RememberMemory( pMemory );

	return ( pMemory );
}


//=============================================================================
void CHeapTracker::operator delete( void *pMemory,
	int BlockType, const char *FileName, int LineNumber )
//=============================================================================
{
	::operator delete( pMemory, BlockType, FileName, LineNumber );

	ForgetMemory( pMemory );
}


//=============================================================================
void *CHeapTracker::operator new( size_t Size,
	const char *FileName, int LineNumber )
//=============================================================================
{
	void *pMemory = ::operator new( Size, FileName, LineNumber );

	RememberMemory( pMemory );

	return ( pMemory );
}


//=============================================================================
void CHeapTracker::operator delete( void *pMemory,
	const char *FileName, int LineNumber )
//=============================================================================
{
	::operator delete( pMemory, FileName, LineNumber );

	ForgetMemory( pMemory );
}

#endif



//=============================================================================
bool CHeapTracker::IsOnHeap( void ) const
//=============================================================================
{
	TThreadResourceLock< set< const void * > > itSet( &our_MemoryPointers );

	const void *pMemory = dynamic_cast< const void * >( this );
	
	return ( itSet->find( pMemory ) != itSet->end() );
}


} // namespace AidKit


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CCrtHeapTracker
//###
//#############################################################################
//#############################################################################
//#############################################################################


/* Ein Versuch mit den Microsoft spezifischen Funktionen. Hat aber Probleme
   bereitet, indem die Funktion auch fuer globale Objekte behauptet hat sie
   liegen auf dem Heap!

	class CCrtHeapTracker {
		public:
			virtual ~CCrtHeapTracker();

			bool IsOnHeap() const;
	};

CCrtHeapTracker::~CCrtHeapTracker( void )
{
}



bool CCrtHeapTracker::IsOnHeap( void ) const
{
	const void *pMemory = dynamic_cast< const void * >( this );

	return ( my_CrtIsValidHeapPointer( pMemory ));
}

*/
