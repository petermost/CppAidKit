#ifndef AIDKIT_FILE_OBSERVER_HPP
#define AIDKIT_FILE_OBSERVER_HPP

#include "AidKit.hpp"
#include "AidKit_Event.hpp"
#include "AidKit_AsyncEvent.hpp"
#include "AidKit_Thread.hpp"
#include "AidKit_Unicode.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_Directory.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CFileObserver : protected CThread {
	//-----------------------------------------------------------------------------
		public:
			CFileObserver( void );
			~CFileObserver( void );

			bool Observe( const char_t FileName[], TEventCall2< CFileObserver *, const char_t * > *pHandler,
				unsigned CheckingPeriod = 1000 );
			bool Unobserve( void );

			bool IgnoreChanges( bool Ignore = true );


		private:
			virtual void Do( void );

			CDebugger my_Debugger;

			TEventCall2< CFileObserver *, const char_t * > *my_pHandler;
			TAsyncEvent2< CFileObserver *, const char_t * > my_ChangedEvt;
			string_t my_FileName;
			unsigned my_CheckingPeriod;
			bool my_CanIgnoreChanges;
			CDirectoryEntry my_CurrentFileEntry;
	};

}

#endif
