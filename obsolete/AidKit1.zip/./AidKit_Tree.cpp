#include "AidKit_Tree.hpp"
#include "AidKit_String.hpp"
#include "AidKit_Debug.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTree
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CTree::CTree( void )
//=============================================================================
{
	my_itCurrentBranch = my_Branches.end();
}



//=============================================================================
void CTree::CreateBranch( const char_t Inscription[] )
//=============================================================================
{
	// If it is the first call, then the 'root' branch doesn't exist yet:
	if ( my_itCurrentBranch == my_Branches.end() ) {
		my_itCurrentBranch = my_Branches.insert( my_Branches.begin(), CBranch( Inscription ));
		my_LastBranches.push( my_itCurrentBranch );
	} else {
		my_LastBranches.push( my_itCurrentBranch );
		my_itCurrentBranch = my_itCurrentBranch->insert( my_itCurrentBranch->end(), CBranch( Inscription ));
	}
}



//=============================================================================
void CTree::AppendLeaf( const char_t Inscription[] )
//=============================================================================
{
	my_itCurrentBranch->push_back( CBranch( Inscription ));
}



//=============================================================================
void CTree::CloseBranch( void )
//=============================================================================
{
	my_itCurrentBranch = my_LastBranches.top();
	my_LastBranches.pop();
}


//=============================================================================
void CTree::Build( CTreeBuilder *pBuilder ) const
//=============================================================================
{
	_Build( my_Branches, pBuilder );
}



//=============================================================================
void CTree::_Build( const CBranch &Branches, CTreeBuilder *pBuilder ) const
//=============================================================================
{
	for ( int nBranch = 0; nBranch < Branches.size(); ++nBranch ) {
		if ( nBranch < Branches.size() - 1 ) { // not the last entry?
			if ( !Branches[ nBranch ].empty() ) {
				pBuilder->CreateNextBranch( Branches[ nBranch ].Inscription() );
			} else {
				pBuilder->AppendNextLeaf( Branches[ nBranch ].Inscription() );
			}
		} else { // last entry!
			if ( !Branches[ nBranch ].empty() ) {
				pBuilder->CreateLastBranch( Branches[ nBranch ].Inscription() );
			} else {
				pBuilder->AppendLastLeaf( Branches[ nBranch ].Inscription() );
			}
		}
		if ( !Branches[ nBranch ].empty() ) {
			_Build( Branches[ nBranch ], pBuilder );
			pBuilder->CloseBranch();
		}
	}
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTree::CBranch
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CTree::CBranch::CBranch( void )
//=============================================================================
{
}


//=============================================================================
CTree::CBranch::CBranch( const char_t Inscription[] )
//=============================================================================
{
	my_Inscription = Inscription;
}


//=============================================================================
const char_t *CTree::CBranch::Inscription( void ) const
//=============================================================================
{
	return ( my_Inscription.c_str() );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CTreeBuilder
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CTreeBuilder::~CTreeBuilder( void )
//=============================================================================
{
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsciiTreeBuilder
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CAsciiTreeBuilder::CAsciiTreeBuilder( vector< string_t > *pTree )
//=============================================================================
{
	AIDKIT_ASSERT( pTree != NULL );

	my_pTree = pTree;
}


//=============================================================================
void CAsciiTreeBuilder::CreateNextBranch( const char_t Inscription[] )
//=============================================================================
{
	AppendString( string_printf( "%s+---%s", my_Indention.c_str(), Inscription ));
	my_Indention.append( "|   " );
}



//=============================================================================
void CAsciiTreeBuilder::CreateLastBranch( const char_t Inscription[] )
//=============================================================================
{
	AppendString( string_printf( "%s\\---%s", my_Indention.c_str(), Inscription ));
	my_Indention.append( "    " );
}



//=============================================================================
void CAsciiTreeBuilder::CloseBranch( void )
//=============================================================================
{
	my_Indention.erase( my_Indention.length() - 4, 4 );
}


	
//=============================================================================
void CAsciiTreeBuilder::AppendNextLeaf( const char_t Inscription[] )
//=============================================================================
{
	AppendString( string_printf( "%s+---%s", my_Indention.c_str(), Inscription ));
}



//=============================================================================
void CAsciiTreeBuilder::AppendLastLeaf( const char_t Inscription[] )
//=============================================================================
{
	AppendString( string_printf( "%s\\---%s", my_Indention.c_str(), Inscription ));
}



//=============================================================================
void CAsciiTreeBuilder::AppendString( const string_t &Inscription )
//=============================================================================
{
	my_pTree->push_back( Inscription );
}


} // namespace AidKit


/*
void main( void )
{
	CTree Tree( "Tree" );

	Tree.CreateBranch( "1" );
		Tree.AppendLeaf( "1.2" );
		Tree.AppendLeaf( "1.3" );
		Tree.AppendLeaf( "1.4" );
		Tree.CreateBranch( "1.5" );
			Tree.AppendLeaf( "1.5.1" );
			Tree.AppendLeaf( "1.5.2" );
			Tree.CreateBranch( "1.5.3" );
				Tree.AppendLeaf( "1.5.3.1" );
			Tree.CloseBranch();
		Tree.CloseBranch();
	Tree.CloseBranch();
	Tree.CreateBranch( "2" );
		Tree.AppendLeaf( "2.1" );
	Tree.CloseBranch();

	CTreeBuilder Builder;
	Tree.Build( &Builder );
}

*/
