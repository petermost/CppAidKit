#ifndef AIDKIT_SINGLETON_MANAGER_HPP
#define AIDKIT_SINGLETON_MANAGER_HPP

#include "AidKit.hpp"
#pragma warning( disable : 4786 ) // identifier was truncated to '255' characters in the browser information
#include <list>

namespace AidKit {
	
	//-----------------------------------------------------------------------------
	class CSingletonManager {
	//-----------------------------------------------------------------------------
		public:
			static CSingletonManager *Instance( void );
			static void DestroyInstance( void );

			bool RegisterSingleton( void ( *DestroyInstance )( void ));
			bool UnregisterSingleton( void ( *DestroyInstance )( void ));

			unsigned DestroySingletons( void );

		protected:
			CSingletonManager( void );
			~CSingletonManager( void );

		private:
			static CSingletonManager *our_pInstance;

			typedef std::list< void ( * )( void ) > CDestroyFunctionList;
			CDestroyFunctionList my_DestroyFunctions;

	};

}

#endif
