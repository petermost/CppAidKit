#ifndef AIDKIT_EVENT_HPP
#define AIDKIT_EVENT_HPP

#include "AidKit.hpp"

#ifdef AIDKIT_MSC
	#pragma warning( disable : 4786 ) // identifier was truncated to '255' characters in the browser information
	#pragma warning( disable : 4355 ) // 'this' : used in base member initializer list
#endif
#include <list>

#define AIDKIT_DECLARE_EVENT_HANDLER0( ClassName, HandlerName ) \
	AidKit::TEventHandler0< ClassName > my_##HandlerName; \
	void HandlerName( void )

#define AIDKIT_DECLARE_EVENT_HANDLER1( ClassName, HandlerName, P1 ) \
	AidKit::TEventHandler1< ClassName, P1 > my_##HandlerName; \
	void HandlerName( P1 )

#define AIDKIT_DECLARE_EVENT_HANDLER2( ClassName, HandlerName, P1, P2 ) \
	AidKit::TEventHandler2< ClassName, P1, P2 > my_##HandlerName; \
	void HandlerName( P1, P2 )

#define AIDKIT_DECLARE_EVENT_HANDLER3( ClassName, HandlerName, P1, P2, P3 ) \
	AidKit::TEventHandler3< ClassName, P1, P2, P3 > my_##HandlerName; \
	void HandlerName( P1, P2, P3 )

#define AIDKIT_DECLARE_EVENT_HANDLER4( ClassName, HandlerName, P1, P2, P3, P4 ) \
	AidKit::TEventHandler4< ClassName, P1, P2, P3, P4 > my_##HandlerName; \
	void HandlerName( P1, P2, P3, P4 )

#define AIDKIT_CONSTRUCT_EVENT_HANDLER( ClassName, HandlerName ) \
	my_##HandlerName( this, &ClassName::HandlerName )

#define AIDKIT_SUBSCRIBE_EVENT( EventName, HandlerName ) \
	( EventName )->Subscribe( &my_##HandlerName )

#define AIDKIT_UNSUBSCRIBE_EVENT( EventName, HandlerName ) \
	( EventName )->Unsubscribe( &my_##HandlerName )


namespace AidKit {

/* template < typename CHandler >
	class TEventHandlerFinder {
		public:
			TEventHandlerFinder( const CHandler *pHandler )
				{ my_pHandler = pHandler; }

			bool operator()( const CHandler *pHandler ) const
				{ return ( *my_pHandler == *pHandler ); }

		private:
			const CHandler *my_pHandler;
	};
*/

//#############################################################################
//
// TEventBase, TEventHandlerBase
//
//#############################################################################

template < typename CEvent, typename CHandler >
	class TEventHandlerBase;

template < typename CEvent, typename CHandler >
	//-----------------------------------------------------------------------------
	class TEventBase {
	//-----------------------------------------------------------------------------
		public:
			friend class TEventHandlerBase< CEvent, CHandler >;

			virtual ~TEventBase( void );

			void Subscribe( CHandler *pHandler );
			void Unsubscribe( CHandler *pHandler );

			void operator += ( CHandler &rHandler )
				{ Subscribe( &rHandler ); }

			void operator -= ( CHandler &rHandler )
				{ Unsubscribe( &rHandler ); }

		protected:
			typedef std::list< CHandler * > CHandlerList;
			CHandlerList my_Handlers;

		private:
			void connect( CHandler *pHandler )
				{ my_Handlers.push_back( pHandler ); }

			void disconnect( CHandler *pHandler )
				{ my_Handlers.remove( pHandler ); }
	};


template < typename CEvent, typename CHandler >
	//-----------------------------------------------------------------------------
	class TEventHandlerBase {
	//-----------------------------------------------------------------------------
		public:
			friend class TEventBase< CEvent, CHandler >;

			virtual ~TEventHandlerBase( void );

			void Subscribe( CEvent *pEvent );
			void Unsubscribe( CEvent *pEvent );

			void operator += ( CEvent &rEvent )
				{ Subscribe( &rEvent ); }

			void operator -= ( CEvent &rEvent )
				{ Unsubscribe( &rEvent ); }

		protected:
			std::list< CEvent * > my_Events;

		private:
			void connect( CEvent *pEvent )
				{ my_Events.push_back( pEvent ); }

			void disconnect( CEvent *pEvent )
				{ my_Events.remove( pEvent ); }
	};



//#############################################################################
//
// TEventHandler0, TEventFunction0, TEvent0
//
//#############################################################################

	class TEvent0;

	//-----------------------------------------------------------------------------
	class TEventCall0 : public TEventHandlerBase< TEvent0, TEventCall0 > {
	//-----------------------------------------------------------------------------
		public:
			virtual void operator()( void ) const = 0;
	};


template < typename CHandler >
	//-----------------------------------------------------------------------------
	class TEventHandler0 : public TEventCall0 {
	//-----------------------------------------------------------------------------
		public:
			TEventHandler0( CHandler *pHandler, void ( CHandler::*pMethod )( void ))
				{ my_pHandler = pHandler; my_pMethod = pMethod; my_pFunction = NULL;}

			TEventHandler0( void ( *pFunction )( void ))
				{ my_pHandler = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( void ) const;

		private:
			CHandler *my_pHandler;
			void ( CHandler::*my_pMethod )( void );
			void ( *my_pFunction )( void );
	};


	//-----------------------------------------------------------------------------
	class TEvent0 : public TEventBase< TEvent0, TEventCall0 > {
	//-----------------------------------------------------------------------------
		public:
			virtual void Announce( void ) const;

			void operator()( void ) const
				{ Announce(); }
	};


//#############################################################################
//
// TEventHandler1, TEventFunction1, TEvent1
//
//#############################################################################

template < typename P1 >
	class TEvent1;

template < typename P1 >
	//-----------------------------------------------------------------------------
	class TEventCall1 : public TEventHandlerBase< TEvent1< P1 >, TEventCall1< P1 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void operator()( P1 ) const = 0;
	};


template < typename CHandler, typename P1 >
	//-----------------------------------------------------------------------------
	class TEventHandler1 : public TEventCall1< P1 > {
	//-----------------------------------------------------------------------------
		public:
			TEventHandler1( CHandler *pHandler, void ( CHandler::*pMethod )( P1 ))
				{ my_pHandler = pHandler; my_pMethod = pMethod; my_pFunction = NULL; }

			TEventHandler1( void ( *pFunction )( P1 ))
				{ my_pHandler = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( P1 p1 ) const;

			/* virtual bool operator == ( const TEventCall1< P1 > &Handler ) const
				{ return ( my_pHandler == static_cast< const CHandler & >( Handler ).my_pHandler ); }
			*/

		private:
			CHandler *my_pHandler;
			void ( CHandler::*my_pMethod )( P1 );
			void ( *my_pFunction )( P1 );
	};


template < typename P1 >
	//-----------------------------------------------------------------------------
	class TEvent1 : public TEventBase< TEvent1< P1 >, TEventCall1< P1 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void Announce( P1 ) const;

			void operator()( P1 p1 ) const
				{ Announce( p1 ); }

	};



//#############################################################################
//
// TEventHandler2, TEventFunction2, TEvent2
//
//#############################################################################

template < typename P1, typename P2 >
	class TEvent2;


template < typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TEventCall2 : public TEventHandlerBase< TEvent2< P1, P2 >, TEventCall2< P1, P2 > > {

	//-----------------------------------------------------------------------------
		public:
			virtual void operator()( P1, P2 ) const =  0;
	};


template < typename CHandler, typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TEventHandler2 : public TEventCall2< P1, P2 > {
	//-----------------------------------------------------------------------------
		public:
			TEventHandler2( CHandler *pHandler, void ( CHandler::*pMethod )( P1, P2 ))
				{ my_pHandler = pHandler; my_pMethod = pMethod; my_pFunction = NULL; }

			TEventHandler2( void ( *pFunction )( P1, P2 ))
				{ my_pHandler = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( P1 p1, P2 p2 ) const;

		private:
			CHandler *my_pHandler;
			void ( CHandler::*my_pMethod )( P1, P2 );
			void ( *my_pFunction )( P1, P2 );
	};


template < typename P1, typename P2 >
	//-----------------------------------------------------------------------------
	class TEvent2 : public TEventBase< TEvent2< P1, P2 >, TEventCall2< P1, P2 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void Announce( P1, P2 ) const;

			void operator()( P1 p1, P2 p2 ) const
				{ Announce( p1, p2 ); }
	};



//#############################################################################
//
// TEventHandler3, TEventFunction3, TEvent3
//
//#############################################################################

template < typename P1, typename P2, typename P3 >
	class TEvent3;


template < typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TEventCall3 : public TEventHandlerBase< TEvent3< P1, P2, P3 >, TEventCall3< P1, P2, P3 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void operator()( P1, P2, P3 ) const = 0;
	};


template < typename CHandler, typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TEventHandler3 : public TEventCall3< P1, P2, P3 > {
	//-----------------------------------------------------------------------------
		public:
			TEventHandler3( CHandler *pHandler, void ( CHandler::*pMethod )( P1, P2, P3 ))
				{ my_pHandler = pHandler; my_pMethod = pMethod; my_pFunction = NULL; }

			TEventHandler3( void ( *pFunction )( P1, P2, P3 ))
				{ my_pHandler = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( P1 p1, P2 p2, P3 p3 ) const;

		private:
			CHandler *my_pHandler;
			void ( CHandler::*my_pMethod )( P1, P2, P3 );
			void ( *my_pFunction )( P1, P2, P3 );
	};


template < typename P1, typename P2, typename P3 >
	//-----------------------------------------------------------------------------
	class TEvent3 : public TEventBase< TEvent3< P1, P2, P3 >, TEventCall3< P1, P2, P3 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void Announce( P1, P2, P3 ) const;

			void operator()( P1 p1, P2 p2, P3 p3 ) const
				{ Announce( p1, p2, p3 ); }
	};



//#############################################################################
//
// TEventHandler4, TEventFunction4, TEvent4
//
//#############################################################################

template < typename P1, typename P2, typename P3, typename P4 >
	class TEvent4;


template < typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TEventCall4 : public TEventHandlerBase< TEvent4< P1, P2, P3, P4 >, TEventCall4< P1, P2, P3, P4 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void operator()( P1, P2, P3, P4 ) const = 0;
	};


template < typename CHandler, typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TEventHandler4 : public TEventCall4< P1, P2, P3, P4 > {
	//-----------------------------------------------------------------------------
		public:
			TEventHandler4( CHandler *pHandler, void ( CHandler::*pMethod )( P1, P2, P3, P4 ))
				{ my_pHandler = pHandler; my_pMethod = pMethod; my_pFunction = NULL; }

			TEventHandler4( void ( *pFunction )( P1, P2, P3, P4 ))
				{ my_pHandler = NULL; my_pMethod = NULL; my_pFunction = pFunction; }

			virtual void operator()( P1 p1, P2 p2, P3 p3, P4 p4 ) const;

		private:
			CHandler *my_pHandler;
			void ( CHandler::*my_pMethod )( P1, P2, P3, P4 );
			void ( *my_pFunction )( P1, P2, P3, P4 );
	};


template < typename P1, typename P2, typename P3, typename P4 >
	//-----------------------------------------------------------------------------
	class TEvent4 : public TEventBase< TEvent4< P1, P2, P3, P4 >, TEventCall4< P1, P2, P3, P4 > > {
	//-----------------------------------------------------------------------------
		public:
			virtual void Announce( P1, P2, P3, P4 ) const;

			void operator()( P1 p1, P2 p2, P3 p3, P4 p4 ) const
				{ Announce( p1, p2, p3, p4 ); }
	};

} // namespace AidKit

#include "AidKit_EventImp.cpp"

#endif
