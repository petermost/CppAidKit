#include "AidKit_Directory.hpp"
#include <time.h>
#include <direct.h>
#include <string.h>
#include "AidKit_Misc.hpp"
#include "AidKit_Warnings.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectoryHelper
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
string_t CDirectoryHelper::AttributesAsString( const CDirectoryEntry &Entry )
//=============================================================================
{
	static struct {
		bool ( CDirectoryEntry::*IsAttribute )( void ) const;
		char_t     Char;
	} AttributChecker[] = {
		{ &CDirectoryEntry::IsReadOnly,  TEXT( 'R' ) },
		{ &CDirectoryEntry::IsHidden  ,  TEXT( 'H' ) },
		{ &CDirectoryEntry::IsSystem  ,  TEXT( 'S' ) },
		{ &CDirectoryEntry::IsArchived,  TEXT( 'A' ) },
		{ &CDirectoryEntry::IsDirectory, TEXT( 'D' ) }
	};
	size_t i;
	string_t Attributes;

	for ( i = 0; i < countof( AttributChecker ); i++ ) {
		if (( Entry.*AttributChecker[ i ].IsAttribute )() )
			Attributes += AttributChecker[ i ].Char;
		else
			Attributes += TEXT( '_' );
	}
	return ( Attributes );
}



//=============================================================================
string_t CDirectoryHelper::TimeAsString( time_t time )
//=============================================================================
{
	const char_t TimeFormat[] = TEXT( "%d.%m.%Y %H:%M:%S" );

	string_t TimeStr( TEXT( "--.--.---- --:--:--" ));
	tm     *pTimeStruct;
	char_t   TimeBuffer[ 80 ];

	if (( pTimeStruct = gmtime( &time )) != NULL ) {
		if ( str_f_time( TimeBuffer, countof( TimeBuffer ), TimeFormat, pTimeStruct ) > 0 )
			TimeStr = TimeBuffer;
	}
	return ( TimeStr );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectoryEntry
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CDirectoryEntry::CDirectoryEntry( void )
//=============================================================================
{
	memset( &my_EntryData, 0, sizeof( my_EntryData ));
}



//=============================================================================
CDirectoryEntry::~CDirectoryEntry( void )
//=============================================================================
{
}



//=============================================================================
const char_t *CDirectoryEntry::Name( void ) const
//=============================================================================
{
	return ( my_EntryData.name );
}



//=============================================================================
_fsize_t CDirectoryEntry::Size( void ) const
//=============================================================================
{
	return ( my_EntryData.size );
}



//=============================================================================
bool CDirectoryEntry::IsArchived( void ) const
//=============================================================================
{
	return (( my_EntryData.attrib & _A_ARCH ) == _A_ARCH );
}



//=============================================================================
bool CDirectoryEntry::IsHidden( void ) const
//=============================================================================
{
	return (( my_EntryData.attrib & _A_HIDDEN ) == _A_HIDDEN );
}



//=============================================================================
bool CDirectoryEntry::IsNormal( void ) const
//=============================================================================
{
	return (( my_EntryData.attrib & _A_NORMAL ) == _A_NORMAL );
}



//=============================================================================
bool CDirectoryEntry::IsReadOnly( void ) const
//=============================================================================
{
	return (( my_EntryData.attrib & _A_RDONLY ) == _A_RDONLY );
}



//=============================================================================
bool CDirectoryEntry::IsSystem( void ) const
//=============================================================================
{
	return (( my_EntryData.attrib & _A_SYSTEM ) == _A_SYSTEM );
}



//=============================================================================
bool CDirectoryEntry::IsDirectory( void ) const
//=============================================================================
{
	return (( my_EntryData.attrib & _A_SUBDIR ) == _A_SUBDIR );
}




//=============================================================================
time_t CDirectoryEntry::CreationTime( void ) const
//=============================================================================
{
	return ( my_EntryData.time_create );
}



//=============================================================================
time_t CDirectoryEntry::LastAccessTime( void ) const
//=============================================================================
{
	return ( my_EntryData.time_access );
}



//=============================================================================
time_t CDirectoryEntry::LastWriteTime( void ) const
//=============================================================================
{
	return ( my_EntryData.time_write );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectory
//###
//#############################################################################
//#############################################################################
//#############################################################################

const long HANDLE_ERROR = -1;

//=============================================================================
string_t CDirectory::CurrentDirectoryAsString( void )
//=============================================================================
{
	char_t CurrentDirectory[ _MAX_PATH ];
	string_t CurrentDirectoryStr;

	if ( _get_cwd( CurrentDirectory, countof( CurrentDirectory )) != NULL )
		CurrentDirectoryStr = CurrentDirectory;

	return ( CurrentDirectoryStr );
}



//=============================================================================
CDirectory::CDirectory( void )
//=============================================================================
{
	my_hDirectory = HANDLE_ERROR;
}
	
	
//=============================================================================
CDirectory::~CDirectory( void )
//=============================================================================
{
	Close();
}



//=============================================================================
bool CDirectory::Open( const char_t Path[] )
//=============================================================================
{
	bool Success = true;

	my_OldDirectoryName = CurrentDirectoryAsString();
	Success = ( _ch_dir( Path ) == 0 );
	my_CurrentDirectoryName = CurrentDirectoryAsString();

	return ( Success );
}



//=============================================================================
bool CDirectory::Close( void )
//=============================================================================
{
	bool Success = false;

	if ( !my_OldDirectoryName.empty() )
		Success = ( _ch_dir( my_OldDirectoryName.c_str() ) == 0 );

	if ( my_hDirectory != HANDLE_ERROR ) {
		Success = ( _findclose( my_hDirectory ) == 0 );
		my_hDirectory = HANDLE_ERROR;
	}
	return ( Success );
}	



//=============================================================================
bool CDirectory::FirstEntry( CDirectoryEntry *Entry, const char_t WildCard[] )
//=============================================================================
{
	return (( my_hDirectory = _find_first( const_cast< char_t * >( WildCard ), &Entry->my_EntryData )) != HANDLE_ERROR );
}



//=============================================================================
bool CDirectory::NextEntry( CDirectoryEntry *Entry )
//=============================================================================
{
	return ( _find_next( my_hDirectory, &Entry->my_EntryData ) == 0 );
}




//=============================================================================
const char_t *CDirectory::PathName( void ) const
//=============================================================================
{
	return ( my_CurrentDirectoryName.c_str() );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectoryVisitor
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CDirectoryVisitor::CDirectoryVisitor( void )
//=============================================================================
{
}



//=============================================================================
CDirectoryVisitor::~CDirectoryVisitor( void )
//=============================================================================
{
}



//=============================================================================
void CDirectoryVisitor::EnterDirectory( const CDirectory &, bool /* IsLastEntry */ )
//=============================================================================
{
}



//=============================================================================
void CDirectoryVisitor::LeaveDirectory( const CDirectory & )
//=============================================================================
{
}



//=============================================================================
void CDirectoryVisitor::VisitEntry( const CDirectoryEntry &, bool /* IsLastEntry */ )
//=============================================================================
{
}

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDirectoryGuide
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
CDirectoryGuide::CDirectoryGuide( void )
//=============================================================================
{
	my_Visitor = NULL;
}


//=============================================================================
bool CDirectoryGuide::Tour( const char_t Path[], CDirectoryVisitor *Visitor )
//=============================================================================
{
	const bool kIsLastEntry = true;

	my_Visitor = Visitor;
	return ( ParseDirectory( Path, kIsLastEntry ));
}



//=============================================================================
static bool IsVisitableSubDirectory( const CDirectoryEntry &Entry )
//=============================================================================
{
	return ( Entry.IsDirectory() && str_cmp( Entry.Name(), TEXT( "." )) != 0
		&& str_cmp( Entry.Name(), TEXT( ".." )) != 0 );
}



//=============================================================================
bool CDirectoryGuide::ParseDirectory( const char_t Path[], bool IsLastEntry )
//=============================================================================
{
	bool EntryFound;
	CDirectory Directory;
	CDirectoryEntry FirstEntry;
	CDirectoryEntry NextEntry;

	bool Success = false;

	if ( Directory.Open( Path )) {
		my_Visitor->EnterDirectory( Directory, IsLastEntry );

		EntryFound = Directory.FirstEntry( &FirstEntry, TEXT( "*" ));
		while ( EntryFound ) {	
			EntryFound = Directory.NextEntry( &NextEntry );
			IsLastEntry = !EntryFound;
			
			// Wir filtern "." und ".." heraus, da ich keinen Nutzen sehen. Im
			// Gegenteil, diese besonderen Eintraege machen nur Probleme, weil sie
			// in der Regel nicht erwartet werden!

			if ( !FirstEntry.IsDirectory() || IsVisitableSubDirectory( FirstEntry ))
				my_Visitor->VisitEntry( FirstEntry, IsLastEntry );

			if ( IsVisitableSubDirectory( FirstEntry ))
				Success = ParseDirectory( FirstEntry.Name(), IsLastEntry );

			FirstEntry = NextEntry;
		}
		my_Visitor->LeaveDirectory( Directory );
		Directory.Close();
		Success = true;
	}
	return ( Success );
}


} // namespace AidKit
