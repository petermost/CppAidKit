#include "AidKit_DebuggerWindow.hpp"

#if defined( AIDKIT_WINDOWS )

#include "AidKit_Text.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_Application.hpp"
#include "AidKit_SingletonManager.hpp"
#include "AidKit_Warnings.hpp"
#include "AidKit_WinHelper.hpp"
#include "AidKit_Resource.h"

namespace AidKit {

static const CText kCrashTxt(
	TEXT( "Crash ..." ), CText::eEnglish,
	TEXT( "Absturz ..." ), CText::eGerman,
	NULL );

static const CText kDebuggerOutputTitle(
	TEXT( "Debugger Output" ),   CText::eEnglish,
	TEXT( "Debugger Ausgabe" ), CText::eGerman,
	NULL );

static const CText kAboutTxt(
	TEXT( "&About ..." ), CText::eEnglish,
	TEXT( "&�ber ..." ),  CText::eGerman,
	NULL );

static const CText kDebugTxt(
	TEXT( "&Debug" ), CText::eEnglish,
	TEXT( "&Debug" ), CText::eGerman,
	NULL );

static const CText kHelpTxt(
	TEXT( "&Help" ),  CText::eEnglish,
	TEXT( "&Hilfe" ), CText::eGerman,
	NULL );

static const CText kCrashQuestion(
	TEXT( "Do you really want to crash the program?" ), CText::eEnglish,
	TEXT( "Wollen Sie wirklich das Programm zum abst�rzen bringen?" ), CText::eGerman,
	NULL );

static const CText kAboutContentTxt(
	TEXT( "AidKit Library (w) by P. Most" ),     CText::eEnglish,
	TEXT( "AidKit Bibliothek (w) von P. Most" ), CText::eGerman,
	NULL );

const BOOL kInitialLock = TRUE;

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDebuggerDisplayGadget
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CDebuggerDisplayGadget::CDebuggerDisplayGadget( unsigned MaxEntries )
: my_MaxEntries( MaxEntries )
//=============================================================================
{
	if ( IsDebugging() ) {
		my_EntriesCount = 0;
	}
}



//=============================================================================
CDebuggerDisplayGadget::~CDebuggerDisplayGadget( void )
//=============================================================================
{
}



//=============================================================================
BOOL CDebuggerDisplayGadget::Create( CWnd *ParentWnd, UINT ControlID )
//=============================================================================
{
	BOOL IsCreated = TRUE;

	if ( IsDebugging() ) {
		// Make the control fit into the parent:

		CRect ControlSize;
		ParentWnd->GetClientRect( &ControlSize );
		IsCreated = CListCtrl::Create( LVS_REPORT| LVS_NOCOLUMNHEADER |
			WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER,
			ControlSize, ParentWnd, ControlID );

		if ( IsCreated ) {
			// Add a column:

			LVCOLUMN Column;
			Column.mask       = LVCF_FMT | LVCF_WIDTH;
			Column.fmt        = LVCFMT_LEFT;
			Column.cx         = SHRT_MAX; // ControlSize.Width()
			Column.pszText    = NULL;
			Column.cchTextMax = 0;
			Column.iSubItem   = 0;
			Column.iImage     = 0;
			Column.iOrder     = 0;
			InsertColumn( 0, &Column );
		}
	}
	return ( IsCreated );
}	


//=============================================================================
void CDebuggerDisplayGadget::Write( const char_t Data[] )
//=============================================================================
{
	if ( IsDebugging() ) {
		const BOOL kIsPartialOK = TRUE;
		const int kOverlapCount = 100;

		int ItemIndex;

		// Delete the surplus entries:

		if ( my_EntriesCount > my_MaxEntries + kOverlapCount ) {
			LockWindowUpdate();
			for ( int i = 0; i < kOverlapCount; ++i )
				DeleteItem( 0 );
			UnlockWindowUpdate();
			my_EntriesCount -= kOverlapCount;
			AIDKIT_ASSERT( my_EntriesCount == GetItemCount() );
		}
			
		// Insert the message at the end:

		if (( ItemIndex = InsertItem( my_EntriesCount, Data )) != -1 ) {
			++my_EntriesCount;
			EnsureVisible( ItemIndex, kIsPartialOK );
			if ( IsCUI() )
				UpdateWindow();
		}
	}
}





//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CDebuggerWindow
//###
//#############################################################################
//#############################################################################
//#############################################################################

BEGIN_MESSAGE_MAP(CDebuggerWindow, CFrameWnd)
	ON_WM_CLOSE()
	ON_COMMAND( ID_DEBUG_CRASH, OnCrash )
	ON_COMMAND( ID_HELP_ABOUT, OnAbout )
END_MESSAGE_MAP()

CDebuggerWindow *CDebuggerWindow::our_pSingleInstance = NULL;

//=============================================================================
CDebuggerWindow *CDebuggerWindow::Instance( void )
//=============================================================================
{
	if ( our_pSingleInstance == NULL ) {
		our_pSingleInstance = new CDebuggerWindow();
		our_pSingleInstance->Create();
		CSingletonManager::Instance()->RegisterSingleton( &DestroyInstance );
	}
	our_pSingleInstance->ShowWindow( SW_SHOWNOACTIVATE );

	return ( our_pSingleInstance );
}



//=============================================================================
void CDebuggerWindow::DestroyInstance( void )
//=============================================================================
{
	delete our_pSingleInstance;
	our_pSingleInstance = NULL;
	CSingletonManager::Instance()->UnregisterSingleton( &DestroyInstance );
}



//=============================================================================
CDebuggerWindow::CDebuggerWindow()
//=============================================================================
{
	if ( IsDebugging() ) {
	}
}



//=============================================================================
CDebuggerWindow::~CDebuggerWindow()
//=============================================================================
{
	if ( IsDebugging() ) {
	}
}



//=============================================================================
BOOL CDebuggerWindow::Create( void )
//=============================================================================
{
	BOOL IsCreated = TRUE;

	if ( IsDebugging() ) {

		const CString WindowTitle = CString( CApplication::Instance()->Name() ) + TEXT( " - " ) + kDebuggerOutputTitle;
		// Create the window:
		IsCreated = CFrameWnd::Create( NULL, WindowTitle );
		if ( IsCreated ) {
			
			// m_bAutoMenuEnable = FALSE;
			
			// Create the debug menu entries:

			VERIFY( my_DebugMenu.CreatePopupMenu() );
			my_DebugMenu.AppendMenu( MF_STRING, ID_DEBUG_CRASH, kCrashTxt );

			// Create the help menu entries:

			VERIFY( my_HelpMenu.CreatePopupMenu() );
			my_HelpMenu.AppendMenu( MF_STRING, ID_HELP_ABOUT, kAboutTxt );

			// Create the main menu:

			VERIFY( my_MainMenu.CreateMenu() );
			my_MainMenu.AppendMenu( MF_POPUP, reinterpret_cast< UINT >( static_cast< HMENU >( my_DebugMenu )), kDebugTxt );
			my_MainMenu.AppendMenu( MF_POPUP, reinterpret_cast< UINT >( static_cast< HMENU >( my_HelpMenu )), kHelpTxt );
			
			SetMenu( &my_MainMenu );

			// Create the inner gadget:
			if ( !my_DisplayGadget.Create( this ))
				return ( FALSE );

			// Attach a icon:
			const char_t kIconName[] = TEXT( "AIDKIT_IDI_DEBUG" );
			HICON hDebugIcon = AfxGetApp()->LoadIcon( kIconName );
			if ( hDebugIcon != NULL ) {
				SetIcon( hDebugIcon, TRUE  );
				SetIcon( hDebugIcon, FALSE );
			}
		}
	}
	return ( IsCreated );
}



//=============================================================================
void CDebuggerWindow::Write( const char_t Data[] )
//=============================================================================
{
	if ( IsDebugging() ) {
		my_DisplayGadget.Write( Data );
	}
}



//=============================================================================
void CDebuggerWindow::OnCrash( void )
//=============================================================================
{
	if ( IsDebugging() ) {
		if ( AfxMessageBox( kCrashQuestion, MB_YESNO | MB_ICONSTOP | MB_DEFBUTTON2 ) == IDYES ) {
			CDebugger::Break();
		}
	}
}


//=============================================================================
void CDebuggerWindow::OnAbout( void )
//=============================================================================
{
	if ( IsDebugging() ) {
		AfxMessageBox( kAboutContentTxt );
	}
}


//=============================================================================
void CDebuggerWindow::OnClose( void )
//=============================================================================
{
	if ( IsDebugging() ) {
		ShowWindow( SW_MINIMIZE );
	}
}

} // namespace AidKit

#endif // defined( AIDKIT_WINDOWS )
