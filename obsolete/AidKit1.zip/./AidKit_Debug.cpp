#include "AidKit_Debug.hpp"
#include "AidKit_Error.hpp"
#include "AidKit_String.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_Warnings.hpp"
#include "AidKit_System.hpp"
#include "AidKit_Templates.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### Assert support
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
assertion_error::assertion_error( const string &message )
	: logic_error( message )
//=============================================================================
{
}


//=============================================================================
assertion_error::~assertion_error( void )
	throw()
//=============================================================================
{
}



//=============================================================================
void CheckAssertion( bool IsSatisfied, const char Expression[], const char FileName[], int LineNumber )
	throw ( assertion_error )
//=============================================================================
{
	if ( !IsSatisfied )
		throw ( assertion_error( string_printf( "%s(%d): Assertion '%s' failed.", FileName, LineNumber, Expression )));
}



//=============================================================================
const char_t *ShortFileName( const char_t FileName[] )
//=============================================================================
{
	const char_t *pShortFileName = str_r_chr( FileName, DIRECTORY_SEPARATOR );
	return (( pShortFileName != NULL ) ? ++pShortFileName : FileName );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### Error log functions
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
void LogError( CDebugger *pDebugger, const CError &Error )
//=============================================================================
{
	size_t StackIdx, nParameter;
	std::vector< SErrorCall > CallStack;
	std::vector< SErrorCall >::reverse_iterator pCallStack;

	pDebugger->Log( TEXT( "%s: Reason: %s" ), typeid( Error ).name(), Error.what() );
	Error.CallStack( &CallStack );

	StackIdx = CallStack.size();
	for ( pCallStack = CallStack.rbegin(); pCallStack != CallStack.rend(); ++pCallStack ) {
		string_t Parameters = TEXT( "{ " );
		for ( nParameter = 0; nParameter < pCallStack->Parameters.size(); ++nParameter ) {
			if ( nParameter > 0 )
				Parameters += string_t( TEXT( " | " ));

			Parameters += pCallStack->Parameters[ nParameter ];
		}
		Parameters += TEXT( " }" );

		pDebugger->Log( TEXT( "ErrorStack[%d] = %s" ), --StackIdx, Parameters.c_str() );
	}
}



//=============================================================================
void LogUnknownError( CDebugger *pDebugger, const char_t *SourceFileName,
	int SourceLineNumber )
//=============================================================================
{
	pDebugger->Log( TEXT( "%s(%d) : Unknown error!" ), SourceFileName, SourceLineNumber );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### Flag dump functions
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
string_vector AnalyzeFlags( unsigned long FlagBits, const SFlag Flags[], size_t Count )
//=============================================================================
{
	string_vector FlagList;

	while ( Count-- > 0 ) {
		if ( FlagBits & Flags[ Count ].Bits )
			FlagList.push_back( Flags[ Count ].pName );
	}
	return ( FlagList );
}


//=============================================================================
void DumpFlags( const string_vector &Flags, void ( *pDump )( const char_t [], ... ))
//=============================================================================
{
	size_t i;

	pDump( TEXT( "{ " ));
	for ( i = 0; i < Flags.size(); ++i ) {
		if ( i > 0 )
			pDump( TEXT( " | " ));

		pDump( TEXT( "%s" ), Flags[ i ].c_str() );
	}
	pDump( TEXT( " }" ));
}


} // namespace AidKit
