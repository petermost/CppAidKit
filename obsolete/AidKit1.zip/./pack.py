#! /usr/bin/env python

import os
import sys
import zipfile
import dircache

EXTENSIONS = [ ".cpp", ".hpp", ".c", ".h", ".rc", ".DSM", ".dsp", ".dsw", ".ico", ".bmp",
	".txt", ".imp", ".xpm", ".py", ".pl", ".sh", ".kdevprj" ]
	
FILENAMES = [ "SConstruct", "makefile", "Doxyfile" ]

#===============================================================================
def packDirectory( zipFile, dirName, fileNames ):
#===============================================================================
	print "Examining ", dirName, "..."
	for fileName in fileNames:
		# print "Examining ", fileName, "..."
		extension = os.path.splitext( fileName )
		if extension[ 1 ] in EXTENSIONS or fileName in FILENAMES:
			print "Packing", os.path.join( dirName, fileName )
			zipFile.write( os.path.join( dirName, fileName ))


# def main():

if len( sys.argv ) != 2:
	print "Usage: pack <zipfilename>"
	sys.exit( 1 )
	
zipFile = zipfile.ZipFile( file = sys.argv[ 1 ], mode = "w", compression = zipfile.ZIP_DEFLATED )
os.path.walk( os.curdir, packDirectory, zipFile )
zipFile.close()
