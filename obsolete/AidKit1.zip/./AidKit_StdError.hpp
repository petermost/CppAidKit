#ifndef AIDKIT_STD_ERROR_HPP
#define AIDKIT_STD_ERROR_HPP

#include "AidKit.hpp"
#include "AidKit_Error.hpp"
// #include "AidKit_String.hpp"
#include "AidKit_Unicode.hpp"
#include <errno.h>

#ifdef ERROR
	#undef ERROR
#endif

namespace AidKit {

	extern const string_t EMPTY_STRING;

	const int ENONE = 0;
	const int ERROR = -1;

	const string_t ErrNoString( int nError );
	const string_t ErrNoDescription( int nError );

	//-----------------------------------------------------------------------------
	class CStdError : public CError {
	//-----------------------------------------------------------------------------
		public:
			static CStdError LastError( void )
				throw();

			explicit CStdError( int nError = ENONE, const string_t &Description = EMPTY_STRING )
				throw();
				
			CStdError( const CStdError & )
				throw();

			CStdError &operator = ( const CStdError & )
				throw();
			
			virtual ~CStdError( void )
				throw();

			int Reason( void ) const ///< For a complete list of error codes see errno.h.
				throw();

			virtual const string_t &Description( void ) const
				throw();

			operator int ( void ) const
				throw()
					{ return ( Reason() ); }

		private:
			int     my_Reason;
			mutable string_t my_Description;
	};

	//-----------------------------------------------------------------------------
	template < typename TName >
		class TStdError : public CStdError {
	//-----------------------------------------------------------------------------
			public:
				static TStdError LastError( void )
					throw();

				explicit TStdError( int nError = ENONE, const string_t &Description = EMPTY_STRING )
					throw();

				TStdError( const TStdError &OtherError )
					throw();

				TStdError &operator = ( const TStdError & )
					throw();
		};

	//-----------------------------------------------------------------------------
	template < typename name_t >
		class generic_exception : public std::exception {
	//-----------------------------------------------------------------------------
			public:
				explicit generic_exception( const std::string &what ) throw()
					: my_what( what )
					{ }

				~generic_exception( void ) throw()
					{ }

				virtual const char *what( void ) const throw()
					{ return ( my_what.c_str() ); }

			private:
				std::string my_what;
		};


	template < typename TError >
		int check_err_no( int nError )
			throw ( TError );

	template < typename TError >
		int check_err_no_api( int nResult )
			throw ( TError );


	//=============================================================================
	inline int CheckErrNoApi( int nResult )
		throw ( CStdError )
	//=============================================================================
			{ return ( check_err_no_api< CStdError >( nResult )); }


	//=============================================================================
	inline int CheckErrNo( int nError )
		throw ( CStdError )
	//=============================================================================
			{ return ( check_err_no< CStdError >( nError )); }


}

#endif

#include "AidKit_StdErrorImp.cpp"
