#include "AidKit_WinHelper.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_WinError.hpp"
#include "AidKit_Debugger.hpp"
#include "AidKit_FilePath.hpp"
#include "Windows\AidKit_Windows_Main.hpp"
#include "AidKit_User.hpp"

#include <afxwin.h>
#include <comdef.h>
#include <atlbase.h>
#include <wininet.h>
#include <shlobj.h>
#include <lmcons.h>

namespace AidKit {

// Works but isn't used yet:
//=============================================================================
static int GetDynamicApplicationType( void )
//=============================================================================
// Looks wether the standard handles are connected:
{
	HANDLE hInput  = GetStdHandle( STD_INPUT_HANDLE );
	HANDLE hOutput = GetStdHandle( STD_OUTPUT_HANDLE );
	HANDLE hError  = GetStdHandle( STD_ERROR_HANDLE );

	if ( hInput != 0 && hOutput != 0 && hError != 0 )
		return ( IMAGE_SUBSYSTEM_WINDOWS_CUI );
	else
		return ( IMAGE_SUBSYSTEM_WINDOWS_GUI );
}


//#############################################################################
//#############################################################################
//#############################################################################
//###
//### WinHelper
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
unsigned GetModuleFlags( HMODULE hModule )
//=============================================================================
// Looks into the module header to determine the application type:
{
	unsigned ModuleFlags = 0;

	if ( hModule == 0 )
		hModule = GetInstanceHandle(); // It doesn't work with GetModuleHandle( NULL )!

	if ( hModule != NULL ) {
		IMAGE_DOS_HEADER *pDosHeader = reinterpret_cast< IMAGE_DOS_HEADER * >( hModule );
		IMAGE_NT_HEADERS *pNtHeader =  reinterpret_cast< IMAGE_NT_HEADERS * >( reinterpret_cast< BYTE * >( hModule ) + pDosHeader->e_lfanew );


		// We first have to check for the DLL flag, because it is possible that
		// both flags (DLL, EXE) are set:
		if ( pNtHeader->FileHeader.Characteristics & IMAGE_FILE_DLL )
			ModuleFlags |= fModuleIsDLL;
		
		else if ( pNtHeader->FileHeader.Characteristics & IMAGE_FILE_EXECUTABLE_IMAGE )
			ModuleFlags |= fModuleIsEXE;

		if ( pNtHeader->OptionalHeader.Subsystem == IMAGE_SUBSYSTEM_WINDOWS_GUI )
			ModuleFlags |= fModuleIsGUI;

		else if ( pNtHeader->OptionalHeader.Subsystem == IMAGE_SUBSYSTEM_WINDOWS_CUI )
			ModuleFlags |= fModuleIsCUI;
	}
	return ( ModuleFlags );
}


//=============================================================================
bool IsGUI( void )
//=============================================================================
{
	return (( GetModuleFlags() & fModuleIsGUI ) == fModuleIsGUI );
}



//=============================================================================
bool IsCUI( void )
//=============================================================================
{
	return (( GetModuleFlags() & fModuleIsCUI ) == fModuleIsCUI );
}



//=============================================================================
bool IsEXE( void )
//=============================================================================
{
	return (( GetModuleFlags() & fModuleIsEXE ) == fModuleIsEXE );
}



//=============================================================================
bool IsDLL( void )
//=============================================================================
{
	return (( GetModuleFlags() & fModuleIsDLL ) == fModuleIsDLL );
}




//=============================================================================
static BOOL SetSafeWindowLong( HWND hWnd, int Index, DWORD NewValue )
//=============================================================================
{
	SetLastError( 0 );
	
	return ( ::SetWindowLong( hWnd, Index, NewValue ) == 0 && GetLastError() == 0 );
}



//=============================================================================
static BOOL UpdateWindowFrame( CWnd *pWnd )
//=============================================================================
{
	return ( pWnd->SetWindowPos( NULL, 0, 0, 0, 0,
		SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED ));
}




//=============================================================================
BOOL SetWindowStyle( CWnd *pWnd, DWORD Style, BOOL Update )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	if ( !SetSafeWindowLong( pWnd->GetSafeHwnd(), GWL_STYLE, Style ))
		return ( FALSE );

	if ( Update && !UpdateWindowFrame( pWnd ))
		return ( FALSE );

	return ( TRUE );
}

//=============================================================================
BOOL SetWindowStyleEx( CWnd *pWnd, DWORD ExStyle, BOOL Update )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	if ( !SetSafeWindowLong( pWnd->GetSafeHwnd(), GWL_EXSTYLE, ExStyle ))
		return ( FALSE );

	if ( Update && !UpdateWindowFrame( pWnd ))
		return ( FALSE );

	return ( TRUE );
}



//=============================================================================
BOOL ResizeWindow( CWnd *pWnd, const CSize &NewSize, BOOL Update )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	UINT Flags = SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE;
	if ( !Update )
		Flags |= SWP_NOREDRAW;

	return ( pWnd->SetWindowPos( NULL, 0, 0, NewSize.cx, NewSize.cy, Flags ));
}



//=============================================================================
BOOL GrowWindow( CWnd *pWnd, const CSize &DeltaSize, BOOL Update )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	CRect CurrentSize;
	pWnd->GetWindowRect( CurrentSize );
	CurrentSize.right  += DeltaSize.cx;
	CurrentSize.bottom += DeltaSize.cy;

	return ( ResizeWindow( pWnd, CurrentSize.Size(), Update ));
} 


//=============================================================================
BOOL MoveWindow( CWnd *pWnd, const CPoint &NewPosition, BOOL Update )
//=============================================================================
{
	ASSERT_VALID( pWnd );
	
	UINT Flags = SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE;
	if ( !Update )
		Flags |= SWP_NOREDRAW;

	return ( pWnd->SetWindowPos( NULL, NewPosition.x, NewPosition.y, 0, 0, Flags ));
}



//=============================================================================
BOOL SlideWindow( CWnd *pWnd, const CPoint &DeltaPosition, BOOL Update )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	CRect CurrentPosition;
	pWnd->GetWindowRect( &CurrentPosition );
	CurrentPosition.top  += DeltaPosition.y;
	CurrentPosition.left += DeltaPosition.x;

	return ( MoveWindow( pWnd, CurrentPosition.TopLeft(), Update ));
}



//=============================================================================
BOOL UpdateWindowData( CWnd *pWnd, BOOL SaveAndValidate )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	BOOL IsUpdated = TRUE;

	if ( ::IsWindow( pWnd->m_hWnd ))
		IsUpdated = pWnd->UpdateData( SaveAndValidate );

	return ( IsUpdated );
}



//=============================================================================
BOOL EnableWindow( CWnd *pWnd, BOOL Enable )
//=============================================================================
{
	ASSERT_VALID( pWnd );

	BOOL IsEnabled = TRUE;

	if ( ::IsWindow( pWnd->m_hWnd ))
		IsEnabled = pWnd->EnableWindow( Enable );

	return ( IsEnabled );
}


//=============================================================================
CString GetProgramPath( void )
	throw ( CWinError )
//=============================================================================
{
	HINSTANCE hInstance = NULL; // AfxGetInstanceHandle(); Does not work for console applications!
	char_t Path[ MAX_PATH + 1 ] = TEXT( "" );
	DWORD PathLength = ::GetModuleFileName( hInstance, Path, countof( Path ));

	CheckWinApi( PathLength != 0 );
	return ( CString( Path, PathLength ));
}




//=============================================================================
CString GetUserFilePath( const char_t FileName[] )
	throw ( CWinError )
//=============================================================================
{
	CFilePath ProgramPath( GetProgramPath() );
	CString UserName( CUser().Name().c_str() );

	ProgramPath.ChangeName( UserName );

	return ( ProgramPath );
}




//=============================================================================
CString GetWorkingDirectory( void )
	throw ( CWinError )
//=============================================================================
{
	char_t Directory[ MAX_PATH + 1 ];
	DWORD DirectoryLength = ::GetCurrentDirectory( countof( Directory ), Directory );
	CheckWinApi( DirectoryLength != 0 );

	return ( CString( Directory, DirectoryLength ));
}



//=============================================================================
int GetWindowTitleLength( HWND hWnd )
	throw ( CWinError )
//=============================================================================
{
	SetLastError( 0 );
	int TitleLength = GetWindowTextLength( hWnd );
	CheckWinApi( TitleLength != 0 && GetLastError() == 0 );

	return ( TitleLength );
}




//=============================================================================
CString GetWindowTitle( HWND hWnd )
	throw ( CWinError )
//=============================================================================
{
	CString Title;
	int TitleLength = GetWindowTitleLength( hWnd );

	SetLastError( 0 );
	int ReturnedTitleLength = GetWindowText( hWnd, Title.GetBufferSetLength( TitleLength + 1 ), TitleLength + 1 );
	Title.ReleaseBuffer( ReturnedTitleLength );
	CheckWinApi( ReturnedTitleLength == TitleLength && GetLastError() == 0 );
	return ( Title );
}


//=============================================================================
CString XGetWorkingDirectory( void )
	throw ( CWinError )
//=============================================================================
{
	CString Directory;
	try {
		Directory = GetWorkingDirectory( );
	}
	catch ( CError &rError ) {
		rError << TEXT( "GetWorkingDirectory" ) << endl;
		throw;
	}
	return ( Directory );
}



//=============================================================================
void SetDesktopWallpaper( const char_t WallpaperName[] )
	throw ( CWinError )
//=============================================================================
{
	CComPtr< IActiveDesktop > pActiveDesktop;
	COMPONENTSOPT DesktopOptions = { sizeof( DesktopOptions ) };
	DesktopOptions.fActiveDesktop = FALSE;

	if ( IsComInitialized() ) {
		CheckHResult( pActiveDesktop.CoCreateInstance( CLSID_ActiveDesktop ));
		CheckHResult( pActiveDesktop->GetDesktopItemOptions( &DesktopOptions, 0 ));
	}
	if ( DesktopOptions.fActiveDesktop ) {
		CheckHResult( pActiveDesktop->SetWallpaper( text( WallpaperName ), 0 ));
		CheckHResult( pActiveDesktop->ApplyChanges( AD_APPLY_ALL ));
	} else {
		CheckWinApi( SystemParametersInfo( SPI_SETDESKWALLPAPER, 0,
			static_cast< PVOID >( const_cast< char_t * >( WallpaperName )), SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE ));
	}
}


//=============================================================================
void XSetDesktopWallpaper( const char_t WallpaperName[] )
	throw ( CWinError )
//=============================================================================
{
	try {
		SetDesktopWallpaper( WallpaperName );
	}
	catch ( CError &rError ) {
		rError << TEXT( "SetDesktopWallpaper" ) << WallpaperName << endl;
		throw;
	}
}


//=============================================================================
void QueryDraggedFiles( HDROP hDrop, CStringArray *pFileNames )
//=============================================================================
{
	CString FileName;
	UINT nFileCount, nFile, nFileNameLength;

	nFileCount = DragQueryFile( hDrop, -1, NULL, 0 );
	pFileNames->SetSize( nFileCount );
	for ( nFile = 0; nFile < nFileCount; ++nFile ) {
		nFileNameLength = DragQueryFile( hDrop, nFile, NULL, 0 ) + 1;
		nFileNameLength = DragQueryFile( hDrop, nFile, FileName.GetBuffer( nFileNameLength ), nFileNameLength );
		FileName.ReleaseBuffer( nFileNameLength );
		pFileNames->SetAt( nFile, FileName );
	}
	DragFinish( hDrop );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### COM - Helper
//###
//#############################################################################
//#############################################################################
//#############################################################################


static BOOL our_IsComInitialized = FALSE;

//=============================================================================
HRESULT InitializeCom( void )
	throw ( CWinError )
//=============================================================================
{
	HRESULT hResult = CheckHResult( CoInitialize( NULL ));
	our_IsComInitialized = TRUE;

	return ( hResult );
}



//=============================================================================
HRESULT UninitializeCom( void )
	throw ( CWinError )
//=============================================================================
{
	HRESULT hResult = S_OK;

	if ( our_IsComInitialized ) {
		CoUninitialize();
		our_IsComInitialized = FALSE;
	} else {
		throw ( CWinError( S_FALSE ));
	}
	return ( S_OK );
}



//=============================================================================
BOOL IsComInitialized( void )
//=============================================================================
{
	return ( our_IsComInitialized );
}



//#############################################################################
//#############################################################################
//#############################################################################
//###
//### KEY_MESSAGE_FLAGS
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
KEY_MESSAGE_FLAGS::KEY_MESSAGE_FLAGS( LPARAM lParam )
//=============================================================================
{
	*this = lParam;
}



//=============================================================================
LPARAM KEY_MESSAGE_FLAGS::operator = ( LPARAM lParam )
//=============================================================================
{
	COMPILER_ASSERT( sizeof( KEY_MESSAGE_FLAGS ) == sizeof( LPARAM ));

	memcpy( this, &lParam, sizeof( *this ));

	return ( lParam );
}



//=============================================================================
KEY_MESSAGE_FLAGS::operator LPARAM ( void ) const
//=============================================================================
{
	COMPILER_ASSERT( sizeof( LPARAM ) == sizeof( KEY_MESSAGE_FLAGS ));

	LPARAM lParam;
	memcpy( &lParam, this, sizeof( lParam ));

	return ( lParam );
}


} // namespace AidKit

