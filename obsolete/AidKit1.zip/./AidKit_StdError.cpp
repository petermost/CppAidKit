#include "AidKit_StdError.hpp"
#include "AidKit_StlMap.hpp"
#include "AidKit_Misc.hpp"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "AidKit_Warnings.hpp"

using namespace std;

#define ENTRY( Number ) { Number, TEXT( #Number ) }

namespace AidKit {

static uni_map< int, const char_t * >::entry our_ErrNoMapEntries[] = {
	ENTRY( 0 ),
	ENTRY( EPERM ),
	ENTRY( ENOENT ),
	ENTRY( ESRCH ),
	ENTRY( EINTR ),
	ENTRY( EIO ),
	ENTRY( ENXIO ),
	ENTRY( E2BIG ),
	ENTRY( ENOEXEC ),
	ENTRY( EBADF ),
	ENTRY( ECHILD ),
	ENTRY( EAGAIN ),
	ENTRY( ENOMEM ),
	ENTRY( EACCES ),
	ENTRY( EFAULT ),
	ENTRY( EBUSY ),
	ENTRY( EEXIST ),
	ENTRY( EXDEV ),
	ENTRY( ENODEV ),
	ENTRY( ENOTDIR ),
	ENTRY( EISDIR ),
	ENTRY( EINVAL ),
	ENTRY( ENFILE ),
	ENTRY( EMFILE ),
	ENTRY( ENOTTY ),
	ENTRY( EFBIG ),
	ENTRY( ENOSPC ),
	ENTRY( ESPIPE ),
	ENTRY( EROFS ),
	ENTRY( EMLINK ),
	ENTRY( EPIPE ),
	ENTRY( EDOM ),
	ENTRY( ERANGE ),
	ENTRY( EDEADLK ),
	ENTRY( ENAMETOOLONG ),
	ENTRY( ENOLCK ),
	ENTRY( ENOSYS ),
	ENTRY( ENOTEMPTY ),
	ENTRY( EILSEQ )
	#ifdef ECONNREFUSED
		,ENTRY( ECONNREFUSED )
	#endif
	#ifdef ECONNRESET
		,ENTRY( ECONNRESET )
	#endif
	#ifdef ENOTCONN
		,ENTRY( ENOTCONN )
	#endif
	#ifdef ETIMEDOUT
		,ENTRY( ETIMEDOUT )
	#endif
	#ifdef EINPROGRESS
		,ENTRY( EINPROGRESS )
	#endif
	#ifdef EADDRINUSE
		,ENTRY( EADDRINUSE )
	#endif
	#ifdef EHOSTUNREACH
		,ENTRY( EHOSTUNREACH )
	#endif
	#ifdef ENETUNREACH
		,ENTRY( ENETUNREACH )
	#endif
	#ifdef EADDRNOTAVAIL
		,ENTRY( EADDRNOTAVAIL )
	#endif
};

#undef ENTRY


static uni_map< int, const char_t * > our_ErrNoMap( our_ErrNoMapEntries, countof( our_ErrNoMapEntries ));

//=============================================================================
const string_t ErrNoString( int nError )
//=============================================================================
{
	try {
		const char_t *ErrNoString = our_ErrNoMap[ nError ];
		return ( string_t( ErrNoString ));
	}
	catch ( out_of_range & ) {
		char_t buffer[ 33 + 1 ];
		size_t length = s_print_f( buffer, TEXT( "%d" ), nError );
		return ( string_t( buffer, length ));
	}
}



/*
//=============================================================================
const string_t ErrNoDescription( int nError )
//=============================================================================
{
	string_t Description;

	if ( nError < sys_nerr )
		Description = text( sys_errlist[ nError ] );

	Description += string_t( TEXT( " (" )) + ErrNoString( nError ) + TEXT( ")" );

	return ( Description );
}
*/

//=============================================================================
const string_t ErrNoDescription( int nError )
//=============================================================================
{
	char_t Buffer[ 1024 ]; // All the glibc functions use 1024 as a buffer size for strerror_r.

	string_t Description = strerror_r( nError, Buffer, countof( Buffer ));
	Description += string_t( TEXT( " (" )) + ErrNoString( nError ) + TEXT( ")" );

	return ( Description );
}

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CStdError
//###
//#############################################################################
//#############################################################################
//#############################################################################




//=============================================================================
CStdError CStdError::LastError( void )
	throw()
//=============================================================================
{
	return CStdError( errno );
}



//=============================================================================
CStdError::CStdError( int nError, const string_t &Description )
	throw()
//=============================================================================
{
	my_Reason = nError;
	my_Description = Description;
}



//=============================================================================
CStdError::CStdError( const CStdError &OtherError )
	throw()
: CError( OtherError )
//=============================================================================
{
	my_Reason      = OtherError.my_Reason;
	my_Description = OtherError.my_Description;
}



//=============================================================================
CStdError &CStdError::operator = ( const CStdError &OtherError )
	throw()
//=============================================================================
{
	CError::operator = ( OtherError );

	my_Reason      = OtherError.my_Reason;
	my_Description = OtherError.my_Description;

	return ( *this );
}



//=============================================================================
CStdError::~CStdError( void )
	throw()
//=============================================================================
{
}



//=============================================================================
int CStdError::Reason( void ) const
	throw()
//=============================================================================
{
	return ( my_Reason );
}



//=============================================================================
const string_t &CStdError::Description( void ) const
	throw()
//=============================================================================
{
	if ( my_Description.empty() )
		my_Description = ErrNoDescription( my_Reason );

	return ( my_Description );
}


} // namespace AidKit
