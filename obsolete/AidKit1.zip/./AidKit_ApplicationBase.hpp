#ifndef AIDKIT_APPLICATION_BASE_HPP
#define AIDKIT_APPLICATION_BASE_HPP

#include "AidKit.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CApplicationBase {
	//-----------------------------------------------------------------------------
		public:
			virtual bool IsGUI( void ) const = 0;
			virtual bool IsCUI( void ) const = 0;
			virtual bool IsEXE( void ) const = 0;
			virtual bool IsDLL( void ) const = 0;

		protected:
			CApplicationBase( void );
			virtual ~CApplicationBase( void );

			virtual bool OnStartup( void );
			virtual bool OnShutdown( void );

		private:

	};

}

#endif
