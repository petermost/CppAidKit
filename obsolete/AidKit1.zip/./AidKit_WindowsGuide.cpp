#include "AidKit_WindowsGuide.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Warnings.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWindowsVisitor
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CWindowsVisitor::~CWindowsVisitor( void )
//=============================================================================
{
}




//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CWindowsGuide
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CWindowsGuide::CWindowsGuide( void )
//=============================================================================
{
	my_pVisitor = NULL;
	my_VisitorResult = false;
}



//=============================================================================
CWindowsGuide::~CWindowsGuide( void )
//=============================================================================
{
}



/* We want to use the Tour funktion like this:
if ( WindowsGuide.Tour( &WindowsFinder )) {
	// Tour was successful; Use gathered information from WindowsFinder.
}
*/
//=============================================================================
bool CWindowsGuide::Tour( CWindowsVisitor *pVisitor )
//=============================================================================
{
	bool Success;
	my_pVisitor = pVisitor;
	COMPILER_ASSERT( sizeof( LPARAM ) >= sizeof( this ));
	
	// Standart technique to determine wether EnumWindows really failed or the
	// EnumerateFunction just returned false:

	SetLastError( 0 );
	if ( !EnumWindows( &EnumerateFunction, reinterpret_cast< LPARAM >( this )))
		Success = ( GetLastError() == 0 );

	if ( Success )
		Success = my_VisitorResult;

	return ( Success );
}



//=============================================================================
bool CWindowsGuide::TourChilds( CWindowsVisitor *pVisitor, CWnd *pWnd )
//=============================================================================
{
	bool Success;
	my_pVisitor = pVisitor;
	COMPILER_ASSERT( sizeof( LPARAM ) >= sizeof( this ));

	// Standart technique to determine wether EnumWindows really failed or the
	// EnumerateFunction just returned false:

	SetLastError( 0 );
	if ( !EnumChildWindows( pWnd->GetSafeHwnd(), &EnumerateFunction, reinterpret_cast< LPARAM >( this )))
		Success = ( GetLastError() == 0 );

	if ( Success )
		Success = my_VisitorResult;

	return ( Success );
}



//=============================================================================
BOOL CALLBACK CWindowsGuide::EnumerateFunction( HWND hWnd, LPARAM lParam )
//=============================================================================
{
	CWindowsGuide *pGuide = reinterpret_cast< CWindowsGuide * >( lParam );
	CWnd *pWnd = CWnd::FromHandle( hWnd );
	bool ContinueTour = pGuide->my_pVisitor->VisitWindow( pWnd );

	// If the tour should not be continued, we assume that it was successful:

	pGuide->my_VisitorResult = !ContinueTour;

	return ( ContinueTour );
}

} // namespace AidKit
