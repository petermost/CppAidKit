#include "AidKit_DeferredFunction.hpp"

namespace AidKit {

//=============================================================================
CDeferredFunctionCommand::~CDeferredFunctionCommand( void )
//=============================================================================
{
}

} // namespace AidKit
