#ifndef AIDKIT_HEAP_TRACKED_HPP
#define AIDKIT_HEAP_TRACKED_HPP

#include "AidKit.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_ThreadLock.hpp"
#include "AidKit_Static.hpp"

#if defined( AIDKIT_MSC )
	#pragma warning( disable : 4786 ) // identifier was truncated to '255' characters in the browser information
#endif
#include <set>

namespace AidKit {

	class CThreadGuard;

	/*---------------------------------------------------------------------------*/
	class CHeapTracker {
	/*---------------------------------------------------------------------------*/
		public:
			static void *operator new( size_t MemorySize );
			static void operator delete( void *pMemoryAddress );
			
			#if defined( AIDKIT_MSC ) && defined( AIDKIT_DEBUG )
				// Overloaded new operator from crtdbg.h:

				static void *operator new( unsigned int Size,
					int BlockType, const char *FileName, int LineNumber );

				static void operator delete( void *,
					int BlockType, const char *FileName, int LineNumber );

				// Overloaded new operator from afx.h:

				static void *operator new( size_t Size,
					const char *FileName, int LineNumber );

				static void operator delete( void *,
					const char *FileName, int LineNumber );

			#endif

			CHeapTracker( void );
			virtual ~CHeapTracker();

			bool IsOnHeap() const;

		private:
			static void RememberMemory( const void *pMemory );
			static void ForgetMemory( const void *pMemory );

			static TStatic< TThreadResourceGuard< std::set< const void * > > > our_MemoryPointers;
	};

}
#endif
