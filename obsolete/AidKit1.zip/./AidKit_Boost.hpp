#ifndef AIDKIT_BOOST_HPP
#define AIDKIT_BOOST_HPP

#include <boost/regex.hpp>
#include "AidKit.hpp"

namespace AidKit {

	namespace Boost {

		#if defined( AIDKIT_UNICODE )
			typedef boost::wregex  regex_t;
			typedef boost::wcmatch cmatch_t;
			typedef boost::wsmatch smatch_t;
		#else
			typedef boost::regex  regex_t;
			typedef boost::cmatch cmatch_t;
			typedef boost::smatch smatch_t;
		#endif

	}
	
}

#endif
