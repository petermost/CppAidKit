#include "AidKit_SingletonManager.hpp"
#include <stdlib.h>
#include "AidKit_Warnings.hpp"

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CSingletonManager
//###
//#############################################################################
//#############################################################################
//#############################################################################

CSingletonManager *CSingletonManager::our_pInstance = NULL;

//=============================================================================
CSingletonManager *CSingletonManager::Instance( void )
//=============================================================================
{
	if ( our_pInstance == NULL ) {
		our_pInstance = new CSingletonManager;
		atexit( DestroyInstance );
	}
	return ( our_pInstance );
}



//=============================================================================
void CSingletonManager::DestroyInstance( void )
//=============================================================================
{
	delete our_pInstance;
	our_pInstance = NULL;
}



//=============================================================================
CSingletonManager::CSingletonManager( void )
//=============================================================================
{
}




//=============================================================================
CSingletonManager::~CSingletonManager( void )
//=============================================================================
{
	DestroySingletons();
}



//=============================================================================
bool CSingletonManager::RegisterSingleton( void ( *Destroy )( void ))
//=============================================================================
{
	my_DestroyFunctions.push_back( Destroy );

	return ( true );
}



//=============================================================================
bool CSingletonManager::UnregisterSingleton( void ( *Destroy )( void ))
//=============================================================================
{
	my_DestroyFunctions.remove( Destroy );

	return ( true );
}	




//=============================================================================
unsigned CSingletonManager::DestroySingletons( void )
//=============================================================================
{
	CDestroyFunctionList::size_type OldSize;
	void ( *pDestroySingleton )( void );
	
	do {
		if (( OldSize = my_DestroyFunctions.size()) > 0 ) {
			pDestroySingleton = my_DestroyFunctions.back();
			pDestroySingleton();
		}
	} while ( OldSize > my_DestroyFunctions.size() );

	return ( my_DestroyFunctions.size() );
}

} // namespace AidKit
