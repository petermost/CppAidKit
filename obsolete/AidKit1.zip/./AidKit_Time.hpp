#ifndef AIDKIT_TIME_HPP
#define AIDKIT_TIME_HPP

#include "AidKit.hpp"
#include "AidKit_Unicode.hpp"
#include <time.h>
#include <limits.h>

struct timeval;
struct tm;

namespace AidKit {

	// Time functions/definitions:

	typedef unsigned long milliseconds_t;

	const milliseconds_t INFINITE_MILLISECONDS = ULONG_MAX;

	timeval *ConvertMilliseconds( milliseconds_t Milliseconds, timeval *pTimeVal )
		throw ();

	milliseconds_t ConvertTime( const timeval *pTimeVal, milliseconds_t *pMilliseconds )
		throw ();

	// ISO date time functions:

	extern const string_t ISO_DATE_FORMAT;
	extern const string_t ISO_TIME_FORMAT;

	enum ESecondsFraction {
		eFraction_None,
		eFraction_Milliseconds,
		eFraction_Microseconds
	};

	struct DateTime : public tm {
		unsigned long usec; // Microseconds
	};

	DateTime CurrentDateTime( void );
	string_t FormatDateTime( const string_t &Format, const DateTime & );

	string_t ISODate( const DateTime & );
	string_t ISODate( void );

	string_t ISOTime( const DateTime &currentDateTime, ESecondsFraction Fraction, bool WithTimezone );
	string_t ISOTime( ESecondsFraction Fraction = eFraction_Milliseconds, bool WithTimezone = true );

	string_t ISODateTime( ESecondsFraction Fraction = eFraction_Milliseconds, bool WithTimezone = true );
}

#if defined( AIDKIT_WINDOWS )
	#include "Windows\AidKit_Windows_Time.hpp"
#elif defined( AIDKIT_UNIX )
	#include "Unix/AidKit_Unix_Time.hpp"
#endif

#endif
