#ifndef AIDKIT_WND_HOOK_HPP
#define AIDKIT_WND_HOOK_HPP

#include "AidKit.hpp"
#include <afxtempl.h> // CTypedPtrMap;
#include "AidKit_Event.hpp"

class CWnd;

namespace AidKit {

	//-----------------------------------------------------------------------------
	class CWndHook {
	//-----------------------------------------------------------------------------
		public:
			CWndHook( void );
			virtual ~CWndHook( void );

			BOOL InstallHook( CWnd *pWnd );
				// Installs a hook (or subclasses) for the given window.

			BOOL UninstallHook( CWnd *pWnd );
				// Uninstalls a hook from the given window.

			TEvent4< CWnd *, UINT, WPARAM, LPARAM > MessageEvt;

			static CWndHook *FindHook( CWnd *pWnd );
			static BOOL IsHooked( CWnd *pWnd );

		private:
			CWndHook( const CWndHook & );
			CWndHook &operator = ( const CWndHook & );

			static LRESULT CALLBACK WndHookProc(HWND, UINT, WPARAM, LPARAM);
			static CTypedPtrMap< CMapPtrToPtr, CWnd *, CWndHook * > our_WndHookMap;

			CWnd *my_pHookedWnd;
			WNDPROC my_pOldWndProc;
	};

}

#endif
