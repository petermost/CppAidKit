#include "AidKit_Asn1.hpp"
#include <stdio.h>
#include <stdarg.h>

#include "AidKit_File.hpp"
#include "AidKit_Misc.hpp"
#include "AidKit_Debug.hpp"
#include "AidKit_Memory.hpp"
#include "AidKit_Memory.hpp"
#include "AidKit_StlMap.hpp"

using namespace std;

namespace AidKit {

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### SAsn1Size
//###
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
SAsn1Size &SAsn1Size::operator += ( const SAsn1Size &Other )
//=============================================================================
{
	nHead += Other.nHead;
	nBody += Other.nBody;
	nTail += Other.nTail;

	return ( *this );
}


//=============================================================================
SAsn1Size &SAsn1Size::operator -= ( const SAsn1Size &Other )
//=============================================================================
{
	nHead -= Other.nHead;
	nBody -= Other.nBody;
	nTail -= Other.nTail;

	return ( *this );
}




//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsn1Visitor
//###
//#############################################################################
//#############################################################################
//#############################################################################



//=============================================================================
CAsn1Visitor::~CAsn1Visitor( void )
//=============================================================================
	{ }



//=============================================================================
void CAsn1Visitor::EnterStream( const CAsn1Stream * )
//=============================================================================
	{ }



//=============================================================================
void CAsn1Visitor::LeaveStream( const CAsn1Stream * )
//=============================================================================
	{ }



//=============================================================================
void CAsn1Visitor::VisitItem( const CAsn1Item * )
//=============================================================================
	{ }





//#############################################################################
//#############################################################################
//#############################################################################
//###
//### SAsn1CodingInfo
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
SAsn1CodingInfo::SAsn1CodingInfo( void )
//=============================================================================
{
	nIdentifierOctet = 0;
	eTagCoding       = eCodingUndefined;
	nLengthOctet     = 0;
	eLengthCoding    = eCodingUndefined;
}

//=============================================================================
const char_t *SAsn1CodingInfo::CodingAsString( ECoding eCoding )
//=============================================================================
{
	typedef AidKit::uni_map< SAsn1CodingInfo::ECoding, const char_t * > CMap;

	static CMap::entry s_MapEntries[] = {
		{ SAsn1CodingInfo::eCodingUndefined,  TEXT( "---" )        },
		{ SAsn1CodingInfo::eCodingShort,      TEXT( "Short" )      },
		{ SAsn1CodingInfo::eCodingLong,       TEXT( "Long" )       },
		{ SAsn1CodingInfo::eCodingIndefinite, TEXT( "Indefinite" ) }
	};
	static CMap s_Map( s_MapEntries, countof( s_MapEntries ));

	return ( s_Map[ eCoding ] );
}


//=============================================================================
char_t SAsn1CodingInfo::CodingAsCharacter( ECoding eCoding )
//=============================================================================
{
	return ( *CodingAsString( eCoding ));
}





//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsn1Header
//###
//#############################################################################
//#############################################################################
//#############################################################################

const UINT8 fClassUniversal   = BIN8( 0,0,0,0,0,0,0,0 );
const UINT8 fClassContext     = BIN8( 1,0,0,0,0,0,0,0 );
const UINT8 fClassApplication = BIN8( 0,1,0,0,0,0,0,0 );
const UINT8 fClassPrivate     = BIN8( 1,1,0,0,0,0,0,0 );

const UINT8 fFormPrimitive    = BIN8( 0,0,0,0,0,0,0,0 );
const UINT8 fFormConstructed  = BIN8( 0,0,1,0,0,0,0,0 );

const UINT8 fMoreData = BIN8( 1,0,0,0,0,0,0,0 );


//=============================================================================
CAsn1Header::CAsn1Header( EClass eClass, EForm eForm, UINT32 nTag )
//=============================================================================
{
	my_eClass  = eClass;
	my_eForm   = eForm;
	my_nTag    = nTag;
	my_nLength = 0;
}


//=============================================================================
CAsn1Header::~CAsn1Header( void )
//=============================================================================
{
}



//=============================================================================
const char_t *CAsn1Header::ClassAsString( EClass eClass )
//=============================================================================
{
	// Map definitions for translation of EClass to String:

	typedef AidKit::uni_map< CAsn1Item::EClass, const char_t * > CMap;

	static CMap::entry s_MapEntries[] = {
		{ CAsn1Item::eClassUndefined,   TEXT( "---" )     },
		{ CAsn1Item::eClassUniversal,   TEXT( "Universal" )   },
		{ CAsn1Item::eClassApplication, TEXT( "Application" ) },
		{ CAsn1Item::eClassContext,     TEXT( "Context" )     },
		{ CAsn1Item::eClassPrivate,     TEXT( "Private" )     }
	};
	static CMap s_Map( s_MapEntries, countof( s_MapEntries ));

	return ( s_Map[ eClass ] );
}


//=============================================================================
char_t CAsn1Header::ClassAsCharacter( EClass eClass )
//=============================================================================
{
	return ( *ClassAsString( eClass ));
}



//=============================================================================
const char_t *CAsn1Header::FormAsString( EForm eForm )
//=============================================================================
{
	// Map definitions for translation of EForm to String:

	typedef AidKit::uni_map< CAsn1Item::EForm, const char_t * > CMap;

	static CMap::entry s_MapEntries[] = {
		{ CAsn1Item::eFormUndefined,   TEXT( "---" )     },
		{ CAsn1Item::eFormPrimitive,   TEXT( "Primitive" )   },
		{ CAsn1Item::eFormConstructed, TEXT( "Constructed" ) }
	};
	static CMap s_Map( s_MapEntries, countof( s_MapEntries ));

	return ( s_Map[ eForm ] );
}



//=============================================================================
char_t CAsn1Header::FormAsCharacter( EForm eForm )
//=============================================================================
{
	return ( *FormAsString( eForm ));
}


//=============================================================================
SAsn1Size CAsn1Header::Read( const void *pMemory, size_t nMemorySize )
	throw ( CAsn1Error )
//=============================================================================
{
	UINT8 Octet;
	SAsn1Size Size;

	// Read identifier octet (contains class, form and tag bits):

	Size.nHead += memory_read( &pMemory, &nMemorySize, &Octet );
	my_CodingInfo.nIdentifierOctet = Octet;

	// Decode class bits:

	if (( Octet & fClassApplication ) == fClassApplication )
		my_eClass = eClassApplication;

	else if (( Octet & fClassContext ) == fClassContext )
		my_eClass = eClassContext;

	else if (( Octet & fClassPrivate ) == fClassPrivate )
		my_eClass = eClassPrivate;

	else
		my_eClass = eClassUniversal;

	// Decode form bit:

	if (( Octet & fFormConstructed ) == fFormConstructed )
		my_eForm = eFormConstructed;
	else
		my_eForm = eFormPrimitive;

	// Decode tag bits:

	my_nTag = Octet & BIN8( 0,0,0,1,1,1,1,1 );
	my_CodingInfo.eTagCoding = SAsn1CodingInfo::eCodingShort;

	if ( my_nTag == BIN8( 0,0,0,1,1,1,1,1 )) {
		// The following octets represent tag number:		
		// Bits 7 to 1 are concatenated for the binary representation of the tag number:
		my_CodingInfo.eTagCoding = SAsn1CodingInfo::eCodingLong;
		my_nTag = 0;
		do {
			Size.nHead += memory_read( &pMemory, &nMemorySize, &Octet );
			
			// Concatenate the <tag>-octets and erase the more data bit:

			my_nTag = ( my_nTag << 7 ) | ( Octet & ~fMoreData );
		} while (( Octet & fMoreData ) == fMoreData  );
	}

	// Decode the length bits:

	Size.nHead += memory_read( &pMemory, &nMemorySize, &Octet );
	my_CodingInfo.nLengthOctet = Octet;

	if ( Octet < BIN8( 1,0,0,0,0,0,0,0 )) {

		// Short form:
		// The octet value is the value for the length.

		my_CodingInfo.eLengthCoding = SAsn1CodingInfo::eCodingShort;
		my_nLength = Octet;
	} else if ( Octet > BIN8( 1,0,0,0,0,0,0,0 )) {
		
		// Long form:
		// Bits 1 to 7 are indicating how many octets must be read. They are
		// concatenated for the binary representation of the length:

		my_CodingInfo.eLengthCoding = SAsn1CodingInfo::eCodingLong;
		my_nLength = 0;
		UINT8 LengthCount = Octet & BIN8( 0,1,1,1,1,1,1,1 );
		
		if ( LengthCount <= sizeof( my_nLength )) {
			while ( LengthCount-- > 0 ) {
				Size.nHead += memory_read( &pMemory, &nMemorySize, &Octet );
				my_nLength = my_nLength << 8 | Octet;
			}
		} else {
			my_CodingInfo.eLengthCoding = SAsn1CodingInfo::eCodingUndefined;
			throw CAsn1LengthError( LengthCount );
		}
	} else if ( Octet == BIN8( 1,0,0,0,0,0,0,0 )) {
		// Indefinite form:
		// If two octets are zero, then the end of the content has been reached:

		my_CodingInfo.eLengthCoding = SAsn1CodingInfo::eCodingIndefinite;
		my_nLength = 0;
		while ( nMemorySize >= 1 ) {
			if ( *( static_cast< const UINT8 * >( pMemory ) + 0 ) == 0
				&& *( static_cast< const UINT8 * >( pMemory ) + 1 ) == 0 ) {
					Size.nTail += 2;
					break;
			}
			if ( my_eForm == eFormConstructed ) {
				CAsn1Header Header;
				SAsn1Size HeaderSize = Header.Read( pMemory, nMemorySize );

				if ( HeaderSize <= nMemorySize ) {
					nMemorySize -= HeaderSize;
					pMemory = static_cast< const UINT8 * >( pMemory ) + HeaderSize;
					my_nLength += HeaderSize;
				} else
					throw CAsn1LengthError( HeaderSize );
			} else {
				++my_nLength;
				pMemory = static_cast< const UINT8 * >( pMemory ) + 1;
				--nMemorySize;
			}
		}
	}
	Size.nBody = my_nLength;
	return ( Size );
}



//=============================================================================
SAsn1Size CAsn1Header::Write( void *pMemory, size_t nMemorySize ) const
//=============================================================================
{
	UINT8 Octet;
	SAsn1Size Size;
	
	Octet = 0;

	// Encode class bits:

	switch ( Class() ) {
		case eClassUniversal:
			Octet = fClassUniversal;

		case eClassApplication:
			Octet = fClassApplication;
			break;
		
		case eClassContext:
			Octet = fClassContext;
			break;

		case eClassPrivate:
			Octet = fClassPrivate;
			break;

		case eClassUndefined:
		default:
			AIDKIT_ASSERT( my_eClass != eClassUndefined );
			break;
	}

	// Encode form bit:

	switch ( Form() ) {
		case eFormConstructed:
			Octet |= fFormConstructed;
			break;

		case eFormPrimitive:
			Octet |= fFormPrimitive;
			break;

		case eFormUndefined:
		default:
			AIDKIT_ASSERT( my_eForm != eFormUndefined );
			break;
	}

	// Encode tag bits:

	if ( Tag() < BIN8( 0,0,0,1,1,1,1,1 )) {
		
		// Short form:

		Octet |= Tag();
		Size.nHead += memory_write( &pMemory, &nMemorySize, Octet );

		my_CodingInfo.nIdentifierOctet = Octet;
		my_CodingInfo.eTagCoding = SAsn1CodingInfo::eCodingShort;
	} else {
		
		// Long form:

		Octet |= BIN8( 0,0,0,1,1,1,1,1 );
		Size.nHead += memory_write( &pMemory, &nMemorySize, Octet );

		my_CodingInfo.nIdentifierOctet = Octet;
		my_CodingInfo.eTagCoding = SAsn1CodingInfo::eCodingLong;
		AIDKIT_ASSERT( false ); // The encoding of the actual tag is missing!
	}

	// Encode the length bits:

	if ( Length() < BIN8( 1,0,0,0,0,0,0,0 )) {
		
		// Short form:
		// The octet value is the value for the length.

		Octet = Length();
		Size.nHead += memory_write( &pMemory, &nMemorySize, Octet );

		my_CodingInfo.nLengthOctet = Octet;
		my_CodingInfo.eLengthCoding = SAsn1CodingInfo::eCodingShort;
	} else {
		AIDKIT_ASSERT( false ); // Other encodings are missing!
	}
	return ( Size );
}




//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsn1Item
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CAsn1Item::CAsn1Item( EClass eClass, UINT32 nTag )
: CAsn1Header( eClass, eFormPrimitive, nTag )
//=============================================================================
{
	my_pOwner = NULL;
}



//=============================================================================
CAsn1Item::CAsn1Item( EClass eClass, EForm eForm, UINT32 nTag )
: CAsn1Header( eClass, eForm, nTag )
//=============================================================================
{
	my_pOwner = NULL;
}



//=============================================================================
CAsn1Item::~CAsn1Item( void )
//=============================================================================
{
}



//=============================================================================
size_t CAsn1Item::ReadContent( const void *pMemory, size_t nMemorySize )
//=============================================================================
{
	my_Content.clear();
	my_Content.reserve( nMemorySize );

	size_t nMemoryLength = 0;
	while ( nMemorySize > 0 ) {
		UINT8 Octet;
		memory_read( &pMemory, &nMemorySize, &Octet );
		my_Content.push_back( Octet );
		++nMemoryLength;
	}
	return ( nMemoryLength );
}



//=============================================================================
SAsn1Size CAsn1Item::Read( const void *pMemory, size_t nMemorySize, CAsn1Creator * )
	throw ( CAsn1Error, assertion_error )
//=============================================================================
{
	const SAsn1Size HeaderSize = CAsn1Header::Read( pMemory, nMemorySize );

	if ( HeaderSize > 0 ) {

		// Skip over the header:

		pMemory = static_cast< const UINT8 * >( pMemory ) + HeaderSize.nHead;
		nMemorySize -= HeaderSize.nHead;

		// Read the content:

		AIDKIT_ASSERT( HeaderSize.nBody == Length() );
		ReadContent( pMemory, Length() );
	}
	return ( HeaderSize );
}


//=============================================================================
SAsn1Size CAsn1Item::Write( void *pMemory, size_t nMemorySize ) const
//=============================================================================
{
	const SAsn1Size HeaderSize = CAsn1Header::Write( pMemory, nMemorySize );

	// Skip over the header:

	pMemory = static_cast< UINT8 * >( pMemory ) + HeaderSize.nHead;
	nMemorySize -= HeaderSize.nHead;

	// Write the content:

	AIDKIT_ASSERT( HeaderSize.nBody == Length() );
	for ( UINT32 i = 0; i < Length(); ++i ) {
		memory_write( &pMemory, &nMemorySize, ContentAt( i ));
	}
	return ( HeaderSize );
}



//=============================================================================
CAsn1Item &CAsn1Item::operator = ( const char_t Value[] )
//=============================================================================
{
	ReadContent( Value, str_len( Value ));
	return ( *this );
}



//=============================================================================
CAsn1Item &CAsn1Item::operator = ( int Value )
//=============================================================================
{
	ReadContent( &Value, sizeof( Value ));
	return ( *this );
}




//=============================================================================
void CAsn1Item::AcceptVisitor( CAsn1Visitor *pVisitor ) const
//=============================================================================
{
	pVisitor->VisitItem( this );
}



		

//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsn1Stream
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CAsn1Stream::CAsn1Stream( EClass eClass, UINT32 nTag )
	: CAsn1Item( eClass, eFormConstructed, nTag )
//=============================================================================
{
}



//=============================================================================
CAsn1Stream::CAsn1Stream( EClass eClass, EForm eForm, UINT32 nTag )
	: CAsn1Item( eClass, eForm, nTag )
//=============================================================================
{
}



//=============================================================================
CAsn1Stream::~CAsn1Stream( void )
//=============================================================================
{
	EraseItems();
}



//=============================================================================
void CAsn1Stream::EraseItems( void )
//=============================================================================
{
	vector< CAsn1Item * >::iterator pItem;

	for ( pItem = my_Items.begin(); pItem != my_Items.end(); ++pItem )
		delete *pItem;
}


//=============================================================================
SAsn1Size CAsn1Stream::ReadItems( const void *pMemory, size_t nMemorySize, CAsn1Creator *pCreator )
	throw ( CAsn1Error )
//=============================================================================
{
	SAsn1Size ItemSize;
	SAsn1Size StreamSize;
	
	CAsn1Item *pItem;
	CAsn1Header Header;

	while ( nMemorySize > 0 && Header.Read( pMemory, nMemorySize ) > 0 ) {
		if ( Header.Form() == CAsn1Item::eFormConstructed )
			pItem = pCreator->MakeNewStream( Header );
		else
			pItem = pCreator->MakeNewItem( Header );

		
		try {
			ItemSize = pItem->Read( pMemory, nMemorySize, pCreator );
		} catch ( CAsn1Error & ) {
			delete pItem;
			throw;
		}
		pItem->my_pOwner = this;
		my_Items.push_back( pItem );

		pMemory = static_cast< const UINT8 * >( pMemory ) + ItemSize;
		nMemorySize -= ItemSize;

		StreamSize.nBody += ItemSize;
	}
	return ( StreamSize );
}


		
//=============================================================================
SAsn1Size CAsn1Stream::Read( const void *pMemory, size_t nMemorySize, CAsn1Creator *pCreator )
	throw ( CAsn1Error )
//=============================================================================
{
	SAsn1Size StreamSize;

	if (( StreamSize = CAsn1Item::Read( pMemory, nMemorySize, pCreator )) > 0 ) {
		ReadItems( Content(), ContentLength(), pCreator );
	}
	return ( StreamSize );
}



//=============================================================================
SAsn1Size CAsn1Stream::Write( void *pMemory, size_t nMemorySize ) const
//=============================================================================
{
	return ( CAsn1Item::Write( pMemory, nMemorySize ));
}




//=============================================================================
void CAsn1Stream::AcceptVisitor( CAsn1Visitor *pVisitor ) const
//=============================================================================
{
	size_t nItem;
	const CAsn1Item *pItem;

	pVisitor->EnterStream( this );
	for ( nItem = 0; nItem < ItemCount(); ++nItem ) {
		pItem = ItemAt( nItem );
		pItem->AcceptVisitor( pVisitor );
	}
	pVisitor->LeaveStream( this );
}





//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsn1Creator
//###
//#############################################################################
//#############################################################################
//#############################################################################


//=============================================================================
CAsn1Creator::~CAsn1Creator( void )
//=============================================================================
{
}


//=============================================================================
CAsn1Item *CAsn1Creator::MakeNewItem( const CAsn1Header & )
//=============================================================================
{
	return ( new CAsn1Item );
}



//=============================================================================
CAsn1Stream *CAsn1Creator::MakeNewStream( const CAsn1Header & )
//=============================================================================
{
	return ( new CAsn1Stream );
}




//#############################################################################
//#############################################################################
//#############################################################################
//###
//### CAsn1Reader
//###
//#############################################################################
//#############################################################################
//#############################################################################

//=============================================================================
void CAsn1Reader::FreeAsn1Items( vector< CAsn1Item * > *pItems )
//=============================================================================
{
	for ( vector< CAsn1Item * >::iterator itItem = pItems->begin(); itItem != pItems->end(); ++itItem ) {
		delete *itItem;
	}
	pItems->clear();
}



//=============================================================================
CAsn1Reader::CAsn1Reader( CAsn1Creator *pCreator )
//=============================================================================
{
	my_pCreator = ( pCreator != NULL ) ? pCreator : &my_DefaultCreator;
}



//=============================================================================
CAsn1Reader::~CAsn1Reader( void )
//=============================================================================
{
}


//=============================================================================
SAsn1Size CAsn1Reader::ReadItemsFromMemory( const void *pMemory, size_t nMemorySize, CAsn1Stream *pStream )
	throw ( CAsn1Error )
//=============================================================================
{
	return ( pStream->ReadItems( pMemory, nMemorySize, my_pCreator ));
}



//=============================================================================
SAsn1Size CAsn1Reader::ReadStreamFromMemory( const void *pMemory, size_t nMemorySize, CAsn1Stream *pStream )
	throw ( CAsn1Error )
//=============================================================================
{
	return ( pStream->Read( pMemory, nMemorySize, my_pCreator ));
}



//=============================================================================
SAsn1Size CAsn1Reader::ReadFromMemory( const void *pMemory, size_t nMemorySize,
	vector< CAsn1Item * > *pItems )
		throw ( CAsn1Error )
//=============================================================================
{
	SAsn1Size HeaderSize, StreamSize, CompleteStreamSize;
	CAsn1Header Header;
	CAsn1Item *pItem;

	while ( nMemorySize > 0 && ( HeaderSize =  Header.Read( pMemory, nMemorySize )) > 0 ) {
		if ( Header.Form() == CAsn1Header::eFormConstructed ) {
			pItem = my_pCreator->MakeNewStream( Header );
		} else {
			pItem = my_pCreator->MakeNewItem( Header );
		}
		StreamSize = pItem->Read( pMemory, nMemorySize, my_pCreator );
		pItems->push_back( pItem );

		CompleteStreamSize += StreamSize;

		pMemory = static_cast< const UINT8 * >( pMemory ) + StreamSize;
		nMemorySize -= StreamSize;
	}
	return ( CompleteStreamSize );
}



//=============================================================================
SAsn1Size CAsn1Reader::ReadFromFile( const string_t &Asn1FileName, vector< CAsn1Item * > *pItems,
	MemoryReadFunction pReadFromMemory )
		throw ( CAsn1Error )
//=============================================================================
{
	size_t nFileSize;
	SAsn1Size StreamSize;

	try {
		CStdFile InputFile( Asn1FileName, TEXT( "rb" ));
		
		// Read the ASN1 data into a buffer:
		nFileSize = FileSize( &InputFile );
		memory< UINT8 > FileBuffer( nFileSize );
		InputFile.Read( FileBuffer, 1, nFileSize );
		InputFile.Close();

		// Read the ASN1 stream from the buffer:
		if ( pReadFromMemory == 0 )
			pReadFromMemory = &CAsn1Reader::ReadFromMemory;

		StreamSize = ( this->*pReadFromMemory )( FileBuffer, nFileSize, pItems );
	}
	catch ( CStdFileError & ) {
		throw CAsn1FileError( Asn1FileName );
	}
	return ( StreamSize );
}


} // namespace AidKit



/*
//=============================================================================
void CAsn1Reader::pReadFromMemory( const void *pMemory, size_t nMemorySize, CAsn1Stream *pStream )
//=============================================================================
{
	size_t nLength;
	CAsn1Header Header;
	CAsn1Item *pNewItem;
	CAsn1Stream *pNewStream;
	
	while ( nMemorySize > 0 && Header.Read( pMemory, nMemorySize ) > 0 ) {
		if ( Header.Form() == CAsn1Header::eFormPrimitive ) {
			pNewItem = DoCreateNewAsn1Item();
			nLength = pNewItem->Read( pMemory, nMemorySize );
			pStream->AddItem( pNewItem );
		}
		else if ( Header.Form() == CAsn1Header::eFormConstructed ) {
			pNewStream = DoCreateNewAsn1Stream();
			nLength = pNewStream->Read( pMemory, nMemorySize );
			pStream->AddItem( pNewStream );
			pReadFromMemory( pNewStream->Content(), pNewStream->Length(), pNewStream );
		}
		pMemory     = static_cast< const UINT8 * >( pMemory ) + nLength;
		nMemorySize = nMemorySize - nLength;
	}
}
*/


