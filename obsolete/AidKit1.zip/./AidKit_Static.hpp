#ifndef AIDKIT_STATIC_HPP
#define AIDKIT_STATIC_HPP

#include "AidKit.hpp"
#include "AidKit_Memory.hpp"

namespace AidKit {

	//-----------------------------------------------------------------------------
	union UAllignment {
	//-----------------------------------------------------------------------------
		char c;
		signed char sc;
		unsigned char uc;

		int  i;
		signed int si;
		unsigned int ui;

		short s;
		signed short ss;
		unsigned short us;

		long l;
		signed long sl;
		unsigned long ul;

		float f;
		double d;
		long double ld;

		void *vp;
		void ( *vpf )( void );

		void ( UAllignment::*pm )( void );
	};

	template < typename CClass >
		//-----------------------------------------------------------------------------
		class TStatic {
		//-----------------------------------------------------------------------------
			public:
				TStatic( void )
				{
					if ( my_pInstance == NULL )
						my_pInstance = new( &my_Instance, sizeof( my_Instance )) CClass;
				}

				~TStatic( void )
				{
					my_pInstance->CClass::~CClass();
				}

				CClass *Pointer( void )
				{
					new( this ) TStatic;
					return ( my_pInstance );
				}

				CClass &Reference( void )
				{
					new( this ) TStatic;
					return ( *my_pInstance );
				}

				CClass *operator & ( void )
					{ return ( Pointer() ); }
					
				CClass *operator -> ( void )
					{ return ( Pointer() ); }

				CClass &operator * ( void )
					{ return ( Reference() ); }

				operator const CClass & ( void ) const
					{ return ( Reference() ); }
								
			private:
				CClass *my_pInstance;
				union {
					UAllignment Allignment;
					char Buffer[ sizeof( CClass ) ];
				} my_Instance;
		};
}
#endif
